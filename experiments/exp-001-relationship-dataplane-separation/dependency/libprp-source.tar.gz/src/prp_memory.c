#include "prp_memory.h"

#include <stdint.h>

void prp_secure_zero(void *memory, size_t length)
{
    volatile uint8_t *cursor = memory;

    while (cursor != NULL && length-- != 0U)
        *cursor++ = 0U;
}

int prp_constant_time_equal(
    const void *left, const void *right, size_t length)
{
    const uint8_t *first = left;
    const uint8_t *second = right;
    uint8_t difference = 0U;
    size_t index;

    if (length == 0U)
        return 1;
    if (first == NULL || second == NULL)
        return 0;
    for (index = 0U; index < length; index++)
        difference |= first[index] ^ second[index];
    return difference == 0U;
}
