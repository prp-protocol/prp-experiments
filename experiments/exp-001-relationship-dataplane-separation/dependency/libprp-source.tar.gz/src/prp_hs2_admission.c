#include "prp_hs2_admission.h"

#include "prp_crypto_backend.h"
#include "prp_hash.h"

#include <string.h>

#if defined(__wasm__)
#define PRP_HS2_EXPORT(name) __attribute__((export_name(name)))
#else
#define PRP_HS2_EXPORT(name)
#endif

static const uint8_t offer_magic[] = "PRPO";
static const uint8_t challenge_magic[] = "PRPC";
static const uint8_t proof_magic[] = "PRPP";
static const uint8_t work_domain[] = "PRP-HS2-ADMISSION-POW-v1";

static void put_u16(uint8_t *out, uint16_t value)
{
    out[0] = (uint8_t)(value >> 8);
    out[1] = (uint8_t)value;
}

static void put_u32(uint8_t *out, uint32_t value)
{
    out[0] = (uint8_t)(value >> 24);
    out[1] = (uint8_t)(value >> 16);
    out[2] = (uint8_t)(value >> 8);
    out[3] = (uint8_t)value;
}

static void put_u64(uint8_t *out, uint64_t value)
{
    unsigned int index;
    for (index = 0u; index < 8u; index++)
        out[index] = (uint8_t)(value >> (56u - index * 8u));
}

static uint16_t get_u16(const uint8_t *data)
{
    return (uint16_t)(((uint16_t)data[0] << 8) | data[1]);
}

static uint32_t get_u32(const uint8_t *data)
{
    return ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) | data[3];
}

static uint64_t get_u64(const uint8_t *data)
{
    uint64_t value = 0u;
    unsigned int index;
    for (index = 0u; index < 8u; index++)
        value = (value << 8) | data[index];
    return value;
}

static int bytes_nonzero(const uint8_t *data, size_t data_len)
{
    uint8_t value = 0u;
    size_t index;
    for (index = 0u; index < data_len; index++)
        value |= data[index];
    return value != 0u;
}

static int bytes_equal(const uint8_t *left, const uint8_t *right,
    size_t data_len)
{
    uint8_t difference = 0u;
    size_t index;
    for (index = 0u; index < data_len; index++)
        difference |= (uint8_t)(left[index] ^ right[index]);
    return difference == 0u;
}

PRP_HS2_EXPORT("prp_hs2_admission_suite_work_primitive")
int prp_hs2_admission_suite_work_primitive(uint16_t suite,
    uint8_t *work_primitive)
{
    if (work_primitive == NULL)
        return -1;
    switch (suite) {
    case PRP_HS2_ADMISSION_SESSION_NONE_BLAKE3:
    case PRP_HS2_ADMISSION_SESSION_X25519_CHACHA20POLY1305_BLAKE3:
    case PRP_HS2_ADMISSION_SESSION_X25519_AES256GCM_BLAKE3:
    case PRP_HS2_ADMISSION_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3:
    case PRP_HS2_ADMISSION_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3:
        *work_primitive = PRP_HS2_ADMISSION_WORK_BLAKE3;
        return 0;
    case PRP_HS2_ADMISSION_SESSION_NONE_SHA256:
        *work_primitive = PRP_HS2_ADMISSION_WORK_SHA256;
        return 0;
    default:
        return -1;
    }
}

static int suite_hash(uint16_t suite, const uint8_t *data, size_t data_len,
    uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    uint8_t primitive;
    int result;

    if (data == NULL || data_len == 0u || digest == NULL ||
            prp_hs2_admission_suite_work_primitive(
                suite, &primitive) != 0)
        return -1;
    if (primitive == PRP_HS2_ADMISSION_WORK_BLAKE3)
        return prp_hash_blake3(data, data_len, digest);
    result = prp_crypto_hash_sha2_concat(256u, data, data_len, NULL, 0u,
        digest, PRP_HS2_ADMISSION_COMMITMENT_LEN);
    return result == PRP_CRYPTO_OK ? 0 : -1;
}

PRP_HS2_EXPORT("prp_hs2_admission_m1_commitment")
int prp_hs2_admission_m1_commitment(uint16_t suite, const uint8_t *m1,
    size_t m1_len, uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    return suite_hash(suite, m1, m1_len, commitment);
}

PRP_HS2_EXPORT("prp_hs2_admission_offer_encode")
int prp_hs2_admission_offer_encode(const prp_hs2_admission_offer_t *offer,
    uint8_t out[PRP_HS2_ADMISSION_OFFER_LEN])
{
    uint8_t primitive;
    if (offer == NULL || out == NULL ||
            prp_hs2_admission_suite_work_primitive(
                offer->suite, &primitive) != 0 ||
            offer->method_mask == 0u ||
            (offer->method_mask & ~PRP_HS2_ADMISSION_METHOD_MASK) != 0u ||
            !bytes_nonzero(offer->attempt_nonce,
                sizeof(offer->attempt_nonce)) ||
            !bytes_nonzero(offer->m1_commitment,
                sizeof(offer->m1_commitment)))
        return -1;
    memcpy(out, offer_magic, sizeof(offer_magic) - 1u);
    out[4] = PRP_HS2_ADMISSION_VERSION;
    out[5] = 1u;
    put_u16(out + 6, offer->suite);
    put_u16(out + 8, offer->method_mask);
    put_u16(out + 10, 0u);
    memcpy(out + 12, offer->attempt_nonce, sizeof(offer->attempt_nonce));
    memcpy(out + 28, offer->m1_commitment, sizeof(offer->m1_commitment));
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_offer_decode")
int prp_hs2_admission_offer_decode(const uint8_t *data, size_t data_len,
    prp_hs2_admission_offer_t *offer)
{
    prp_hs2_admission_offer_t decoded;
    uint8_t primitive;
    if (data == NULL || offer == NULL ||
            data_len != PRP_HS2_ADMISSION_OFFER_LEN ||
            memcmp(data, offer_magic, sizeof(offer_magic) - 1u) != 0 ||
            data[4] != PRP_HS2_ADMISSION_VERSION || data[5] != 1u ||
            get_u16(data + 10) != 0u)
        return -1;
    memset(&decoded, 0, sizeof(decoded));
    decoded.suite = get_u16(data + 6);
    decoded.method_mask = get_u16(data + 8);
    memcpy(decoded.attempt_nonce, data + 12, sizeof(decoded.attempt_nonce));
    memcpy(decoded.m1_commitment, data + 28,
        sizeof(decoded.m1_commitment));
    if (prp_hs2_admission_suite_work_primitive(
            decoded.suite, &primitive) != 0 || decoded.method_mask == 0u ||
            (decoded.method_mask & ~PRP_HS2_ADMISSION_METHOD_MASK) != 0u ||
            !bytes_nonzero(decoded.attempt_nonce,
                sizeof(decoded.attempt_nonce)) ||
            !bytes_nonzero(decoded.m1_commitment,
                sizeof(decoded.m1_commitment)))
        return -1;
    *offer = decoded;
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_offer_commitment")
int prp_hs2_admission_offer_commitment(const uint8_t *offer,
    size_t offer_len, uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    prp_hs2_admission_offer_t decoded;
    if (prp_hs2_admission_offer_decode(offer, offer_len, &decoded) != 0)
        return -1;
    return suite_hash(decoded.suite, offer, offer_len, commitment);
}

PRP_HS2_EXPORT("prp_hs2_admission_challenge_encode")
int prp_hs2_admission_challenge_encode(
    const prp_hs2_admission_challenge_t *challenge,
    uint8_t out[PRP_HS2_ADMISSION_CHALLENGE_LEN])
{
    uint8_t primitive;
    if (challenge == NULL || out == NULL ||
            challenge->method != PRP_HS2_ADMISSION_METHOD_HASHCASH ||
            prp_hs2_admission_suite_work_primitive(
                challenge->suite, &primitive) != 0 ||
            challenge->work_primitive != primitive ||
            challenge->difficulty_bits == 0u ||
            challenge->validity_ms == 0u ||
            challenge->validity_ms > PRP_HS2_ADMISSION_VALIDITY_MAX_MS ||
            challenge->generation == 0u ||
            !bytes_nonzero(challenge->offer_commitment,
                sizeof(challenge->offer_commitment)) ||
            !bytes_nonzero(challenge->challenge_nonce,
                sizeof(challenge->challenge_nonce)) ||
            !bytes_nonzero(challenge->cookie, sizeof(challenge->cookie)))
        return -1;
    memcpy(out, challenge_magic, sizeof(challenge_magic) - 1u);
    out[4] = PRP_HS2_ADMISSION_VERSION;
    out[5] = 2u;
    put_u16(out + 6, challenge->suite);
    out[8] = challenge->method;
    out[9] = challenge->work_primitive;
    out[10] = challenge->difficulty_bits;
    out[11] = 0u;
    put_u32(out + 12, challenge->validity_ms);
    put_u64(out + 16, challenge->generation);
    memcpy(out + 24, challenge->offer_commitment,
        sizeof(challenge->offer_commitment));
    memcpy(out + 56, challenge->challenge_nonce,
        sizeof(challenge->challenge_nonce));
    memcpy(out + 88, challenge->cookie, sizeof(challenge->cookie));
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_challenge_decode")
int prp_hs2_admission_challenge_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_challenge_t *challenge)
{
    prp_hs2_admission_challenge_t decoded;
    uint8_t primitive;
    if (data == NULL || challenge == NULL ||
            data_len != PRP_HS2_ADMISSION_CHALLENGE_LEN ||
            memcmp(data, challenge_magic,
                sizeof(challenge_magic) - 1u) != 0 ||
            data[4] != PRP_HS2_ADMISSION_VERSION || data[5] != 2u ||
            data[11] != 0u)
        return -1;
    memset(&decoded, 0, sizeof(decoded));
    decoded.suite = get_u16(data + 6);
    decoded.method = data[8];
    decoded.work_primitive = data[9];
    decoded.difficulty_bits = data[10];
    decoded.validity_ms = get_u32(data + 12);
    decoded.generation = get_u64(data + 16);
    memcpy(decoded.offer_commitment, data + 24,
        sizeof(decoded.offer_commitment));
    memcpy(decoded.challenge_nonce, data + 56,
        sizeof(decoded.challenge_nonce));
    memcpy(decoded.cookie, data + 88, sizeof(decoded.cookie));
    if (decoded.method != PRP_HS2_ADMISSION_METHOD_HASHCASH ||
            prp_hs2_admission_suite_work_primitive(
                decoded.suite, &primitive) != 0 ||
            decoded.work_primitive != primitive ||
            decoded.difficulty_bits == 0u || decoded.validity_ms == 0u ||
            decoded.validity_ms > PRP_HS2_ADMISSION_VALIDITY_MAX_MS ||
            decoded.generation == 0u ||
            !bytes_nonzero(decoded.offer_commitment,
                sizeof(decoded.offer_commitment)) ||
            !bytes_nonzero(decoded.challenge_nonce,
                sizeof(decoded.challenge_nonce)) ||
            !bytes_nonzero(decoded.cookie, sizeof(decoded.cookie)))
        return -1;
    *challenge = decoded;
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_challenge_commitment")
int prp_hs2_admission_challenge_commitment(const uint8_t *challenge,
    size_t challenge_len,
    uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    prp_hs2_admission_challenge_t decoded;
    if (prp_hs2_admission_challenge_decode(
            challenge, challenge_len, &decoded) != 0)
        return -1;
    return suite_hash(decoded.suite, challenge, challenge_len, commitment);
}

PRP_HS2_EXPORT("prp_hs2_admission_proof_encode")
int prp_hs2_admission_proof_encode(const prp_hs2_admission_proof_t *proof,
    uint8_t out[PRP_HS2_ADMISSION_PROOF_LEN])
{
    uint8_t primitive;
    if (proof == NULL || out == NULL ||
            proof->method != PRP_HS2_ADMISSION_METHOD_HASHCASH ||
            prp_hs2_admission_suite_work_primitive(
                proof->suite, &primitive) != 0 ||
            proof->work_primitive != primitive ||
            !bytes_nonzero(proof->challenge_commitment,
                sizeof(proof->challenge_commitment)))
        return -1;
    memcpy(out, proof_magic, sizeof(proof_magic) - 1u);
    out[4] = PRP_HS2_ADMISSION_VERSION;
    out[5] = 3u;
    put_u16(out + 6, proof->suite);
    out[8] = proof->method;
    out[9] = proof->work_primitive;
    put_u16(out + 10, 0u);
    memcpy(out + 12, proof->challenge_commitment,
        sizeof(proof->challenge_commitment));
    put_u64(out + 44, proof->solution_nonce);
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_proof_decode")
int prp_hs2_admission_proof_decode(const uint8_t *data, size_t data_len,
    prp_hs2_admission_proof_t *proof)
{
    prp_hs2_admission_proof_t decoded;
    uint8_t primitive;
    if (data == NULL || proof == NULL ||
            data_len != PRP_HS2_ADMISSION_PROOF_LEN ||
            memcmp(data, proof_magic, sizeof(proof_magic) - 1u) != 0 ||
            data[4] != PRP_HS2_ADMISSION_VERSION || data[5] != 3u ||
            get_u16(data + 10) != 0u)
        return -1;
    memset(&decoded, 0, sizeof(decoded));
    decoded.suite = get_u16(data + 6);
    decoded.method = data[8];
    decoded.work_primitive = data[9];
    memcpy(decoded.challenge_commitment, data + 12,
        sizeof(decoded.challenge_commitment));
    decoded.solution_nonce = get_u64(data + 44);
    if (decoded.method != PRP_HS2_ADMISSION_METHOD_HASHCASH ||
            prp_hs2_admission_suite_work_primitive(
                decoded.suite, &primitive) != 0 ||
            decoded.work_primitive != primitive ||
            !bytes_nonzero(decoded.challenge_commitment,
                sizeof(decoded.challenge_commitment)))
        return -1;
    *proof = decoded;
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_proof_fragment_encode")
int prp_hs2_admission_proof_fragment_encode(
    const prp_hs2_admission_proof_fragment_t *fragment, uint8_t *out,
    size_t out_capacity, size_t *out_len)
{
    size_t encoded_len;
    if (fragment == NULL || out == NULL || out_len == NULL ||
            fragment->m1_total_len == 0u || fragment->fragment == NULL ||
            fragment->m1_total_len > PRP_HS2_ADMISSION_M1_MAX_LEN ||
            fragment->fragment_len == 0u ||
            fragment->m1_offset >= fragment->m1_total_len ||
            fragment->fragment_len >
                fragment->m1_total_len - fragment->m1_offset)
        return -1;
    encoded_len = PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN +
        fragment->fragment_len;
    if (out_capacity < encoded_len)
        return -1;
    if (prp_hs2_admission_proof_encode(&fragment->proof, out) != 0)
        return -1;
    put_u16(out + 52u, fragment->m1_total_len);
    put_u16(out + 54u, fragment->m1_offset);
    put_u16(out + 56u, fragment->fragment_len);
    put_u16(out + 58u, 0u);
    memcpy(out + PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN,
        fragment->fragment, fragment->fragment_len);
    *out_len = encoded_len;
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_proof_fragment_decode")
int prp_hs2_admission_proof_fragment_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_proof_fragment_t *fragment)
{
    prp_hs2_admission_proof_fragment_t decoded;
    uint16_t fragment_len;
    if (data == NULL || fragment == NULL ||
            data_len <= PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN ||
            prp_hs2_admission_proof_decode(data,
                PRP_HS2_ADMISSION_PROOF_LEN, &decoded.proof) != 0 ||
            get_u16(data + 58u) != 0u)
        return -1;
    decoded.m1_total_len = get_u16(data + 52u);
    decoded.m1_offset = get_u16(data + 54u);
    fragment_len = get_u16(data + 56u);
    decoded.fragment_len = fragment_len;
    decoded.fragment = data + PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN;
    if (decoded.m1_total_len == 0u ||
            decoded.m1_total_len > PRP_HS2_ADMISSION_M1_MAX_LEN ||
            fragment_len == 0u ||
            decoded.m1_offset >= decoded.m1_total_len ||
            fragment_len > decoded.m1_total_len - decoded.m1_offset ||
            data_len != PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN +
                fragment_len)
        return -1;
    *fragment = decoded;
    return 0;
}

PRP_HS2_EXPORT("prp_hs2_admission_work_digest")
int prp_hs2_admission_work_digest(uint16_t suite,
    uint16_t responder_identity_profile, const uint8_t *responder_id,
    size_t responder_id_len,
    const uint8_t challenge_commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN],
    uint64_t solution_nonce,
    uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    uint8_t preimage[2u + sizeof(work_domain) - 1u + 2u + 2u +
        PRP_HS2_ADMISSION_RESPONDER_ID_MAX +
        PRP_HS2_ADMISSION_COMMITMENT_LEN + 8u];
    uint8_t *cursor = preimage;
    size_t domain_len = sizeof(work_domain) - 1u;
    if (responder_identity_profile == 0u || responder_id == NULL ||
            responder_id_len == 0u ||
            responder_id_len > PRP_HS2_ADMISSION_RESPONDER_ID_MAX ||
            challenge_commitment == NULL || digest == NULL)
        return -1;
    put_u16(cursor, (uint16_t)domain_len); cursor += 2;
    memcpy(cursor, work_domain, domain_len); cursor += domain_len;
    put_u16(cursor, responder_identity_profile); cursor += 2;
    put_u16(cursor, (uint16_t)responder_id_len); cursor += 2;
    memcpy(cursor, responder_id, responder_id_len); cursor += responder_id_len;
    memcpy(cursor, challenge_commitment,
        PRP_HS2_ADMISSION_COMMITMENT_LEN);
    cursor += PRP_HS2_ADMISSION_COMMITMENT_LEN;
    put_u64(cursor, solution_nonce); cursor += 8;
    return suite_hash(suite, preimage, (size_t)(cursor - preimage), digest);
}

PRP_HS2_EXPORT("prp_hs2_admission_work_meets_difficulty")
int prp_hs2_admission_work_meets_difficulty(
    const uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN],
    uint8_t difficulty_bits)
{
    unsigned int full_bytes = difficulty_bits / 8u;
    unsigned int remaining = difficulty_bits % 8u;
    unsigned int index;
    if (digest == NULL || difficulty_bits == 0u)
        return 0;
    for (index = 0u; index < full_bytes; index++)
        if (digest[index] != 0u)
            return 0;
    return remaining == 0u ||
        (digest[full_bytes] >> (8u - remaining)) == 0u;
}

PRP_HS2_EXPORT("prp_hs2_admission_verify")
int prp_hs2_admission_verify(uint16_t deterministic_suite,
    uint16_t responder_identity_profile, const uint8_t *responder_id,
    size_t responder_id_len, const uint8_t *canonical_m1, size_t m1_len,
    const uint8_t *offer, size_t offer_len,
    const uint8_t *challenge, size_t challenge_len,
    const uint8_t expected_cookie[PRP_HS2_ADMISSION_COOKIE_LEN],
    const uint8_t *proof, size_t proof_len, uint64_t challenge_age_ms,
    uint8_t proof_id[PRP_HS2_ADMISSION_COMMITMENT_LEN])
{
    prp_hs2_admission_offer_t decoded_offer;
    prp_hs2_admission_challenge_t decoded_challenge;
    prp_hs2_admission_proof_t decoded_proof;
    uint8_t expected_m1[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    uint8_t expected_offer[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    uint8_t expected_challenge[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    if (deterministic_suite == 0u || canonical_m1 == NULL || m1_len == 0u ||
            expected_cookie == NULL || proof_id == NULL ||
            prp_hs2_admission_offer_decode(
                offer, offer_len, &decoded_offer) != 0 ||
            prp_hs2_admission_challenge_decode(
                challenge, challenge_len, &decoded_challenge) != 0 ||
            prp_hs2_admission_proof_decode(
                proof, proof_len, &decoded_proof) != 0)
        return -1;
    if (decoded_offer.suite != deterministic_suite ||
            decoded_challenge.suite != deterministic_suite ||
            decoded_proof.suite != deterministic_suite ||
            decoded_challenge.method != decoded_proof.method ||
            decoded_challenge.work_primitive != decoded_proof.work_primitive ||
            (decoded_offer.method_mask &
                (1u << decoded_challenge.method)) == 0u ||
            challenge_age_ms > decoded_challenge.validity_ms ||
            !bytes_equal(expected_cookie, decoded_challenge.cookie,
                PRP_HS2_ADMISSION_COOKIE_LEN))
        return -1;
    if (prp_hs2_admission_m1_commitment(deterministic_suite,
            canonical_m1, m1_len, expected_m1) != 0 ||
            !bytes_equal(expected_m1, decoded_offer.m1_commitment,
                sizeof(expected_m1)) ||
            prp_hs2_admission_offer_commitment(
                offer, offer_len, expected_offer) != 0 ||
            !bytes_equal(expected_offer, decoded_challenge.offer_commitment,
                sizeof(expected_offer)) ||
            prp_hs2_admission_challenge_commitment(
                challenge, challenge_len, expected_challenge) != 0 ||
            !bytes_equal(expected_challenge,
                decoded_proof.challenge_commitment,
                sizeof(expected_challenge)) ||
            prp_hs2_admission_work_digest(deterministic_suite,
                responder_identity_profile, responder_id, responder_id_len,
                expected_challenge, decoded_proof.solution_nonce,
                digest) != 0 ||
            !prp_hs2_admission_work_meets_difficulty(
                digest, decoded_challenge.difficulty_bits))
        return -1;
    return suite_hash(deterministic_suite, proof, proof_len, proof_id);
}
