#include "prp_hash.h"
#include "prp_crypto_backend.h"
#include "prp_pq_internal.h"

#include <prp/wire_v4_codec.h>
#include <string.h>

int
prp_hash_blake3(const uint8_t *input, size_t input_len,
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN])
{
    return prp_crypto_hash_blake3(input, input_len, out,
        PRP_HASH_BLAKE3_OUT_LEN);
}

int
prp_hash_blake3_concat(const uint8_t *first, size_t first_len,
    const uint8_t *second, size_t second_len,
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN])
{
    return prp_crypto_hash_blake3_concat(first, first_len, second, second_len,
        out, PRP_HASH_BLAKE3_OUT_LEN);
}

int
prp_hash_blake3_derive_key(const uint8_t *context, size_t context_len,
    const uint8_t *key, size_t key_len, const uint8_t *input,
    size_t input_len, uint8_t out[PRP_HASH_BLAKE3_OUT_LEN])
{
    char domain[256];

    if (context == NULL || context_len == 0u || context_len >= sizeof(domain) ||
            (key == NULL && key_len != 0u) ||
            (input == NULL && input_len != 0u) || out == NULL)
        return -1;
    memcpy(domain, context, context_len);
    domain[context_len] = '\0';
    return prp_crypto_blake3_derive_key(domain, key, key_len, input,
        input_len, out, PRP_HASH_BLAKE3_OUT_LEN);
}

int
prp_self_cert_id_compute(uint8_t identity_profile,
    uint8_t identity_proof_profile, const uint8_t *public_key,
    size_t public_key_len, uint8_t *out, size_t out_size, size_t *written)
{
    static const char context[] = "PRP-SELF-CERT-ID-v1";
    uint8_t profile_input[4] = { 0, 0, 0, 0 };
    size_t output_len;

    if (identity_profile == PRP_SELF_CERT_ID_PROFILE_BLAKE3) {
        output_len = PRP_HASH_BLAKE3_OUT_LEN;
    } else if (identity_profile == PRP_SELF_CERT_ID_PROFILE_BLAKE3_512) {
        output_len = PRP_SELF_CERT_ID_MAX_LEN;
    } else {
        return -1;
    }
    if (identity_proof_profile < PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3 ||
            identity_proof_profile >
                PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87) {
        return -1;
    }
    if (public_key == NULL || public_key_len == 0u || out == NULL ||
            out_size < output_len || written == NULL) {
        return -1;
    }
    profile_input[0] = identity_profile;
    profile_input[1] = identity_proof_profile;
    if (prp_crypto_blake3_derive_key(context, public_key, public_key_len,
            profile_input, sizeof(profile_input), out,
            output_len) != 0) {
        return -1;
    }
    *written = output_len;
    return 0;
}

int
prp_wire_v4_strong_id_compute(uint16_t identity_suite,
    const uint8_t *public_key, size_t public_key_len,
    uint8_t *out, size_t out_size, size_t *written)
{
    struct prp_wire_v4_identity_suite_desc suite;
    uint8_t prefix[PRP_WIRE_V4_STRONG_ID_DOMAIN_LEN + 2u];
    unsigned int sha_bits;

    if (prp_wire_v4_identity_suite_get(identity_suite, &suite) !=
            PRP_WIRE_V4_OK || public_key == NULL || out == NULL ||
            written == NULL || public_key_len != suite.public_key_len ||
            out_size < suite.strong_id_len)
        return -1;
    memcpy(prefix, PRP_WIRE_V4_STRONG_ID_DOMAIN,
        PRP_WIRE_V4_STRONG_ID_DOMAIN_LEN);
    prp_wire_v4_put_be16(prefix + PRP_WIRE_V4_STRONG_ID_DOMAIN_LEN,
        identity_suite);
    if (suite.hash == PRP_WIRE_V4_HASH_BLAKE3) {
        if (suite.strong_id_len != PRP_HASH_BLAKE3_OUT_LEN ||
                prp_crypto_hash_blake3_concat(prefix, sizeof(prefix),
                    public_key, public_key_len, out,
                    suite.strong_id_len) != 0)
            return -1;
        *written = suite.strong_id_len;
        return 0;
    }
    sha_bits = suite.hash == PRP_WIRE_V4_HASH_SHA256 ? 256u :
        suite.hash == PRP_WIRE_V4_HASH_SHA384 ? 384u : 0u;
    if (sha_bits == 0u ||
            prp_crypto_hash_sha2_concat(sha_bits, prefix, sizeof(prefix),
                public_key, public_key_len, out, suite.strong_id_len) !=
                PRP_CRYPTO_OK)
        return -1;
    *written = suite.strong_id_len;
    return 0;
}

size_t
prp_identity_proof_public_key_len(uint8_t profile)
{
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return PRP_ID_PROOF_MLDSA65_PUBLIC_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return PRP_ID_PROOF_MLDSA87_PUBLIC_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return PRP_ID_PROOF_HYBRID_PUBLIC_KEY_LEN;
    default:
        return 0u;
    }
}

size_t
prp_identity_proof_signature_len(uint8_t profile)
{
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return PRP_ID_PROOF_ED25519_SIGNATURE_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return PRP_ID_PROOF_MLDSA65_SIGNATURE_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return PRP_ID_PROOF_MLDSA87_SIGNATURE_LEN;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return PRP_ID_PROOF_HYBRID_SIGNATURE_LEN;
    default:
        return 0u;
    }
}

int
prp_identity_proof_verify(uint8_t profile, const uint8_t *public_key,
    size_t public_key_len, const uint8_t *signature, size_t signature_len,
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len)
{
    if (public_key == NULL || signature == NULL || message == NULL ||
        message_len == 0u || (context_len != 0u && context == NULL) ||
        public_key_len != prp_identity_proof_public_key_len(profile) ||
        signature_len != prp_identity_proof_signature_len(profile))
        return -1;
    if (profile == PRP_SELF_CERT_ID_PROOF_MLDSA87)
        return prp_mldsa87_verify_canonical(public_key, signature, message,
            message_len, context, context_len);
    return prp_crypto_identity_proof_verify(profile, public_key, signature,
        message, message_len, context, context_len) == PRP_CRYPTO_OK ? 0 : -1;
}
