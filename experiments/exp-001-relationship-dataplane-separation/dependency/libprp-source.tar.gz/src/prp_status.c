#include "prp_status.h"

const char *prp_error_name(int code)
{
    switch (code) {
    case PRP_OK: return "ok";
    case PRP_ERR_SHORT: return "short";
    case PRP_ERR_MARKER: return "marker";
    case PRP_ERR_VERSION: return "version";
    case PRP_ERR_PAYLOAD_TOO_LARGE: return "payload_too_large";
    case PRP_ERR_OUTPUT_TOO_SMALL: return "output_too_small";
    case PRP_ERR_ARGUMENT: return "argument";
    case PRP_ERR_STATE: return "state";
    case PRP_ERR_CARRIER: return "carrier";
    case PRP_ERR_PROTOCOL: return "protocol";
    case PRP_ERR_AGAIN: return "again";
    case PRP_ERR_CRYPTO: return "crypto";
    case PRP_ERR_CANCELLED: return "cancelled";
    case PRP_ERR_ALREADY: return "already";
    case PRP_ERR_NOT_FOUND: return "not_found";
    case PRP_ERR_POLICY: return "policy";
    case PRP_ERR_UNAVAILABLE: return "unavailable";
    case PRP_ERR_NO_MEMORY: return "no_memory";
    default: return "unknown";
    }
}
