#include "prp_crypto_backend.h"

#include <bearssl.h>

#include <limits.h>
#include <string.h>

static void prp_bearssl_gcm_start(br_aes_ct_ctr_keys *aes,
    br_gcm_context *gcm, const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len)
{
    static const uint8_t empty = 0U;

    br_aes_ct_ctr_init(aes, key, PRP_CRYPTO_KEY_LEN);
    br_gcm_init(gcm, &aes->vtable, br_ghash_ctmul32);
    br_gcm_reset(gcm, nonce, PRP_CRYPTO_AESGCM_NONCE_LEN);
    br_gcm_aad_inject(gcm,
        associated_data != NULL ? associated_data : &empty,
        associated_data_len);
    br_gcm_flip(gcm);
}

int prp_crypto_aes_256_gcm_encrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len, uint8_t *ciphertext,
    uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN])
{
    br_aes_ct_ctr_keys aes;
    br_gcm_context gcm;

    if (key == NULL || nonce == NULL || ciphertext == NULL || tag == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (plaintext == NULL && plaintext_len != 0U) ||
            associated_data_len > UINT32_MAX || plaintext_len > UINT32_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    if (plaintext_len != 0U)
        memmove(ciphertext, plaintext, plaintext_len);
    prp_bearssl_gcm_start(&aes, &gcm, key, nonce, associated_data,
        associated_data_len);
    br_gcm_run(&gcm, 1, ciphertext, plaintext_len);
    br_gcm_get_tag(&gcm, tag);
    prp_crypto_secure_zero(&gcm, sizeof(gcm));
    prp_crypto_secure_zero(&aes, sizeof(aes));
    return PRP_CRYPTO_OK;
}

int prp_crypto_aes_256_gcm_decrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN], uint8_t *plaintext)
{
    br_aes_ct_ctr_keys aes;
    br_gcm_context gcm;
    uint32_t valid;

    if (key == NULL || nonce == NULL || tag == NULL || plaintext == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (ciphertext == NULL && ciphertext_len != 0U) ||
            associated_data_len > UINT32_MAX || ciphertext_len > UINT32_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    if (ciphertext_len != 0U)
        memmove(plaintext, ciphertext, ciphertext_len);
    prp_bearssl_gcm_start(&aes, &gcm, key, nonce, associated_data,
        associated_data_len);
    br_gcm_run(&gcm, 0, plaintext, ciphertext_len);
    valid = br_gcm_check_tag(&gcm, tag);
    prp_crypto_secure_zero(&gcm, sizeof(gcm));
    prp_crypto_secure_zero(&aes, sizeof(aes));
    if (valid == 0U) {
        prp_crypto_secure_zero(plaintext, ciphertext_len);
        return PRP_CRYPTO_ERR_CRYPTO;
    }
    return PRP_CRYPTO_OK;
}
