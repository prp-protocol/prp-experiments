#include "prp_content_id.h"

#include "prp_crypto_backend.h"
#include "prp_hash.h"
#include "prp_status.h"

#include <prp/wire_v4_codec.h>
#include <stdlib.h>
#include <string.h>

#define PRP_CONTENT_STACK_LEVELS 64u

struct prp_content_builder_s {
    uint16_t content_suite;
    uint16_t digest_len;
    uint8_t leaf[PRP_CONTENT_LEAF_BYTES];
    size_t leaf_len;
    uint64_t total_length;
    uint64_t leaf_count;
    uint8_t stack[PRP_CONTENT_STACK_LEVELS][PRP_CONTENT_DIGEST_MAX_LEN];
    uint8_t present[PRP_CONTENT_STACK_LEVELS];
    uint8_t stack_contains_target[PRP_CONTENT_STACK_LEVELS];
    struct {
        uint8_t position;
        uint8_t child_count;
        uint8_t sibling[PRP_CONTENT_DIGEST_MAX_LEN];
    } proof[PRP_CONTENT_STACK_LEVELS];
    uint64_t proof_leaf_index;
    int proof_enabled;
    int finalized;
};

static const uint8_t leaf_domain[] = "PRP-CONTENT-LEAF-v1";
static const uint8_t node_domain[] = "PRP-CONTENT-NODE-v1";
static const uint8_t id_domain[] = "PRP-CONTENT-ID-v1";

static uint16_t tree_height(uint64_t leaf_count);

static int
bytes_equal(const uint8_t *left, const uint8_t *right, size_t length)
{
    uint8_t difference = 0u;
    size_t i;

    for (i = 0u; i < length; i++)
        difference |= left[i] ^ right[i];
    return difference == 0u;
}

static uint16_t
get_be16(const uint8_t *value)
{
    return (uint16_t)((uint16_t)value[0] << 8) | value[1];
}

static uint32_t
get_be32(const uint8_t *value)
{
    return ((uint32_t)value[0] << 24) | ((uint32_t)value[1] << 16) |
        ((uint32_t)value[2] << 8) | value[3];
}

static uint64_t
get_be64(const uint8_t *value)
{
    return ((uint64_t)get_be32(value) << 32) | get_be32(value + 4u);
}

static void
put_be16(uint8_t *value, uint16_t number)
{
    value[0] = (uint8_t)(number >> 8);
    value[1] = (uint8_t)number;
}

static void
put_be32(uint8_t *value, uint32_t number)
{
    value[0] = (uint8_t)(number >> 24);
    value[1] = (uint8_t)(number >> 16);
    value[2] = (uint8_t)(number >> 8);
    value[3] = (uint8_t)number;
}

static void
put_be64(uint8_t *value, uint64_t number)
{
    put_be32(value, (uint32_t)(number >> 32));
    put_be32(value + 4u, (uint32_t)number);
}

static int
content_suite(uint16_t suite_id, struct prp_wire_v4_identity_suite_desc *suite)
{
    if (suite == NULL || prp_wire_v4_identity_suite_get(suite_id, suite) !=
            PRP_WIRE_V4_OK || (suite->hash != PRP_WIRE_V4_HASH_BLAKE3 &&
            suite->hash != PRP_WIRE_V4_HASH_SHA256 &&
            suite->hash != PRP_WIRE_V4_HASH_SHA384) ||
            (suite->strong_id_len != 32u && suite->strong_id_len != 48u))
        return PRP_ERR_ARGUMENT;
    return PRP_OK;
}

size_t
prp_content_suite_digest_len(uint16_t content_suite_id)
{
    struct prp_wire_v4_identity_suite_desc suite;

    return content_suite(content_suite_id, &suite) == PRP_OK ?
        suite.strong_id_len : 0u;
}

static int
content_hash(uint16_t suite_id, const uint8_t *input, size_t input_len,
    uint8_t *digest, size_t digest_len)
{
    struct prp_wire_v4_identity_suite_desc suite;
    unsigned int bits;

    if (input == NULL || digest == NULL ||
            content_suite(suite_id, &suite) != PRP_OK ||
            digest_len != suite.strong_id_len)
        return PRP_ERR_ARGUMENT;
    if (suite.hash == PRP_WIRE_V4_HASH_BLAKE3)
        return prp_crypto_hash_blake3(input, input_len, digest, digest_len) ==
            PRP_CRYPTO_OK ? PRP_OK : PRP_ERR_CRYPTO;
    bits = suite.hash == PRP_WIRE_V4_HASH_SHA256 ? 256u : 384u;
    return prp_crypto_hash_sha2_concat(bits, input, input_len, NULL, 0u,
        digest, digest_len) == PRP_CRYPTO_OK ? PRP_OK : PRP_ERR_CRYPTO;
}

static int
leaf_hash(uint16_t suite, const uint8_t *leaf, size_t leaf_len,
    uint8_t *digest, size_t digest_len)
{
    uint8_t *input;
    size_t prefix_len = sizeof(leaf_domain) - 1u + 8u;
    int rc;

    if ((leaf == NULL && leaf_len != 0u) || leaf_len > PRP_CONTENT_LEAF_BYTES)
        return PRP_ERR_ARGUMENT;
    input = malloc(prefix_len + leaf_len);
    if (input == NULL)
        return PRP_ERR_STATE;
    memcpy(input, leaf_domain, sizeof(leaf_domain) - 1u);
    put_be16(input + sizeof(leaf_domain) - 1u, suite);
    put_be16(input + sizeof(leaf_domain) + 1u,
        PRP_CONTENT_PROFILE_MERKLE_64K_BINARY);
    put_be32(input + sizeof(leaf_domain) + 3u, (uint32_t)leaf_len);
    if (leaf_len != 0u)
        memcpy(input + prefix_len, leaf, leaf_len);
    rc = content_hash(suite, input, prefix_len + leaf_len, digest, digest_len);
    prp_crypto_secure_zero(input, prefix_len + leaf_len);
    free(input);
    return rc;
}

static int
node_hash(uint16_t suite, uint16_t level, uint16_t child_count,
    const uint8_t *children, size_t digest_len, uint8_t *digest)
{
    uint8_t input[sizeof(node_domain) - 1u + 8u +
        2u * PRP_CONTENT_DIGEST_MAX_LEN];
    size_t prefix_len = sizeof(node_domain) - 1u + 8u;

    if (level == 0u || (child_count != 1u && child_count != 2u) ||
            children == NULL || digest == NULL)
        return PRP_ERR_ARGUMENT;
    memcpy(input, node_domain, sizeof(node_domain) - 1u);
    put_be16(input + sizeof(node_domain) - 1u, suite);
    put_be16(input + sizeof(node_domain) + 1u,
        PRP_CONTENT_PROFILE_MERKLE_64K_BINARY);
    put_be16(input + sizeof(node_domain) + 3u, level);
    put_be16(input + sizeof(node_domain) + 5u, child_count);
    memcpy(input + prefix_len, children, child_count * digest_len);
    return content_hash(suite, input, prefix_len + child_count * digest_len,
        digest, digest_len);
}

int
prp_content_builder_create(uint16_t suite, prp_content_builder_t **builder)
{
    size_t digest_len;

    if (builder == NULL)
        return PRP_ERR_ARGUMENT;
    *builder = NULL;
    digest_len = prp_content_suite_digest_len(suite);
    if (digest_len == 0u)
        return PRP_ERR_ARGUMENT;
    *builder = calloc(1u, sizeof(**builder));
    if (*builder == NULL)
        return PRP_ERR_STATE;
    (*builder)->content_suite = suite;
    (*builder)->digest_len = (uint16_t)digest_len;
    return PRP_OK;
}

int
prp_content_proof_builder_create(uint16_t suite, uint64_t leaf_index,
    prp_content_builder_t **builder)
{
    int rc = prp_content_builder_create(suite, builder);

    if (rc == PRP_OK) {
        (*builder)->proof_enabled = 1;
        (*builder)->proof_leaf_index = leaf_index;
    }
    return rc;
}

static int
builder_leaf(prp_content_builder_t *builder)
{
    uint8_t digest[PRP_CONTENT_DIGEST_MAX_LEN];
    uint8_t children[2u * PRP_CONTENT_DIGEST_MAX_LEN];
    unsigned int level = 0u;
    int contains_target = builder->proof_enabled &&
        builder->leaf_count == builder->proof_leaf_index;
    int rc;

    rc = leaf_hash(builder->content_suite, builder->leaf, builder->leaf_len,
        digest, builder->digest_len);
    if (rc != PRP_OK)
        return rc;
    while (level < PRP_CONTENT_STACK_LEVELS && builder->present[level]) {
        int left_contains = builder->stack_contains_target[level];

        if (left_contains || contains_target) {
            builder->proof[level].position = left_contains ? 0u : 1u;
            builder->proof[level].child_count = 2u;
            memcpy(builder->proof[level].sibling,
                left_contains ? digest : builder->stack[level],
                builder->digest_len);
        }
        memcpy(children, builder->stack[level], builder->digest_len);
        memcpy(children + builder->digest_len, digest, builder->digest_len);
        builder->present[level] = 0u;
        builder->stack_contains_target[level] = 0u;
        rc = node_hash(builder->content_suite, (uint16_t)(level + 1u), 2u,
            children, builder->digest_len, digest);
        if (rc != PRP_OK)
            return rc;
        level++;
        contains_target = left_contains || contains_target;
    }
    if (level == PRP_CONTENT_STACK_LEVELS)
        return PRP_ERR_ARGUMENT;
    memcpy(builder->stack[level], digest, builder->digest_len);
    builder->present[level] = 1u;
    builder->stack_contains_target[level] = (uint8_t)contains_target;
    builder->leaf_count++;
    builder->leaf_len = 0u;
    return PRP_OK;
}

int
prp_content_builder_update(prp_content_builder_t *builder,
    const uint8_t *data, size_t data_len)
{
    size_t copied;

    if (builder == NULL || builder->finalized ||
            (data == NULL && data_len != 0u) ||
            data_len > UINT64_MAX - builder->total_length)
        return PRP_ERR_ARGUMENT;
    builder->total_length += data_len;
    while (data_len != 0u) {
        copied = PRP_CONTENT_LEAF_BYTES - builder->leaf_len;
        if (copied > data_len)
            copied = data_len;
        memcpy(builder->leaf + builder->leaf_len, data, copied);
        builder->leaf_len += copied;
        data += copied;
        data_len -= copied;
        if (builder->leaf_len == PRP_CONTENT_LEAF_BYTES &&
                builder_leaf(builder) != PRP_OK)
            return PRP_ERR_CRYPTO;
    }
    return PRP_OK;
}

static int
builder_root(prp_content_builder_t *builder, uint8_t *root,
    uint16_t *height)
{
    uint8_t accumulator[PRP_CONTENT_DIGEST_MAX_LEN];
    uint8_t children[2u * PRP_CONTENT_DIGEST_MAX_LEN];
    unsigned int accumulator_level = 0u, level;
    int accumulator_contains = 0;
    int found = 0, rc;

    for (level = 0u; level < PRP_CONTENT_STACK_LEVELS; level++) {
        if (!builder->present[level])
            continue;
        if (!found) {
            memcpy(accumulator, builder->stack[level], builder->digest_len);
            accumulator_level = level;
            accumulator_contains = builder->stack_contains_target[level];
            found = 1;
            continue;
        }
        while (accumulator_level < level) {
            if (accumulator_contains) {
                builder->proof[accumulator_level].position = 0u;
                builder->proof[accumulator_level].child_count = 1u;
            }
            rc = node_hash(builder->content_suite,
                (uint16_t)(accumulator_level + 1u), 1u, accumulator,
                builder->digest_len, accumulator);
            if (rc != PRP_OK)
                return rc;
            accumulator_level++;
        }
        memcpy(children, builder->stack[level], builder->digest_len);
        memcpy(children + builder->digest_len, accumulator,
            builder->digest_len);
        if (builder->stack_contains_target[level] || accumulator_contains) {
            int left_contains = builder->stack_contains_target[level];
            builder->proof[level].position = left_contains ? 0u : 1u;
            builder->proof[level].child_count = 2u;
            memcpy(builder->proof[level].sibling,
                left_contains ? accumulator : builder->stack[level],
                builder->digest_len);
        }
        rc = node_hash(builder->content_suite, (uint16_t)(level + 1u), 2u,
            children, builder->digest_len, accumulator);
        if (rc != PRP_OK)
            return rc;
        accumulator_level = level + 1u;
        accumulator_contains = builder->stack_contains_target[level] ||
            accumulator_contains;
    }
    if (!found || accumulator_level > UINT16_MAX)
        return PRP_ERR_ARGUMENT;
    memcpy(root, accumulator, builder->digest_len);
    *height = (uint16_t)accumulator_level;
    return PRP_OK;
}

int
prp_content_id_compute(const uint8_t *descriptor, size_t descriptor_len,
    uint8_t *content_id, size_t content_id_size, size_t *written)
{
    prp_content_descriptor_t decoded;
    uint8_t input[sizeof(id_domain) - 1u + 2u +
        PRP_CONTENT_DESCRIPTOR_MAX_LEN];
    size_t prefix_len = sizeof(id_domain) - 1u + 2u;
    int rc;

    if (content_id == NULL || written == NULL ||
            prp_content_descriptor_decode(descriptor, descriptor_len,
                &decoded) != PRP_OK ||
            content_id_size < PRP_CONTENT_ID_PREFIX_LEN +
                decoded.root_digest_len)
        return PRP_ERR_ARGUMENT;
    memcpy(input, id_domain, sizeof(id_domain) - 1u);
    put_be16(input + sizeof(id_domain) - 1u, (uint16_t)descriptor_len);
    memcpy(input + prefix_len, descriptor, descriptor_len);
    put_be16(content_id, decoded.content_suite);
    put_be16(content_id + 2u, decoded.content_profile);
    rc = content_hash(decoded.content_suite, input, prefix_len + descriptor_len,
        content_id + 4u, decoded.root_digest_len);
    if (rc != PRP_OK)
        return rc;
    *written = PRP_CONTENT_ID_PREFIX_LEN + decoded.root_digest_len;
    return PRP_OK;
}

int
prp_content_builder_finalize(prp_content_builder_t *builder,
    uint8_t *descriptor, size_t descriptor_size, size_t *descriptor_len,
    uint8_t *content_id, size_t content_id_size, size_t *content_id_len)
{
    uint8_t root[PRP_CONTENT_DIGEST_MAX_LEN];
    size_t encoded_len;
    uint16_t height;
    int rc;

    if (builder == NULL || builder->finalized || descriptor == NULL ||
            descriptor_len == NULL || content_id == NULL ||
            content_id_len == NULL)
        return PRP_ERR_ARGUMENT;
    if ((builder->leaf_len != 0u || builder->leaf_count == 0u) &&
            builder_leaf(builder) != PRP_OK)
        return PRP_ERR_CRYPTO;
    rc = builder_root(builder, root, &height);
    encoded_len = PRP_CONTENT_DESCRIPTOR_PREFIX_LEN + builder->digest_len;
    if (rc != PRP_OK || descriptor_size < encoded_len ||
            (builder->proof_enabled &&
             builder->proof_leaf_index >= builder->leaf_count))
        return PRP_ERR_ARGUMENT;
    put_be32(descriptor, PRP_CONTENT_DESCRIPTOR_MAGIC);
    descriptor[4] = PRP_CONTENT_DESCRIPTOR_VERSION;
    descriptor[5] = 0u;
    put_be16(descriptor + 6u, builder->content_suite);
    put_be16(descriptor + 8u, PRP_CONTENT_PROFILE_MERKLE_64K_BINARY);
    descriptor[10] = PRP_CONTENT_LEAF_ORDER;
    descriptor[11] = PRP_CONTENT_FANOUT_ORDER;
    put_be16(descriptor + 12u, height);
    put_be16(descriptor + 14u, builder->digest_len);
    put_be64(descriptor + 16u, builder->total_length);
    memset(descriptor + 24u, 0, 8u);
    memcpy(descriptor + 32u, root, builder->digest_len);
    *descriptor_len = encoded_len;
    rc = prp_content_id_compute(descriptor, encoded_len, content_id,
        content_id_size, content_id_len);
    if (rc == PRP_OK)
        builder->finalized = 1;
    return rc;
}

int
prp_content_builder_proof(const prp_content_builder_t *builder,
    uint8_t *proof, size_t proof_size, size_t *written)
{
    uint16_t height;
    size_t needed = PRP_CONTENT_PROOF_PREFIX_LEN, offset;
    unsigned int level;

    if (builder == NULL || proof == NULL || written == NULL ||
            !builder->finalized || !builder->proof_enabled ||
            builder->proof_leaf_index >= builder->leaf_count)
        return PRP_ERR_ARGUMENT;
    height = tree_height(builder->leaf_count);
    for (level = 0u; level < height; level++) {
        if (builder->proof[level].child_count == 0u)
            return PRP_ERR_STATE;
        needed += 4u + (builder->proof[level].child_count == 2u ?
            builder->digest_len : 0u);
    }
    if (proof_size < needed)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    proof[0] = 1u;
    put_be16(proof + 1u, builder->content_suite);
    put_be16(proof + 3u, PRP_CONTENT_PROFILE_MERKLE_64K_BINARY);
    put_be64(proof + 5u, builder->proof_leaf_index);
    put_be64(proof + 13u, builder->leaf_count);
    put_be16(proof + 21u, height);
    proof[23] = 0u;
    offset = PRP_CONTENT_PROOF_PREFIX_LEN;
    for (level = 0u; level < height; level++) {
        proof[offset] = builder->proof[level].position;
        proof[offset + 1u] = builder->proof[level].child_count;
        proof[offset + 2u] = 0u;
        proof[offset + 3u] = 0u;
        offset += 4u;
        if (builder->proof[level].child_count == 2u) {
            memcpy(proof + offset, builder->proof[level].sibling,
                builder->digest_len);
            offset += builder->digest_len;
        }
    }
    *written = offset;
    return PRP_OK;
}

void
prp_content_builder_destroy(prp_content_builder_t *builder)
{
    if (builder != NULL) {
        prp_crypto_secure_zero(builder, sizeof(*builder));
        free(builder);
    }
}

static uint16_t
tree_height(uint64_t leaf_count)
{
    uint16_t height = 0u;

    while (leaf_count > 1u) {
        leaf_count = (leaf_count >> 1) + (leaf_count & 1u);
        height++;
    }
    return height;
}

int
prp_content_descriptor_decode(const uint8_t *encoded, size_t encoded_len,
    prp_content_descriptor_t *descriptor)
{
    size_t digest_len;
    uint64_t leaf_count;

    if (encoded == NULL || descriptor == NULL ||
            encoded_len < PRP_CONTENT_DESCRIPTOR_PREFIX_LEN ||
            get_be32(encoded) != PRP_CONTENT_DESCRIPTOR_MAGIC ||
            encoded[4] != PRP_CONTENT_DESCRIPTOR_VERSION || encoded[5] != 0u ||
            get_be16(encoded + 8u) != PRP_CONTENT_PROFILE_MERKLE_64K_BINARY ||
            encoded[10] != PRP_CONTENT_LEAF_ORDER ||
            encoded[11] != PRP_CONTENT_FANOUT_ORDER ||
            get_be64(encoded + 24u) != 0u)
        return PRP_ERR_ARGUMENT;
    digest_len = prp_content_suite_digest_len(get_be16(encoded + 6u));
    if (digest_len == 0u || get_be16(encoded + 14u) != digest_len ||
            encoded_len != PRP_CONTENT_DESCRIPTOR_PREFIX_LEN + digest_len)
        return PRP_ERR_ARGUMENT;
    leaf_count = get_be64(encoded + 16u) == 0u ? 1u :
        ((get_be64(encoded + 16u) - 1u) >> PRP_CONTENT_LEAF_ORDER) + 1u;
    if (get_be16(encoded + 12u) != tree_height(leaf_count))
        return PRP_ERR_ARGUMENT;
    memset(descriptor, 0, sizeof(*descriptor));
    descriptor->content_suite = get_be16(encoded + 6u);
    descriptor->content_profile = get_be16(encoded + 8u);
    descriptor->tree_height = get_be16(encoded + 12u);
    descriptor->root_digest_len = (uint16_t)digest_len;
    descriptor->total_length = get_be64(encoded + 16u);
    memcpy(descriptor->root_digest, encoded + 32u, digest_len);
    return PRP_OK;
}

int
prp_content_id_validate(const uint8_t *content_id, size_t content_id_len,
    const uint8_t *descriptor, size_t descriptor_len)
{
    uint8_t expected[PRP_CONTENT_ID_MAX_LEN];
    size_t expected_len = 0u;

    if (content_id == NULL || prp_content_id_compute(descriptor,
            descriptor_len, expected, sizeof(expected), &expected_len) !=
            PRP_OK || content_id_len != expected_len)
        return PRP_ERR_ARGUMENT;
    return bytes_equal(content_id, expected, expected_len) ? PRP_OK :
        PRP_ERR_CRYPTO;
}

int
prp_content_proof_verify(const uint8_t *descriptor_bytes,
    size_t descriptor_len, const uint8_t *leaf, size_t leaf_len,
    const uint8_t *proof, size_t proof_len)
{
    prp_content_descriptor_t descriptor;
    uint8_t digest[PRP_CONTENT_DIGEST_MAX_LEN];
    uint8_t children[2u * PRP_CONTENT_DIGEST_MAX_LEN];
    uint64_t leaf_index, leaf_count, current_index, current_count;
    uint16_t level_count, level;
    size_t offset = PRP_CONTENT_PROOF_PREFIX_LEN, expected_leaf_len;
    int rc;

    if (proof == NULL || proof_len < PRP_CONTENT_PROOF_PREFIX_LEN ||
            prp_content_descriptor_decode(descriptor_bytes, descriptor_len,
                &descriptor) != PRP_OK || proof[0] != 1u ||
            get_be16(proof + 1u) != descriptor.content_suite ||
            get_be16(proof + 3u) != descriptor.content_profile ||
            proof[23] != 0u)
        return PRP_ERR_ARGUMENT;
    leaf_index = get_be64(proof + 5u);
    leaf_count = get_be64(proof + 13u);
    level_count = get_be16(proof + 21u);
    current_count = descriptor.total_length == 0u ? 1u :
        ((descriptor.total_length - 1u) >> PRP_CONTENT_LEAF_ORDER) + 1u;
    if (leaf_count != current_count || leaf_index >= leaf_count ||
            level_count != descriptor.tree_height)
        return PRP_ERR_ARGUMENT;
    expected_leaf_len = leaf_index + 1u == leaf_count ?
        (size_t)(descriptor.total_length -
            (leaf_index << PRP_CONTENT_LEAF_ORDER)) : PRP_CONTENT_LEAF_BYTES;
    if (leaf_len != expected_leaf_len || (leaf == NULL && leaf_len != 0u) ||
            leaf_hash(descriptor.content_suite, leaf, leaf_len, digest,
                descriptor.root_digest_len) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    current_index = leaf_index;
    for (level = 1u; level <= level_count; level++) {
        uint8_t position, child_count;
        size_t sibling_len;

        if (proof_len - offset < 4u)
            return PRP_ERR_ARGUMENT;
        position = proof[offset];
        child_count = proof[offset + 1u];
        if (proof[offset + 2u] != 0u || proof[offset + 3u] != 0u ||
                (child_count != 1u && child_count != 2u) ||
                position >= child_count)
            return PRP_ERR_ARGUMENT;
        sibling_len = child_count == 2u ? descriptor.root_digest_len : 0u;
        if (proof_len - offset - 4u < sibling_len)
            return PRP_ERR_ARGUMENT;
        if ((current_index & 1u) != 0u) {
            if (child_count != 2u || position != 1u)
                return PRP_ERR_ARGUMENT;
            memcpy(children, proof + offset + 4u, sibling_len);
            memcpy(children + sibling_len, digest, sibling_len);
        } else if (current_index + 1u < current_count) {
            if (child_count != 2u || position != 0u)
                return PRP_ERR_ARGUMENT;
            memcpy(children, digest, sibling_len);
            memcpy(children + sibling_len, proof + offset + 4u, sibling_len);
        } else {
            if (child_count != 1u || position != 0u)
                return PRP_ERR_ARGUMENT;
            memcpy(children, digest, descriptor.root_digest_len);
        }
        rc = node_hash(descriptor.content_suite, level, child_count, children,
            descriptor.root_digest_len, digest);
        if (rc != PRP_OK)
            return rc;
        offset += 4u + sibling_len;
        current_index >>= 1;
        current_count = (current_count >> 1) + (current_count & 1u);
    }
    if (offset != proof_len || current_count != 1u)
        return PRP_ERR_ARGUMENT;
    return bytes_equal(digest, descriptor.root_digest,
        descriptor.root_digest_len) ? PRP_OK : PRP_ERR_CRYPTO;
}
