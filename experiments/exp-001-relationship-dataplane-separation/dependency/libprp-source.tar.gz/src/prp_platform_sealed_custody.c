#include "prp_platform_sealed_custody.h"

#include "prp_ed25519_blake3.h"
#include "prp_ed25519ctx.h"
#include "prp_hash.h"
#include "prp_identity_hybrid.h"
#include "prp_mldsa65.h"
#include "prp_pq.h"

#include <prp/wire_v4.h>

#include <stdlib.h>
#include <string.h>

#define CUSTODY_RECORD_HEADER_LEN 64U
#define CUSTODY_STORAGE_KEY_LEN (8U + PRP_PLATFORM_KEY_ID_LEN)
#define CUSTODY_MAX_HANDLES 16U
#define CUSTODY_MAX_PRIVATE PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN
#define CUSTODY_X25519_KEY_LEN 32U
#define CUSTODY_MLKEM_PRIVATE_TRAILER_LEN 64U
#define CUSTODY_BASE_PROPERTIES (PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE | \
    PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST | \
    PRP_CUSTODY_PROPERTY_ATOMIC_DURABLE)

struct custody_handle {
    uint64_t value;
    uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN];
    uint16_t suite;
    uint16_t profile;
    uint32_t purpose;
    uint64_t generation;
    void *keypair;
};

struct custody_context {
    prp_platform_sealed_custody_config_t config;
    uint64_t next_handle;
    struct custody_handle handles[CUSTODY_MAX_HANDLES];
};

struct session_keypair {
    uint8_t has_x25519;
    uint16_t kem_bits;
    uint8_t x25519_public[CUSTODY_X25519_KEY_LEN];
    uint8_t x25519_private[CUSTODY_X25519_KEY_LEN];
    uint8_t kem_public[PRP_MLKEM1024_PUBLIC_KEY_LEN];
    uint8_t kem_private[PRP_MLKEM1024_PRIVATE_KEY_LEN];
};

int prp_crypto_x25519_public_from_private(
    const uint8_t private_key[CUSTODY_X25519_KEY_LEN],
    uint8_t public_key[CUSTODY_X25519_KEY_LEN]);
int prp_crypto_x25519_dh(
    const uint8_t private_key[CUSTODY_X25519_KEY_LEN],
    const uint8_t public_key[CUSTODY_X25519_KEY_LEN],
    uint8_t output[CUSTODY_X25519_KEY_LEN]);

static uint64_t custody_properties(const struct custody_context *context)
{
    return CUSTODY_BASE_PROPERTIES |
        (context->config.protection_properties &
         PRP_CUSTODY_PROPERTY_USER_AUTHENTICATION);
}

static int forwarded_random(void *opaque, uint8_t *output, size_t output_len)
{
    struct custody_context *context = opaque;
    return context->config.random(context->config.context, output, output_len);
}

static int forwarded_load(void *opaque, const uint8_t *key, size_t key_len,
    uint8_t *value, size_t *value_len)
{
    struct custody_context *context = opaque;
    return context->config.storage_load(context->config.context, key, key_len,
        value, value_len);
}

static int forwarded_store(void *opaque, const uint8_t *key, size_t key_len,
    const uint8_t *value, size_t value_len)
{
    struct custody_context *context = opaque;
    return context->config.storage_store(context->config.context, key, key_len,
        value, value_len);
}

static int forwarded_delete(void *opaque, const uint8_t *key, size_t key_len)
{
    struct custody_context *context = opaque;
    return context->config.storage_delete(context->config.context, key, key_len);
}

static int forwarded_replace(void *opaque, const uint8_t *key, size_t key_len,
    const uint8_t *value, size_t value_len)
{
    struct custody_context *context = opaque;
    return context->config.storage_replace(context->config.context, key,
        key_len, value, value_len);
}

static int forwarded_flush(void *opaque)
{
    struct custody_context *context = opaque;
    return context->config.storage_flush(context->config.context);
}

static void erase(void *pointer, size_t length)
{
    volatile uint8_t *cursor = pointer;
    while (cursor != NULL && length-- != 0U)
        *cursor++ = 0U;
}

static void put16(uint8_t *out, uint16_t value)
{
    out[0] = (uint8_t)(value >> 8);
    out[1] = (uint8_t)value;
}

static void put32(uint8_t *out, uint32_t value)
{
    out[0] = (uint8_t)(value >> 24);
    out[1] = (uint8_t)(value >> 16);
    out[2] = (uint8_t)(value >> 8);
    out[3] = (uint8_t)value;
}

static void put64(uint8_t *out, uint64_t value)
{
    unsigned int i;
    for (i = 0U; i < 8U; i++)
        out[i] = (uint8_t)(value >> (56U - i * 8U));
}

static uint16_t get16(const uint8_t *in)
{
    return (uint16_t)(((uint16_t)in[0] << 8) | in[1]);
}

static uint32_t get32(const uint8_t *in)
{
    return ((uint32_t)in[0] << 24) | ((uint32_t)in[1] << 16) |
        ((uint32_t)in[2] << 8) | in[3];
}

static uint64_t get64(const uint8_t *in)
{
    uint64_t value = 0U;
    unsigned int i;
    for (i = 0U; i < 8U; i++)
        value = (value << 8) | in[i];
    return value;
}

static int identity_pair_valid(uint16_t suite, uint16_t profile)
{
    return suite == profile &&
        profile >= PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_256 &&
        profile <=
            PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_MLDSA87_BLAKE3_256;
}

static int identity_valid(uint16_t suite, uint16_t profile, uint32_t purpose)
{
    return identity_pair_valid(suite, profile) &&
        purpose == PRP_CUSTODY_PURPOSE_SIGN;
}

static int session_has_x25519(uint16_t suite)
{
    return suite == PRP_WIRE_V4_SESSION_X25519_CHACHA20POLY1305_BLAKE3 ||
        suite == PRP_WIRE_V4_SESSION_X25519_AES256GCM_BLAKE3 ||
        suite ==
            PRP_WIRE_V4_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3 ||
        suite ==
            PRP_WIRE_V4_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3;
}

static uint16_t session_kem_bits(uint16_t suite)
{
    if (suite ==
            PRP_WIRE_V4_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3 ||
            suite == PRP_WIRE_V4_SESSION_MLKEM768_AES256GCM_SHA256)
        return 768U;
    if (suite ==
            PRP_WIRE_V4_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3 ||
            suite == PRP_WIRE_V4_SESSION_MLKEM1024_AES256GCM_SHA384)
        return 1024U;
    return 0U;
}

static uint32_t session_purpose(uint16_t suite)
{
    uint32_t purpose = 0U;
    if (session_has_x25519(suite))
        purpose |= PRP_CUSTODY_PURPOSE_KEY_AGREEMENT;
    if (session_kem_bits(suite) != 0U)
        purpose |= PRP_CUSTODY_PURPOSE_DECAPSULATE;
    return purpose;
}

static int object_valid(uint16_t suite, uint16_t profile, uint32_t purpose)
{
    uint32_t expected = session_purpose(suite);
    return identity_valid(suite, profile, purpose) ||
        (profile == 0U && expected != 0U && purpose == expected);
}

static size_t identity_private_len(uint16_t profile)
{
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return PRP_ED25519CTX_PRIVATE_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return PRP_MLDSA65_PRIVATE_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return PRP_MLDSA87_PRIVATE_KEY_LEN;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN;
    default:
        return 0U;
    }
}

static size_t private_len(uint16_t suite, uint16_t profile)
{
    size_t length = 0U;
    uint16_t kem_bits;
    if (profile != 0U)
        return identity_private_len(profile);
    if (session_has_x25519(suite))
        length += CUSTODY_X25519_KEY_LEN;
    kem_bits = session_kem_bits(suite);
    if (kem_bits == 768U)
        length += PRP_MLKEM768_PRIVATE_KEY_LEN;
    else if (kem_bits == 1024U)
        length += PRP_MLKEM1024_PRIVATE_KEY_LEN;
    return length;
}

static size_t public_len(uint16_t suite, uint16_t profile)
{
    size_t length = 0U;
    uint16_t kem_bits;
    if (profile != 0U)
        return prp_identity_proof_public_key_len((uint8_t)profile);
    if (session_has_x25519(suite))
        length += CUSTODY_X25519_KEY_LEN;
    kem_bits = session_kem_bits(suite);
    if (kem_bits == 768U)
        length += PRP_MLKEM768_PUBLIC_KEY_LEN;
    else if (kem_bits == 1024U)
        length += PRP_MLKEM1024_PUBLIC_KEY_LEN;
    return length;
}

static size_t signature_len(uint16_t profile)
{
    return prp_identity_proof_signature_len((uint8_t)profile);
}

static void keypair_destroy(uint16_t suite, uint16_t profile, void *keypair)
{
    (void)suite;
    if (profile == 0U) {
        erase(keypair, sizeof(struct session_keypair));
        free(keypair);
        return;
    }
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        prp_ed25519_blake3_keypair_destroy(keypair); break;
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        prp_ed25519ctx_keypair_destroy(keypair); break;
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        prp_mldsa65_keypair_destroy(keypair); break;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        prp_mldsa87_keypair_destroy(keypair); break;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        prp_identity_hybrid_keypair_destroy(keypair); break;
    default:
        break;
    }
}

static int session_kem_validate(const struct session_keypair *session)
{
    uint8_t ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN];
    uint8_t expected[PRP_MLKEM1024_SHARED_SECRET_LEN];
    uint8_t actual[PRP_MLKEM1024_SHARED_SECRET_LEN];
    uint8_t seed[PRP_MLKEM1024_ENCAPS_SEED_LEN] = {0};
    int result;
    if (session->kem_bits == 768U) {
        result = prp_mlkem768_encapsulate_derand(ciphertext, expected,
            session->kem_public, seed);
        if (result == PRP_OK)
            result = prp_mlkem768_decapsulate(actual, ciphertext,
                session->kem_private);
    } else {
        result = prp_mlkem1024_encapsulate_derand(ciphertext, expected,
            session->kem_public, seed);
        if (result == PRP_OK)
            result = prp_mlkem1024_decapsulate(actual, ciphertext,
                session->kem_private);
    }
    if (result == PRP_OK && memcmp(expected, actual, sizeof(expected)) != 0)
        result = PRP_ERR_CRYPTO;
    erase(ciphertext, sizeof(ciphertext));
    erase(expected, sizeof(expected));
    erase(actual, sizeof(actual));
    return result;
}

static int session_keypair_import(uint16_t suite, const uint8_t *private_key,
    size_t length, void **keypair)
{
    struct session_keypair *session;
    size_t offset = 0U, public_offset;
    int result = PRP_OK;
    uint16_t kem_bits = session_kem_bits(suite);
    if (length != private_len(suite, 0U))
        return PRP_ERR_ARGUMENT;
    session = calloc(1U, sizeof(*session));
    if (session == NULL)
        return PRP_ERR_NO_MEMORY;
    session->has_x25519 = (uint8_t)session_has_x25519(suite);
    session->kem_bits = kem_bits;
    if (session->has_x25519) {
        memcpy(session->x25519_private, private_key,
            CUSTODY_X25519_KEY_LEN);
        offset += CUSTODY_X25519_KEY_LEN;
        if (prp_crypto_x25519_public_from_private(session->x25519_private,
                session->x25519_public) != 0)
            result = PRP_ERR_CRYPTO;
    }
    if (result == PRP_OK && kem_bits != 0U) {
        size_t private_size = kem_bits == 768U ?
            PRP_MLKEM768_PRIVATE_KEY_LEN : PRP_MLKEM1024_PRIVATE_KEY_LEN;
        size_t public_size = kem_bits == 768U ?
            PRP_MLKEM768_PUBLIC_KEY_LEN : PRP_MLKEM1024_PUBLIC_KEY_LEN;
        memcpy(session->kem_private, private_key + offset, private_size);
        /* FIPS 203 private-key encoding ends with H(ek) || z (32 bytes each). */
        public_offset = private_size - public_size -
            CUSTODY_MLKEM_PRIVATE_TRAILER_LEN;
        memcpy(session->kem_public, session->kem_private + public_offset,
            public_size);
        result = session_kem_validate(session);
    }
    if (result != PRP_OK) {
        keypair_destroy(suite, 0U, session);
        return result;
    }
    *keypair = session;
    return PRP_OK;
}

static int keypair_import(uint16_t suite, uint16_t profile,
    const uint8_t *private_key, size_t length, void **keypair)
{
    *keypair = NULL;
    if (profile == 0U)
        return session_keypair_import(suite, private_key, length, keypair);
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return prp_ed25519_blake3_keypair_import(
            (prp_ed25519_blake3_keypair_t **)keypair, private_key, length);
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return prp_ed25519ctx_keypair_import(
            (prp_ed25519ctx_keypair_t **)keypair, private_key, length);
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return prp_mldsa65_keypair_import(
            (prp_mldsa65_keypair_t **)keypair, private_key, length);
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return prp_mldsa87_keypair_import(
            (prp_mldsa87_keypair_t **)keypair, private_key, length);
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return prp_identity_hybrid_keypair_import(
            (prp_identity_hybrid_keypair_t **)keypair, private_key, length);
    default:
        return PRP_ERR_ARGUMENT;
    }
}

static prp_platform_t random_platform(struct custody_context *context)
{
    prp_platform_t platform;
    memset(&platform, 0, sizeof(platform));
    platform.abi_version = PRP_PLATFORM_ABI_VERSION;
    platform.struct_size = sizeof(platform);
    platform.capabilities = PRP_PLATFORM_CAP_RANDOM;
    platform.context = context->config.context;
    platform.random = context->config.random;
    return platform;
}

static int session_keypair_generate(struct custody_context *context,
    uint16_t suite, void **keypair)
{
    struct session_keypair *session = calloc(1U, sizeof(*session));
    prp_platform_t platform = random_platform(context);
    int result = PRP_OK;
    if (session == NULL)
        return PRP_ERR_NO_MEMORY;
    session->has_x25519 = (uint8_t)session_has_x25519(suite);
    session->kem_bits = session_kem_bits(suite);
    if (session->has_x25519) {
        result = context->config.random(context->config.context,
            session->x25519_private, sizeof(session->x25519_private));
        if (result == PRP_OK &&
                prp_crypto_x25519_public_from_private(
                    session->x25519_private, session->x25519_public) !=
                    0)
            result = PRP_ERR_CRYPTO;
    }
    if (result == PRP_OK && session->kem_bits == 768U)
        result = prp_mlkem768_keypair_generate_with_platform(
            session->kem_public, session->kem_private, &platform);
    else if (result == PRP_OK && session->kem_bits == 1024U)
        result = prp_mlkem1024_keypair_generate_with_platform(
            session->kem_public, session->kem_private, &platform);
    if (result != PRP_OK) {
        keypair_destroy(suite, 0U, session);
        return result;
    }
    *keypair = session;
    return PRP_OK;
}

static int keypair_generate(struct custody_context *context, uint16_t suite,
    uint16_t profile, void **keypair)
{
    prp_platform_t platform = random_platform(context);
    *keypair = NULL;
    if (profile == 0U)
        return session_keypair_generate(context, suite, keypair);
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return prp_ed25519_blake3_keypair_generate_with_platform(
            (prp_ed25519_blake3_keypair_t **)keypair, &platform);
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return prp_ed25519ctx_keypair_generate_with_platform(
            (prp_ed25519ctx_keypair_t **)keypair, &platform);
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return prp_mldsa65_keypair_generate_with_platform(
            (prp_mldsa65_keypair_t **)keypair, &platform);
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return prp_mldsa87_keypair_generate_with_platform(
            (prp_mldsa87_keypair_t **)keypair, &platform);
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return prp_identity_hybrid_keypair_generate_with_platform(
            (prp_identity_hybrid_keypair_t **)keypair, &platform);
    default:
        return PRP_ERR_ARGUMENT;
    }
}

static int session_keypair_export(uint16_t suite, void *keypair,
    int private_part, uint8_t *output, size_t capacity, size_t *written)
{
    struct session_keypair *session = keypair;
    size_t offset = 0U;
    size_t required = private_part ? private_len(suite, 0U) :
        public_len(suite, 0U);
    if (capacity < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (session->has_x25519) {
        memcpy(output, private_part ? session->x25519_private :
            session->x25519_public, CUSTODY_X25519_KEY_LEN);
        offset += CUSTODY_X25519_KEY_LEN;
    }
    if (session->kem_bits != 0U) {
        size_t length = private_part ?
            (session->kem_bits == 768U ? PRP_MLKEM768_PRIVATE_KEY_LEN :
             PRP_MLKEM1024_PRIVATE_KEY_LEN) :
            (session->kem_bits == 768U ? PRP_MLKEM768_PUBLIC_KEY_LEN :
             PRP_MLKEM1024_PUBLIC_KEY_LEN);
        memcpy(output + offset, private_part ? session->kem_private :
            session->kem_public, length);
        offset += length;
    }
    *written = offset;
    return PRP_OK;
}

static int keypair_export(uint16_t suite, uint16_t profile, void *keypair,
    int private_part, uint8_t *output, size_t capacity, size_t *written)
{
    if (profile == 0U)
        return session_keypair_export(suite, keypair, private_part, output,
            capacity, written);
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return private_part ? prp_ed25519_blake3_private_key_export(keypair,
            output, capacity, written) : prp_ed25519_blake3_public_key_export(
            keypair, output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return private_part ? prp_ed25519ctx_private_key_export(keypair,
            output, capacity, written) : prp_ed25519ctx_public_key_export(
            keypair, output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return private_part ? prp_mldsa65_private_key_export(keypair, output,
            capacity, written) : prp_mldsa65_public_key_export(keypair,
            output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return private_part ? prp_mldsa87_private_key_export(keypair, output,
            capacity, written) : prp_mldsa87_public_key_export(keypair,
            output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return private_part ? prp_identity_hybrid_private_key_export(keypair,
            output, capacity, written) : prp_identity_hybrid_public_key_export(
            keypair, output, capacity, written);
    default:
        return PRP_ERR_ARGUMENT;
    }
}

static int keypair_sign(struct custody_context *context,
    struct custody_handle *handle, const uint8_t *input, size_t input_len,
    uint8_t *output, size_t capacity, size_t *written)
{
    prp_platform_t platform = random_platform(context);
    switch (handle->profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return prp_ed25519_blake3_sign(handle->keypair, input, input_len,
            output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return prp_ed25519ctx_sign(handle->keypair, input, input_len, output,
            capacity, written);
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return prp_mldsa65_sign_with_platform(handle->keypair, input,
            input_len, &platform, output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return prp_mldsa87_sign_with_platform(handle->keypair, input,
            input_len, &platform, output, capacity, written);
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return prp_identity_hybrid_sign_with_platform(handle->keypair, input,
            input_len, &platform, output, capacity, written);
    default:
        return PRP_ERR_ARGUMENT;
    }
}

static void storage_key(const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    uint8_t key[CUSTODY_STORAGE_KEY_LEN])
{
    static const uint8_t prefix[8] = {'P','R','P','C','S','T','2',0};
    memcpy(key, prefix, sizeof(prefix));
    memcpy(key + sizeof(prefix), key_id, PRP_PLATFORM_KEY_ID_LEN);
}

static struct custody_handle *find_handle(struct custody_context *context,
    uint64_t value)
{
    size_t i;
    for (i = 0U; i < CUSTODY_MAX_HANDLES; i++)
        if (context->handles[i].value == value)
            return &context->handles[i];
    return NULL;
}

static struct custody_handle *add_handle(struct custody_context *context,
    const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN], uint16_t suite,
    uint16_t profile, uint32_t purpose, uint64_t generation, void *keypair)
{
    size_t i;
    for (i = 0U; i < CUSTODY_MAX_HANDLES; i++) {
        struct custody_handle *handle = &context->handles[i];
        if (handle->value == 0U) {
            context->next_handle++;
            if (context->next_handle == 0U)
                context->next_handle++;
            handle->value = context->next_handle;
            memcpy(handle->key_id, key_id, PRP_PLATFORM_KEY_ID_LEN);
            handle->suite = suite;
            handle->profile = profile;
            handle->purpose = purpose;
            handle->generation = generation;
            handle->keypair = keypair;
            return handle;
        }
    }
    return NULL;
}

static int handle_slot_available(const struct custody_context *context)
{
    size_t i;
    for (i = 0U; i < CUSTODY_MAX_HANDLES; i++)
        if (context->handles[i].value == 0U)
            return 1;
    return 0;
}

static void drop_handle(struct custody_handle *handle)
{
    if (handle != NULL) {
        keypair_destroy(handle->suite, handle->profile, handle->keypair);
        erase(handle, sizeof(*handle));
    }
}

static size_t component_count(uint16_t suite, uint16_t profile)
{
    if (profile ==
            PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_MLDSA87_BLAKE3_256)
        return 2U;
    if (profile == 0U && session_has_x25519(suite) &&
            session_kem_bits(suite) != 0U)
        return 2U;
    return 1U;
}

static void result_metadata(const prp_platform_custody_request_t *request,
    const struct custody_handle *opened,
    uint64_t properties, prp_platform_custody_result_t *result, uint64_t handle,
    uint64_t generation)
{
    memcpy(result->key_id, opened != NULL ? opened->key_id : request->key_id,
        PRP_PLATFORM_KEY_ID_LEN);
    result->negotiated_suite = opened != NULL ? opened->suite :
        request->negotiated_suite;
    result->algorithm_profile = opened != NULL ? opened->profile :
        request->algorithm_profile;
    result->purpose = opened != NULL ? opened->purpose : request->purpose;
    result->key_handle = handle;
    result->actual_properties = properties;
    result->generation = generation;
    result->component_count = (uint32_t)component_count(
        result->negotiated_suite, result->algorithm_profile);
    result->public_output_len = public_len(result->negotiated_suite,
        result->algorithm_profile);
}

static int components_emit(const prp_platform_custody_request_t *request,
    uint16_t suite, uint16_t requested_profile, uint64_t properties)
{
    size_t count = component_count(suite, requested_profile);
    size_t i;
    if (request->components == NULL || request->component_capacity < count)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    for (i = 0U; i < count; i++) {
        prp_platform_custody_component_t *component = &request->components[i];
        uint16_t profile = requested_profile;
        uint32_t purpose = PRP_CUSTODY_PURPOSE_SIGN;
        size_t offset = 0U, length;
        if (requested_profile != 0U) {
            if (count == 2U)
                profile = i == 0U ?
                    PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_256 :
                    PRP_WIRE_V4_IDENTITY_MLDSA87_SHA384_384;
            length = public_len(profile, profile);
            if (i != 0U)
                offset = PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN;
        } else if (session_has_x25519(suite) && i == 0U) {
            purpose = PRP_CUSTODY_PURPOSE_KEY_AGREEMENT;
            length = CUSTODY_X25519_KEY_LEN;
        } else {
            purpose = PRP_CUSTODY_PURPOSE_DECAPSULATE;
            length = session_kem_bits(suite) == 768U ?
                PRP_MLKEM768_PUBLIC_KEY_LEN : PRP_MLKEM1024_PUBLIC_KEY_LEN;
            if (session_has_x25519(suite))
                offset = CUSTODY_X25519_KEY_LEN;
        }
        memset(component, 0, sizeof(*component));
        component->abi_version = PRP_PLATFORM_CUSTODY_ABI_VERSION;
        component->struct_size = sizeof(*component);
        component->negotiated_suite = requested_profile != 0U ? profile : suite;
        component->algorithm_profile = profile;
        component->purpose = purpose;
        component->actual_properties = properties;
        component->public_key_offset = offset;
        component->public_key_len = length;
    }
    return PRP_OK;
}

static void record_header(uint8_t header[CUSTODY_RECORD_HEADER_LEN],
    const prp_platform_custody_request_t *request, uint64_t generation,
    uint64_t properties, size_t public_size, size_t sealed_size)
{
    memset(header, 0, CUSTODY_RECORD_HEADER_LEN);
    memcpy(header, "PRPCST2", 7U);
    put16(header + 8U, request->negotiated_suite);
    put16(header + 10U, request->algorithm_profile);
    put32(header + 12U, request->purpose);
    put64(header + 16U, properties);
    put64(header + 24U, generation);
    put32(header + 32U, (uint32_t)public_size);
    put32(header + 36U, (uint32_t)sealed_size);
}

static int persist(struct custody_context *context,
    const prp_platform_custody_request_t *request, void *keypair,
    uint64_t generation)
{
    uint8_t private_key[CUSTODY_MAX_PRIVATE];
    uint8_t *public_key = NULL, *sealed = NULL, *record = NULL, *aad = NULL;
    uint8_t header[CUSTODY_RECORD_HEADER_LEN], key[CUSTODY_STORAGE_KEY_LEN];
    size_t private_size = private_len(request->negotiated_suite,
        request->algorithm_profile);
    size_t public_size = public_len(request->negotiated_suite,
        request->algorithm_profile);
    size_t sealed_size = 0U, expected_sealed_size, written = 0U;
    uint64_t properties = custody_properties(context);
    int result;

    public_key = malloc(public_size);
    if (public_key == NULL)
        return PRP_ERR_NO_MEMORY;
    result = keypair_export(request->negotiated_suite,
        request->algorithm_profile, keypair, 0,
        public_key, public_size, &written);
    if (result != PRP_OK || written != public_size)
        goto done;
    result = keypair_export(request->negotiated_suite,
        request->algorithm_profile, keypair, 1,
        private_key, sizeof(private_key), &written);
    if (result != PRP_OK || written != private_size)
        goto done;
    aad = malloc(CUSTODY_RECORD_HEADER_LEN + public_size);
    if (aad == NULL) {
        result = PRP_ERR_NO_MEMORY;
        goto done;
    }
    record_header(header, request, generation, properties, public_size, 0U);
    memcpy(aad, header, sizeof(header));
    memcpy(aad + sizeof(header), public_key, public_size);
    result = context->config.protect(context->config.context, request->key_id,
        aad, CUSTODY_RECORD_HEADER_LEN + public_size, private_key, private_size,
        NULL, &sealed_size);
    if (result != PRP_ERR_OUTPUT_TOO_SMALL || sealed_size == 0U) {
        if (result == PRP_OK)
            result = PRP_ERR_STATE;
        goto done;
    }
    sealed = malloc(sealed_size);
    record = malloc(CUSTODY_RECORD_HEADER_LEN + public_size + sealed_size);
    if (sealed == NULL || record == NULL) {
        result = PRP_ERR_NO_MEMORY;
        goto done;
    }
    record_header(header, request, generation, properties, public_size,
        sealed_size);
    memcpy(aad, header, sizeof(header));
    expected_sealed_size = sealed_size;
    result = context->config.protect(context->config.context, request->key_id,
        aad, CUSTODY_RECORD_HEADER_LEN + public_size, private_key, private_size,
        sealed, &sealed_size);
    if (result != PRP_OK)
        goto done;
    if (sealed_size != expected_sealed_size) {
        result = PRP_ERR_STATE;
        goto done;
    }
    record_header(header, request, generation, properties, public_size,
        sealed_size);
    memcpy(record, header, sizeof(header));
    memcpy(record + sizeof(header), public_key, public_size);
    memcpy(record + sizeof(header) + public_size, sealed, sealed_size);
    storage_key(request->key_id, key);
    result = context->config.storage_store(context->config.context, key,
        sizeof(key), record, sizeof(header) + public_size + sealed_size);
    if (result == PRP_OK) {
        result = context->config.storage_flush(context->config.context);
        if (result != PRP_OK) {
            int flush_result = result;

            /* Best-effort rollback keeps an ordinary retry unambiguous. */
            (void)context->config.storage_delete(context->config.context, key,
                sizeof(key));
            (void)context->config.storage_flush(context->config.context);
            result = flush_result;
        }
    }
done:
    erase(private_key, sizeof(private_key));
    if (sealed != NULL) erase(sealed, sealed_size);
    if (record != NULL) erase(record, CUSTODY_RECORD_HEADER_LEN + public_size + sealed_size);
    free(public_key);
    free(aad);
    free(sealed);
    free(record);
    return result;
}

static int load_keypair(struct custody_context *context,
    const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN], uint16_t *suite,
    uint16_t *profile, uint32_t *purpose, uint64_t *generation,
    void **keypair, uint8_t **public_key, size_t *public_size)
{
    uint8_t key[CUSTODY_STORAGE_KEY_LEN], private_key[CUSTODY_MAX_PRIVATE];
    uint8_t *record = NULL;
    size_t record_size = 0U, private_size = sizeof(private_key);
    uint32_t stored_public, sealed_size;
    int result;
    storage_key(key_id, key);
    result = context->config.storage_load(context->config.context, key,
        sizeof(key), NULL, &record_size);
    if (result != PRP_ERR_OUTPUT_TOO_SMALL)
        return result == PRP_OK ? PRP_ERR_STATE : result;
    if (record_size < CUSTODY_RECORD_HEADER_LEN)
        return PRP_ERR_STATE;
    record = malloc(record_size);
    if (record == NULL)
        return PRP_ERR_NO_MEMORY;
    result = context->config.storage_load(context->config.context, key,
        sizeof(key), record, &record_size);
    if (result != PRP_OK)
        goto done;
    if (record_size < CUSTODY_RECORD_HEADER_LEN ||
            memcmp(record, "PRPCST2", 7U) != 0) {
        result = PRP_ERR_STATE;
        goto done;
    }
    *suite = get16(record + 8U);
    *profile = get16(record + 10U);
    *purpose = get32(record + 12U);
    *generation = get64(record + 24U);
    stored_public = get32(record + 32U);
    sealed_size = get32(record + 36U);
    if (!object_valid(*suite, *profile, *purpose) ||
            get64(record + 16U) != custody_properties(context) ||
            stored_public != public_len(*suite, *profile) ||
            stored_public > record_size - CUSTODY_RECORD_HEADER_LEN ||
            sealed_size != record_size - CUSTODY_RECORD_HEADER_LEN -
                stored_public ||
            CUSTODY_RECORD_HEADER_LEN + stored_public + sealed_size != record_size) {
        result = PRP_ERR_STATE;
        goto done;
    }
    result = context->config.unprotect(context->config.context, key_id,
        record, CUSTODY_RECORD_HEADER_LEN + stored_public,
        record + CUSTODY_RECORD_HEADER_LEN + stored_public, sealed_size,
        private_key, &private_size);
    if (result != PRP_OK || private_size != private_len(*suite, *profile)) {
        if (result == PRP_OK) result = PRP_ERR_CRYPTO;
        goto done;
    }
    result = keypair_import(*suite, *profile, private_key, private_size,
        keypair);
    if (result != PRP_OK)
        goto done;
    *public_key = malloc(stored_public);
    if (*public_key == NULL) {
        keypair_destroy(*suite, *profile, *keypair);
        *keypair = NULL;
        result = PRP_ERR_NO_MEMORY;
        goto done;
    }
    memcpy(*public_key, record + CUSTODY_RECORD_HEADER_LEN, stored_public);
    *public_size = stored_public;
done:
    erase(private_key, sizeof(private_key));
    if (record != NULL) erase(record, record_size);
    free(record);
    return result;
}

static int custody_query(void *opaque,
    const prp_platform_custody_query_t *query,
    prp_platform_custody_capabilities_t *capabilities)
{
    struct custody_context *context = opaque;
    uint64_t properties = custody_properties(context);
    uint32_t expected_purpose = session_purpose(query->negotiated_suite);
    int identity = identity_pair_valid(query->negotiated_suite,
        query->algorithm_profile) &&
        (query->purpose == 0U ||
         query->purpose == PRP_CUSTODY_PURPOSE_SIGN);
    int session = query->algorithm_profile == 0U && expected_purpose != 0U;
    int wildcard = query->operation == PRP_CUSTODY_OP_OPEN ||
        query->operation == PRP_CUSTODY_OP_CLOSE ||
        query->operation == PRP_CUSTODY_OP_INFO ||
        query->operation == PRP_CUSTODY_OP_PUBLIC_EXPORT ||
        query->operation == PRP_CUSTODY_OP_PRIVATE_EXPORT ||
        query->operation == PRP_CUSTODY_OP_DELETE;
    if ((wildcard &&
         !((query->negotiated_suite == 0U && query->algorithm_profile == 0U &&
            query->purpose == 0U) || identity ||
           (session && (query->purpose == 0U ||
            (query->purpose & ~expected_purpose) == 0U)))) ||
        (!wildcard && !identity &&
         !(session && query->purpose != 0U &&
           (query->purpose & ~expected_purpose) == 0U)) ||
        (query->operation == PRP_CUSTODY_OP_SIGN && !identity) ||
        (query->operation == PRP_CUSTODY_OP_DECAPSULATE &&
         (!session ||
          (expected_purpose & PRP_CUSTODY_PURPOSE_DECAPSULATE) == 0U)) ||
        (query->operation == PRP_CUSTODY_OP_KEY_AGREEMENT &&
         (!session ||
           (expected_purpose & PRP_CUSTODY_PURPOSE_KEY_AGREEMENT) == 0U)) ||
        ((query->operation == PRP_CUSTODY_OP_CREATE ||
          query->operation == PRP_CUSTODY_OP_IMPORT) && session &&
         query->purpose != expected_purpose) ||
        (query->required_properties & ~properties) != 0U)
        return PRP_ERR_UNAVAILABLE;
    capabilities->operations = PRP_CUSTODY_OPERATION_MASK &
        ~(PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_SIGN) |
          PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_DECAPSULATE) |
          PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_KEY_AGREEMENT));
    if (identity || (wildcard && query->negotiated_suite == 0U))
        capabilities->operations |=
            PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_SIGN);
    if ((expected_purpose & PRP_CUSTODY_PURPOSE_DECAPSULATE) != 0U ||
            (wildcard && query->negotiated_suite == 0U))
        capabilities->operations |=
            PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_DECAPSULATE);
    if ((expected_purpose & PRP_CUSTODY_PURPOSE_KEY_AGREEMENT) != 0U ||
            (wildcard && query->negotiated_suite == 0U))
        capabilities->operations |=
            PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_KEY_AGREEMENT);
    capabilities->purposes = wildcard ? PRP_CUSTODY_PURPOSE_MASK :
        (identity ? PRP_CUSTODY_PURPOSE_SIGN : expected_purpose);
    capabilities->properties = properties;
    capabilities->max_components = wildcard ? 2U :
        (uint32_t)component_count(query->negotiated_suite,
            query->algorithm_profile);
    return PRP_OK;
}

static int custody_crypto(void *opaque, const prp_platform_request_t *request,
    size_t *output_len, size_t *secondary_output_len)
{
    struct custody_context *context = opaque;
    struct custody_handle *handle = find_handle(context, request->key_handle);
    struct session_keypair *session;
    size_t required;
    (void)secondary_output_len;
    if (handle == NULL || handle->suite != request->negotiated_suite ||
            handle->profile != request->algorithm_profile)
        return PRP_ERR_NOT_FOUND;
    if (request->crypto_operation == PRP_CRYPTO_OP_SIGN) {
        if ((handle->purpose & PRP_CUSTODY_PURPOSE_SIGN) == 0U)
            return PRP_ERR_POLICY;
        required = signature_len(handle->profile);
        *output_len = required;
        if (request->output_capacity < required)
            return PRP_ERR_OUTPUT_TOO_SMALL;
        return keypair_sign(context, handle, request->input,
            request->input_len, request->output, request->output_capacity,
            output_len);
    }
    session = handle->keypair;
    required = PRP_MLKEM1024_SHARED_SECRET_LEN;
    *output_len = required;
    if (request->output_capacity < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (request->crypto_operation == PRP_CRYPTO_OP_KEY_AGREEMENT &&
            session->has_x25519 &&
            request->input_len == CUSTODY_X25519_KEY_LEN)
        return prp_crypto_x25519_dh(session->x25519_private, request->input,
            request->output) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
    if (request->crypto_operation == PRP_CRYPTO_OP_KEM_DECAPSULATE &&
            session->kem_bits == 768U &&
            request->input_len == PRP_MLKEM768_CIPHERTEXT_LEN)
        return prp_mlkem768_decapsulate(request->output, request->input,
            session->kem_private);
    if (request->crypto_operation == PRP_CRYPTO_OP_KEM_DECAPSULATE &&
            session->kem_bits == 1024U &&
            request->input_len == PRP_MLKEM1024_CIPHERTEXT_LEN)
        return prp_mlkem1024_decapsulate(request->output, request->input,
            session->kem_private);
    return PRP_ERR_ARGUMENT;
}

static int custody_execute(void *opaque,
    const prp_platform_custody_request_t *request,
    prp_platform_custody_result_t *result)
{
    struct custody_context *context = opaque;
    struct custody_handle *handle;
    void *keypair = NULL;
    uint8_t *stored_public = NULL;
    uint16_t suite = request->negotiated_suite, profile = request->algorithm_profile;
    uint32_t purpose = request->purpose;
    uint64_t generation = 1U;
    size_t stored_public_size = 0U, written;
    int status;

    if (request->operation == PRP_CUSTODY_OP_CLOSE ||
            request->operation == PRP_CUSTODY_OP_INFO ||
            request->operation == PRP_CUSTODY_OP_PUBLIC_EXPORT ||
            request->operation == PRP_CUSTODY_OP_PRIVATE_EXPORT) {
        handle = find_handle(context, request->key_handle);
        if (handle == NULL)
            return PRP_ERR_NOT_FOUND;
        result_metadata(request, handle, custody_properties(context), result,
            handle->value,
            handle->generation);
        if (request->operation == PRP_CUSTODY_OP_CLOSE) {
            result->component_count = 0U;
            result->public_output_len = 0U;
            drop_handle(handle);
            result->key_handle = 0U;
            return PRP_OK;
        }
        if (request->operation == PRP_CUSTODY_OP_PRIVATE_EXPORT) {
            result->component_count = 0U;
            result->public_output_len = 0U;
            result->output_len = private_len(handle->suite, handle->profile);
            if (request->output == NULL || request->output_capacity < result->output_len)
                return PRP_ERR_OUTPUT_TOO_SMALL;
            return keypair_export(handle->suite, handle->profile,
                handle->keypair, 1,
                request->output, request->output_capacity, &result->output_len);
        }
        result->public_output_len = public_len(handle->suite, handle->profile);
        result->output_len = request->operation == PRP_CUSTODY_OP_PUBLIC_EXPORT ?
            result->public_output_len : 0U;
        if (request->operation == PRP_CUSTODY_OP_INFO &&
                (request->public_output == NULL ||
                 request->public_output_capacity < result->public_output_len ||
                 components_emit(request, handle->suite, handle->profile,
                     custody_properties(context)) != PRP_OK))
            return PRP_ERR_OUTPUT_TOO_SMALL;
        if (request->operation == PRP_CUSTODY_OP_INFO)
            return keypair_export(handle->suite, handle->profile,
                handle->keypair, 0,
                request->public_output, request->public_output_capacity, &written);
        result->component_count = 0U;
        result->public_output_len = 0U;
        if (request->output == NULL || request->output_capacity < result->output_len)
            return PRP_ERR_OUTPUT_TOO_SMALL;
        return keypair_export(handle->suite, handle->profile,
            handle->keypair, 0,
            request->output, request->output_capacity, &result->output_len);
    }

    if (request->operation == PRP_CUSTODY_OP_DELETE) {
        uint8_t key[CUSTODY_STORAGE_KEY_LEN];
        size_t record_size = 0U;
        size_t i;
        int deleted = 0;
        result->actual_properties = custody_properties(context);
        storage_key(request->key_id, key);
        status = context->config.storage_load(context->config.context, key,
            sizeof(key), NULL, &record_size);
        if (status == PRP_ERR_OUTPUT_TOO_SMALL)
            status = context->config.storage_delete(context->config.context,
                key, sizeof(key));
        else if (status == PRP_OK)
            status = PRP_ERR_STATE;
        if (status == PRP_OK) {
            deleted = 1;
            status = context->config.storage_flush(context->config.context);
        }
        if (deleted)
            for (i = 0U; i < CUSTODY_MAX_HANDLES; i++)
                if (context->handles[i].value != 0U &&
                    memcmp(context->handles[i].key_id, request->key_id,
                        PRP_PLATFORM_KEY_ID_LEN) == 0)
                    drop_handle(&context->handles[i]);
        return status;
    }

    result_metadata(request, NULL, custody_properties(context), result, 0U,
        generation);
    if (request->operation != PRP_CUSTODY_OP_OPEN &&
            (request->public_output == NULL ||
             request->public_output_capacity < result->public_output_len ||
             components_emit(request, request->negotiated_suite,
                 request->algorithm_profile,
                 custody_properties(context)) != PRP_OK))
        return PRP_ERR_OUTPUT_TOO_SMALL;

    if (!handle_slot_available(context))
        return PRP_ERR_UNAVAILABLE;

    if (request->operation == PRP_CUSTODY_OP_CREATE ||
            request->operation == PRP_CUSTODY_OP_IMPORT) {
        uint8_t key[CUSTODY_STORAGE_KEY_LEN];
        size_t existing_size = 0U;
        storage_key(request->key_id, key);
        status = context->config.storage_load(context->config.context, key,
            sizeof(key), NULL, &existing_size);
        if (status == PRP_ERR_OUTPUT_TOO_SMALL || status == PRP_OK)
            return PRP_ERR_ALREADY;
        if (status != PRP_ERR_NOT_FOUND)
            return status;
    }

    if (request->operation == PRP_CUSTODY_OP_CREATE)
        status = keypair_generate(context, suite, profile, &keypair);
    else if (request->operation == PRP_CUSTODY_OP_IMPORT)
        status = keypair_import(suite, profile, request->input,
            request->input_len, &keypair);
    else if (request->operation == PRP_CUSTODY_OP_OPEN)
        status = load_keypair(context, request->key_id, &suite, &profile,
            &purpose, &generation, &keypair, &stored_public,
            &stored_public_size);
    else
        return PRP_ERR_UNAVAILABLE;
    if (status != PRP_OK)
        goto done;
    if (request->operation == PRP_CUSTODY_OP_OPEN &&
            ((request->negotiated_suite != 0U && request->negotiated_suite != suite) ||
             (request->algorithm_profile != 0U && request->algorithm_profile != profile) ||
             (request->purpose != 0U && request->purpose != purpose))) {
        status = PRP_ERR_POLICY;
        goto done;
    }
    if (request->operation == PRP_CUSTODY_OP_OPEN) {
        result->negotiated_suite = suite;
        result->algorithm_profile = profile;
        result->purpose = purpose;
        result->generation = generation;
        result->component_count = (uint32_t)component_count(suite, profile);
        result->public_output_len = stored_public_size;
        if (request->public_output == NULL ||
                request->public_output_capacity < stored_public_size ||
                components_emit(request, suite, profile,
                    custody_properties(context)) != PRP_OK) {
            status = PRP_ERR_OUTPUT_TOO_SMALL;
            goto done;
        }
    }
    if (request->operation != PRP_CUSTODY_OP_OPEN) {
        status = persist(context, request, keypair, generation);
        if (status != PRP_OK)
            goto done;
    }
    handle = add_handle(context, request->key_id, suite, profile, purpose,
        generation, keypair);
    if (handle == NULL) {
        status = PRP_ERR_UNAVAILABLE;
        goto done;
    }
    keypair = NULL;
    result->negotiated_suite = suite;
    result->algorithm_profile = profile;
    result->purpose = purpose;
    result->key_handle = handle->value;
    result->generation = generation;
    if (stored_public != NULL) {
        memcpy(request->public_output, stored_public, stored_public_size);
        result->public_output_len = stored_public_size;
    } else {
        status = keypair_export(suite, profile, handle->keypair, 0,
            request->public_output, request->public_output_capacity, &written);
        if (status != PRP_OK) {
            drop_handle(handle);
            goto done;
        }
    }
    status = PRP_OK;
done:
    if (keypair != NULL)
        keypair_destroy(suite, profile, keypair);
    free(stored_public);
    return status;
}

int prp_platform_sealed_custody_initialize(prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config)
{
    struct custody_context *context;
    if (platform == NULL || config == NULL ||
            config->abi_version !=
                PRP_PLATFORM_SEALED_CUSTODY_CONFIG_VERSION ||
            config->struct_size < sizeof(*config) || config->random == NULL ||
            (config->protection_properties &
             ~(PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST |
               PRP_CUSTODY_PROPERTY_USER_AUTHENTICATION)) != 0U ||
            (config->protection_properties &
             PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST) == 0U ||
            config->storage_load == NULL || config->storage_store == NULL ||
            config->storage_delete == NULL || config->storage_replace == NULL ||
            config->storage_flush == NULL || config->protect == NULL ||
            config->unprotect == NULL)
        return PRP_ERR_ARGUMENT;
    context = calloc(1U, sizeof(*context));
    if (context == NULL)
        return PRP_ERR_NO_MEMORY;
    context->config = *config;
    memset(platform, 0, sizeof(*platform));
    platform->abi_version = PRP_PLATFORM_ABI_VERSION;
    platform->struct_size = sizeof(*platform);
    platform->capabilities = PRP_PLATFORM_CAP_RANDOM |
        PRP_PLATFORM_CAP_CRYPTO | PRP_PLATFORM_CAP_KEY_CUSTODY |
        PRP_PLATFORM_CAP_STORAGE | PRP_PLATFORM_CAP_STORAGE_ATOMIC |
        PRP_PLATFORM_CAP_STORAGE_DURABLE;
    platform->context = context;
    platform->crypto = custody_crypto;
    platform->random = forwarded_random;
    platform->storage_load = forwarded_load;
    platform->storage_store = forwarded_store;
    platform->storage_delete = forwarded_delete;
    platform->storage_replace = forwarded_replace;
    platform->storage_flush = forwarded_flush;
    platform->custody_query = custody_query;
    platform->custody_execute = custody_execute;
    return PRP_OK;
}

void prp_platform_sealed_custody_destroy(prp_platform_t *platform)
{
    size_t i;
    struct custody_context *context;
    if (platform == NULL || platform->custody_execute != custody_execute)
        return;
    context = platform->context;
    for (i = 0U; i < CUSTODY_MAX_HANDLES; i++)
        drop_handle(&context->handles[i]);
    erase(context, sizeof(*context));
    free(context);
    memset(platform, 0, sizeof(*platform));
}
