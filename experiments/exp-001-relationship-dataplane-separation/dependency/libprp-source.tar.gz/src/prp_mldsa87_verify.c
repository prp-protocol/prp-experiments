#include "prp_pq_internal.h"

#include <mldsa_native.h>
#include <prp/wire_v4_crypto.h>
#include <string.h>

static const uint8_t mldsa87_hs2_prefix[] =
    "\x00\x0d" PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;
static const uint8_t mldsa87_discovery_context[] = "PRP-DISCOVERY-v1";
static const uint8_t mldsa87_discovery_prefix[] =
    "\x00\x10" "PRP-DISCOVERY-v1";

int prp_mldsa87_verify_canonical(const uint8_t *public_key,
    const uint8_t *signature, const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len)
{
    const uint8_t *prefix;
    size_t prefix_len;

    if (public_key == NULL || signature == NULL || message == NULL ||
            context == NULL)
        return -1;
    if (context_len == PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN &&
            memcmp(context, PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT,
                context_len) == 0) {
        prefix = mldsa87_hs2_prefix;
        prefix_len = sizeof(mldsa87_hs2_prefix) - 1u;
    } else if (context_len == sizeof(mldsa87_discovery_context) - 1u &&
            memcmp(context, mldsa87_discovery_context, context_len) == 0) {
        prefix = mldsa87_discovery_prefix;
        prefix_len = sizeof(mldsa87_discovery_prefix) - 1u;
    } else {
        return -1;
    }
    return prp_thirdparty_mldsa87_verify_internal(signature, message,
        message_len, prefix, prefix_len, public_key, 0) == 0 ? 0 : -1;
}
