#include "prp_pq.h"
#include "prp_platform.h"

static void erase_bytes(unsigned char *bytes, size_t length)
{
    volatile unsigned char *cursor = bytes;
    while (length-- != 0U)
        *cursor++ = 0U;
}

static prp_status_t random_bytes(const prp_platform_t *platform,
    unsigned char *output, size_t length)
{
    int result = prp_platform_validate(platform, PRP_PLATFORM_CAP_RANDOM);
    if (result != PRP_OK)
        return (prp_status_t)result;
    result = platform->random(platform->context, output, length);
    return result > 0 ? PRP_ERR_STATE : (prp_status_t)result;
}

#define DEFINE_MLKEM_PLATFORM(bits, KEY_SEED_LEN, ENCAPS_SEED_LEN) \
prp_status_t prp_mlkem##bits##_keypair_generate_with_platform( \
    unsigned char *public_key, unsigned char *private_key, \
    const prp_platform_t *platform) \
{ \
    unsigned char seed[KEY_SEED_LEN]; \
    prp_status_t result; \
    if (public_key == NULL || private_key == NULL) \
        return PRP_ERR_ARGUMENT; \
    result = random_bytes(platform, seed, sizeof(seed)); \
    if (result == PRP_OK) \
        result = prp_mlkem##bits##_keypair_derand(public_key, private_key, \
            seed); \
    erase_bytes(seed, sizeof(seed)); \
    return result; \
} \
prp_status_t prp_mlkem##bits##_encapsulate_with_platform( \
    unsigned char *ciphertext, unsigned char *shared_secret, \
    const unsigned char *public_key, const prp_platform_t *platform) \
{ \
    unsigned char seed[ENCAPS_SEED_LEN]; \
    prp_status_t result; \
    if (ciphertext == NULL || shared_secret == NULL || public_key == NULL) \
        return PRP_ERR_ARGUMENT; \
    result = random_bytes(platform, seed, sizeof(seed)); \
    if (result == PRP_OK) \
        result = prp_mlkem##bits##_encapsulate_derand(ciphertext, \
            shared_secret, public_key, seed); \
    erase_bytes(seed, sizeof(seed)); \
    return result; \
}

DEFINE_MLKEM_PLATFORM(768, PRP_MLKEM768_KEYPAIR_SEED_LEN,
    PRP_MLKEM768_ENCAPS_SEED_LEN)
DEFINE_MLKEM_PLATFORM(1024, PRP_MLKEM1024_KEYPAIR_SEED_LEN,
    PRP_MLKEM1024_ENCAPS_SEED_LEN)

prp_status_t prp_mldsa87_keypair_generate_with_platform(
    prp_mldsa87_keypair_t **keypair, const prp_platform_t *platform)
{
    unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    result = random_bytes(platform, seed, sizeof(seed));
    if (result == PRP_OK)
        result = prp_mldsa87_keypair_from_seed(keypair, seed);
    erase_bytes(seed, sizeof(seed));
    return result;
}

static prp_status_t sign_with_platform(
    const prp_mldsa87_keypair_t *keypair, const unsigned char *message,
    size_t message_len, const prp_platform_t *platform,
    unsigned char *signature, size_t signature_size, size_t *written,
    int discovery)
{
    unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN];
    prp_status_t result;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || message == NULL || message_len == 0U ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA87_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = random_bytes(platform, random, sizeof(random));
    if (result == PRP_OK)
        result = discovery ? prp_mldsa87_discovery_sign_derand(keypair,
            message, message_len, random, signature, signature_size,
            written) : prp_mldsa87_sign_derand(keypair, message, message_len,
            random, signature, signature_size, written);
    erase_bytes(random, sizeof(random));
    return result;
}

prp_status_t prp_mldsa87_sign_with_platform(
    const prp_mldsa87_keypair_t *keypair, const unsigned char *message,
    size_t message_len, const prp_platform_t *platform,
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return sign_with_platform(keypair, message, message_len, platform,
        signature, signature_size, written, 0);
}

prp_status_t prp_mldsa87_discovery_sign_with_platform(
    const prp_mldsa87_keypair_t *keypair, const unsigned char *message,
    size_t message_len, const prp_platform_t *platform,
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return sign_with_platform(keypair, message, message_len, platform,
        signature, signature_size, written, 1);
}
