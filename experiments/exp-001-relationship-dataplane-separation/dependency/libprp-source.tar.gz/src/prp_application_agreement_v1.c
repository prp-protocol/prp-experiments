#include "prp_application_agreement_v1.h"
#include "prp_crypto_backend.h"
#include <prp/wire_v4_crypto.h>
#include <string.h>

static uint16_t r16(const uint8_t *p) { return (uint16_t)((p[0]<<8)|p[1]); }
static uint32_t r32(const uint8_t *p) { return ((uint32_t)r16(p)<<16)|r16(p+2); }
static void w16(uint8_t *p, uint16_t n) { p[0]=(uint8_t)(n>>8); p[1]=(uint8_t)n; }
static void w32(uint8_t *p, uint32_t n) { w16(p,(uint16_t)(n>>16)); w16(p+2,(uint16_t)n); }
static int hash(const char *domain, const uint8_t *p, size_t n, uint8_t *out)
{
    uint8_t h[32];
    if (!out || prp_crypto_hash_sha2_concat(256, (const uint8_t *)domain,
        strlen(domain), p, n, h, sizeof h) != PRP_CRYPTO_OK) return -1;
    memcpy(out,h,32); return 0;
}
static int prefix(const uint8_t *p, size_t n)
{
    size_t i; uint8_t nonzero=0;
    if (!p || n<43 || p[1]!=1 || (p[2]!=1 && p[2]!=2)) return -1;
    for(i=3;i<11;i++) nonzero|=p[i];
    return nonzero ? 0 : -1;
}
int prp_app_v1_decode(const uint8_t *p, size_t n, prp_app_v1_message *out)
{
    prp_app_v1_message m; size_t i,k; uint8_t h[32];
    if (!out || prefix(p,n)) return -1;
    memset(&m,0,sizeof m); m.kind=p[0]; m.opener=p[2];
    for(i=3;i<11;i++) m.attempt=(m.attempt<<8)|p[i];
    memcpy(m.context,p+11,32);
    switch(m.kind) {
    case 7:
        if(n<62 || n>125) return -1;
        k=r16(p+43); if(k<1 || k>64 || n!=61+k) return -1;
        for(i=0;i<k;i++) if(!((p[45+i]>='A' && p[45+i]<='Z') ||
            (p[45+i]>='0' && p[45+i]<='9') || p[45+i]=='-')) return -1;
        m.application_len=(uint8_t)k; memcpy(m.application,p+45,k); k+=45;
        m.profile=r16(p+k); m.application_version=r16(p+k+2);
        m.flags=r16(p+k+4); m.window=r16(p+k+6);
        m.max_queued_bytes=r32(p+k+8); m.tombstone_ms=r32(p+k+12);
        if(!m.profile || !m.application_version || (m.flags&~7u) ||
            ((m.flags&2) && !(m.flags&1)) || m.tombstone_ms<1000 ||
            m.tombstone_ms>600000) return -1;
        if(m.flags&1) {
            if(!m.window || m.window>64 || !m.max_queued_bytes ||
                m.max_queued_bytes>1048576) return -1;
        } else if(m.window || m.max_queued_bytes) return -1;
        break;
    case 8:
        if(n!=113 || !r16(p+75) || !r32(p+77) ||
            prp_app_v1_acceptance_hash(p,81,h) || memcmp(h,p+81,32)) return -1;
        memcpy(m.offer_hash,p+43,32); m.alias=r16(p+75); m.generation=r32(p+77);
        memcpy(m.acceptance_hash,p+81,32); break;
    case 9:
        if(n!=75) return -1;
        memcpy(m.acceptance_hash,p+43,32); break;
    case 10:
        if(n!=77 || r16(p+75)<1 || r16(p+75)>5) return -1;
        memcpy(m.offer_hash,p+43,32); m.reason=r16(p+75); break;
    default: return -1;
    }
    *out=m; return 0;
}
int prp_app_v1_encode(const prp_app_v1_message *m, uint8_t *out, size_t cap, size_t *written)
{
    uint8_t b[125]={0}; size_t n,k,i; uint64_t a; prp_app_v1_message checked;
    if(!m || !out || !written) return -1;
    b[0]=m->kind; b[1]=1; b[2]=m->opener; a=m->attempt;
    for(i=11;i>3;) { b[--i]=(uint8_t)a; a>>=8; }
    memcpy(b+11,m->context,32);
    switch(m->kind) {
    case 7:
        if(m->application_len<1 || m->application_len>64) return -1;
        w16(b+43,m->application_len); memcpy(b+45,m->application,m->application_len);
        k=45+m->application_len; w16(b+k,m->profile); w16(b+k+2,m->application_version);
        w16(b+k+4,m->flags); w16(b+k+6,m->window); w32(b+k+8,m->max_queued_bytes);
        w32(b+k+12,m->tombstone_ms); n=k+16; break;
    case 8:
        memcpy(b+43,m->offer_hash,32); w16(b+75,m->alias); w32(b+77,m->generation);
        if(prp_app_v1_acceptance_hash(b,81,b+81)) return -1;
        n=113; break;
    case 9: memcpy(b+43,m->acceptance_hash,32); n=75; break;
    case 10: memcpy(b+43,m->offer_hash,32); w16(b+75,m->reason); n=77; break;
    default: return -1;
    }
    if(cap<n || prp_app_v1_decode(b,n,&checked)) return -1;
    memcpy(out,b,n); *written=n; return 0;
}
int prp_app_v1_canonicalize(const uint8_t *p, size_t n, uint8_t *out, size_t cap)
{
    prp_app_v1_message m; size_t written;
    if(prp_app_v1_decode(p,n,&m) || prp_app_v1_encode(&m,out,cap,&written)) return -1;
    return (int)written;
}
int prp_app_v1_offer_hash(const uint8_t *p, size_t n, uint8_t out[32])
{
    uint8_t b[129]; prp_app_v1_message m;
    if(prp_app_v1_decode(p,n,&m) || m.kind!=7) return -1;
    w32(b,(uint32_t)n); memcpy(b+4,p,n);
    return hash("PRP-APP-OFFER-v1",b,n+4,out);
}
int prp_app_v1_acceptance_hash(const uint8_t *p, size_t n, uint8_t out[32])
{
    uint8_t b[85];
    if(n!=81 || prefix(p,n) || p[0]!=8 || !r16(p+75) || !r32(p+77)) return -1;
    w32(b,81); memcpy(b+4,p,81);
    return hash("PRP-APP-ACCEPT-v1",b,85,out);
}
int prp_app_v1_context_hash(const uint8_t *p, size_t n, uint8_t out[32])
{
    struct prp_wire_v4_session_crypto_desc s;
    struct prp_wire_v4_identity_suite_desc id;
    size_t k,len; unsigned i;
    if(!p || n<10 || n>5400 || p[0]!=4 || p[1]!=3 || !r32(p+4) ||
        prp_wire_v4_session_crypto_get(r16(p+2),&s) || !s.aead) return -1;
    len=r16(p+8); if(len!=s.transcript_hash_len || len>n-10) return -1;
    k=10+len;
    for(i=0;i<2;i++) {
        if(n-k<4 || prp_wire_v4_identity_suite_get(r16(p+k),&id)) return -1;
        len=r16(p+k+2); k+=4;
        if(len!=id.public_key_len || len>n-k) return -1;
        k+=len;
    }
    if(k!=n) return -1;
    return hash("PRP-APP-CONTEXT-v1",p,n,out);
}
