#include "prp_address.h"

#include <string.h>

#if defined(__wasm__)
#define PRP_ADDRESS_EXPORT(name) __attribute__((export_name(name)))
#else
#define PRP_ADDRESS_EXPORT(name)
#endif

static int address_error(char *error, size_t error_len, const char *message)
{
    size_t index = 0u;

    if (error != NULL && error_len != 0u) {
        while (index + 1u < error_len && message[index] != '\0') {
            error[index] = message[index];
            index++;
        }
        error[index] = '\0';
    }
    return -1;
}

static size_t profile_length(uint8_t profile)
{
    if (profile == PRP_ADDRESS_PROFILE_BLAKE3)
        return PRP_ADDRESS_BLAKE3_STRONG_ID_LEN;
    if (profile == PRP_ADDRESS_PROFILE_BLAKE3_512)
        return PRP_ADDRESS_BLAKE3_512_STRONG_ID_LEN;
    return 0u;
}

static int hex_value(char value)
{
    if (value >= '0' && value <= '9')
        return value - '0';
    if (value >= 'a' && value <= 'f')
        return value - 'a' + 10;
    return -1;
}

PRP_ADDRESS_EXPORT("prp_address_parse")
int prp_address_parse(const char *text, prp_address_t *address,
    char *error, size_t error_len)
{
    prp_address_t parsed = {0};
    size_t strong_len, text_len, index;
    int high, low;

    if (text == NULL || address == NULL)
        return address_error(error, error_len, "prp-address-policy");
    text_len = strlen(text);
    if (text_len < 8u || memcmp(text, "prp:", 4u) != 0 ||
            text[6] != ':' || hex_value(text[4]) < 0 ||
            hex_value(text[5]) < 0)
        return address_error(error, error_len, "prp-address-syntax");
    parsed.identity_profile = (uint8_t)((hex_value(text[4]) << 4) |
        hex_value(text[5]));
    strong_len = profile_length(parsed.identity_profile);
    if (strong_len == 0u)
        return address_error(error, error_len, "prp-address-profile");
    if (text_len != 7u + strong_len * 2u)
        return address_error(error, error_len, "prp-address-length");
    for (index = 0u; index < strong_len; index++) {
        high = hex_value(text[7u + index * 2u]);
        low = hex_value(text[8u + index * 2u]);
        if (high < 0 || low < 0)
            return address_error(error, error_len,
                "prp-address-canonical");
        parsed.strong_id[index] = (uint8_t)((high << 4) | low);
    }
    parsed.strong_id_len = (uint8_t)strong_len;
    *address = parsed;
    return 0;
}

PRP_ADDRESS_EXPORT("prp_address_format")
int prp_address_format(const prp_address_t *address, char *text,
    size_t text_capacity, char *error, size_t error_len)
{
    static const char digits[] = "0123456789abcdef";
    size_t expected, needed, index;

    if (address == NULL || text == NULL)
        return address_error(error, error_len, "prp-address-policy");
    expected = profile_length(address->identity_profile);
    if (expected == 0u)
        return address_error(error, error_len, "prp-address-profile");
    if (address->strong_id_len != expected)
        return address_error(error, error_len, "prp-address-length");
    needed = 7u + expected * 2u + 1u;
    if (text_capacity < needed)
        return address_error(error, error_len, "prp-address-capacity");
    text[0] = 'p';
    text[1] = 'r';
    text[2] = 'p';
    text[3] = ':';
    text[4] = digits[address->identity_profile >> 4];
    text[5] = digits[address->identity_profile & 0x0fu];
    text[6] = ':';
    for (index = 0u; index < expected; index++) {
        text[7u + index * 2u] = digits[address->strong_id[index] >> 4];
        text[8u + index * 2u] =
            digits[address->strong_id[index] & 0x0fu];
    }
    text[needed - 1u] = '\0';
    return 0;
}

PRP_ADDRESS_EXPORT("prp_address_equal")
int prp_address_equal(const prp_address_t *left, const prp_address_t *right)
{
    return left != NULL && right != NULL &&
        left->identity_profile == right->identity_profile &&
        left->strong_id_len == right->strong_id_len &&
        left->strong_id_len != 0u &&
        left->strong_id_len <= PRP_ADDRESS_STRONG_ID_MAX_LEN &&
        memcmp(left->strong_id, right->strong_id,
            left->strong_id_len) == 0;
}
