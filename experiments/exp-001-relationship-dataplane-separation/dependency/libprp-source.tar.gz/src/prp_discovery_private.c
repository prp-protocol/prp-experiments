#include "prp_discovery_private.h"

#include <prp_hash.h>
#include <prp_status.h>
#include <prp/wire_v4_crypto.h>

#include <string.h>

#if defined(__wasm__)
#define PRP_DISCOVERY_PRIVATE_EXPORT(name) __attribute__((export_name(name)))
#else
#define PRP_DISCOVERY_PRIVATE_EXPORT(name)
#endif

static const uint8_t bloom_domain[] = "PRP-DISCOVERY-BLOOM-INDEX-v2";
static const uint8_t commitment_domain[] = "PRP-DISCOVERY-SHARD-COMMIT-v1";
static const uint8_t challenge_domain[] = "PRP-DISCOVERY-CHALLENGE-v1";
static const uint8_t proof_context[] = "PRP-DISCOVERY-v1";
static const uint8_t shard_magic[] = "PRPS";
static const uint8_t proof_magic[] = "PRPP";

static uint16_t read_u16(const uint8_t *p)
{ return (uint16_t)(((uint16_t)p[0] << 8) | p[1]); }
static uint32_t read_u32(const uint8_t *p)
{ return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
    ((uint32_t)p[2] << 8) | p[3]; }
static uint64_t read_u64(const uint8_t *p)
{ return ((uint64_t)read_u32(p) << 32) | read_u32(p + 4); }
static void write_u16(uint8_t *p, uint16_t v)
{ p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }
static void write_u32(uint8_t *p, uint32_t v)
{ p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16);
  p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }
static void write_u64(uint8_t *p, uint64_t v)
{ write_u32(p, (uint32_t)(v >> 32)); write_u32(p + 4, (uint32_t)v); }

int
prp_discovery_lookup_preimage(const prp_discovery_target_t *target,
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint8_t *out, size_t out_len,
    size_t *written)
{
    return prp_discovery_target_exact_lookup_v2_preimage(rendezvous_id,
        rendezvous_id_len, filter_generation,
        PRP_DISCOVERY_TARGET_LOOKUP_V2_PROFILE_BLAKE3_128, target, out,
        out_len, written) == PRP_OK ? 0 : -1;
}

int
prp_discovery_lookup_tag(uint16_t lookup_index_profile,
    const prp_discovery_target_t *target, const uint8_t *rendezvous_id,
    size_t rendezvous_id_len, uint64_t filter_generation,
    uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN])
{
    return prp_discovery_target_exact_lookup_v2_tag(rendezvous_id,
        rendezvous_id_len, filter_generation, lookup_index_profile, target,
        tag) == PRP_OK ? 0 : -1;
}

PRP_DISCOVERY_PRIVATE_EXPORT("prp_discovery_lookup_request_encode")
int
prp_discovery_lookup_request_encode(
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    const uint8_t nonce[PRP_DISCOVERY_QUERY_NONCE_LEN],
    uint8_t out[PRP_DISCOVERY_LOOKUP_REQUEST_LEN])
{
    if (tag == NULL || nonce == NULL || out == NULL) return -1;
    memcpy(out, tag, PRP_DISCOVERY_LOOKUP_TAG_LEN);
    memcpy(out + PRP_DISCOVERY_LOOKUP_TAG_LEN, nonce,
        PRP_DISCOVERY_QUERY_NONCE_LEN);
    return 0;
}

PRP_DISCOVERY_PRIVATE_EXPORT("prp_discovery_lookup_request_decode")
int
prp_discovery_lookup_request_decode(const uint8_t *data, size_t data_len,
    uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    uint8_t nonce[PRP_DISCOVERY_QUERY_NONCE_LEN])
{
    if (data == NULL || data_len != PRP_DISCOVERY_LOOKUP_REQUEST_LEN ||
        tag == NULL || nonce == NULL) return -1;
    memcpy(tag, data, PRP_DISCOVERY_LOOKUP_TAG_LEN);
    memcpy(nonce, data + PRP_DISCOVERY_LOOKUP_TAG_LEN,
        PRP_DISCOVERY_QUERY_NONCE_LEN);
    return 0;
}

PRP_DISCOVERY_PRIVATE_EXPORT("prp_discovery_shard_select")
int
prp_discovery_shard_select(
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint32_t shard_count,
    uint32_t *shard)
{
    if (tag == NULL || shard == NULL || shard_count == 0u ||
        shard_count > PRP_DISCOVERY_MAX_SHARDS ||
        (shard_count & (shard_count - 1u)) != 0u) return -1;
    *shard = read_u32(tag) & (shard_count - 1u);
    return 0;
}

int
prp_discovery_private_bloom_indexes(const uint8_t *salt,
    size_t salt_len, const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    uint32_t bitmap_bytes, uint8_t hash_count, uint32_t *indexes)
{
    uint8_t input[sizeof(bloom_domain) - 1u + 2u + PRP_DISCOVERY_SALT_LEN +
        PRP_DISCOVERY_LOOKUP_TAG_LEN];
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    uint64_t h1, h2, bits;
    size_t domain_len = sizeof(bloom_domain) - 1u;
    size_t i;

    if (salt == NULL || salt_len == 0u || salt_len > PRP_DISCOVERY_SALT_LEN ||
        tag == NULL || bitmap_bytes == 0u || hash_count == 0u ||
        hash_count > 16u || indexes == NULL) return -1;
    memcpy(input, bloom_domain, domain_len);
    write_u16(input + domain_len, (uint16_t)salt_len);
    memcpy(input + domain_len + 2u, salt, salt_len);
    memcpy(input + domain_len + 2u + salt_len, tag,
        PRP_DISCOVERY_LOOKUP_TAG_LEN);
    if (prp_hash_blake3(input,
            domain_len + 2u + salt_len + PRP_DISCOVERY_LOOKUP_TAG_LEN,
            digest) != 0) return -1;
    h1 = read_u64(digest);
    h2 = read_u64(digest + 8u) | 1u;
    bits = (uint64_t)bitmap_bytes * 8u;
    for (i = 0; i < hash_count; i++)
        indexes[i] = (uint32_t)((h1 + i * h2) % bits);
    return 0;
}

int
prp_discovery_private_bloom_add(uint8_t *bitmap, size_t bitmap_len,
    const uint8_t *salt, size_t salt_len,
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint8_t hash_count)
{
    uint32_t indexes[16]; size_t i;
    if (bitmap == NULL || bitmap_len > UINT32_MAX ||
        prp_discovery_private_bloom_indexes(salt, salt_len, tag,
            (uint32_t)bitmap_len, hash_count, indexes) != 0) return -1;
    for (i = 0; i < hash_count; i++)
        bitmap[indexes[i] >> 3] |= (uint8_t)(1u << (indexes[i] & 7u));
    return 0;
}

int
prp_discovery_private_bloom_test(const uint8_t *bitmap,
    size_t bitmap_len, const uint8_t *salt, size_t salt_len,
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint8_t hash_count,
    int *maybe)
{
    uint32_t indexes[16]; size_t i;
    if (bitmap == NULL || maybe == NULL || bitmap_len > UINT32_MAX ||
        prp_discovery_private_bloom_indexes(salt, salt_len, tag,
            (uint32_t)bitmap_len, hash_count, indexes) != 0) return -1;
    *maybe = 1;
    for (i = 0; i < hash_count; i++)
        if ((bitmap[indexes[i] >> 3] &
                (uint8_t)(1u << (indexes[i] & 7u))) == 0u) {
            *maybe = 0; break;
        }
    return 0;
}

int
prp_discovery_shard_commitment(uint64_t generation, uint32_t shard,
    const uint8_t *data, size_t data_len,
    uint8_t commitment[PRP_DISCOVERY_COMMITMENT_LEN])
{
    uint8_t prefix[sizeof(commitment_domain) - 1u + 8u + 4u + 8u];
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    size_t domain_len = sizeof(commitment_domain) - 1u;

    if (generation == 0u || data == NULL || data_len == 0u ||
        commitment == NULL) return -1;
    memcpy(prefix, commitment_domain, domain_len);
    write_u64(prefix + domain_len, generation);
    write_u32(prefix + domain_len + 8u, shard);
    write_u64(prefix + domain_len + 12u, data_len);
    if (prp_hash_blake3_concat(prefix, sizeof(prefix), data, data_len,
            digest) != 0) return -1;
    memcpy(commitment, digest, PRP_DISCOVERY_COMMITMENT_LEN);
    return 0;
}

int
prp_discovery_shard_record_encode(const prp_discovery_private_shard_t *s,
    uint8_t *out, size_t out_len, size_t *written)
{
    uint8_t computed[PRP_DISCOVERY_COMMITMENT_LEN];
    size_t needed;
    if (s == NULL || s->lookup_index_profile == 0u || s->generation == 0u ||
        s->shard >= PRP_DISCOVERY_MAX_SHARDS || s->bitmap == NULL ||
        s->bitmap_len == 0u || s->commitment == NULL || out == NULL ||
        written == NULL || prp_discovery_shard_commitment(s->generation,
            s->shard, s->bitmap, s->bitmap_len, computed) != 0 ||
        memcmp(computed, s->commitment, sizeof(computed)) != 0)
        return -1;
    needed = PRP_DISCOVERY_SHARD_HEADER_LEN + s->bitmap_len;
    if (out_len < needed) return -1;
    memset(out, 0, PRP_DISCOVERY_SHARD_HEADER_LEN);
    memcpy(out, shard_magic, sizeof(shard_magic) - 1u);
    out[4] = PRP_DISCOVERY_PRIVATE_VERSION;
    write_u16(out + 6, s->lookup_index_profile);
    write_u64(out + 8, s->generation);
    write_u32(out + 16, s->shard);
    write_u32(out + 20, s->bitmap_len);
    memcpy(out + 24, s->commitment, PRP_DISCOVERY_COMMITMENT_LEN);
    memcpy(out + PRP_DISCOVERY_SHARD_HEADER_LEN, s->bitmap, s->bitmap_len);
    *written = needed;
    return 0;
}

int
prp_discovery_shard_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_shard_t *s)
{
    uint8_t computed[PRP_DISCOVERY_COMMITMENT_LEN];
    size_t reserved;
    if (data == NULL || s == NULL || data_len < PRP_DISCOVERY_SHARD_HEADER_LEN ||
        memcmp(data, shard_magic, sizeof(shard_magic) - 1u) != 0 ||
        data[4] != PRP_DISCOVERY_PRIVATE_VERSION || data[5] != 0u)
        return -1;
    for (reserved = 20u + 4u + PRP_DISCOVERY_COMMITMENT_LEN;
            reserved < PRP_DISCOVERY_SHARD_HEADER_LEN; reserved++)
        if (data[reserved] != 0u) return -1;
    memset(s, 0, sizeof(*s));
    s->lookup_index_profile = read_u16(data + 6);
    s->generation = read_u64(data + 8);
    s->shard = read_u32(data + 16);
    s->bitmap_len = read_u32(data + 20);
    s->commitment = data + 24;
    s->bitmap = data + PRP_DISCOVERY_SHARD_HEADER_LEN;
    if (s->lookup_index_profile == 0u || s->generation == 0u ||
        s->shard >= PRP_DISCOVERY_MAX_SHARDS || s->bitmap_len == 0u ||
        data_len != PRP_DISCOVERY_SHARD_HEADER_LEN + s->bitmap_len ||
        prp_discovery_shard_commitment(s->generation, s->shard, s->bitmap,
            s->bitmap_len, computed) != 0 ||
        memcmp(computed, s->commitment, sizeof(computed)) != 0)
        return -1;
    return 0;
}

static int manifest_valid(const prp_discovery_private_manifest_t *m)
{
    uint16_t i;
    if (m == NULL || prp_wire_v4_identity_suite_get(
            m->rendezvous_identity_suite, NULL) != PRP_WIRE_V4_OK ||
        m->rendezvous_identity_proof_profile == 0u ||
        m->rendezvous_id == NULL || m->rendezvous_id_len == 0u ||
        m->generation == 0u || m->valid_from >= m->valid_until ||
        m->shard_count == 0u || m->shard_count > PRP_DISCOVERY_MAX_SHARDS ||
        (m->shard_count & (m->shard_count - 1u)) != 0u ||
        m->bitmap_bytes == 0u || m->bloom_profile == 0u ||
        m->hash_count == 0u || m->hash_count > 16u ||
        m->salt == NULL || m->salt_len == 0u ||
        m->salt_len > PRP_DISCOVERY_SALT_LEN || m->suites == NULL ||
        m->suite_count == 0u || m->suite_count > PRP_DISCOVERY_MAX_SUITES ||
        m->commitments == NULL || m->commitment_count != m->shard_count ||
        (m->auth_len != 0u && m->auth == NULL)) return 0;
    for (i = 0; i < m->suite_count; i++)
        if (m->suites[i].lookup_index_profile !=
                PRP_DISCOVERY_LOOKUP_PROFILE_BLAKE3_128) return 0;
    return 1;
}

int
prp_discovery_manifest_encode(const prp_discovery_private_manifest_t *m,
    uint8_t *out, size_t out_len, size_t *written)
{
    uint8_t *p; size_t suites_len, commitments_len, needed; uint16_t i;
    if (!manifest_valid(m) || out == NULL || written == NULL) return -1;
    suites_len = (size_t)m->suite_count * 4u;
    commitments_len = (size_t)m->commitment_count *
        PRP_DISCOVERY_COMMITMENT_LEN;
    needed = PRP_DISCOVERY_MANIFEST_HEADER_LEN + m->rendezvous_id_len +
        m->salt_len + suites_len + commitments_len + m->auth_len;
    if (out_len < needed) return -1;
    memset(out, 0, PRP_DISCOVERY_MANIFEST_HEADER_LEN);
    out[0] = PRP_DISCOVERY_PRIVATE_VERSION; out[1] = m->bloom_profile;
    out[2] = m->hash_count;
    write_u16(out + 4, m->rendezvous_identity_suite);
    write_u16(out + 6, m->rendezvous_id_len);
    write_u64(out + 8, m->generation);
    write_u64(out + 16, m->previous_generation);
    write_u64(out + 24, m->valid_from); write_u64(out + 32, m->valid_until);
    write_u64(out + 40, m->entry_count); write_u32(out + 48, m->shard_count);
    write_u32(out + 52, m->bitmap_bytes); write_u16(out + 56, m->salt_len);
    write_u16(out + 58, m->suite_count);
    write_u16(out + 60, m->commitment_count); write_u16(out + 62, m->auth_len);
    write_u16(out + 64, m->rendezvous_identity_proof_profile);
    p = out + PRP_DISCOVERY_MANIFEST_HEADER_LEN;
    memcpy(p, m->rendezvous_id, m->rendezvous_id_len); p += m->rendezvous_id_len;
    memcpy(p, m->salt, m->salt_len); p += m->salt_len;
    for (i = 0; i < m->suite_count; i++) {
        write_u16(p, m->suites[i].suite);
        write_u16(p + 2, m->suites[i].lookup_index_profile); p += 4;
    }
    memcpy(p, m->commitments, commitments_len); p += commitments_len;
    if (m->auth_len != 0u) memcpy(p, m->auth, m->auth_len);
    *written = needed;
    return 0;
}

int
prp_discovery_manifest_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_manifest_t *m)
{
    size_t variable_len, needed, reserved; uint16_t i;
    if (data == NULL || m == NULL || data_len < PRP_DISCOVERY_MANIFEST_HEADER_LEN ||
        data[0] != PRP_DISCOVERY_PRIVATE_VERSION) return -1;
    if (data[3] != 0u) return -1;
    for (reserved = 66u; reserved < PRP_DISCOVERY_MANIFEST_HEADER_LEN;
            reserved++) if (data[reserved] != 0u) return -1;
    memset(m, 0, sizeof(*m));
    m->bloom_profile = data[1]; m->hash_count = data[2];
    m->rendezvous_identity_suite = read_u16(data + 4);
    m->rendezvous_identity_proof_profile = read_u16(data + 64);
    m->rendezvous_id_len = read_u16(data + 6);
    m->generation = read_u64(data + 8);
    m->previous_generation = read_u64(data + 16);
    m->valid_from = read_u64(data + 24); m->valid_until = read_u64(data + 32);
    m->entry_count = read_u64(data + 40); m->shard_count = read_u32(data + 48);
    m->bitmap_bytes = read_u32(data + 52); m->salt_len = read_u16(data + 56);
    m->suite_count = read_u16(data + 58);
    m->commitment_count = read_u16(data + 60); m->auth_len = read_u16(data + 62);
    if (m->rendezvous_id_len == 0u ||
        m->rendezvous_id_len > PRP_DISCOVERY_MAX_RENDEZVOUS_ID_LEN ||
        m->salt_len == 0u || m->salt_len > PRP_DISCOVERY_SALT_LEN ||
        m->suite_count == 0u ||
        m->suite_count > PRP_DISCOVERY_MAX_SUITES ||
        m->commitment_count == 0u ||
        m->commitment_count > PRP_DISCOVERY_MAX_SHARDS) return -1;
    variable_len = m->rendezvous_id_len + m->salt_len +
        (size_t)m->suite_count * 4u +
        (size_t)m->commitment_count * PRP_DISCOVERY_COMMITMENT_LEN;
    needed = PRP_DISCOVERY_MANIFEST_HEADER_LEN + variable_len + m->auth_len;
    if (needed != data_len) return -1;
    m->rendezvous_id = data + PRP_DISCOVERY_MANIFEST_HEADER_LEN;
    m->salt = m->rendezvous_id + m->rendezvous_id_len;
    m->suites = m->decoded_suites;
    for (i = 0; i < m->suite_count; i++) {
        const uint8_t *entry = m->salt + m->salt_len + (size_t)i * 4u;
        m->decoded_suites[i].suite = read_u16(entry);
        m->decoded_suites[i].lookup_index_profile = read_u16(entry + 2);
    }
    m->commitments = m->salt + m->salt_len + (size_t)m->suite_count * 4u;
    m->auth = m->commitments +
        (size_t)m->commitment_count * PRP_DISCOVERY_COMMITMENT_LEN;
    m->authenticated_len = data_len - m->auth_len;
    if (!manifest_valid(m)) return -1;
    return 0;
}

static int
identity_auth_verify(uint16_t identity_suite, uint16_t proof_profile,
    const uint8_t *strong_id, size_t strong_id_len,
    const uint8_t *authenticated, size_t authenticated_len,
    const uint8_t *auth, size_t auth_len)
{
    uint8_t computed[PRP_DISCOVERY_MAX_STRONG_ID_LEN];
    size_t computed_len = 0u;
    size_t public_key_len, signature_len;
    struct prp_wire_v4_identity_crypto_desc crypto;
    struct prp_wire_v4_identity_suite_desc suite;
    const uint8_t *context = NULL;
    size_t context_len = 0u;

    if (prp_wire_v4_identity_suite_get(identity_suite, &suite) !=
            PRP_WIRE_V4_OK ||
        prp_wire_v4_identity_crypto_get(identity_suite, &crypto) !=
            PRP_WIRE_V4_OK || proof_profile > UINT8_MAX ||
        proof_profile == 0u || strong_id == NULL || strong_id_len == 0u ||
        authenticated == NULL || authenticated_len == 0u || auth == NULL ||
        (public_key_len = prp_identity_proof_public_key_len(
            (uint8_t)proof_profile)) == 0u ||
        (signature_len = prp_identity_proof_signature_len(
            (uint8_t)proof_profile)) == 0u ||
        crypto.proof_algorithm != proof_profile ||
        public_key_len != suite.public_key_len ||
        signature_len != suite.proof_len ||
        auth_len != public_key_len + signature_len ||
        prp_wire_v4_strong_id_compute(identity_suite, auth, public_key_len,
            computed,
            sizeof(computed), &computed_len) != 0 ||
        computed_len != suite.strong_id_len ||
        computed_len != strong_id_len ||
        memcmp(computed, strong_id, strong_id_len) != 0)
        return -1;
    if (proof_profile != PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3) {
        context = proof_context;
        context_len = sizeof(proof_context) - 1u;
    }
    return prp_identity_proof_verify((uint8_t)proof_profile, auth,
        public_key_len, auth + public_key_len, signature_len, authenticated,
        authenticated_len, context, context_len);
}

int
prp_discovery_manifest_admit(const uint8_t *data, size_t data_len,
    uint64_t now, prp_discovery_private_manifest_t *manifest)
{
    if (now == 0u || prp_discovery_manifest_decode(data, data_len,
            manifest) != 0 || manifest->auth_len == 0u ||
        now < manifest->valid_from || now >= manifest->valid_until ||
        manifest->authenticated_len == 0u ||
        manifest->authenticated_len + manifest->auth_len != data_len)
        return -1;
    return identity_auth_verify(manifest->rendezvous_identity_suite,
        manifest->rendezvous_identity_proof_profile,
        manifest->rendezvous_id, manifest->rendezvous_id_len, data,
        manifest->authenticated_len, manifest->auth, manifest->auth_len);
}

int
prp_discovery_challenge_preimage(
    const prp_discovery_challenge_context_t *c, uint8_t *out,
    size_t out_len, size_t *written)
{
    const size_t domain_len = sizeof(challenge_domain) - 1u;
    size_t needed;
    uint8_t *p;

    if (c == NULL || c->rendezvous_id == NULL ||
        c->rendezvous_id_len == 0u || c->filter_generation == 0u ||
        c->suite == 0u || c->lookup_index_profile == 0u ||
        c->lookup_tag == NULL || c->query_nonce == NULL ||
        c->challenge == NULL || prp_wire_v4_identity_suite_get(
            c->published_identity_suite, NULL) != PRP_WIRE_V4_OK ||
        c->published_identity == NULL || c->published_identity_len == 0u ||
        out == NULL || written == NULL)
        return -1;
    needed = 2u + domain_len + 2u + c->rendezvous_id_len + 8u +
        2u + 2u + PRP_DISCOVERY_LOOKUP_TAG_LEN +
        PRP_DISCOVERY_QUERY_NONCE_LEN + PRP_DISCOVERY_CHALLENGE_LEN + 2u +
        2u + c->published_identity_len;
    if (out_len < needed) return -1;
    p = out;
    write_u16(p, (uint16_t)domain_len); p += 2u;
    memcpy(p, challenge_domain, domain_len); p += domain_len;
    write_u16(p, c->rendezvous_id_len); p += 2u;
    memcpy(p, c->rendezvous_id, c->rendezvous_id_len);
    p += c->rendezvous_id_len;
    write_u64(p, c->filter_generation); p += 8u;
    write_u16(p, c->suite); p += 2u;
    write_u16(p, c->lookup_index_profile); p += 2u;
    memcpy(p, c->lookup_tag, PRP_DISCOVERY_LOOKUP_TAG_LEN);
    p += PRP_DISCOVERY_LOOKUP_TAG_LEN;
    memcpy(p, c->query_nonce, PRP_DISCOVERY_QUERY_NONCE_LEN);
    p += PRP_DISCOVERY_QUERY_NONCE_LEN;
    memcpy(p, c->challenge, PRP_DISCOVERY_CHALLENGE_LEN);
    p += PRP_DISCOVERY_CHALLENGE_LEN;
    write_u16(p, c->published_identity_suite); p += 2u;
    write_u16(p, c->published_identity_len); p += 2u;
    memcpy(p, c->published_identity, c->published_identity_len);
    *written = needed;
    return 0;
}

int
prp_discovery_challenge_preimage_decode(const uint8_t *data, size_t data_len,
    prp_discovery_challenge_context_t *c)
{
    const size_t domain_len = sizeof(challenge_domain) - 1u;
    const uint8_t *p = data;
    size_t remaining = data_len;
    uint16_t length;
#define TAKE(bytes) do { if (remaining < (bytes)) return -1; \
    p += (bytes); remaining -= (bytes); } while (0)
    if (data == NULL || c == NULL || remaining < 2u ||
        read_u16(p) != domain_len) return -1;
    TAKE(2u);
    if (remaining < domain_len || memcmp(p, challenge_domain, domain_len) != 0)
        return -1;
    TAKE(domain_len); memset(c, 0, sizeof(*c));
    if (remaining < 2u) return -1;
    length = read_u16(p); TAKE(2u);
    if (length == 0u || length > PRP_DISCOVERY_MAX_RENDEZVOUS_ID_LEN ||
        remaining < length) return -1;
    c->rendezvous_id_len = length; c->rendezvous_id = p; TAKE(length);
    if (remaining < 12u) return -1;
    c->filter_generation = read_u64(p); TAKE(8u);
    c->suite = read_u16(p); TAKE(2u);
    c->lookup_index_profile = read_u16(p); TAKE(2u);
    if (remaining < PRP_DISCOVERY_LOOKUP_TAG_LEN +
            PRP_DISCOVERY_QUERY_NONCE_LEN + PRP_DISCOVERY_CHALLENGE_LEN + 4u)
        return -1;
    c->lookup_tag = p; TAKE(PRP_DISCOVERY_LOOKUP_TAG_LEN);
    c->query_nonce = p; TAKE(PRP_DISCOVERY_QUERY_NONCE_LEN);
    c->challenge = p; TAKE(PRP_DISCOVERY_CHALLENGE_LEN);
    c->published_identity_suite = read_u16(p); TAKE(2u);
    length = read_u16(p); TAKE(2u);
    if (length == 0u || length > PRP_DISCOVERY_MAX_STRONG_ID_LEN ||
        remaining != length) return -1;
    c->published_identity_len = length; c->published_identity = p;
    return c->filter_generation != 0u && c->suite != 0u &&
        c->lookup_index_profile != 0u &&
        prp_wire_v4_identity_suite_get(c->published_identity_suite, NULL) ==
            PRP_WIRE_V4_OK ? 0 : -1;
#undef TAKE
}

int
prp_discovery_proof_record_encode(const prp_discovery_private_proof_t *p,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t expected, needed;
    if (p == NULL || p->identity_proof_profile == 0u ||
        p->identity_proof_profile > UINT8_MAX || p->challenge == NULL ||
        p->proof == NULL || p->proof_len == 0u ||
        out == NULL || written == NULL ||
        (expected = prp_identity_proof_public_key_len(
            (uint8_t)p->identity_proof_profile) +
            prp_identity_proof_signature_len(
                (uint8_t)p->identity_proof_profile)) != p->proof_len)
        return -1;
    needed = PRP_DISCOVERY_PROOF_HEADER_LEN + p->proof_len;
    if (out_len < needed) return -1;
    memset(out, 0, PRP_DISCOVERY_PROOF_HEADER_LEN);
    memcpy(out, proof_magic, sizeof(proof_magic) - 1u);
    out[4] = PRP_DISCOVERY_PRIVATE_VERSION;
    write_u16(out + 6, p->identity_proof_profile);
    memcpy(out + 8, p->challenge, PRP_DISCOVERY_CHALLENGE_LEN);
    write_u16(out + 40, p->proof_len);
    memcpy(out + PRP_DISCOVERY_PROOF_HEADER_LEN, p->proof, p->proof_len);
    *written = needed;
    return 0;
}

int
prp_discovery_proof_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_proof_t *p)
{
    size_t expected;
    if (data == NULL || p == NULL || data_len < PRP_DISCOVERY_PROOF_HEADER_LEN ||
        memcmp(data, proof_magic, sizeof(proof_magic) - 1u) != 0 ||
        data[4] != PRP_DISCOVERY_PRIVATE_VERSION || data[5] != 0u)
        return -1;
    memset(p, 0, sizeof(*p));
    p->identity_proof_profile = read_u16(data + 6);
    p->challenge = data + 8;
    p->proof_len = read_u16(data + 40);
    p->proof = data + PRP_DISCOVERY_PROOF_HEADER_LEN;
    if (p->identity_proof_profile == 0u ||
        p->identity_proof_profile > UINT8_MAX ||
        data_len != PRP_DISCOVERY_PROOF_HEADER_LEN + p->proof_len)
        return -1;
    expected = prp_identity_proof_public_key_len(
        (uint8_t)p->identity_proof_profile) +
        prp_identity_proof_signature_len((uint8_t)p->identity_proof_profile);
    return expected != 0u && expected == p->proof_len ? 0 : -1;
}

int
prp_discovery_challenge_verify(
    const prp_discovery_challenge_context_t *context,
    uint16_t identity_proof_profile, const uint8_t *proof,
    size_t proof_len)
{
    uint8_t preimage[2u + sizeof(challenge_domain) - 1u + 2u +
        PRP_DISCOVERY_MAX_RENDEZVOUS_ID_LEN + 8u + 2u + 2u +
        PRP_DISCOVERY_LOOKUP_TAG_LEN + PRP_DISCOVERY_QUERY_NONCE_LEN +
        PRP_DISCOVERY_CHALLENGE_LEN + 2u + 2u +
        PRP_DISCOVERY_MAX_STRONG_ID_LEN];
    size_t preimage_len;

    if (prp_discovery_challenge_preimage(context, preimage,
            sizeof(preimage), &preimage_len) != 0)
        return -1;
    return identity_auth_verify(context->published_identity_suite,
        identity_proof_profile, context->published_identity,
        context->published_identity_len, preimage, preimage_len, proof,
        proof_len);
}
