#include "prp_random.h"

#include "prp_crypto_backend.h"
#include "prp_memory.h"

static prp_status_t validate_output(uint8_t *output, size_t output_len)
{
    return output == NULL && output_len != 0U ? PRP_ERR_ARGUMENT : PRP_OK;
}

prp_status_t prp_random_bytes(uint8_t *output, size_t output_len)
{
    int result;

    if (validate_output(output, output_len) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    if (output_len == 0U)
        return PRP_OK;
    prp_secure_zero(output, output_len);
    result = prp_crypto_random(output, output_len);
    if (result == PRP_CRYPTO_OK)
        return PRP_OK;
    prp_secure_zero(output, output_len);
    return result == PRP_CRYPTO_ERR_UNAVAILABLE ? PRP_ERR_UNAVAILABLE :
        PRP_ERR_CRYPTO;
}
