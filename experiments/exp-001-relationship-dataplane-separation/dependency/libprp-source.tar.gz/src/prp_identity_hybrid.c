#include "prp_identity_hybrid.h"

#include "prp_crypto_backend.h"
#include "prp_ed25519_blake3.h"
#include "prp_hash.h"
#include "prp_pq.h"

#include <prp/wire_v4_crypto.h>

#include <stdlib.h>

struct prp_identity_hybrid_keypair_s {
    prp_ed25519_blake3_keypair_t *ed25519;
    prp_mldsa87_keypair_t *mldsa87;
};

void prp_identity_hybrid_keypair_destroy(
    prp_identity_hybrid_keypair_t *keypair)
{
    if (keypair != NULL) {
        prp_ed25519_blake3_keypair_destroy(keypair->ed25519);
        prp_mldsa87_keypair_destroy(keypair->mldsa87);
        prp_crypto_secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}

prp_status_t prp_identity_hybrid_keypair_from_seed(
    prp_identity_hybrid_keypair_t **keypair,
    const uint8_t seed[PRP_IDENTITY_HYBRID_SEED_LEN])
{
    prp_identity_hybrid_keypair_t *created;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (seed == NULL)
        return PRP_ERR_ARGUMENT;
    created = calloc(1U, sizeof(*created));
    if (created == NULL)
        return PRP_ERR_NO_MEMORY;
    if (prp_ed25519_blake3_keypair_from_seed(&created->ed25519, seed) !=
            PRP_OK ||
        prp_mldsa87_keypair_derand(&created->mldsa87,
            seed + PRP_ED25519_BLAKE3_SEED_LEN) != 0) {
        prp_identity_hybrid_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_identity_hybrid_keypair_generate(
    prp_identity_hybrid_keypair_t **keypair)
{
    uint8_t seed[PRP_IDENTITY_HYBRID_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    result = prp_identity_hybrid_keypair_from_seed(keypair, seed);
    prp_crypto_secure_zero(seed, sizeof(seed));
    return result;
}

prp_status_t prp_identity_hybrid_keypair_import(
    prp_identity_hybrid_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len)
{
    prp_identity_hybrid_keypair_t *created;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (private_key == NULL ||
            private_key_len != PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN)
        return PRP_ERR_ARGUMENT;
    created = calloc(1U, sizeof(*created));
    if (created == NULL)
        return PRP_ERR_NO_MEMORY;
    if (prp_ed25519_blake3_keypair_import(&created->ed25519, private_key,
            PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN) != PRP_OK ||
        prp_mldsa87_keypair_import(&created->mldsa87,
            private_key + PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN,
            PRP_MLDSA87_PRIVATE_KEY_LEN) != 0) {
        prp_identity_hybrid_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_identity_hybrid_public_key_export(
    const prp_identity_hybrid_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written)
{
    size_t component;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_IDENTITY_HYBRID_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_ed25519_blake3_public_key_export(keypair->ed25519, public_key,
            public_key_size, &component) != PRP_OK ||
        prp_mldsa87_public_key_export(keypair->mldsa87,
            public_key + component, public_key_size - component,
            &component) != 0)
        return PRP_ERR_CRYPTO;
    *written = PRP_IDENTITY_HYBRID_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_identity_hybrid_private_key_export(
    const prp_identity_hybrid_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written)
{
    size_t component;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || private_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (private_key_size < PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_ed25519_blake3_private_key_export(keypair->ed25519, private_key,
            private_key_size, &component) != PRP_OK ||
        prp_mldsa87_private_key_export(keypair->mldsa87,
            private_key + component, private_key_size - component,
            &component) != 0)
        return PRP_ERR_CRYPTO;
    *written = PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_identity_hybrid_sign(
    const prp_identity_hybrid_keypair_t *keypair, const uint8_t *hs2_prefix,
    size_t hs2_prefix_len, uint8_t *signature, size_t signature_size,
    size_t *written)
{
    size_t component;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || hs2_prefix == NULL || hs2_prefix_len == 0U ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_IDENTITY_HYBRID_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_ed25519_blake3_sign(keypair->ed25519, hs2_prefix,
            hs2_prefix_len, signature, signature_size, &component) != PRP_OK ||
        prp_mldsa87_sign(keypair->mldsa87, hs2_prefix, hs2_prefix_len,
            signature + component, signature_size - component,
            &component) != 0) {
        prp_crypto_secure_zero(signature, PRP_IDENTITY_HYBRID_SIGNATURE_LEN);
        return PRP_ERR_CRYPTO;
    }
    *written = PRP_IDENTITY_HYBRID_SIGNATURE_LEN;
    return PRP_OK;
}

prp_status_t prp_identity_hybrid_verify(
    const uint8_t public_key[PRP_IDENTITY_HYBRID_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_IDENTITY_HYBRID_SIGNATURE_LEN],
    const uint8_t *hs2_prefix, size_t hs2_prefix_len)
{
    if (public_key == NULL || signature == NULL || hs2_prefix == NULL ||
            hs2_prefix_len == 0U)
        return PRP_ERR_ARGUMENT;
    if (prp_ed25519_blake3_verify(public_key, signature, hs2_prefix,
            hs2_prefix_len) != PRP_OK ||
        prp_identity_proof_verify(PRP_SELF_CERT_ID_PROOF_MLDSA87,
            public_key + PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN,
            PRP_MLDSA87_PUBLIC_KEY_LEN,
            signature + PRP_ED25519_BLAKE3_SIGNATURE_LEN,
            PRP_MLDSA87_SIGNATURE_LEN, hs2_prefix, hs2_prefix_len,
            (const uint8_t *)PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT,
            PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}
