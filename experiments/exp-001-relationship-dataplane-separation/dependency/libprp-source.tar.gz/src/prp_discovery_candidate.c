#include "prp_discovery_candidate.h"
#include "prp_hash.h"
#include "prp_status.h"

#include <string.h>

static const uint8_t matrix_magic[4] = { 'P', 'R', 'P', 'M' };

static void
write_u16(uint8_t *out, uint16_t value)
{
    out[0] = (uint8_t)(value >> 8);
    out[1] = (uint8_t)value;
}

static void
write_u32(uint8_t *out, uint32_t value)
{
    out[0] = (uint8_t)(value >> 24);
    out[1] = (uint8_t)(value >> 16);
    out[2] = (uint8_t)(value >> 8);
    out[3] = (uint8_t)value;
}

static void
write_u64(uint8_t *out, uint64_t value)
{
    unsigned int i;

    for (i = 0u; i < 8u; i++)
        out[i] = (uint8_t)(value >> (56u - i * 8u));
}

static uint16_t
read_u16(const uint8_t *data)
{
    return (uint16_t)(((uint16_t)data[0] << 8) | data[1]);
}

static uint32_t
read_u32(const uint8_t *data)
{
    return ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) | data[3];
}

static uint64_t
read_u64(const uint8_t *data)
{
    uint64_t value = 0u;
    unsigned int i;

    for (i = 0u; i < 8u; i++)
        value = (value << 8) | data[i];
    return value;
}

static int
descriptor_geometry_valid(const prp_discovery_matrix_descriptor_t *descriptor)
{
    size_t bitmap_bytes;

    if (descriptor == NULL || descriptor->generation == 0u ||
            descriptor->valid_until <= descriptor->valid_from ||
            descriptor->lookup_index_profile == 0u ||
            descriptor->precision < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
            descriptor->precision >
                PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
            descriptor->hash_count != PRP_DISCOVERY_BLOOM_HASH_COUNT ||
            descriptor->column_count == 0u ||
            descriptor->column_count > PRP_DISCOVERY_MATRIX_MAX_COLUMNS ||
            descriptor->row_bytes != (descriptor->column_count + 7u) / 8u)
        return 0;
    bitmap_bytes = (size_t)1u << (descriptor->precision - 3u);
    return bitmap_bytes != 0u;
}

int
prp_discovery_candidate_validate(const prp_discovery_candidate_t *candidate,
    uint64_t now)
{
    uint8_t any = 0u;
    size_t i;

    if (candidate == NULL || candidate->generation == 0u ||
            candidate->valid_until <= now || candidate->capabilities == 0u ||
            (candidate->capabilities & ~PRP_DISCOVERY_CANDIDATE_CAP_MASK) != 0u ||
            (candidate->source_scope < PRP_DISCOVERY_SOURCE_LOCAL_CARRIER ||
             candidate->source_scope > PRP_DISCOVERY_SOURCE_RENDEZVOUS_PIR))
        return PRP_ERR_ARGUMENT;
    for (i = 0u; i < sizeof(candidate->handle); i++)
        any |= candidate->handle[i];
    return any != 0u ? PRP_OK : PRP_ERR_ARGUMENT;
}

int
prp_discovery_matrix_descriptor_encode(
    const prp_discovery_matrix_descriptor_t *descriptor, uint8_t *out,
    size_t out_len, size_t *written)
{
    if (!descriptor_geometry_valid(descriptor) || out == NULL ||
            written == NULL)
        return PRP_ERR_ARGUMENT;
    if (out_len < PRP_DISCOVERY_MATRIX_DESCRIPTOR_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_MATRIX_DESCRIPTOR_LEN);
    memcpy(out, matrix_magic, sizeof(matrix_magic));
    out[4] = PRP_DISCOVERY_MATRIX_VERSION;
    out[5] = PRP_DISCOVERY_MATRIX_KIND_SNAPSHOT;
    write_u64(out + 8, descriptor->generation);
    write_u64(out + 16, descriptor->previous_generation);
    write_u64(out + 24, descriptor->valid_from);
    write_u64(out + 32, descriptor->valid_until);
    write_u16(out + 40, descriptor->lookup_index_profile);
    out[42] = descriptor->precision;
    out[43] = descriptor->hash_count;
    write_u32(out + 44, descriptor->column_count);
    write_u32(out + 48, descriptor->row_bytes);
    memcpy(out + 56, descriptor->aliases_commitment,
        PRP_HASH_BLAKE3_OUT_LEN);
    memcpy(out + 88, descriptor->matrix_commitment,
        PRP_HASH_BLAKE3_OUT_LEN);
    *written = PRP_DISCOVERY_MATRIX_DESCRIPTOR_LEN;
    return PRP_OK;
}

int
prp_discovery_matrix_descriptor_decode(const uint8_t *data, size_t data_len,
    prp_discovery_matrix_descriptor_t *descriptor)
{
    if (data == NULL || descriptor == NULL ||
            data_len != PRP_DISCOVERY_MATRIX_DESCRIPTOR_LEN)
        return PRP_ERR_ARGUMENT;
    if (memcmp(data, matrix_magic, sizeof(matrix_magic)) != 0)
        return PRP_ERR_MARKER;
    if (data[4] != PRP_DISCOVERY_MATRIX_VERSION)
        return PRP_ERR_VERSION;
    if (data[5] != PRP_DISCOVERY_MATRIX_KIND_SNAPSHOT || data[6] != 0u ||
            data[7] != 0u || read_u32(data + 52) != 0u)
        return PRP_ERR_PROTOCOL;
    memset(descriptor, 0, sizeof(*descriptor));
    descriptor->generation = read_u64(data + 8);
    descriptor->previous_generation = read_u64(data + 16);
    descriptor->valid_from = read_u64(data + 24);
    descriptor->valid_until = read_u64(data + 32);
    descriptor->lookup_index_profile = read_u16(data + 40);
    descriptor->precision = data[42];
    descriptor->hash_count = data[43];
    descriptor->column_count = read_u32(data + 44);
    descriptor->row_bytes = read_u32(data + 48);
    memcpy(descriptor->aliases_commitment, data + 56,
        PRP_HASH_BLAKE3_OUT_LEN);
    memcpy(descriptor->matrix_commitment, data + 88,
        PRP_HASH_BLAKE3_OUT_LEN);
    return descriptor_geometry_valid(descriptor) ? PRP_OK : PRP_ERR_PROTOCOL;
}

int
prp_discovery_matrix_commitments(
    const prp_discovery_matrix_descriptor_t *descriptor,
    const uint8_t *aliases, size_t aliases_len,
    const uint8_t *column_bitmaps, size_t column_bitmaps_len,
    uint8_t aliases_commitment[PRP_HASH_BLAKE3_OUT_LEN],
    uint8_t matrix_commitment[PRP_HASH_BLAKE3_OUT_LEN])
{
    static const uint8_t aliases_context[] =
        "PRP-DISCOVERY-MATRIX-ALIASES-v1";
    static const uint8_t matrix_context[] =
        "PRP-DISCOVERY-MATRIX-COLUMNS-v1";
    uint8_t binding[88] = { 0 };
    size_t bitmap_bytes;

    if (!descriptor_geometry_valid(descriptor) || aliases == NULL ||
            column_bitmaps == NULL || aliases_commitment == NULL ||
            matrix_commitment == NULL ||
            aliases_len != (size_t)descriptor->column_count *
                PRP_DISCOVERY_CANDIDATE_HANDLE_LEN)
        return PRP_ERR_ARGUMENT;
    bitmap_bytes = (size_t)1u << (descriptor->precision - 3u);
    if (descriptor->column_count > SIZE_MAX / bitmap_bytes ||
            column_bitmaps_len !=
                (size_t)descriptor->column_count * bitmap_bytes)
        return PRP_ERR_ARGUMENT;
    if (prp_hash_blake3_derive_key(aliases_context,
            sizeof(aliases_context) - 1u, NULL, 0u, aliases, aliases_len,
            aliases_commitment) != 0)
        return PRP_ERR_CRYPTO;
    memcpy(binding, matrix_magic, sizeof(matrix_magic));
    binding[4] = PRP_DISCOVERY_MATRIX_VERSION;
    binding[5] = PRP_DISCOVERY_MATRIX_KIND_SNAPSHOT;
    write_u64(binding + 8, descriptor->generation);
    write_u64(binding + 16, descriptor->previous_generation);
    write_u64(binding + 24, descriptor->valid_from);
    write_u64(binding + 32, descriptor->valid_until);
    write_u16(binding + 40, descriptor->lookup_index_profile);
    binding[42] = descriptor->precision;
    binding[43] = descriptor->hash_count;
    write_u32(binding + 44, descriptor->column_count);
    write_u32(binding + 48, descriptor->row_bytes);
    memcpy(binding + 56, aliases_commitment, PRP_HASH_BLAKE3_OUT_LEN);
    if (prp_hash_blake3_derive_key(matrix_context,
            sizeof(matrix_context) - 1u, binding, sizeof(binding),
            column_bitmaps, column_bitmaps_len, matrix_commitment) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}

int
prp_discovery_matrix_view_validate(const prp_discovery_matrix_view_t *view)
{
    uint8_t aliases_commitment[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t matrix_commitment[PRP_HASH_BLAKE3_OUT_LEN];

    if (view == NULL || view->descriptor == NULL ||
            prp_discovery_matrix_commitments(view->descriptor, view->aliases,
                view->aliases_len, view->column_bitmaps,
                view->column_bitmaps_len, aliases_commitment,
                matrix_commitment) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    if (memcmp(aliases_commitment, view->descriptor->aliases_commitment,
                sizeof(aliases_commitment)) != 0 ||
            memcmp(matrix_commitment, view->descriptor->matrix_commitment,
                sizeof(matrix_commitment)) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}

int
prp_discovery_matrix_query(const prp_discovery_matrix_view_t *view,
    uint8_t identity_profile, const uint8_t *strong_id,
    size_t strong_id_len, uint64_t work_budget,
    prp_discovery_cancel_fn cancelled, void *cancel_context,
    uint8_t *candidate_bits, size_t candidate_bits_len,
    uint32_t *candidate_count)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t bitmap_bytes, column;
    uint64_t required_work;
    uint32_t count = 0u;

    if (prp_discovery_matrix_view_validate(view) != PRP_OK ||
            strong_id == NULL || candidate_bits == NULL ||
            candidate_count == NULL ||
            candidate_bits_len != view->descriptor->row_bytes)
        return PRP_ERR_ARGUMENT;
    required_work = (uint64_t)view->descriptor->column_count *
        PRP_DISCOVERY_BLOOM_HASH_COUNT;
    if (work_budget < required_work)
        return PRP_ERR_POLICY;
    if (prp_discovery_bloom_v4_indexes(
            view->descriptor->lookup_index_profile,
            PRP_DISCOVERY_TARGET_STRONG_ID, identity_profile, strong_id,
            strong_id_len, view->descriptor->precision,
            indexes) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    memset(candidate_bits, 0, candidate_bits_len);
    bitmap_bytes = (size_t)1u << (view->descriptor->precision - 3u);
    for (column = 0u; column < view->descriptor->column_count; column++) {
        const uint8_t *bitmap = view->column_bitmaps + column * bitmap_bytes;
        size_t hash;
        int maybe = 1;

        if (cancelled != NULL && cancelled(cancel_context)) {
            memset(candidate_bits, 0, candidate_bits_len);
            return PRP_ERR_CANCELLED;
        }
        for (hash = 0u; hash < PRP_DISCOVERY_BLOOM_HASH_COUNT; hash++)
            if ((bitmap[indexes[hash] >> 3] &
                    (uint8_t)(1u << (indexes[hash] & 7u))) == 0u) {
                maybe = 0;
                break;
            }
        if (maybe) {
            candidate_bits[column >> 3] |=
                (uint8_t)(1u << (column & 7u));
            count++;
        }
    }
    *candidate_count = count;
    return PRP_OK;
}

int
prp_discovery_matrix_rows_extract(const prp_discovery_matrix_view_t *view,
    const uint64_t *rows, size_t row_count, uint64_t work_budget,
    prp_discovery_cancel_fn cancelled, void *cancel_context,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t bitmap_bytes, required, row, column;
    uint64_t required_work;

    if (prp_discovery_matrix_view_validate(view) != PRP_OK || rows == NULL ||
            row_count == 0u || out == NULL || written == NULL ||
            row_count > SIZE_MAX / view->descriptor->row_bytes)
        return PRP_ERR_ARGUMENT;
    required = row_count * view->descriptor->row_bytes;
    if (out_len < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    required_work = (uint64_t)row_count * view->descriptor->column_count;
    if (work_budget < required_work)
        return PRP_ERR_POLICY;
    bitmap_bytes = (size_t)1u << (view->descriptor->precision - 3u);
    memset(out, 0, required);
    for (row = 0u; row < row_count; row++) {
        if (rows[row] >= UINT64_C(1) << view->descriptor->precision)
            return PRP_ERR_ARGUMENT;
        for (column = 0u; column < view->descriptor->column_count; column++) {
            const uint8_t *bitmap = view->column_bitmaps +
                column * bitmap_bytes;

            if (cancelled != NULL && cancelled(cancel_context)) {
                memset(out, 0, required);
                return PRP_ERR_CANCELLED;
            }
            if ((bitmap[rows[row] >> 3] &
                    (uint8_t)(1u << (rows[row] & 7u))) != 0u)
                out[row * view->descriptor->row_bytes + (column >> 3)] |=
                    (uint8_t)(1u << (column & 7u));
        }
    }
    *written = required;
    return PRP_OK;
}
