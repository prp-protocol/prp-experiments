#ifndef PRP_APP_V1_TRANSPORT_INTERNAL_H
#define PRP_APP_V1_TRANSPORT_INTERNAL_H
#include "prp_app_v1_state.h"
#include "prp_wire_v4_portable.h"
/* Internal authenticated carriage, not a public capability factory. Key
 * establishment, fresh HS2 ownership and complete alias interception must be
 * supplied by the session owner in prp_app_v1_session.c. That owner runs fresh
 * HS2 and its own KDF. No caller-facing context/key import API is exported. */
struct prp_app_transport {
    struct prp_app_state state;
    uint8_t tx[32],rx[32],transcript[48];
    size_t transcript_len;
    uint16_t suite;
    uint32_t generation;
    uint64_t sequence;
    struct prp_wire_v4_replay_window replay;
};
int prp_app_transport_init(struct prp_app_transport *, unsigned role,
    const uint8_t *m1,size_t,const uint8_t *m2,size_t,
    const uint8_t i2r[32],const uint8_t r2i[32]);
int prp_app_transport_seal(struct prp_app_transport *,const uint8_t *,size_t,
    uint8_t *,size_t,size_t *);
int prp_app_transport_receive(struct prp_app_transport *,const uint8_t *,size_t,
    uint64_t,uint8_t reply[113],size_t *);
void prp_app_transport_invalidate(struct prp_app_transport *);
#endif
