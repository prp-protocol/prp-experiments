#include "prp_x25519.h"

#include "prp_memory.h"
#include "prp_platform.h"

prp_status_t prp_x25519_keypair_generate_with_platform(
    prp_x25519_keypair_t **keypair, const prp_platform_t *platform)
{
    uint8_t seed[PRP_X25519_SEED_LEN];
    prp_status_t result;
    int status;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    status = prp_platform_validate(platform, PRP_PLATFORM_CAP_RANDOM);
    if (status != PRP_OK)
        return (prp_status_t)status;
    status = platform->random(platform->context, seed, sizeof(seed));
    result = status == PRP_OK ? prp_x25519_keypair_from_seed(keypair, seed) :
        (prp_status_t)status;
    prp_secure_zero(seed, sizeof(seed));
    return result;
}
