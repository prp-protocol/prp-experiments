#include "prp_content_id.h"
#include "prp_hash.h"
#include "prp_status.h"

#include <prp/wire_v4_codec.h>
#include <stdlib.h>
#include <string.h>

static const uint8_t exact_lookup_v2_domain[] =
    "PRP-DISCOVERY-TARGET-LOOKUP-v2";

static uint16_t get_be16(const uint8_t *value)
{
    return (uint16_t)((uint16_t)value[0] << 8) | value[1];
}

static void put_be16(uint8_t *value, uint16_t number)
{
    value[0] = (uint8_t)(number >> 8);
    value[1] = (uint8_t)number;
}

static void put_be64(uint8_t *value, uint64_t number)
{
    value[0] = (uint8_t)(number >> 56);
    value[1] = (uint8_t)(number >> 48);
    value[2] = (uint8_t)(number >> 40);
    value[3] = (uint8_t)(number >> 32);
    value[4] = (uint8_t)(number >> 24);
    value[5] = (uint8_t)(number >> 16);
    value[6] = (uint8_t)(number >> 8);
    value[7] = (uint8_t)number;
}

static int target_valid(uint8_t kind, uint16_t profile,
    const uint8_t *identifier, uint16_t identifier_len)
{
    struct prp_wire_v4_identity_suite_desc suite;

    if (kind < PRP_DISCOVERY_TARGET_STRONG_ID ||
            kind > PRP_DISCOVERY_TARGET_CONTENT_ID || profile == 0u ||
            identifier == NULL || identifier_len == 0u)
        return 0;
    if (kind == PRP_DISCOVERY_TARGET_STRONG_ID)
        return prp_wire_v4_identity_suite_get(profile, &suite) ==
            PRP_WIRE_V4_OK && identifier_len == suite.strong_id_len;
    if (kind == PRP_DISCOVERY_TARGET_CONTENT_ID) {
        if (identifier_len < PRP_CONTENT_ID_PREFIX_LEN ||
                get_be16(identifier) != profile ||
                prp_wire_v4_identity_suite_get(profile, &suite) !=
                    PRP_WIRE_V4_OK)
            return 0;
        return identifier_len == PRP_CONTENT_ID_PREFIX_LEN +
            suite.strong_id_len;
    }
    return 1;
}

int prp_discovery_target_encode(const prp_discovery_target_t *target,
    uint8_t *encoded, size_t encoded_size, size_t *written)
{
    size_t length;

    if (target == NULL || encoded == NULL || written == NULL ||
            !target_valid(target->target_kind, target->identifier_profile,
                target->identifier, target->identifier_len))
        return PRP_ERR_ARGUMENT;
    length = PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN + target->identifier_len;
    if (encoded_size < length)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    encoded[0] = target->target_kind;
    put_be16(encoded + 1u, target->identifier_profile);
    put_be16(encoded + 3u, target->identifier_len);
    memcpy(encoded + 5u, target->identifier, target->identifier_len);
    *written = length;
    return PRP_OK;
}

int prp_discovery_target_decode(const uint8_t *encoded, size_t encoded_len,
    prp_discovery_target_t *target)
{
    uint16_t identifier_len;

    if (encoded == NULL || target == NULL ||
            encoded_len < PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN)
        return PRP_ERR_ARGUMENT;
    identifier_len = get_be16(encoded + 3u);
    if (encoded_len != PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN + identifier_len ||
            !target_valid(encoded[0], get_be16(encoded + 1u), encoded + 5u,
                identifier_len))
        return PRP_ERR_ARGUMENT;
    target->target_kind = encoded[0];
    target->identifier_profile = get_be16(encoded + 1u);
    target->identifier_len = identifier_len;
    target->identifier = encoded + 5u;
    return PRP_OK;
}

int prp_discovery_target_exact_lookup_v2_preimage(
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint16_t lookup_index_profile,
    const prp_discovery_target_t *target, uint8_t *preimage,
    size_t preimage_size, size_t *written)
{
    const size_t domain_len = sizeof(exact_lookup_v2_domain) - 1u;
    size_t target_key_len, preimage_len, offset, target_written;

    if (rendezvous_id == NULL || rendezvous_id_len == 0u ||
            rendezvous_id_len > UINT16_MAX ||
            lookup_index_profile !=
                PRP_DISCOVERY_TARGET_LOOKUP_V2_PROFILE_BLAKE3_128 ||
            target == NULL || preimage == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    target_key_len = PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN +
        (size_t)target->identifier_len;
    preimage_len = 2u + domain_len + 2u + rendezvous_id_len + 8u + 2u + 2u +
        target_key_len;
    if (preimage_size < preimage_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;

    put_be16(preimage, (uint16_t)domain_len);
    memcpy(preimage + 2u, exact_lookup_v2_domain, domain_len);
    offset = 2u + domain_len;
    put_be16(preimage + offset, (uint16_t)rendezvous_id_len);
    offset += 2u;
    memcpy(preimage + offset, rendezvous_id, rendezvous_id_len);
    offset += rendezvous_id_len;
    put_be64(preimage + offset, filter_generation);
    offset += 8u;
    put_be16(preimage + offset, lookup_index_profile);
    offset += 2u;
    put_be16(preimage + offset, (uint16_t)target_key_len);
    offset += 2u;
    if (prp_discovery_target_encode(target, preimage + offset,
            preimage_size - offset, &target_written) != PRP_OK ||
            target_written != target_key_len)
        return PRP_ERR_ARGUMENT;
    *written = preimage_len;
    return PRP_OK;
}

int prp_discovery_target_exact_lookup_v2_tag(
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint16_t lookup_index_profile,
    const prp_discovery_target_t *target,
    uint8_t lookup_tag[PRP_DISCOVERY_TARGET_LOOKUP_V2_TAG_LEN])
{
    const size_t domain_len = sizeof(exact_lookup_v2_domain) - 1u;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t *preimage;
    size_t target_key_len, preimage_len, written;
    int rc;

    if (rendezvous_id == NULL || rendezvous_id_len == 0u ||
            rendezvous_id_len > UINT16_MAX ||
            lookup_index_profile !=
                PRP_DISCOVERY_TARGET_LOOKUP_V2_PROFILE_BLAKE3_128 ||
            target == NULL || lookup_tag == NULL)
        return PRP_ERR_ARGUMENT;
    target_key_len = PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN +
        (size_t)target->identifier_len;
    preimage_len = 2u + domain_len + 2u + rendezvous_id_len + 8u + 2u + 2u +
        target_key_len;
    preimage = malloc(preimage_len);
    if (preimage == NULL)
        return PRP_ERR_STATE;
    rc = prp_discovery_target_exact_lookup_v2_preimage(rendezvous_id,
        rendezvous_id_len, filter_generation, lookup_index_profile, target,
        preimage, preimage_len, &written);
    if (rc == PRP_OK && (written != preimage_len ||
            prp_hash_blake3(preimage, written, digest) != 0))
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        memcpy(lookup_tag, digest, PRP_DISCOVERY_TARGET_LOOKUP_V2_TAG_LEN);
    free(preimage);
    return rc;
}
