#include "prp_mldsa65.h"
#include "prp_platform.h"

static void erase_bytes(uint8_t *bytes, size_t length)
{
    volatile uint8_t *cursor = bytes;

    while (length-- != 0U)
        *cursor++ = 0U;
}

static prp_status_t platform_random(const prp_platform_t *platform,
    uint8_t *output, size_t output_len)
{
    prp_status_t result = (prp_status_t)prp_platform_validate(platform,
        PRP_PLATFORM_CAP_RANDOM);

    if (result != PRP_OK)
        return result;
    result = (prp_status_t)platform->random(platform->context, output,
        output_len);
    return (int)result > 0 ? PRP_ERR_STATE : result;
}

prp_status_t prp_mldsa65_keypair_generate_with_platform(
    prp_mldsa65_keypair_t **keypair, const prp_platform_t *platform)
{
    uint8_t seed[PRP_MLDSA65_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    result = platform_random(platform, seed, sizeof(seed));
    if (result == PRP_OK)
        result = prp_mldsa65_keypair_from_seed(keypair, seed);
    erase_bytes(seed, sizeof(seed));
    return result;
}

prp_status_t prp_mldsa65_sign_with_platform(
    const prp_mldsa65_keypair_t *keypair, const uint8_t *message,
    size_t message_len, const prp_platform_t *platform, uint8_t *signature,
    size_t signature_size, size_t *written)
{
    uint8_t random[PRP_MLDSA65_SIGN_RANDOM_LEN];
    prp_status_t result;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || message == NULL || message_len == 0U ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA65_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = platform_random(platform, random, sizeof(random));
    if (result == PRP_OK)
        result = prp_mldsa65_sign_with_random(keypair, message, message_len,
            random, signature, signature_size, written);
    erase_bytes(random, sizeof(random));
    return result;
}
