#include "prp_discovery_payload.h"

#include "prp_discovery_bloom.h"
#include "prp_discovery_publication.h"
#include "prp_discovery_voprf.h"

#include <prp/wire_v4_codec.h>

#include <string.h>

#define EXACT_QUERY_LEN 32u
#define EXACT_TOKEN_LEN 16u
#define CHALLENGE_LEN 32u
#define PROOF_HEADER_LEN 42u

static const uint8_t challenge_domain[] =
    "PRP-DISCOVERY-CHALLENGE-v1";
static const uint8_t proof_magic[4] = { 'P', 'R', 'P', 'P' };

static int
all_zero(const uint8_t *data, size_t len)
{
    uint8_t value = 0u;
    size_t i;

    for (i = 0u; i < len; i++)
        value |= data[i];
    return value == 0u;
}

static int
registered_strong_id_len(uint16_t len)
{
    struct prp_wire_v4_identity_suite_desc identity;

    if (prp_wire_v4_identity_suite_get(
            PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_256, &identity) ==
            PRP_WIRE_V4_OK && len == identity.strong_id_len)
        return 1;
    return prp_wire_v4_identity_suite_get(
        PRP_WIRE_V4_IDENTITY_MLDSA87_SHA384_384, &identity) ==
        PRP_WIRE_V4_OK && len == identity.strong_id_len;
}

int
prp_discovery_payload_kind_info(uint8_t kind,
    prp_discovery_payload_kind_info_t *info)
{
    prp_discovery_payload_kind_info_t value;

    if (info == NULL)
        return PRP_ERR_ARGUMENT;
    switch (kind) {
    case PRP_DISCOVERY_PAYLOAD_IDENTITY_PUBLICATION:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_PUBLICATION_CONTROLLER;
        break;
    case PRP_DISCOVERY_PAYLOAD_BLOOM_MANIFEST:
    case PRP_DISCOVERY_PAYLOAD_BLOOM_SHARD:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_FILTER_ORIGIN;
        break;
    case PRP_DISCOVERY_PAYLOAD_REMOTE_BLOOM_VIEW:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_RENDEZVOUS;
        break;
    case PRP_DISCOVERY_PAYLOAD_MICROSHARD_REQUEST:
    case PRP_DISCOVERY_PAYLOAD_EXACT_LOOKUP_QUERY:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_REQUEST;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_REQUESTER;
        break;
    case PRP_DISCOVERY_PAYLOAD_MICROSHARD_RESPONSE:
    case PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE:
        value.payload_class = kind ==
            PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE ?
            PRP_DISCOVERY_PAYLOAD_CLASS_REQUEST :
            PRP_DISCOVERY_PAYLOAD_CLASS_RESPONSE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_RENDEZVOUS;
        break;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_KEY:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_VOPRF_SERVER;
        break;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_REQUEST:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_REQUEST;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_VOPRF_CLIENT;
        break;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_RESPONSE:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_RESPONSE;
        value.sender_role = PRP_DISCOVERY_PAYLOAD_ROLE_VOPRF_SERVER;
        break;
    case PRP_DISCOVERY_PAYLOAD_DESTINATION_PROOF:
        value.payload_class = PRP_DISCOVERY_PAYLOAD_CLASS_RESPONSE;
        value.sender_role =
            PRP_DISCOVERY_PAYLOAD_ROLE_PUBLISHED_DESTINATION;
        break;
    default:
        return PRP_ERR_PROTOCOL;
    }
    *info = value;
    return PRP_OK;
}

static int
validate_challenge(const uint8_t *data, size_t len, uint64_t subject,
    const uint8_t correlation[PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN])
{
    struct prp_wire_v4_identity_suite_desc identity;
    size_t offset = 0u;
    uint16_t strong_len, profile;

    if (len < 2u + sizeof(challenge_domain) - 1u + 2u + 8u + 2u + 2u +
            EXACT_TOKEN_LEN + PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN +
            CHALLENGE_LEN + 2u + 2u)
        return PRP_ERR_PROTOCOL;
    if (prp_wire_v4_get_be16(data) != sizeof(challenge_domain) - 1u ||
            memcmp(data + 2u, challenge_domain,
                sizeof(challenge_domain) - 1u) != 0)
        return PRP_ERR_PROTOCOL;
    offset = 2u + sizeof(challenge_domain) - 1u;
    strong_len = prp_wire_v4_get_be16(data + offset);
    offset += 2u;
    if (!registered_strong_id_len(strong_len) || offset + strong_len > len)
        return PRP_ERR_PROTOCOL;
    offset += strong_len;
    if (offset + 8u + 2u + 2u + EXACT_TOKEN_LEN +
            PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN + CHALLENGE_LEN + 4u > len ||
            prp_wire_v4_get_be64(data + offset) != subject)
        return PRP_ERR_PROTOCOL;
    offset += 8u;
    if (prp_wire_v4_session_suite_get(
            prp_wire_v4_get_be16(data + offset), NULL) != PRP_WIRE_V4_OK)
        return PRP_ERR_PROTOCOL;
    offset += 2u;
    profile = prp_wire_v4_get_be16(data + offset);
    if (profile != 1u && profile != 2u)
        return PRP_ERR_PROTOCOL;
    offset += 2u + EXACT_TOKEN_LEN;
    if (memcmp(data + offset, correlation,
            PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) != 0)
        return PRP_ERR_PROTOCOL;
    offset += PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN;
    if (all_zero(data + offset, CHALLENGE_LEN))
        return PRP_ERR_PROTOCOL;
    offset += CHALLENGE_LEN;
    profile = prp_wire_v4_get_be16(data + offset);
    strong_len = prp_wire_v4_get_be16(data + offset + 2u);
    offset += 4u;
    if (prp_wire_v4_identity_suite_get(profile, &identity) !=
            PRP_WIRE_V4_OK || strong_len != identity.strong_id_len ||
            offset + strong_len != len)
        return PRP_ERR_PROTOCOL;
    return PRP_OK;
}

static void
challenge_fields(const uint8_t *data, const uint8_t **token,
    const uint8_t **challenge, uint16_t *published_identity_suite)
{
    size_t offset = 2u + sizeof(challenge_domain) - 1u;
    uint16_t strong_len = prp_wire_v4_get_be16(data + offset);

    offset += 2u + strong_len + 8u + 2u + 2u;
    *token = data + offset;
    offset += EXACT_TOKEN_LEN + PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN;
    *challenge = data + offset;
    offset += CHALLENGE_LEN;
    *published_identity_suite = prp_wire_v4_get_be16(data + offset);
}

static int
validate_proof(const uint8_t *data, size_t len)
{
    struct prp_wire_v4_identity_suite_desc identity;
    uint16_t profile, proof_len;

    if (len < PROOF_HEADER_LEN ||
            memcmp(data, proof_magic, sizeof(proof_magic)) != 0)
        return PRP_ERR_PROTOCOL;
    if (data[4] != 1u)
        return PRP_ERR_VERSION;
    if (data[5] != 0u || all_zero(data + 8u, CHALLENGE_LEN))
        return PRP_ERR_PROTOCOL;
    profile = prp_wire_v4_get_be16(data + 6u);
    proof_len = prp_wire_v4_get_be16(data + 40u);
    if (prp_wire_v4_identity_suite_get(profile, &identity) !=
            PRP_WIRE_V4_OK ||
            proof_len != (uint32_t)identity.public_key_len + identity.proof_len ||
            PROOF_HEADER_LEN + (size_t)proof_len != len)
        return PRP_ERR_PROTOCOL;
    return PRP_OK;
}

static int
validate_inner(const prp_discovery_payload_t *envelope)
{
    prp_discovery_publication_t publication;
    prp_discovery_bloom_v4_manifest_t manifest;
    prp_discovery_bloom_remote_view_t view;
    prp_discovery_bloom_v4_shard_t shard;
    prp_discovery_bloom_microshard_request_t request;
    prp_discovery_bloom_microshard_response_t response;
    prp_discovery_voprf_key_record_t key;
    prp_discovery_voprf_request_record_t vrequest;
    prp_discovery_voprf_response_record_t vresponse;
    int status;

    switch (envelope->kind) {
    case PRP_DISCOVERY_PAYLOAD_IDENTITY_PUBLICATION:
        status = prp_discovery_publication_decode(envelope->payload,
            envelope->payload_len, &publication);
        return status == PRP_OK && publication.policy_generation ==
            envelope->subject_generation ? PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_BLOOM_MANIFEST:
        status = prp_discovery_bloom_v4_manifest_decode(envelope->payload,
            envelope->payload_len, &manifest);
        return status == PRP_OK && manifest.generation ==
            envelope->subject_generation ? PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_REMOTE_BLOOM_VIEW:
        status = prp_discovery_bloom_remote_view_decode(envelope->payload,
            envelope->payload_len, &view);
        return status == PRP_OK && view.filter_generation ==
            envelope->subject_generation && view.relationship_generation ==
            envelope->policy_generation ? PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_BLOOM_SHARD:
        status = prp_discovery_bloom_v4_shard_decode(envelope->payload,
            envelope->payload_len, &shard);
        return status == PRP_OK && shard.generation ==
            envelope->subject_generation ? PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_MICROSHARD_REQUEST:
        status = prp_discovery_bloom_microshard_request_decode(
            envelope->payload, envelope->payload_len, &request);
        return status == PRP_OK && request.generation ==
            envelope->subject_generation && memcmp(request.query_nonce,
            envelope->correlation, PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) == 0 ?
            PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_MICROSHARD_RESPONSE:
        status = prp_discovery_bloom_microshard_response_decode(
            envelope->payload, envelope->payload_len, &response);
        return status == PRP_OK && response.generation ==
            envelope->subject_generation && memcmp(response.query_nonce,
            envelope->correlation, PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) == 0 ?
            PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_KEY:
        status = prp_discovery_voprf_key_record_decode(envelope->payload,
            envelope->payload_len, &key);
        return status == PRP_OK && key.relationship_generation ==
            envelope->subject_generation && key.relationship_generation ==
            envelope->policy_generation ? PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_REQUEST:
        status = prp_discovery_voprf_request_record_decode(envelope->payload,
            envelope->payload_len, &vrequest);
        return status == PRP_OK && vrequest.relationship_generation ==
            envelope->subject_generation && vrequest.relationship_generation ==
            envelope->policy_generation && memcmp(vrequest.request_id,
            envelope->correlation, PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) == 0 ?
            PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_RESPONSE:
        status = prp_discovery_voprf_response_record_decode(envelope->payload,
            envelope->payload_len, &vresponse);
        return status == PRP_OK && vresponse.relationship_generation ==
            envelope->subject_generation && vresponse.relationship_generation ==
            envelope->policy_generation && memcmp(vresponse.request_id,
            envelope->correlation, PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) == 0 ?
            PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_EXACT_LOOKUP_QUERY:
        return envelope->payload_len == EXACT_QUERY_LEN &&
            memcmp(envelope->payload + EXACT_TOKEN_LEN, envelope->correlation,
                PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) == 0 ?
            PRP_OK : PRP_ERR_PROTOCOL;
    case PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE:
        return validate_challenge(envelope->payload, envelope->payload_len,
            envelope->subject_generation, envelope->correlation);
    case PRP_DISCOVERY_PAYLOAD_DESTINATION_PROOF:
        return validate_proof(envelope->payload, envelope->payload_len);
    default:
        return PRP_ERR_PROTOCOL;
    }
}

static int
validate_envelope(const prp_discovery_payload_t *payload)
{
    prp_discovery_payload_kind_info_t info;
    int correlation_zero;

    if (payload == NULL || payload->policy_generation == 0u ||
            payload->subject_generation == 0u || payload->payload == NULL ||
            payload->payload_len == 0u ||
            payload->payload_len > PRP_DISCOVERY_PAYLOAD_INNER_MAX ||
            prp_discovery_payload_kind_info(payload->kind, &info) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    correlation_zero = all_zero(payload->correlation,
        PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN);
    if ((info.payload_class == PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE) !=
            correlation_zero)
        return PRP_ERR_PROTOCOL;
    return validate_inner(payload);
}

int
prp_discovery_payload_encode(const prp_discovery_payload_t *payload,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t total;
    int status;

    if (out == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    status = validate_envelope(payload);
    if (status != PRP_OK)
        return status;
    total = PRP_DISCOVERY_PAYLOAD_HEADER_LEN + payload->payload_len;
    if (out_len < total)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_PAYLOAD_HEADER_LEN);
    out[PRP_DISCOVERY_PAYLOAD_VERSION_OFFSET] =
        PRP_DISCOVERY_PAYLOAD_VERSION;
    out[PRP_DISCOVERY_PAYLOAD_KIND_OFFSET] = payload->kind;
    prp_wire_v4_put_be32(out + PRP_DISCOVERY_PAYLOAD_POLICY_GENERATION_OFFSET,
        payload->policy_generation);
    prp_wire_v4_put_be64(out + PRP_DISCOVERY_PAYLOAD_SUBJECT_GENERATION_OFFSET,
        payload->subject_generation);
    memcpy(out + PRP_DISCOVERY_PAYLOAD_CORRELATION_OFFSET,
        payload->correlation, PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN);
    prp_wire_v4_put_be16(out + PRP_DISCOVERY_PAYLOAD_LENGTH_OFFSET,
        payload->payload_len);
    memcpy(out + PRP_DISCOVERY_PAYLOAD_BODY_OFFSET, payload->payload,
        payload->payload_len);
    *written = total;
    return PRP_OK;
}

int
prp_discovery_payload_decode(const uint8_t *data, size_t data_len,
    prp_discovery_payload_t *payload)
{
    uint16_t payload_len;

    if (data == NULL || payload == NULL)
        return PRP_ERR_ARGUMENT;
    if (data_len < PRP_DISCOVERY_PAYLOAD_HEADER_LEN)
        return PRP_ERR_SHORT;
    if (data_len > PRP_DISCOVERY_PAYLOAD_E2E_BODY_MAX)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (data[PRP_DISCOVERY_PAYLOAD_VERSION_OFFSET] !=
            PRP_DISCOVERY_PAYLOAD_VERSION)
        return PRP_ERR_VERSION;
    if (prp_wire_v4_get_be16(data + PRP_DISCOVERY_PAYLOAD_FLAGS_OFFSET) != 0u ||
            prp_wire_v4_get_be16(data +
                PRP_DISCOVERY_PAYLOAD_RESERVED_OFFSET) != 0u)
        return PRP_ERR_PROTOCOL;
    payload_len = prp_wire_v4_get_be16(data +
        PRP_DISCOVERY_PAYLOAD_LENGTH_OFFSET);
    if (payload_len > PRP_DISCOVERY_PAYLOAD_INNER_MAX)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (data_len != PRP_DISCOVERY_PAYLOAD_HEADER_LEN + (size_t)payload_len)
        return PRP_ERR_PROTOCOL;
    payload->kind = data[PRP_DISCOVERY_PAYLOAD_KIND_OFFSET];
    payload->policy_generation = prp_wire_v4_get_be32(data +
        PRP_DISCOVERY_PAYLOAD_POLICY_GENERATION_OFFSET);
    payload->subject_generation = prp_wire_v4_get_be64(data +
        PRP_DISCOVERY_PAYLOAD_SUBJECT_GENERATION_OFFSET);
    memcpy(payload->correlation,
        data + PRP_DISCOVERY_PAYLOAD_CORRELATION_OFFSET,
        PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN);
    payload->payload = data + PRP_DISCOVERY_PAYLOAD_BODY_OFFSET;
    payload->payload_len = payload_len;
    return validate_envelope(payload);
}

int
prp_discovery_payload_context_validate(
    const prp_discovery_payload_t *payload, int lane_active,
    uint32_t active_policy_generation, uint64_t expected_subject_generation,
    prp_discovery_payload_role_t sender_role)
{
    prp_discovery_payload_kind_info_t info;
    int status;

    status = validate_envelope(payload);
    if (status != PRP_OK)
        return status;
    if (!lane_active)
        return PRP_ERR_STATE;
    if (payload->policy_generation != active_policy_generation)
        return PRP_ERR_POLICY;
    if (payload->subject_generation != expected_subject_generation)
        return PRP_ERR_STATE;
    status = prp_discovery_payload_kind_info(payload->kind, &info);
    if (status != PRP_OK || info.sender_role != sender_role)
        return PRP_ERR_POLICY;
    return PRP_OK;
}

static uint8_t
expected_response(uint8_t request_kind)
{
    switch (request_kind) {
    case PRP_DISCOVERY_PAYLOAD_MICROSHARD_REQUEST:
        return PRP_DISCOVERY_PAYLOAD_MICROSHARD_RESPONSE;
    case PRP_DISCOVERY_PAYLOAD_VOPRF_REQUEST:
        return PRP_DISCOVERY_PAYLOAD_VOPRF_RESPONSE;
    case PRP_DISCOVERY_PAYLOAD_EXACT_LOOKUP_QUERY:
        return PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE;
    case PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE:
        return PRP_DISCOVERY_PAYLOAD_DESTINATION_PROOF;
    default:
        return 0u;
    }
}

int
prp_discovery_payload_pending_match(const prp_discovery_payload_t *request,
    const prp_discovery_payload_t *response)
{
    const uint8_t *token, *challenge;
    uint16_t published_identity_suite;

    if (request == NULL || response == NULL ||
            validate_envelope(request) != PRP_OK ||
            validate_envelope(response) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    if (expected_response(request->kind) != response->kind ||
            request->policy_generation != response->policy_generation ||
            request->subject_generation != response->subject_generation ||
            memcmp(request->correlation, response->correlation,
                PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN) != 0)
        return PRP_ERR_STATE;
    if (request->kind == PRP_DISCOVERY_PAYLOAD_EXACT_LOOKUP_QUERY) {
        challenge_fields(response->payload, &token, &challenge,
            &published_identity_suite);
        (void)challenge;
        (void)published_identity_suite;
        if (memcmp(request->payload, token, EXACT_TOKEN_LEN) != 0)
            return PRP_ERR_STATE;
    } else if (request->kind ==
            PRP_DISCOVERY_PAYLOAD_DESTINATION_CHALLENGE) {
        challenge_fields(request->payload, &token, &challenge,
            &published_identity_suite);
        (void)token;
        if (memcmp(challenge, response->payload + 8u, CHALLENGE_LEN) != 0 ||
                published_identity_suite !=
                    prp_wire_v4_get_be16(response->payload + 6u))
            return PRP_ERR_STATE;
    }
    return PRP_OK;
}

int
prp_discovery_payload_replay_compare(
    const prp_discovery_payload_t *accepted,
    const prp_discovery_payload_t *candidate)
{
    if (accepted == NULL || candidate == NULL ||
            validate_envelope(accepted) != PRP_OK ||
            validate_envelope(candidate) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    if (accepted->kind == candidate->kind &&
            accepted->policy_generation == candidate->policy_generation &&
            accepted->subject_generation == candidate->subject_generation &&
            accepted->payload_len == candidate->payload_len &&
            memcmp(accepted->payload, candidate->payload,
                accepted->payload_len) == 0)
        return PRP_OK;
    return PRP_ERR_ALREADY;
}
