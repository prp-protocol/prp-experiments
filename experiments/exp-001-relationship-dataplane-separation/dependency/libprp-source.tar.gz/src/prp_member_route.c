#include "prp_member_route.h"
#include "prp_status.h"

#include <prp/wire_v4_codec.h>

#include <string.h>

static int
identity_valid(uint16_t suite, size_t strong_id_len)
{
    struct prp_wire_v4_identity_suite_desc descriptor;

    return prp_wire_v4_identity_suite_get(suite, &descriptor) ==
            PRP_WIRE_V4_OK &&
        strong_id_len == descriptor.strong_id_len;
}

static int
single_section_open(const uint8_t *wire, size_t wire_len,
    uint8_t operation, struct prp_wire_v4_relation_cursor *cursor,
    struct prp_wire_v4_relation_section *section)
{
    if (prp_wire_v4_relation_control_open(wire, wire_len, cursor) !=
            PRP_WIRE_V4_OK || cursor->operation != operation ||
            cursor->scope != PRP_WIRE_V4_SCOPE_ADJACENT ||
            cursor->route_alias != PRP_WIRE_V4_ROUTE_ALIAS_CONTROL ||
            cursor->sections_remaining != 1U ||
            prp_wire_v4_relation_control_next(cursor, section) !=
                PRP_WIRE_V4_OK ||
            cursor->sections_remaining != 0U || cursor->remaining != 0U ||
            section->type != PRP_MEMBER_ROUTE_SECTION_TYPE ||
            section->version != PRP_MEMBER_ROUTE_VERSION ||
            section->flags != PRP_WIRE_V4_RELATION_SECTION_F_CRITICAL ||
            section->base_generation != 0U)
        return PRP_ERR_PROTOCOL;
    return PRP_OK;
}

int
prp_member_route_request_encode(const prp_member_route_request_t *request,
    uint8_t *wire, size_t capacity, size_t *written)
{
    struct prp_wire_v4_relation_section section;
    uint8_t body[PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN +
        PRP_MEMBER_ROUTE_STRONG_ID_MAX_LEN];
    int rc;

    if (request == NULL || wire == NULL || written == NULL ||
            request->transaction_id == 0U || request->generation == 0U ||
            request->strong_id == NULL ||
            !identity_valid(request->identity_suite,
                request->strong_id_len))
        return PRP_ERR_ARGUMENT;
    prp_wire_v4_put_be16(body, request->identity_suite);
    prp_wire_v4_put_be16(body + 2U, request->strong_id_len);
    memcpy(body + PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN, request->strong_id,
        request->strong_id_len);
    memset(&section, 0, sizeof(section));
    section.type = PRP_MEMBER_ROUTE_SECTION_TYPE;
    section.version = PRP_MEMBER_ROUTE_VERSION;
    section.flags = PRP_WIRE_V4_RELATION_SECTION_F_CRITICAL;
    section.generation = request->generation;
    section.body = body;
    section.body_len = (uint16_t)(PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN +
        request->strong_id_len);
    rc = prp_wire_v4_relation_control_encode(PRP_WIRE_V4_SCOPE_ADJACENT,
        PRP_WIRE_V4_ROUTE_ALIAS_CONTROL, PRP_WIRE_V4_RELATION_PROPOSE,
        request->transaction_id, &section, 1U, wire, capacity, written);
    memset(body, 0, sizeof(body));
    return rc == PRP_WIRE_V4_OK ? PRP_OK : PRP_ERR_OUTPUT_TOO_SMALL;
}

int
prp_member_route_request_decode(const uint8_t *wire, size_t wire_len,
    prp_member_route_request_t *request)
{
    struct prp_wire_v4_relation_cursor cursor;
    struct prp_wire_v4_relation_section section;
    uint16_t strong_id_len;

    if (wire == NULL || request == NULL)
        return PRP_ERR_ARGUMENT;
    if (single_section_open(wire, wire_len, PRP_WIRE_V4_RELATION_PROPOSE,
            &cursor, &section) != PRP_OK ||
            section.status != PRP_WIRE_V4_RELATION_STATUS_NONE ||
            section.body_len < PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN)
        return PRP_ERR_PROTOCOL;
    strong_id_len = prp_wire_v4_get_be16(section.body + 2U);
    if (section.body_len != PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN +
            (size_t)strong_id_len ||
            !identity_valid(prp_wire_v4_get_be16(section.body),
                strong_id_len))
        return PRP_ERR_PROTOCOL;
    memset(request, 0, sizeof(*request));
    request->transaction_id = cursor.transaction_id;
    request->generation = section.generation;
    request->identity_suite = prp_wire_v4_get_be16(section.body);
    request->strong_id_len = strong_id_len;
    request->strong_id = section.body + PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN;
    return PRP_OK;
}

int
prp_member_route_result_encode(const prp_member_route_result_t *result,
    uint8_t *wire, size_t capacity, size_t *written)
{
    struct prp_wire_v4_relation_section section;
    uint8_t body[PRP_MEMBER_ROUTE_RESULT_LEN];
    int accepted;
    int rc;

    if (result == NULL || wire == NULL || written == NULL ||
            result->transaction_id == 0U || result->generation == 0U)
        return PRP_ERR_ARGUMENT;
    accepted = result->status == PRP_WIRE_V4_RELATION_STATUS_ACCEPTED;
    if ((accepted && (result->route_alias ==
                PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
            result->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL)) ||
            (!accepted && result->route_alias != 0U) ||
            (!accepted && result->status !=
                PRP_WIRE_V4_RELATION_STATUS_DEFERRED &&
             result->status !=
                PRP_WIRE_V4_RELATION_STATUS_REJECTED &&
             result->status != PRP_WIRE_V4_RELATION_STATUS_STALE &&
             result->status != PRP_WIRE_V4_RELATION_STATUS_UNSUPPORTED))
        return PRP_ERR_ARGUMENT;
    memset(&section, 0, sizeof(section));
    section.type = PRP_MEMBER_ROUTE_SECTION_TYPE;
    section.version = PRP_MEMBER_ROUTE_VERSION;
    section.flags = PRP_WIRE_V4_RELATION_SECTION_F_CRITICAL;
    section.status = result->status;
    section.generation = result->generation;
    if (accepted) {
        prp_wire_v4_put_be16(body, result->route_alias);
        section.body = body;
        section.body_len = sizeof(body);
    }
    rc = prp_wire_v4_relation_control_encode(PRP_WIRE_V4_SCOPE_ADJACENT,
        PRP_WIRE_V4_ROUTE_ALIAS_CONTROL, PRP_WIRE_V4_RELATION_RESULT,
        result->transaction_id, &section, 1U, wire, capacity, written);
    memset(body, 0, sizeof(body));
    return rc == PRP_WIRE_V4_OK ? PRP_OK : PRP_ERR_OUTPUT_TOO_SMALL;
}

int
prp_member_route_result_decode(const uint8_t *wire, size_t wire_len,
    prp_member_route_result_t *result)
{
    struct prp_wire_v4_relation_cursor cursor;
    struct prp_wire_v4_relation_section section;
    uint16_t alias = 0U;

    if (wire == NULL || result == NULL)
        return PRP_ERR_ARGUMENT;
    if (single_section_open(wire, wire_len, PRP_WIRE_V4_RELATION_RESULT,
            &cursor, &section) != PRP_OK)
        return PRP_ERR_PROTOCOL;
    if (section.status == PRP_WIRE_V4_RELATION_STATUS_ACCEPTED) {
        if (section.body_len != PRP_MEMBER_ROUTE_RESULT_LEN)
            return PRP_ERR_PROTOCOL;
        alias = prp_wire_v4_get_be16(section.body);
        if (alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
                alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL)
            return PRP_ERR_PROTOCOL;
    } else if (section.body_len != 0U ||
            (section.status != PRP_WIRE_V4_RELATION_STATUS_DEFERRED &&
             section.status != PRP_WIRE_V4_RELATION_STATUS_REJECTED &&
             section.status != PRP_WIRE_V4_RELATION_STATUS_STALE &&
             section.status != PRP_WIRE_V4_RELATION_STATUS_UNSUPPORTED)) {
        return PRP_ERR_PROTOCOL;
    }
    memset(result, 0, sizeof(*result));
    result->transaction_id = cursor.transaction_id;
    result->generation = section.generation;
    result->route_alias = alias;
    result->status = section.status;
    return PRP_OK;
}
