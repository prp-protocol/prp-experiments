#include "prp_mldsa65.h"

#include "prp_crypto_backend.h"
#include "prp_hash.h"

#include <mldsa_native.h>
#include <prp/wire_v4_crypto.h>

#include <stdlib.h>
#include <string.h>

struct prp_mldsa65_keypair_s {
    uint8_t public_key[PRP_MLDSA65_PUBLIC_KEY_LEN];
    uint8_t private_key[PRP_MLDSA65_PRIVATE_KEY_LEN];
};

static const uint8_t hs2_prefix[] =
    "\x00\x0d" PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;

static prp_status_t allocate_keypair(prp_mldsa65_keypair_t **keypair)
{
    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = calloc(1U, sizeof(**keypair));
    return *keypair != NULL ? PRP_OK : PRP_ERR_NO_MEMORY;
}

void prp_mldsa65_keypair_destroy(prp_mldsa65_keypair_t *keypair)
{
    if (keypair != NULL) {
        prp_crypto_secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}

prp_status_t prp_mldsa65_keypair_from_seed(
    prp_mldsa65_keypair_t **keypair,
    const uint8_t seed[PRP_MLDSA65_SEED_LEN])
{
    prp_mldsa65_keypair_t *created;
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (seed == NULL)
        return PRP_ERR_ARGUMENT;
    result = allocate_keypair(&created);
    if (result != PRP_OK)
        return result;
    if (prp_thirdparty_mldsa65_keypair_internal(created->public_key,
            created->private_key, seed) != 0) {
        prp_mldsa65_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_mldsa65_keypair_generate(
    prp_mldsa65_keypair_t **keypair)
{
    uint8_t seed[PRP_MLDSA65_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    result = prp_mldsa65_keypair_from_seed(keypair, seed);
    prp_crypto_secure_zero(seed, sizeof(seed));
    return result;
}

prp_status_t prp_mldsa65_keypair_import(
    prp_mldsa65_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len)
{
    prp_mldsa65_keypair_t *created;
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (private_key == NULL || private_key_len != PRP_MLDSA65_PRIVATE_KEY_LEN)
        return PRP_ERR_ARGUMENT;
    result = allocate_keypair(&created);
    if (result != PRP_OK)
        return result;
    memcpy(created->private_key, private_key, sizeof(created->private_key));
    if (prp_thirdparty_mldsa65_pk_from_sk(created->public_key,
            created->private_key) != 0) {
        prp_mldsa65_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_mldsa65_public_key_export(
    const prp_mldsa65_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_MLDSA65_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(public_key, keypair->public_key, PRP_MLDSA65_PUBLIC_KEY_LEN);
    *written = PRP_MLDSA65_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_mldsa65_private_key_export(
    const prp_mldsa65_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || private_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (private_key_size < PRP_MLDSA65_PRIVATE_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(private_key, keypair->private_key, PRP_MLDSA65_PRIVATE_KEY_LEN);
    *written = PRP_MLDSA65_PRIVATE_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_mldsa65_sign_with_random(
    const prp_mldsa65_keypair_t *keypair, const uint8_t *message,
    size_t message_len, const uint8_t random[PRP_MLDSA65_SIGN_RANDOM_LEN],
    uint8_t *signature, size_t signature_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || message == NULL || message_len == 0U ||
            random == NULL || signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA65_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_thirdparty_mldsa65_signature_internal(signature, message,
            message_len, hs2_prefix, sizeof(hs2_prefix) - 1U, random,
            keypair->private_key, 0) != 0) {
        prp_crypto_secure_zero(signature, PRP_MLDSA65_SIGNATURE_LEN);
        return PRP_ERR_CRYPTO;
    }
    *written = PRP_MLDSA65_SIGNATURE_LEN;
    return PRP_OK;
}

prp_status_t prp_mldsa65_sign(const prp_mldsa65_keypair_t *keypair,
    const uint8_t *message, size_t message_len, uint8_t *signature,
    size_t signature_size, size_t *written)
{
    uint8_t random[PRP_MLDSA65_SIGN_RANDOM_LEN];
    prp_status_t result;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || message == NULL || message_len == 0U ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA65_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_crypto_random(random, sizeof(random)) != PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(random, sizeof(random));
        return PRP_ERR_UNAVAILABLE;
    }
    result = prp_mldsa65_sign_with_random(keypair, message, message_len,
        random, signature, signature_size, written);
    prp_crypto_secure_zero(random, sizeof(random));
    return result;
}

prp_status_t prp_mldsa65_verify(
    const uint8_t public_key[PRP_MLDSA65_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_MLDSA65_SIGNATURE_LEN],
    const uint8_t *message, size_t message_len)
{
    if (public_key == NULL || signature == NULL || message == NULL ||
            message_len == 0U)
        return PRP_ERR_ARGUMENT;
    return prp_identity_proof_verify(PRP_SELF_CERT_ID_PROOF_MLDSA65,
        public_key, PRP_MLDSA65_PUBLIC_KEY_LEN, signature,
        PRP_MLDSA65_SIGNATURE_LEN, message, message_len,
        (const uint8_t *)PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT,
        PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}
