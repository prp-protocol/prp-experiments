#include "prp_application_session_v1.h"
#include "prp_app_v1_transport.h"
#include "prp_crypto_backend.h"
#include "prp_pq.h"
#include <string.h>

/* All registry mutations, including close/invalidate, use the same guard.
 * No callbacks occur under it. Native contention fails closed (no spin).
 * The non-shared-memory WASM instance is single-threaded; its caller still
 * needs one cross-context owner for asynchronous delivery/commit. */
#define prp_app_session_v1_create app_create_locked
#define prp_app_session_v1_prefix app_prefix_locked
#define prp_app_session_v1_proof app_proof_locked
#define prp_app_session_v1_peer_hs2 app_peer_hs2_locked
#define prp_app_session_v1_offer app_offer_locked
#define prp_app_session_v1_receive app_receive_locked
#define prp_app_session_v1_pending app_pending_locked
#define prp_app_session_v1_decide app_decide_locked
#define prp_app_session_v1_handed app_handed_locked
#define prp_app_session_v1_cancel app_cancel_locked
#define prp_app_session_v1_close app_close_locked
#define prp_app_session_v1_agreement app_agreement_locked
#define prp_app_session_v1_agreement_for_attempt app_agreement_for_attempt_locked
#define prp_app_session_v1_invalidate app_invalidate_locked
#define prp_app_session_v1_memory_bytes app_memory_bytes_locked
#define prp_app_session_v1_seal_item app_seal_item_locked
#define prp_app_session_v1_dispatch app_dispatch_locked
#define prp_app_session_v1_retry app_retry_locked

#define dh_public prp_crypto_x25519_public_from_private
#define dh prp_crypto_x25519_dh

#define SESSION_LIMIT 8u
struct session {
    uint64_t id, now, deadline, rate_epoch;
    uint32_t received;
    uint16_t suite, local_identity, peer_identity, local_len, peer_len;
    uint8_t role, phase; /* 1 created, 2 own prefix, 3 waiting peer, 4 live */
    uint8_t local_key[2624],peer_key[2624],entropy[116],xpublic[32],kemprivate[3168];
    uint8_t m1[16384],m2[16384],shared[64];
    size_t n1,n2,prefix_len,shared_len;
    struct prp_app_transport transport;
    struct { uint8_t accept[23],sender,closed; uint16_t alias; uint32_t generation; } compatibility[64];
};
static struct session sessions[SESSION_LIMIT];
static uint64_t next_id;
/* Serialized-owner interface. No callbacks/reentrancy occur within calls.
 * The consumer must supply the shared sequencer before admitting capabilities. */
static struct session *lookup(uint64_t id)
{
    unsigned i;
    if(!id) return NULL;
    for(i=0;i<SESSION_LIMIT;i++) if(sessions[i].id==id) return &sessions[i];
    return NULL;
}
static int fail(struct session *s)
{ if(s) prp_crypto_secure_zero(s,sizeof *s); return -1; }
static struct session *at(uint64_t id,uint64_t now)
{
    struct session *s=lookup(id);
    if(!s) return NULL;
    if(now<s->now || (s->phase!=4 && now>=s->deadline)) { fail(s); return NULL; }
    s->now=now;
    if(s->phase==4 && prp_app_state_tick(&s->transport.state,now)) { fail(s); return NULL; }
    return s;
}
static int copy_out(const uint8_t *p,size_t n,uint8_t *out,uint32_t cap)
{ if(!out || cap<n) return -1; memcpy(out,p,n); return (int)n; }
static int kem_keypair(unsigned n,uint8_t *pub,uint8_t *priv,const uint8_t *seed)
{ return n==1568 ? prp_mlkem1024_keypair_derand(pub,priv,seed) :
    prp_mlkem768_keypair_derand(pub,priv,seed); }
static int kem_enc(unsigned n,uint8_t *ct,uint8_t *secret,const uint8_t *pub,const uint8_t *seed)
{ return n==1568 ? prp_mlkem1024_encapsulate_derand(ct,secret,pub,seed) :
    prp_mlkem768_encapsulate_derand(ct,secret,pub,seed); }
static int kem_dec(unsigned n,uint8_t *secret,const uint8_t *ct,const uint8_t *priv)
{ return n==1568 ? prp_mlkem1024_decapsulate(secret,ct,priv) :
    prp_mlkem768_decapsulate(secret,ct,priv); }
uint64_t prp_app_session_v1_create(uint32_t role,uint32_t suite,uint32_t li,
    const uint8_t *lk,uint32_t ln,uint32_t pi,const uint8_t *pk,uint32_t pn,
    const uint8_t entropy[116],uint64_t now)
{
    struct prp_wire_v4_identity_suite_desc local,peer;
    struct prp_wire_v4_session_crypto_desc crypto;
    struct session *s=NULL; unsigned i; uint8_t nonce_preimage[124],digest[32];
    if((role!=1 && role!=2) || suite>65535 || li>65535 || pi>65535 ||
       !lk || !pk || !entropy || next_id==UINT64_MAX || now>UINT64_MAX-30000 ||
       prp_wire_v4_identity_suite_get((uint16_t)li,&local) ||
       prp_wire_v4_identity_suite_get((uint16_t)pi,&peer) ||
       ln!=local.public_key_len || pn!=peer.public_key_len || ln>2624 || pn>2624 ||
       prp_wire_v4_session_crypto_get((uint16_t)suite,&crypto) || !crypto.traffic_key_len) return 0;
    for(i=0;i<SESSION_LIMIT;i++) if(!sessions[i].id) { s=&sessions[i]; break; }
    if(!s) return 0;
    memset(s,0,sizeof *s); s->id=++next_id; s->now=now; s->deadline=now+30000;
    s->role=(uint8_t)role; s->phase=1; s->suite=(uint16_t)suite;
    s->local_identity=(uint16_t)li; s->peer_identity=(uint16_t)pi;
    s->local_len=(uint16_t)ln; s->peer_len=(uint16_t)pn;
    memcpy(s->local_key,lk,ln); memcpy(s->peer_key,pk,pn); memcpy(s->entropy,entropy,116);
    /* CSPRNG input is the platform's responsibility. Counter binding also
     * prevents same-process nonce reuse if a caller repeats its input. */
    memcpy(nonce_preimage,entropy,116); prp_wire_v4_put_be64(nonce_preimage+116,s->id);
    if(prp_crypto_hash_sha2_concat(256,(const uint8_t *)"PRP-APP-HS2-NONCE-v1",20,
       nonce_preimage,sizeof nonce_preimage,digest,sizeof digest)) { fail(s); return 0; }
    memcpy(s->entropy,digest,16); prp_crypto_secure_zero(digest,sizeof digest);
    prp_crypto_secure_zero(nonce_preimage,sizeof nonce_preimage);
    if(crypto.x25519_secret_len && dh_public(entropy+16,s->xpublic)) { fail(s); return 0; }
    return s->id;
}
static int make_prefix(struct session *s)
{
    prp_wire_v4_hs2_fields_t f;
    struct prp_wire_v4_session_suite_desc desc;
    struct prp_wire_v4_hs2_view peer;
    uint8_t kem[1568],binding[48]; size_t bn=0; int rc=-1;
    memset(&f,0,sizeof f);
    if(prp_wire_v4_session_suite_get(s->suite,&desc)) return -1;
    f.session_suite_id=s->suite; f.identity_suite_id=s->local_identity;
    f.kind=s->role; f.identity_public_key=s->local_key; f.identity_public_key_len=s->local_len;
    f.ephemeral_key=desc.ephemeral_key_len?s->xpublic:NULL; f.ephemeral_key_len=desc.ephemeral_key_len;
    f.nonce=s->entropy; f.nonce_len=16;
    if(s->role==1) {
        if(desc.kem_public_key_len && kem_keypair(desc.kem_public_key_len,kem,s->kemprivate,s->entropy+48)) goto done;
        f.kem_value=desc.kem_public_key_len?kem:NULL; f.kem_value_len=desc.kem_public_key_len;
    } else {
        if(!s->n1 || prp_wire_v4_hs2_extract(s->m1,s->n1,&peer) ||
           prp_wire_v4_m1_binding(s->m1,s->n1,binding,sizeof binding,&bn)) goto done;
        f.nonce=peer.nonce; f.m1_binding=binding; f.m1_binding_len=bn;
        f.session_generation=prp_wire_v4_get_be32(s->entropy+112);
        if(!f.session_generation) goto done;
        if(desc.ephemeral_key_len) {
            if(dh(s->entropy+16,peer.ephemeral_key,s->shared)) goto done;
            s->shared_len=32;
        }
        if(desc.kem_public_key_len) {
            if(kem_enc(desc.kem_public_key_len,kem,s->shared+s->shared_len,peer.kem_value,s->entropy+48)) goto done;
            s->shared_len+=32;
        }
        f.kem_value=desc.kem_ciphertext_len?kem:NULL; f.kem_value_len=desc.kem_ciphertext_len;
    }
    rc=prp_wire_v4_hs2_prefix_encode(&f,s->role==1?s->m1:s->m2,16384,&s->prefix_len);
done:
    prp_crypto_secure_zero(kem,sizeof kem); prp_crypto_secure_zero(binding,sizeof binding);
    if(!rc) s->phase=2;
    return rc;
}
int32_t prp_app_session_v1_prefix(uint64_t id,uint8_t *out,uint32_t cap)
{
    struct session *s=lookup(id);
    if(!s || !out || cap<16384 || (s->phase!=1 && s->phase!=2)) return -1;
    if(s->phase==1 && make_prefix(s)) return fail(s);
    return copy_out(s->role==1?s->m1:s->m2,s->prefix_len,out,cap);
}
static int establish(struct session *s)
{
    struct prp_wire_v4_hs2_view peer;
    struct prp_wire_v4_session_suite_desc desc;
    uint8_t transcript[48],i2r[32],r2i[32]; size_t tn=0; int result=-1;
    if(prp_wire_v4_session_suite_get(s->suite,&desc) ||
       prp_wire_v4_hs2_extract(s->m2,s->n2,&peer)) goto done;
    if(s->role==1) {
        if(desc.ephemeral_key_len) {
            if(dh(s->entropy+16,peer.ephemeral_key,s->shared)) goto done;
            s->shared_len=32;
        }
        if(desc.kem_public_key_len) {
            if(kem_dec(desc.kem_public_key_len,s->shared+s->shared_len,peer.kem_value,s->kemprivate)) goto done;
            s->shared_len+=32;
        }
    }
    if(prp_wire_v4_transcript_hash(s->m1,s->n1,s->m2,s->n2,transcript,sizeof transcript,&tn) ||
       prp_wire_v4_traffic_keys(3,s->suite,peer.session_generation,transcript,tn,s->shared,s->shared_len,i2r,r2i) ||
       prp_app_transport_init(&s->transport,s->role,s->m1,s->n1,s->m2,s->n2,i2r,r2i)) goto done;
    s->phase=4; s->transport.state.now=s->now; result=0;
done:
    prp_crypto_secure_zero(transcript,sizeof transcript); prp_crypto_secure_zero(i2r,sizeof i2r);
    prp_crypto_secure_zero(r2i,sizeof r2i); prp_crypto_secure_zero(s->entropy,sizeof s->entropy);
    prp_crypto_secure_zero(s->kemprivate,sizeof s->kemprivate); prp_crypto_secure_zero(s->shared,sizeof s->shared);
    return result;
}
int32_t prp_app_session_v1_proof(uint64_t id,const uint8_t *proof,uint32_t n,
    uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=at(id,now); uint8_t *wire; size_t len;
    if(!s || s->phase!=2 || !proof || !out || cap<16384) return -1;
    wire=s->role==1?s->m1:s->m2; len=s->prefix_len;
    if(prp_wire_v4_hs2_proof_append(s->local_identity,proof,n,wire,16384,&len) ||
       prp_wire_v4_hs2_identity_verify(wire,len)) return fail(s);
    if(s->role==1) { s->n1=len; s->phase=3; }
    else { s->n2=len; if(establish(s)) return fail(s); }
    return copy_out(wire,len,out,cap);
}
int32_t prp_app_session_v1_peer_hs2(uint64_t id,const uint8_t *wire,uint32_t n,uint64_t now)
{
    struct session *s=at(id,now); struct prp_wire_v4_hs2_view v;
    uint8_t binding[48]; size_t bn=0;
    if(!s || !wire || n>16384 || !n ||
       (s->role==1?s->phase!=3:s->phase!=1) || (s->role==2 && s->n1)) return -1;
    if(prp_wire_v4_hs2_extract(wire,n,&v) || v.kind!=3u-s->role ||
       v.session_suite_id!=s->suite || v.identity_suite_id!=s->peer_identity ||
       v.public_key_len!=s->peer_len || memcmp(v.public_key,s->peer_key,s->peer_len) ||
       prp_wire_v4_hs2_identity_verify(wire,n)) return fail(s);
    if(s->role==2) { memcpy(s->m1,wire,n); s->n1=n; return 0; }
    if(v.nonce_len!=16 || memcmp(v.nonce,s->entropy,16) ||
       prp_wire_v4_m1_binding(s->m1,s->n1,binding,sizeof binding,&bn) ||
       v.m1_binding_len!=bn || memcmp(v.m1_binding,binding,bn)) return fail(s);
    memcpy(s->m2,wire,n); s->n2=n;
    if(establish(s)) return fail(s);
    return 0;
}
static struct session *live(uint64_t id,uint64_t now)
{ struct session *s=at(id,now); return s && s->phase==4 ? s : NULL; }
static int receive_budget(struct session *s)
{
    if(s->now-s->rate_epoch>=1000) { s->rate_epoch=s->now; s->received=0; }
    if(s->received>=128) return -1;
    s->received++; return 0;
}
static int emit(struct session *s,const uint8_t *body,size_t n,uint8_t *out,uint32_t cap)
{ size_t written=0; return prp_app_transport_seal(&s->transport,body,n,out,cap,&written)?-1:(int)written; }
static int sync_result(struct session *s,int rc)
{ return s && !s->transport.state.live ? fail(s) : rc; }
int32_t prp_app_session_v1_offer(uint64_t id,const uint8_t *wire,uint32_t n,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); prp_app_v1_message m; uint8_t body[125]; size_t bn=0; unsigned i;
    if(!s || !out || cap<167 || prp_app_v1_decode(wire,n,&m) || m.kind!=7) return -1;
    for(i=0;i<32;i++) if(m.context[i]) return -1;
    memcpy(m.context,s->transport.state.context,32); m.opener=s->role;
    if(prp_app_state_offer(&s->transport.state,&m,now,body,&bn)) return -1;
    return emit(s,body,bn,out,cap);
}
int32_t prp_app_session_v1_receive(uint64_t id,const uint8_t *wire,uint32_t n,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); uint8_t body[113]; size_t bn=0; int rc;
    if(!s || !out || cap<167 || receive_budget(s)) return -1;
    rc=prp_app_transport_receive(&s->transport,wire,n,now,body,&bn);
    if(!s->transport.state.live) return fail(s);
    if(rc==1) return -2;
    if(rc || !bn) return rc;
    return emit(s,body,bn,out,cap);
}
static struct prp_app_attempt *attempt(struct session *s,uint64_t a,uint32_t r)
{
    unsigned i;
    for(i=0;i<64;i++) if(s->transport.state.slots[i].phase &&
        s->transport.state.slots[i].id==a && s->transport.state.slots[i].role==r) return &s->transport.state.slots[i];
    return NULL;
}
int32_t prp_app_session_v1_pending(uint64_t id,uint64_t a,uint32_t r,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); struct prp_app_attempt *p;
    if(!s || !(p=attempt(s,a,r)) || p->phase!=APP_RECEIVED) return -1;
    return copy_out(p->offer,p->offer_len,out,cap);
}
int32_t prp_app_session_v1_decide(uint64_t id,uint64_t a,uint32_t r,uint32_t alias,uint32_t gen,uint32_t reason,
    uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); uint8_t body[113]; size_t n=0; int rc;
    if(!s || !out || cap<167 || alias>65535 || reason>5) return -1;
    rc=prp_app_state_decide(&s->transport.state,a,r,(uint16_t)alias,gen,(uint16_t)reason,now,body,&n);
    if(rc) return sync_result(s,rc);
    return emit(s,body,n,out,cap);
}
int32_t prp_app_session_v1_handed(uint64_t id,uint64_t a,uint64_t now)
{ struct session *s=live(id,now); return s?prp_app_state_handed(&s->transport.state,a,s->role,now):-1; }
int32_t prp_app_session_v1_retry(uint64_t id,uint64_t a,uint32_t role,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); struct prp_app_attempt *p;
    if(!s || !out || cap<167 || !(p=attempt(s,a,role)) || p->duplicates>=8 ||
       (p->phase==APP_ACTIVE && now>=p->expires)) return -1;
    if(p->phase==APP_OFFER && role==s->role) {
        p->duplicates++; return emit(s,p->offer,p->offer_len,out,cap);
    }
    if(!p->reply_len) return -1;
    p->duplicates++; return emit(s,p->reply,p->reply_len,out,cap);
}
int32_t prp_app_session_v1_cancel(uint64_t id,uint64_t a,uint32_t r,uint64_t now)
{ struct session *s=live(id,now); return s?prp_app_state_cancel(&s->transport.state,a,r,now):-1; }
int32_t prp_app_session_v1_close(uint64_t id,uint32_t alias,uint32_t gen,uint64_t now)
{ struct session *s=live(id,now); return s && alias<=65535?prp_app_state_close(&s->transport.state,(uint16_t)alias,gen,now):-1; }
int32_t prp_app_session_v1_agreement(uint64_t id,uint32_t alias,uint32_t gen,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); unsigned i;
    if(!s || alias>65535 || !prp_app_state_admits(&s->transport.state,(uint16_t)alias,gen,now)) return -1;
    for(i=0;i<64;i++) if(s->transport.state.slots[i].phase==APP_ACTIVE &&
       s->transport.state.slots[i].alias==alias && s->transport.state.slots[i].generation==gen)
        return copy_out(s->transport.state.slots[i].accept,113,out,cap);
    return -1;
}
int32_t prp_app_session_v1_agreement_for_attempt(uint64_t id,uint64_t a,uint32_t r,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); struct prp_app_attempt *p;
    if(!s || !(p=attempt(s,a,r)) || p->phase!=APP_ACTIVE) return -1;
    return copy_out(p->accept,113,out,cap);
}
int32_t prp_app_session_v1_invalidate(uint64_t id)
{ struct session *s=lookup(id); if(!s) return -1; fail(s); return 0; }
uint32_t prp_app_session_v1_memory_bytes(void) { return (uint32_t)sizeof sessions; }

static struct prp_app_attempt *by_alias(struct session *s,uint16_t alias)
{
    unsigned i;
    for(i=0;i<64;i++) if(s->transport.state.slots[i].phase && s->transport.state.slots[i].alias==alias)
        return &s->transport.state.slots[i];
    return NULL;
}
/* Returns 3 for bound data, 4 for compatibility data. Labels cannot change authority. */
static int item_gate(struct session *s,const uint8_t *item,size_t n,unsigned sender)
{
    struct prp_wire_v4_e2e_item view; struct prp_wire_v4_connection_control c;
    struct prp_app_attempt *a; unsigned i,free_slot=64;
    if(prp_wire_v4_e2e_item_decode(item,n,&view)) return -1;
    if(view.connection_alias) {
        a=by_alias(s,view.connection_alias);
        if(a) return a->phase==APP_ACTIVE?3:-1;
        for(i=0;i<64;i++) if(s->compatibility[i].alias==view.connection_alias)
            return s->compatibility[i].closed?-1:4;
        return -1;
    }
    if(prp_wire_v4_connection_control_decode(view.body,view.body_len,&c)) return -1;
    if(c.kind==PRP_WIRE_V4_CONNECTION_ACCEPT) {
        for(i=0;i<64;i++) {
            if(!s->compatibility[i].alias) free_slot=i;
            else if(s->compatibility[i].alias==c.connection_alias) {
                if(s->compatibility[i].sender!=sender || memcmp(s->compatibility[i].accept,view.body,23)) return fail(s);
                return s->compatibility[i].closed?-1:4;
            }
        }
        if(s->transport.state.used[c.connection_alias>>3]&(1u<<(c.connection_alias&7))) return fail(s);
        if(free_slot==64) return -1;
        if(prp_app_state_compatibility_reserve(&s->transport.state,c.connection_alias)) return fail(s);
        s->compatibility[free_slot].alias=c.connection_alias; s->compatibility[free_slot].generation=c.generation;
        s->compatibility[free_slot].sender=(uint8_t)sender; memcpy(s->compatibility[free_slot].accept,view.body,23);
        if(c.generation>s->transport.state.generation[sender-1])
            s->transport.state.generation[sender-1]=c.generation;
    } else if(c.kind==PRP_WIRE_V4_CONNECTION_CLOSE || c.kind==PRP_WIRE_V4_CONNECTION_CLOSE_ACK ||
              c.kind==PRP_WIRE_V4_CONNECTION_FEEDBACK) {
        a=by_alias(s,c.connection_alias);
        if(a) {
            if(a->generation!=c.generation) return -1;
            if(c.kind!=PRP_WIRE_V4_CONNECTION_FEEDBACK)
                prp_app_state_close(&s->transport.state,c.connection_alias,c.generation,s->now);
            else if(a->phase!=APP_ACTIVE) return -1;
            return 4; /* control, never application payload */
        }
        for(i=0;i<64;i++) if(s->compatibility[i].alias==c.connection_alias) {
            if(s->compatibility[i].generation!=c.generation) return -1;
            if(c.kind!=PRP_WIRE_V4_CONNECTION_FEEDBACK) s->compatibility[i].closed=1;
            else if(s->compatibility[i].closed) return -1;
            return 4;
        }
        return -1;
    }
    return 4;
}
int32_t prp_app_session_v1_seal_item(uint64_t id,const uint8_t *item,uint32_t n,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); size_t written=0; uint64_t seq;
    if(!s || !item || !out || n>65507 || cap<n+28 || s->transport.sequence==UINT64_MAX) return -1;
    if(item_gate(s,item,n,s->role)<0) return -1;
    seq=s->transport.sequence++;
    if(prp_wire_v4_aop_seal(3,s->suite,s->transport.generation,seq,s->transport.tx,
       s->transport.transcript,s->transport.transcript_len,item,n,out,cap,&written)) return -1;
    return (int32_t)written;
}
int32_t prp_app_session_v1_dispatch(uint64_t id,const uint8_t *wire,uint32_t n,uint64_t now,uint8_t *out,uint32_t cap)
{
    struct session *s=live(id,now); uint8_t item[65535],reply[113]; size_t len=0,rn=0;
    prp_app_v1_message m; struct prp_app_attempt *a; int rc=-1,tag; unsigned i;
    if(!s || !wire || !out || cap<65649 || n>65535 || receive_budget(s)) return -1;
    if(prp_wire_v4_aop_open(3,s->suite,s->transport.rx,s->transport.transcript,s->transport.transcript_len,
       &s->transport.replay,wire,n,item,sizeof item,&len) || len<14 || len!=14u+prp_wire_v4_get_be16(item+12)) goto done;
    if(!prp_wire_v4_get_be16(item) && len>14 && item[14]>=7 && item[14]<=10) {
        for(i=0;i<12;i++) if(item[i]) goto done;
        tag=prp_app_state_receive(&s->transport.state,item+14,len-14,3u-s->role,now,reply,&rn);
        if(!s->transport.state.live) { fail(s); goto done; }
        if(tag==1) { out[0]=2; memcpy(out+1,item+14,len-14); rc=(int)len-13; }
        else if(!tag && rn) { rc=emit(s,reply,rn,out+1,cap-1); if(rc>0) { out[0]=1; rc++; } }
        else if(!tag) { out[0]=0; rc=1; }
        goto done;
    }
    tag=item_gate(s,item,len,3u-s->role); if(tag<0) goto done;
    if(tag==3) {
        a=by_alias(s,prp_wire_v4_get_be16(item));
        if(!a || prp_app_v1_decode(a->offer,a->offer_len,&m)) goto done;
        out[0]=3; memcpy(out+1,a->accept,113); memcpy(out+114,item,len); rc=(int)len+114;
    } else { out[0]=4; memcpy(out+1,item,len); rc=(int)len+1; }
done:
    prp_crypto_secure_zero(item,sizeof item); prp_crypto_secure_zero(reply,sizeof reply); return rc;
}

#undef prp_app_session_v1_create
#undef prp_app_session_v1_prefix
#undef prp_app_session_v1_proof
#undef prp_app_session_v1_peer_hs2
#undef prp_app_session_v1_offer
#undef prp_app_session_v1_receive
#undef prp_app_session_v1_pending
#undef prp_app_session_v1_decide
#undef prp_app_session_v1_handed
#undef prp_app_session_v1_cancel
#undef prp_app_session_v1_close
#undef prp_app_session_v1_agreement
#undef prp_app_session_v1_agreement_for_attempt
#undef prp_app_session_v1_invalidate
#undef prp_app_session_v1_memory_bytes
#undef prp_app_session_v1_seal_item
#undef prp_app_session_v1_dispatch
#undef prp_app_session_v1_retry
static unsigned char registry_guard;
static int enter(void)
{
#ifdef __wasm__
    if(registry_guard) return -1;
    registry_guard=1; return 0;
#else
    return __atomic_test_and_set(&registry_guard,__ATOMIC_ACQUIRE)?-1:0;
#endif
}
static void leave(void)
{
#ifdef __wasm__
    registry_guard=0;
#else
    __atomic_clear(&registry_guard,__ATOMIC_RELEASE);
#endif
}
#define WRAP(type,name,reject,params,args) \
type prp_app_session_v1_##name params { type rc; if(enter()) return reject; \
    rc=app_##name##_locked args; leave(); return rc; }
WRAP(uint64_t,create,0,(uint32_t r,uint32_t s,uint32_t li,const uint8_t *lk,uint32_t ln,uint32_t pi,const uint8_t *pk,uint32_t pn,const uint8_t e[116],uint64_t t),(r,s,li,lk,ln,pi,pk,pn,e,t))
WRAP(int32_t,prefix,-1,(uint64_t h,uint8_t *o,uint32_t c),(h,o,c))
WRAP(int32_t,proof,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t,uint8_t *o,uint32_t c),(h,p,n,t,o,c))
WRAP(int32_t,peer_hs2,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t),(h,p,n,t))
WRAP(int32_t,offer,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t,uint8_t *o,uint32_t c),(h,p,n,t,o,c))
WRAP(int32_t,receive,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t,uint8_t *o,uint32_t c),(h,p,n,t,o,c))
WRAP(int32_t,pending,-1,(uint64_t h,uint64_t a,uint32_t r,uint64_t t,uint8_t *o,uint32_t c),(h,a,r,t,o,c))
WRAP(int32_t,decide,-1,(uint64_t h,uint64_t a,uint32_t r,uint32_t alias,uint32_t g,uint32_t reason,uint64_t t,uint8_t *o,uint32_t c),(h,a,r,alias,g,reason,t,o,c))
WRAP(int32_t,handed,-1,(uint64_t h,uint64_t a,uint64_t t),(h,a,t))
WRAP(int32_t,cancel,-1,(uint64_t h,uint64_t a,uint32_t r,uint64_t t),(h,a,r,t))
WRAP(int32_t,close,-1,(uint64_t h,uint32_t a,uint32_t g,uint64_t t),(h,a,g,t))
WRAP(int32_t,agreement,-1,(uint64_t h,uint32_t a,uint32_t g,uint64_t t,uint8_t *o,uint32_t c),(h,a,g,t,o,c))
WRAP(int32_t,agreement_for_attempt,-1,(uint64_t h,uint64_t a,uint32_t r,uint64_t t,uint8_t *o,uint32_t c),(h,a,r,t,o,c))
WRAP(int32_t,invalidate,-1,(uint64_t h),(h))
WRAP(uint32_t,memory_bytes,0,(void),())
WRAP(int32_t,seal_item,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t,uint8_t *o,uint32_t c),(h,p,n,t,o,c))
WRAP(int32_t,dispatch,-1,(uint64_t h,const uint8_t *p,uint32_t n,uint64_t t,uint8_t *o,uint32_t c),(h,p,n,t,o,c))
WRAP(int32_t,retry,-1,(uint64_t h,uint64_t a,uint32_t r,uint64_t t,uint8_t *o,uint32_t c),(h,a,r,t,o,c))
