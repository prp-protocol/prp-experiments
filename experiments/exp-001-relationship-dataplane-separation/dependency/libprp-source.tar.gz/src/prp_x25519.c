#include "prp_x25519.h"

#include "prp_crypto_backend.h"
#include "prp_memory.h"

#include <stdlib.h>
#include <string.h>

struct prp_x25519_keypair_s {
    uint8_t private_key[PRP_X25519_SEED_LEN];
    uint8_t public_key[PRP_X25519_PUBLIC_KEY_LEN];
};

static prp_status_t create_from_seed(prp_x25519_keypair_t **keypair,
    const uint8_t seed[PRP_X25519_SEED_LEN])
{
    prp_x25519_keypair_t *created;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (seed == NULL)
        return PRP_ERR_ARGUMENT;
    created = calloc(1U, sizeof(*created));
    if (created == NULL)
        return PRP_ERR_NO_MEMORY;
    memcpy(created->private_key, seed, sizeof(created->private_key));
    if (prp_crypto_x25519_public_from_private(created->private_key,
            created->public_key) != PRP_CRYPTO_OK) {
        prp_x25519_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_x25519_keypair_from_seed(prp_x25519_keypair_t **keypair,
    const uint8_t seed[PRP_X25519_SEED_LEN])
{
    return create_from_seed(keypair, seed);
}

prp_status_t prp_x25519_keypair_generate(prp_x25519_keypair_t **keypair)
{
    uint8_t private_key[PRP_X25519_SEED_LEN];
    uint8_t public_key[PRP_X25519_PUBLIC_KEY_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_x25519_keypair(public_key, private_key) != PRP_CRYPTO_OK) {
        prp_secure_zero(private_key, sizeof(private_key));
        prp_secure_zero(public_key, sizeof(public_key));
        return PRP_ERR_UNAVAILABLE;
    }
    result = create_from_seed(keypair, private_key);
    if (result == PRP_OK && !prp_constant_time_equal(
            (*keypair)->public_key, public_key, sizeof(public_key))) {
        prp_x25519_keypair_destroy(*keypair);
        *keypair = NULL;
        result = PRP_ERR_CRYPTO;
    }
    prp_secure_zero(private_key, sizeof(private_key));
    prp_secure_zero(public_key, sizeof(public_key));
    return result;
}

prp_status_t prp_x25519_public_key_export(
    const prp_x25519_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_X25519_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(public_key, keypair->public_key, PRP_X25519_PUBLIC_KEY_LEN);
    *written = PRP_X25519_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_x25519_agree(const prp_x25519_keypair_t *keypair,
    const uint8_t peer_public_key[PRP_X25519_PUBLIC_KEY_LEN],
    uint8_t *shared_secret, size_t shared_secret_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || peer_public_key == NULL ||
            shared_secret == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (shared_secret_size < PRP_X25519_SHARED_SECRET_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_crypto_x25519_dh(keypair->private_key, peer_public_key,
            shared_secret) != PRP_CRYPTO_OK) {
        prp_secure_zero(shared_secret, PRP_X25519_SHARED_SECRET_LEN);
        return PRP_ERR_CRYPTO;
    }
    *written = PRP_X25519_SHARED_SECRET_LEN;
    return PRP_OK;
}

void prp_x25519_keypair_destroy(prp_x25519_keypair_t *keypair)
{
    if (keypair != NULL) {
        prp_secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}
