#include "prp_random.h"

#include "prp_memory.h"
#include "prp_platform.h"

prp_status_t prp_random_bytes_with_platform(uint8_t *output,
    size_t output_len, const prp_platform_t *platform)
{
    int result;

    if (output == NULL && output_len != 0U)
        return PRP_ERR_ARGUMENT;
    result = prp_platform_validate(platform, PRP_PLATFORM_CAP_RANDOM);
    if (result != PRP_OK)
        return (prp_status_t)result;
    if (output_len == 0U)
        return PRP_OK;
    prp_secure_zero(output, output_len);
    result = platform->random(platform->context, output, output_len);
    if (result == PRP_OK)
        return PRP_OK;
    prp_secure_zero(output, output_len);
    return (prp_status_t)result;
}
