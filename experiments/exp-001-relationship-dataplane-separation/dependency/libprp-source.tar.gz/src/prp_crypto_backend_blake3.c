#include "prp_crypto_backend.h"

#ifndef PRP_REQUIRE_KERNEL_HASH
#include <blake3.h>
#endif

#include <stdlib.h>
#include <string.h>

#ifdef PRP_ENABLE_KERNEL_HASH
#include <linux/prp_netlink.h>
#include "prp_crypto_backend_kernel.h"
#endif

#ifdef PRP_ENABLE_KERNEL_HASH
static int
kernel_fallback_allowed(int rc)
{
#ifdef PRP_REQUIRE_KERNEL_HASH
    (void) rc;
    return 0;
#else
    return rc == PRP_CRYPTO_ERR_UNAVAILABLE ||
        rc == PRP_CRYPTO_ERR_UNSUPPORTED;
#endif
}
#endif

int
prp_crypto_hash_blake3(const uint8_t *input, size_t input_len, uint8_t *out,
    size_t out_len)
{
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher hasher;
#endif
#ifdef PRP_ENABLE_KERNEL_HASH
    uint8_t digest[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN];
    int rc;
#endif

    if (out == NULL || out_len > PRP_CRYPTO_HASH_BLAKE3_OUT_LEN ||
        (input == NULL && input_len != 0u)) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    if (out_len == 0u) {
        return PRP_CRYPTO_OK;
    }
#ifdef PRP_ENABLE_KERNEL_HASH
    if (input_len <= PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN) {
        rc = prp_crypto_kernel_blake3_hash(input, input_len, digest);
        if (rc == PRP_CRYPTO_OK) {
            memcpy(out, digest, out_len);
            memset(digest, 0, sizeof(digest));
            return PRP_CRYPTO_OK;
        }
        memset(digest, 0, sizeof(digest));
        if (!kernel_fallback_allowed(rc)) {
            return rc;
        }
    }
#ifdef PRP_REQUIRE_KERNEL_HASH
    else {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
#endif
#endif
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher_init(&hasher);
    if (input_len != 0u) {
        blake3_hasher_update(&hasher, input, input_len);
    }
    blake3_hasher_finalize(&hasher, out, out_len);
    memset(&hasher, 0, sizeof(hasher));
    return 0;
#else
    return PRP_CRYPTO_ERR_UNAVAILABLE;
#endif
}

int
prp_crypto_hash_blake3_concat(const uint8_t *first, size_t first_len,
    const uint8_t *second, size_t second_len, uint8_t *out, size_t out_len)
{
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher hasher;
#endif
#ifdef PRP_ENABLE_KERNEL_HASH
    uint8_t digest[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN];
    uint8_t *joined;
    size_t joined_len;
    int rc;
#endif

    if ((first == NULL && first_len != 0u) ||
        (second == NULL && second_len != 0u) || out == NULL ||
        out_len > PRP_CRYPTO_HASH_BLAKE3_OUT_LEN) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    if (out_len == 0u) {
        return PRP_CRYPTO_OK;
    }
#ifdef PRP_ENABLE_KERNEL_HASH
    if (first_len <= SIZE_MAX - second_len) {
        joined_len = first_len + second_len;
        joined = NULL;
        if (joined_len <= PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN) {
            joined = malloc(joined_len != 0u ? joined_len : 1u);
        }
        if (joined != NULL) {
            if (first_len != 0u) {
                memcpy(joined, first, first_len);
            }
            if (second_len != 0u) {
                memcpy(joined + first_len, second, second_len);
            }
            rc = prp_crypto_kernel_blake3_hash(joined, joined_len, digest);
            free(joined);
            if (rc == PRP_CRYPTO_OK) {
                memcpy(out, digest, out_len);
                memset(digest, 0, sizeof(digest));
                return PRP_CRYPTO_OK;
            }
            memset(digest, 0, sizeof(digest));
            if (!kernel_fallback_allowed(rc)) {
                return rc;
            }
        }
#ifdef PRP_REQUIRE_KERNEL_HASH
        else {
            return joined_len > PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN ?
                PRP_CRYPTO_ERR_BAD_ARGS : PRP_CRYPTO_ERR_UNAVAILABLE;
        }
#endif
    }
#ifdef PRP_REQUIRE_KERNEL_HASH
    else {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
#endif
#endif
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher_init(&hasher);
    if (first_len != 0u) {
        blake3_hasher_update(&hasher, first, first_len);
    }
    if (second_len != 0u) {
        blake3_hasher_update(&hasher, second, second_len);
    }
    blake3_hasher_finalize(&hasher, out, out_len);
    memset(&hasher, 0, sizeof(hasher));
    return 0;
#else
    return PRP_CRYPTO_ERR_UNAVAILABLE;
#endif
}

int
prp_crypto_blake3_derive_key(const char *context, const uint8_t *key,
    size_t key_len, const uint8_t *input, size_t input_len, uint8_t *out,
    size_t out_len)
{
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher hasher;
#endif
#ifdef PRP_ENABLE_KERNEL_HASH
    uint8_t digest[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN];
    int rc;
#endif
    if (context == NULL || context[0] == '\0' ||
            (key == NULL && key_len != 0u) ||
            (input == NULL && input_len != 0u) || out == NULL ||
            out_len == 0u) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
#ifdef PRP_ENABLE_KERNEL_HASH
    if (out_len <= sizeof(digest) &&
            input_len <= PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN &&
            key_len <= PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN - input_len) {
        rc = prp_crypto_kernel_blake3_derive_key(context, key, key_len,
            input, input_len, digest);
        if (rc == PRP_CRYPTO_OK) {
            memcpy(out, digest, out_len);
            memset(digest, 0, sizeof(digest));
            return PRP_CRYPTO_OK;
        }
        memset(digest, 0, sizeof(digest));
        if (!kernel_fallback_allowed(rc)) {
            return rc;
        }
    }
#ifdef PRP_REQUIRE_KERNEL_HASH
    else {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
#endif
#endif
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher_init_derive_key(&hasher, context);
    blake3_hasher_update(&hasher, key, key_len);
    blake3_hasher_update(&hasher, input, input_len);
    blake3_hasher_finalize(&hasher, out, out_len);
    memset(&hasher, 0, sizeof(hasher));
    return PRP_CRYPTO_OK;
#else
    return PRP_CRYPTO_ERR_UNAVAILABLE;
#endif
}

int
prp_crypto_hash_blake3_keyed(
    const uint8_t key[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN], const uint8_t *input,
    size_t input_len, uint8_t *out, size_t out_len)
{
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher hasher;
#endif
#ifdef PRP_ENABLE_KERNEL_HASH
    uint8_t digest[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN];
    int rc;
#endif

    if (key == NULL || out == NULL ||
        out_len > PRP_CRYPTO_HASH_BLAKE3_OUT_LEN ||
        (input == NULL && input_len != 0u)) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    if (out_len == 0u) {
        return PRP_CRYPTO_OK;
    }
#ifdef PRP_ENABLE_KERNEL_HASH
    if (input_len <= PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN) {
        rc = prp_crypto_kernel_blake3_keyed_hash(key, input, input_len,
            digest);
        if (rc == PRP_CRYPTO_OK) {
            memcpy(out, digest, out_len);
            memset(digest, 0, sizeof(digest));
            return PRP_CRYPTO_OK;
        }
        memset(digest, 0, sizeof(digest));
        if (!kernel_fallback_allowed(rc)) {
            return rc;
        }
    }
#ifdef PRP_REQUIRE_KERNEL_HASH
    else {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
#endif
#endif
#ifndef PRP_REQUIRE_KERNEL_HASH
    blake3_hasher_init_keyed(&hasher, key);
    if (input_len != 0u) {
        blake3_hasher_update(&hasher, input, input_len);
    }
    blake3_hasher_finalize(&hasher, out, out_len);
    memset(&hasher, 0, sizeof(hasher));
    return 0;
#else
    return PRP_CRYPTO_ERR_UNAVAILABLE;
#endif
}
