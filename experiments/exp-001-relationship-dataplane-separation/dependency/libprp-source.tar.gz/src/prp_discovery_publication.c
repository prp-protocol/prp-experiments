#include "prp_discovery_publication.h"
#include "prp_status.h"

#include <prp/wire_v4_codec.h>

#include <string.h>

static const uint8_t publication_magic[4] = { 'P', 'R', 'P', 'U' };

static int
publication_valid(const prp_discovery_publication_t *publication)
{
    struct prp_wire_v4_identity_suite_desc identity;
    uint16_t previous = 0u;
    size_t i;

    if (publication == NULL || publication->policy_generation == 0u ||
            publication->strong_id == NULL ||
            publication->strong_id_len == 0u ||
            prp_wire_v4_identity_suite_get(publication->identity_suite,
                &identity) != PRP_WIRE_V4_OK ||
            publication->strong_id_len != identity.strong_id_len ||
            publication->session_suite_count >
                PRP_DISCOVERY_PUBLICATION_MAX_SESSION_SUITES ||
            publication->policy_len > PRP_DISCOVERY_PUBLICATION_MAX_POLICY_LEN)
        return 0;
    if (publication->operation == PRP_DISCOVERY_PUBLICATION_OP_WITHDRAW)
        return publication->session_suite_count == 0u &&
            publication->policy_len == 0u;
    if (publication->operation != PRP_DISCOVERY_PUBLICATION_OP_PUBLISH ||
            publication->session_suite_count == 0u ||
            (publication->policy_len != 0u && publication->policy == NULL))
        return 0;
    for (i = 0u; i < publication->session_suite_count; i++) {
        uint16_t suite = publication->session_suites[i];

        if (prp_wire_v4_session_suite_get(suite, NULL) != PRP_WIRE_V4_OK ||
                (i != 0u && suite <= previous))
            return 0;
        previous = suite;
    }
    return 1;
}

int
prp_discovery_publication_encode(
    const prp_discovery_publication_t *publication, uint8_t *out,
    size_t out_len, size_t *written)
{
    size_t total, offset, i;

    if (!publication_valid(publication) || out == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    total = PRP_DISCOVERY_PUBLICATION_HEADER_LEN +
        publication->strong_id_len +
        (size_t)publication->session_suite_count * 2u +
        publication->policy_len;
    if (total > PRP_DISCOVERY_PUBLICATION_MAX_RECORD_LEN)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (out_len < total)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_PUBLICATION_HEADER_LEN);
    memcpy(out, publication_magic, sizeof(publication_magic));
    out[4] = PRP_DISCOVERY_PUBLICATION_VERSION;
    out[5] = publication->operation;
    prp_wire_v4_put_be16(out + 6u, publication->session_suite_count);
    prp_wire_v4_put_be64(out + 8u, publication->policy_generation);
    prp_wire_v4_put_be16(out + 16u, publication->identity_suite);
    prp_wire_v4_put_be16(out + 18u, publication->strong_id_len);
    prp_wire_v4_put_be16(out + 20u, publication->policy_len);
    offset = PRP_DISCOVERY_PUBLICATION_HEADER_LEN;
    memcpy(out + offset, publication->strong_id,
        publication->strong_id_len);
    offset += publication->strong_id_len;
    for (i = 0u; i < publication->session_suite_count; i++) {
        prp_wire_v4_put_be16(out + offset, publication->session_suites[i]);
        offset += 2u;
    }
    if (publication->policy_len != 0u)
        memcpy(out + offset, publication->policy, publication->policy_len);
    *written = total;
    return PRP_OK;
}

int
prp_discovery_publication_decode(const uint8_t *data, size_t data_len,
    prp_discovery_publication_t *publication)
{
    size_t expected, offset, i;

    if (data == NULL || publication == NULL ||
            data_len < PRP_DISCOVERY_PUBLICATION_HEADER_LEN ||
            data_len > PRP_DISCOVERY_PUBLICATION_MAX_RECORD_LEN)
        return PRP_ERR_ARGUMENT;
    if (memcmp(data, publication_magic, sizeof(publication_magic)) != 0)
        return PRP_ERR_MARKER;
    if (data[4] != PRP_DISCOVERY_PUBLICATION_VERSION)
        return PRP_ERR_VERSION;
    if (prp_wire_v4_get_be16(data + 22u) != 0u)
        return PRP_ERR_PROTOCOL;
    memset(publication, 0, sizeof(*publication));
    publication->operation = data[5];
    publication->session_suite_count = prp_wire_v4_get_be16(data + 6u);
    publication->policy_generation = prp_wire_v4_get_be64(data + 8u);
    publication->identity_suite = prp_wire_v4_get_be16(data + 16u);
    publication->strong_id_len = prp_wire_v4_get_be16(data + 18u);
    publication->policy_len = prp_wire_v4_get_be16(data + 20u);
    if (publication->session_suite_count >
            PRP_DISCOVERY_PUBLICATION_MAX_SESSION_SUITES)
        return PRP_ERR_PROTOCOL;
    expected = PRP_DISCOVERY_PUBLICATION_HEADER_LEN +
        publication->strong_id_len +
        (size_t)publication->session_suite_count * 2u +
        publication->policy_len;
    if (expected != data_len)
        return PRP_ERR_PROTOCOL;
    offset = PRP_DISCOVERY_PUBLICATION_HEADER_LEN;
    publication->strong_id = data + offset;
    offset += publication->strong_id_len;
    for (i = 0u; i < publication->session_suite_count; i++) {
        publication->session_suites[i] = prp_wire_v4_get_be16(data + offset);
        offset += 2u;
    }
    publication->policy = publication->policy_len != 0u ? data + offset : NULL;
    return publication_valid(publication) ? PRP_OK : PRP_ERR_PROTOCOL;
}
