#ifndef PRP_CRYPTO_BACKEND_H
#define PRP_CRYPTO_BACKEND_H

#include <stddef.h>
#include <stdint.h>

#define PRP_CRYPTO_OK 0
#define PRP_CRYPTO_ERR_UNAVAILABLE -1
#define PRP_CRYPTO_ERR_UNSUPPORTED -2
#define PRP_CRYPTO_ERR_BAD_ARGS -3
#define PRP_CRYPTO_ERR_CRYPTO -4

#define PRP_CRYPTO_HASH_BLAKE3_OUT_LEN 32u
#define PRP_CRYPTO_HASH_SHA256_OUT_LEN 32u
#define PRP_CRYPTO_HASH_SHA384_OUT_LEN 48u
#define PRP_CRYPTO_KEY_LEN 32u
#define PRP_CRYPTO_CHACHAPOLY_NONCE_LEN 12u
#define PRP_CRYPTO_CHACHAPOLY_TAG_LEN 16u
#define PRP_CRYPTO_AESGCM_NONCE_LEN 12u
#define PRP_CRYPTO_AESGCM_TAG_LEN 16u
#define PRP_CRYPTO_BACKEND_ABI_VERSION 1u

typedef enum prp_crypto_suite {
    PRP_CRYPTO_SUITE_BLAKE3_256 = 1,
    PRP_CRYPTO_SUITE_BLAKE3_KEYED_256 = 2,
    PRP_CRYPTO_SUITE_CHACHA20_POLY1305 = 3,
    PRP_CRYPTO_SUITE_X25519 = 4,
    PRP_CRYPTO_SUITE_RANDOM = 5,
    PRP_CRYPTO_SUITE_AES_256_GCM = 6
} prp_crypto_suite_t;

typedef enum prp_crypto_operation {
    PRP_CRYPTO_OP_HASH = 1,
    PRP_CRYPTO_OP_AEAD_ENCRYPT = 2,
    PRP_CRYPTO_OP_AEAD_DECRYPT = 3,
    PRP_CRYPTO_OP_KEYPAIR = 4,
    PRP_CRYPTO_OP_PUBLIC_FROM_PRIVATE = 5,
    PRP_CRYPTO_OP_DH = 6,
    PRP_CRYPTO_OP_RANDOM = 7
} prp_crypto_operation_t;

#define PRP_CRYPTO_INFO_FLAG_USERLEVEL 0x00000001u
#define PRP_CRYPTO_INFO_FLAG_KERNEL 0x00000002u
#define PRP_CRYPTO_INFO_FLAG_SOFTWARE_FALLBACK 0x00000004u
#define PRP_CRYPTO_INFO_FLAG_RAW_KEYS 0x00000008u
#define PRP_CRYPTO_INFO_FLAG_KEY_SLOTS 0x00000010u
#define PRP_CRYPTO_INFO_FLAG_PORTABLE_ED25519CTX 0x00000020u

typedef struct prp_crypto_backend_info {
    uint32_t abi_version;
    uint32_t flags;
    const char *name;
    uint32_t max_ad_len;
    uint32_t max_input_len;
    uint32_t max_output_len;
    uint32_t key_slot_count;
} prp_crypto_backend_info_t;

/*
 * Versioned component ABI between libprp-crypto and the protocol/application
 * components. It is not an installed application API. Keep its exported
 * symbol set exact and audit it with check-security-boundaries.
 */
#if defined(__GNUC__) || defined(__clang__)
#pragma GCC visibility push(default)
#endif

const char *prp_crypto_backend_name(void);
uint32_t prp_crypto_backend_flags(void);
int prp_crypto_backend_info(prp_crypto_backend_info_t *info);
int prp_crypto_backend_capable(prp_crypto_suite_t suite,
    prp_crypto_operation_t operation);
const char *prp_crypto_error_name(int error_code);

int prp_crypto_hash_blake3(const uint8_t *input, size_t input_len,
    uint8_t *out, size_t out_len);
int prp_crypto_hash_blake3_concat(const uint8_t *first, size_t first_len,
    const uint8_t *second, size_t second_len, uint8_t *out, size_t out_len);
int prp_crypto_hash_sha2_concat(unsigned int bits,
    const uint8_t *first, size_t first_len, const uint8_t *second,
    size_t second_len, uint8_t *out, size_t out_len);
int prp_crypto_blake3_derive_key(const char *context,
    const uint8_t *key, size_t key_len, const uint8_t *input,
    size_t input_len, uint8_t *out, size_t out_len);
int prp_crypto_hash_blake3_keyed(
    const uint8_t key[PRP_CRYPTO_HASH_BLAKE3_OUT_LEN],
    const uint8_t *input, size_t input_len, uint8_t *out, size_t out_len);
int prp_crypto_identity_proof_verify(uint8_t profile,
    const uint8_t *public_key, const uint8_t *signature,
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len);
int prp_crypto_identity_proof_capable(uint8_t profile);
int prp_crypto_random(uint8_t *out, size_t out_len);
void prp_crypto_secure_zero(void *ptr, size_t len);
int prp_crypto_chacha20_poly1305_encrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *plaintext,
    size_t plaintext_len, uint8_t *ciphertext,
    uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN]);
int prp_crypto_chacha20_poly1305_decrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *ciphertext,
    size_t ciphertext_len, const uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN],
    uint8_t *plaintext);
int prp_crypto_aes_256_gcm_encrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *plaintext,
    size_t plaintext_len, uint8_t *ciphertext,
    uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN]);
int prp_crypto_aes_256_gcm_decrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *ciphertext,
    size_t ciphertext_len, const uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN],
    uint8_t *plaintext);
int prp_crypto_x25519_public_from_private(
    const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    uint8_t public_key[PRP_CRYPTO_KEY_LEN]);
int prp_crypto_x25519_keypair(uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t private_key[PRP_CRYPTO_KEY_LEN]);
int prp_crypto_x25519_dh(const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    const uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t out[PRP_CRYPTO_KEY_LEN]);

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC visibility pop
#endif

#endif
