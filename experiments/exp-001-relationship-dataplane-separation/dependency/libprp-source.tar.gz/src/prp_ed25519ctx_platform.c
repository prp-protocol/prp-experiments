#include "prp_ed25519ctx.h"
#include "prp_platform.h"

static void erase_seed(uint8_t *seed, size_t seed_len)
{
    volatile uint8_t *cursor = seed;

    while (seed_len-- != 0U)
        *cursor++ = 0U;
}

prp_status_t prp_ed25519ctx_keypair_generate_with_platform(
    prp_ed25519ctx_keypair_t **keypair, const prp_platform_t *platform)
{
    uint8_t seed[PRP_ED25519CTX_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    result = (prp_status_t)prp_platform_validate(platform,
        PRP_PLATFORM_CAP_RANDOM);
    if (result != PRP_OK)
        return result;
    result = (prp_status_t)platform->random(platform->context, seed,
        sizeof(seed));
    if (result == PRP_OK)
        result = prp_ed25519ctx_keypair_from_seed(keypair, seed);
    else if ((int)result > 0)
        result = PRP_ERR_STATE;
    erase_seed(seed, sizeof(seed));
    return result;
}
