#include "prp_identity_hybrid.h"

#include "prp_ed25519_blake3.h"
#include "prp_platform.h"
#include "prp_pq.h"

struct prp_identity_hybrid_keypair_s {
    prp_ed25519_blake3_keypair_t *ed25519;
    prp_mldsa87_keypair_t *mldsa87;
};

static void erase_bytes(uint8_t *bytes, size_t length)
{
    volatile uint8_t *cursor = bytes;
    while (length-- != 0U)
        *cursor++ = 0U;
}

static prp_status_t random_bytes(const prp_platform_t *platform,
    uint8_t *output, size_t length)
{
    int result = prp_platform_validate(platform, PRP_PLATFORM_CAP_RANDOM);
    if (result != PRP_OK)
        return (prp_status_t)result;
    result = platform->random(platform->context, output, length);
    return result > 0 ? PRP_ERR_STATE : (prp_status_t)result;
}

prp_status_t prp_identity_hybrid_keypair_generate_with_platform(
    prp_identity_hybrid_keypair_t **keypair, const prp_platform_t *platform)
{
    uint8_t seed[PRP_IDENTITY_HYBRID_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    result = random_bytes(platform, seed, sizeof(seed));
    if (result == PRP_OK)
        result = prp_identity_hybrid_keypair_from_seed(keypair, seed);
    erase_bytes(seed, sizeof(seed));
    return result;
}

prp_status_t prp_identity_hybrid_sign_with_platform(
    const prp_identity_hybrid_keypair_t *keypair, const uint8_t *hs2_prefix,
    size_t hs2_prefix_len, const prp_platform_t *platform,
    uint8_t *signature, size_t signature_size, size_t *written)
{
    uint8_t random[PRP_MLDSA87_SIGN_RANDOM_LEN];
    size_t component;
    prp_status_t result;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || hs2_prefix == NULL || hs2_prefix_len == 0U ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_IDENTITY_HYBRID_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = random_bytes(platform, random, sizeof(random));
    if (result == PRP_OK)
        result = prp_ed25519_blake3_sign(keypair->ed25519, hs2_prefix,
            hs2_prefix_len, signature, signature_size, &component);
    if (result == PRP_OK && prp_mldsa87_sign_derand(keypair->mldsa87,
            hs2_prefix, hs2_prefix_len, random, signature + component,
            signature_size - component, &component) != 0)
        result = PRP_ERR_CRYPTO;
    erase_bytes(random, sizeof(random));
    if (result != PRP_OK) {
        erase_bytes(signature, PRP_IDENTITY_HYBRID_SIGNATURE_LEN);
        return result;
    }
    *written = PRP_IDENTITY_HYBRID_SIGNATURE_LEN;
    return PRP_OK;
}
