#include "prp_pq_internal.h"

#include <mldsa_native.h>
#include <prp/wire_v4_crypto.h>
#include <string.h>

static const uint8_t mldsa65_hs2_prefix[] =
    "\x00\x0d" PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;

int prp_mldsa65_verify_canonical(const uint8_t *public_key,
    const uint8_t *signature, const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len)
{
    if (public_key == NULL || signature == NULL || message == NULL ||
        context == NULL ||
        context_len != PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN ||
        memcmp(context, PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT,
            context_len) != 0)
        return -1;
    return prp_thirdparty_mldsa65_verify_internal(signature, message,
        message_len, mldsa65_hs2_prefix, sizeof(mldsa65_hs2_prefix) - 1U,
        public_key, 0) == 0 ? 0 : -1;
}
