#include "prp_app_v1_transport.h"
#include "prp_crypto_backend.h"
#include <string.h>
void prp_app_transport_invalidate(struct prp_app_transport *t)
{ if(t) prp_crypto_secure_zero(t,sizeof *t); }
int prp_app_transport_init(struct prp_app_transport *t,unsigned role,
    const uint8_t *m1,size_t n1,const uint8_t *m2,size_t n2,
    const uint8_t i2r[32],const uint8_t r2i[32])
{
    struct prp_wire_v4_hs2_view a,b;
    uint8_t binding[48],pre[5400],c[32]; size_t bn=0,k=0;
    struct prp_wire_v4_session_crypto_desc suite;
    if(!t) return -1;
    prp_app_transport_invalidate(t);
    if((role!=1 && role!=2) || !i2r || !r2i ||
       prp_wire_v4_hs2_extract(m1,n1,&a) || prp_wire_v4_hs2_extract(m2,n2,&b) ||
       a.kind!=1 || b.kind!=2 || a.session_suite_id!=b.session_suite_id ||
       !b.session_generation || a.nonce_len!=b.nonce_len ||
       memcmp(a.nonce,b.nonce,a.nonce_len) ||
       prp_wire_v4_session_crypto_get(a.session_suite_id,&suite) ||
       (suite.aead!=PRP_WIRE_V4_AEAD_CHACHA20_POLY1305 && suite.aead!=PRP_WIRE_V4_AEAD_AES_256_GCM) ||
       prp_wire_v4_hs2_identity_verify(m1,n1) || prp_wire_v4_hs2_identity_verify(m2,n2) ||
       prp_wire_v4_m1_binding(m1,n1,binding,sizeof binding,&bn) ||
       b.m1_binding_len!=bn || memcmp(b.m1_binding,binding,bn) ||
       prp_wire_v4_transcript_hash(m1,n1,m2,n2,t->transcript,sizeof t->transcript,&t->transcript_len)) goto bad;
    if(18+t->transcript_len+a.public_key_len+b.public_key_len>sizeof pre) goto bad;
    pre[k++]=4; pre[k++]=3;
    prp_wire_v4_put_be16(pre+k,a.session_suite_id); k+=2;
    prp_wire_v4_put_be32(pre+k,b.session_generation); k+=4;
    prp_wire_v4_put_be16(pre+k,(uint16_t)t->transcript_len); k+=2;
    memcpy(pre+k,t->transcript,t->transcript_len); k+=t->transcript_len;
    prp_wire_v4_put_be16(pre+k,a.identity_suite_id); k+=2;
    prp_wire_v4_put_be16(pre+k,a.public_key_len); k+=2;
    memcpy(pre+k,a.public_key,a.public_key_len); k+=a.public_key_len;
    prp_wire_v4_put_be16(pre+k,b.identity_suite_id); k+=2;
    prp_wire_v4_put_be16(pre+k,b.public_key_len); k+=2;
    memcpy(pre+k,b.public_key,b.public_key_len); k+=b.public_key_len;
    if(prp_app_v1_context_hash(pre,k,c)) goto bad;
    prp_app_state_init(&t->state,c,role); t->suite=a.session_suite_id;
    t->generation=b.session_generation; t->replay.generation=b.session_generation;
    t->sequence=1; /* AOP unit sequence zero is reserved; item sequence stays zero. */
    memcpy(t->tx,role==1?i2r:r2i,32); memcpy(t->rx,role==1?r2i:i2r,32);
    return 0;
bad:
    prp_app_transport_invalidate(t); return -1;
}
int prp_app_transport_seal(struct prp_app_transport *t,const uint8_t *body,size_t n,
    uint8_t *out,size_t cap,size_t *written)
{
    uint8_t item[139]={0}; prp_app_v1_message m; uint64_t seq;
    if(!t || !t->state.live || prp_app_v1_decode(body,n,&m) ||
       memcmp(m.context,t->state.context,32) || t->sequence==UINT64_MAX) return -1;
    if(((m.kind==7 || m.kind==9) && m.opener!=t->state.role) ||
       ((m.kind==8 || m.kind==10) && m.opener==t->state.role)) return -1;
    prp_wire_v4_put_be16(item+12,(uint16_t)n); memcpy(item+14,body,n);
    /* Consume sequence even if seal/output fails: never retry the nonce. */
    seq=t->sequence++;
    return prp_wire_v4_aop_seal(3,t->suite,t->generation,seq,t->tx,t->transcript,
        t->transcript_len,item,n+14,out,cap,written);
}
int prp_app_transport_receive(struct prp_app_transport *t,const uint8_t *wire,size_t n,
    uint64_t now,uint8_t reply[113],size_t *rn)
{
    uint8_t item[139]; size_t len=0; unsigned i; int result;
    if(!t || prp_app_state_tick(&t->state,now)) return -1;
    result=prp_wire_v4_aop_open(3,t->suite,t->rx,t->transcript,t->transcript_len,
        &t->replay,wire,n,item,sizeof item,&len);
    if(result || len<14 || len!=14u+prp_wire_v4_get_be16(item+12)) return -1;
    for(i=0;i<12;i++) if(item[i]) return -1;
    result=prp_app_state_receive(&t->state,item+14,len-14,3u-t->state.role,now,reply,rn);
    prp_crypto_secure_zero(item,sizeof item);
    if(!t->state.live) prp_app_transport_invalidate(t);
    return result;
}
