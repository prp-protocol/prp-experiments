#define _POSIX_C_SOURCE 200809L

#include "prp_crypto_backend.h"
#include "prp_crypto_backend_kernel.h"

#include <errno.h>
#include <string.h>

#include <linux/prp_netlink.h>
#include <netlink/attr.h>
#include <netlink/genl/ctrl.h>
#include <netlink/genl/genl.h>
#include <netlink/msg.h>
#include <netlink/netlink.h>

typedef struct prp_kernel_result {
    uint8_t operation;
    uint8_t output[PRP_CRYPTO_BACKEND_BLAKE3_OUTPUT_LEN];
    int found;
    int have_output;
    int done;
    int error;
} prp_kernel_result_t;

static int
map_error(int error)
{
    if (error == 0) {
        return PRP_CRYPTO_OK;
    }
    switch (-error) {
    case EINVAL:
    case EMSGSIZE:
        return PRP_CRYPTO_ERR_BAD_ARGS;
    case EPROTONOSUPPORT:
    case EOPNOTSUPP:
        return PRP_CRYPTO_ERR_UNSUPPORTED;
    case ENOENT:
    case ENODEV:
    case ENOMEM:
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    default:
        return PRP_CRYPTO_ERR_CRYPTO;
    }
}

static int
error_callback(struct sockaddr_nl *address, struct nlmsgerr *error, void *arg)
{
    prp_kernel_result_t *result = arg;

    (void) address;
    result->error = error != NULL ? error->error : -EIO;
    result->done = 1;
    return NL_STOP;
}

static int
finish_callback(struct nl_msg *message, void *arg)
{
    prp_kernel_result_t *result = arg;

    (void) message;
    result->done = 1;
    return NL_STOP;
}

static int
capability_callback(struct nl_msg *message, void *arg)
{
    prp_kernel_result_t *result = arg;
    struct nlattr *attrs[PRP_ATTR_MAX + 1] = { 0 };
    struct genlmsghdr *header = nlmsg_data(nlmsg_hdr(message));

    if (nla_parse(attrs, PRP_ATTR_MAX, genlmsg_attrdata(header, 0),
            genlmsg_attrlen(header, 0), NULL) < 0) {
        result->error = -EPROTO;
        result->done = 1;
        return NL_STOP;
    }
    if (attrs[PRP_ATTR_FLAGS] != NULL &&
        attrs[PRP_ATTR_CRYPTO_BACKEND_OPERATION] == NULL) {
        result->done = 1;
        return NL_STOP;
    }
    if (attrs[PRP_ATTR_CRYPTO_BACKEND_ABI_VERSION] != NULL &&
        attrs[PRP_ATTR_CRYPTO_BACKEND_NAME] != NULL &&
        attrs[PRP_ATTR_CRYPTO_KDF] != NULL &&
        attrs[PRP_ATTR_CRYPTO_BACKEND_OPERATION] != NULL &&
        attrs[PRP_ATTR_FLAGS] != NULL &&
        attrs[PRP_ATTR_CRYPTO_BACKEND_MAX_INPUT_LEN] != NULL &&
        attrs[PRP_ATTR_CRYPTO_BACKEND_MAX_OUTPUT_LEN] != NULL &&
        nla_get_u32(attrs[PRP_ATTR_CRYPTO_BACKEND_ABI_VERSION]) ==
            PRP_CRYPTO_BACKEND_ABI_VERSION &&
        strcmp(nla_get_string(attrs[PRP_ATTR_CRYPTO_BACKEND_NAME]),
            PRP_CRYPTO_BACKEND_KERNEL_NAME) == 0 &&
        nla_get_u8(attrs[PRP_ATTR_CRYPTO_KDF]) ==
            PRP_CRYPTO_BACKEND_PROFILE_BLAKE3 &&
        nla_get_u8(attrs[PRP_ATTR_CRYPTO_BACKEND_OPERATION]) ==
            result->operation &&
        (nla_get_u32(attrs[PRP_ATTR_FLAGS]) &
            PRP_CRYPTO_BACKEND_FLAG_KERNEL) != 0u &&
        (result->operation != PRP_CRYPTO_BACKEND_OP_KEYED_HASH ||
            (nla_get_u32(attrs[PRP_ATTR_FLAGS]) &
                PRP_CRYPTO_BACKEND_FLAG_RAW_KEYS) != 0u) &&
        nla_get_u32(attrs[PRP_ATTR_CRYPTO_BACKEND_MAX_INPUT_LEN]) >=
            PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN &&
        nla_get_u32(attrs[PRP_ATTR_CRYPTO_BACKEND_MAX_OUTPUT_LEN]) ==
            PRP_CRYPTO_BACKEND_BLAKE3_OUTPUT_LEN) {
        result->found = 1;
    }
    return NL_OK;
}

static int
output_callback(struct nl_msg *message, void *arg)
{
    prp_kernel_result_t *result = arg;
    struct nlattr *attrs[PRP_ATTR_MAX + 1] = { 0 };
    struct genlmsghdr *header = nlmsg_data(nlmsg_hdr(message));

    if (nla_parse(attrs, PRP_ATTR_MAX, genlmsg_attrdata(header, 0),
            genlmsg_attrlen(header, 0), NULL) < 0 ||
        attrs[PRP_ATTR_CRYPTO_BACKEND_ABI_VERSION] == NULL ||
        attrs[PRP_ATTR_CRYPTO_BACKEND_NAME] == NULL ||
        attrs[PRP_ATTR_CRYPTO_KDF] == NULL ||
        attrs[PRP_ATTR_CRYPTO_BACKEND_OPERATION] == NULL ||
        attrs[PRP_ATTR_CRYPTO_BACKEND_OUTPUT] == NULL ||
        nla_get_u32(attrs[PRP_ATTR_CRYPTO_BACKEND_ABI_VERSION]) !=
            PRP_CRYPTO_BACKEND_ABI_VERSION ||
        strcmp(nla_get_string(attrs[PRP_ATTR_CRYPTO_BACKEND_NAME]),
            PRP_CRYPTO_BACKEND_KERNEL_NAME) != 0 ||
        nla_get_u8(attrs[PRP_ATTR_CRYPTO_KDF]) !=
            PRP_CRYPTO_BACKEND_PROFILE_BLAKE3 ||
        nla_get_u8(attrs[PRP_ATTR_CRYPTO_BACKEND_OPERATION]) !=
            result->operation ||
        nla_len(attrs[PRP_ATTR_CRYPTO_BACKEND_OUTPUT]) !=
            PRP_CRYPTO_BACKEND_BLAKE3_OUTPUT_LEN) {
        result->error = -EPROTO;
    } else {
        memcpy(result->output,
            nla_data(attrs[PRP_ATTR_CRYPTO_BACKEND_OUTPUT]),
            sizeof(result->output));
        result->have_output = 1;
    }
    result->done = 1;
    return NL_STOP;
}

static int
send_and_receive(struct nl_sock *socket, struct nl_msg *message,
    nl_recvmsg_msg_cb_t valid, prp_kernel_result_t *result)
{
    struct nl_cb *callbacks;
    int rc;

    callbacks = nl_cb_alloc(NL_CB_DEFAULT);
    if (callbacks == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    nl_cb_err(callbacks, NL_CB_CUSTOM, error_callback, result);
    nl_cb_set(callbacks, NL_CB_VALID, NL_CB_CUSTOM, valid, result);
    nl_cb_set(callbacks, NL_CB_FINISH, NL_CB_CUSTOM, finish_callback, result);
    rc = nl_send_auto(socket, message);
    while (rc >= 0 && !result->done) {
        rc = nl_recvmsgs(socket, callbacks);
    }
    nl_cb_put(callbacks);
    if (result->error != 0) {
        return map_error(result->error);
    }
    return rc < 0 ? PRP_CRYPTO_ERR_CRYPTO : PRP_CRYPTO_OK;
}

static int
check_capability(struct nl_sock *socket, int family, uint8_t operation)
{
    prp_kernel_result_t result;
    struct nl_msg *message;
    int rc;

    memset(&result, 0, sizeof(result));
    result.operation = operation;
    message = nlmsg_alloc();
    if (message == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    if (genlmsg_put(message, NL_AUTO_PORT, NL_AUTO_SEQ, family, 0,
            NLM_F_REQUEST | NLM_F_ACK, PRP_CMD_CRYPTO_BACKEND_CAP_LIST,
            PRP_GENL_VERSION) == NULL) {
        nlmsg_free(message);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    rc = send_and_receive(socket, message, capability_callback, &result);
    nlmsg_free(message);
    if (rc != PRP_CRYPTO_OK) {
        return rc;
    }
    return result.found ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_UNSUPPORTED;
}

int
prp_crypto_kernel_blake3_exec(uint8_t operation, const uint8_t *key,
    size_t key_len, const uint8_t *input, size_t input_len,
    const uint8_t *context, size_t context_len, uint8_t output[32])
{
    prp_kernel_result_t result;
    struct nl_sock *socket;
    struct nl_msg *message;
    int family;
    int rc;

    if (output == NULL || (input == NULL && input_len != 0u) ||
        input_len > PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN ||
        (key == NULL && key_len != 0u) ||
        key_len > PRP_CRYPTO_BACKEND_EXEC_MAX_INPUT_LEN - input_len ||
        (operation == PRP_CRYPTO_BACKEND_OP_HASH && key_len != 0u) ||
        (operation == PRP_CRYPTO_BACKEND_OP_KEYED_HASH &&
            (key == NULL ||
             key_len != PRP_CRYPTO_BACKEND_BLAKE3_KEY_LEN)) ||
        (operation == PRP_CRYPTO_BACKEND_OP_KDF &&
            (context == NULL || context_len == 0u ||
                context_len > PRP_CRYPTO_BACKEND_EXEC_MAX_CONTEXT_LEN)) ||
        (operation != PRP_CRYPTO_BACKEND_OP_KDF && context_len != 0u) ||
        (operation != PRP_CRYPTO_BACKEND_OP_HASH &&
            operation != PRP_CRYPTO_BACKEND_OP_KEYED_HASH &&
            operation != PRP_CRYPTO_BACKEND_OP_KDF)) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    socket = nl_socket_alloc();
    if (socket == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    if (genl_connect(socket) != 0) {
        nl_socket_free(socket);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    family = genl_ctrl_resolve(socket, PRP_GENL_FAMILY_NAME);
    if (family < 0) {
        nl_socket_free(socket);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    rc = check_capability(socket, family, operation);
    if (rc != PRP_CRYPTO_OK) {
        nl_socket_free(socket);
        return rc;
    }
    memset(&result, 0, sizeof(result));
    result.operation = operation;
    message = nlmsg_alloc();
    if (message == NULL) {
        nl_socket_free(socket);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    if (genlmsg_put(message, NL_AUTO_PORT, NL_AUTO_SEQ, family, 0,
            NLM_F_REQUEST, PRP_CMD_CRYPTO_BACKEND_EXEC,
            PRP_GENL_VERSION) == NULL ||
        nla_put_u32(message, PRP_ATTR_CRYPTO_BACKEND_ABI_VERSION,
            PRP_CRYPTO_BACKEND_ABI_VERSION) != 0 ||
        nla_put_string(message, PRP_ATTR_CRYPTO_BACKEND_NAME,
            PRP_CRYPTO_BACKEND_KERNEL_NAME) != 0 ||
        nla_put_u8(message, PRP_ATTR_CRYPTO_KDF,
            PRP_CRYPTO_BACKEND_PROFILE_BLAKE3) != 0 ||
        nla_put_u8(message, PRP_ATTR_CRYPTO_BACKEND_OPERATION,
            operation) != 0 ||
        nla_put(message, PRP_ATTR_CRYPTO_BACKEND_INPUT, input_len,
            input) != 0 ||
        (context_len != 0u &&
            nla_put(message, PRP_ATTR_CRYPTO_BACKEND_CONTEXT, context_len,
                context) != 0) ||
        (key_len != 0u &&
            nla_put(message, PRP_ATTR_CRYPTO_BACKEND_RAW_KEY, key_len,
                key) != 0)) {
        nlmsg_free(message);
        nl_socket_free(socket);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    rc = send_and_receive(socket, message, output_callback, &result);
    nlmsg_free(message);
    nl_socket_free(socket);
    if (rc != PRP_CRYPTO_OK) {
        return rc;
    }
    if (!result.have_output) {
        return PRP_CRYPTO_ERR_CRYPTO;
    }
    memcpy(output, result.output, sizeof(result.output));
    return PRP_CRYPTO_OK;
}

int
prp_crypto_kernel_blake3_hash(const uint8_t *input, size_t input_len,
    uint8_t output[32])
{
    return prp_crypto_kernel_blake3_exec(PRP_CRYPTO_BACKEND_OP_HASH, NULL,
        0u, input, input_len, NULL, 0u, output);
}

int
prp_crypto_kernel_blake3_keyed_hash(const uint8_t key[32],
    const uint8_t *input, size_t input_len, uint8_t output[32])
{
    return prp_crypto_kernel_blake3_exec(
        PRP_CRYPTO_BACKEND_OP_KEYED_HASH, key,
        PRP_CRYPTO_BACKEND_BLAKE3_KEY_LEN, input, input_len, NULL, 0u,
        output);
}

int
prp_crypto_kernel_blake3_derive_key(const char *context,
    const uint8_t *key, size_t key_len, const uint8_t *input,
    size_t input_len, uint8_t output[32])
{
    size_t context_len;

    if (context == NULL) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    context_len = strlen(context);
    return prp_crypto_kernel_blake3_exec(PRP_CRYPTO_BACKEND_OP_KDF, key,
        key_len, input, input_len, (const uint8_t *)context, context_len,
        output);
}
