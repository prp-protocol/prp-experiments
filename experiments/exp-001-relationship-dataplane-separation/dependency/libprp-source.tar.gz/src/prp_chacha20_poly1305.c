#include "prp_chacha20_poly1305.h"

#include "prp_crypto_backend.h"
#include "prp_memory.h"

#include <limits.h>

static prp_status_t status_from_backend(int result)
{
    if (result == PRP_CRYPTO_OK)
        return PRP_OK;
    if (result == PRP_CRYPTO_ERR_UNAVAILABLE ||
            result == PRP_CRYPTO_ERR_UNSUPPORTED)
        return PRP_ERR_UNAVAILABLE;
    return PRP_ERR_CRYPTO;
}

prp_status_t prp_chacha20_poly1305_seal(
    const uint8_t key[PRP_CHACHA20_POLY1305_KEY_LEN],
    const uint8_t nonce[PRP_CHACHA20_POLY1305_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *ciphertext, size_t ciphertext_size,
    uint8_t tag[PRP_CHACHA20_POLY1305_TAG_LEN], size_t *written)
{
    prp_status_t status;

    if (written != NULL)
        *written = 0U;
    if (key == NULL || nonce == NULL || ciphertext == NULL || tag == NULL ||
            written == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (plaintext == NULL && plaintext_len != 0U))
        return PRP_ERR_ARGUMENT;
    if (associated_data_len > (size_t)INT_MAX ||
            plaintext_len > (size_t)INT_MAX)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (ciphertext_size < plaintext_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    status = status_from_backend(prp_crypto_chacha20_poly1305_encrypt(key,
        nonce, associated_data, associated_data_len, plaintext, plaintext_len,
        ciphertext, tag));
    if (status != PRP_OK) {
        prp_secure_zero(ciphertext, plaintext_len);
        prp_secure_zero(tag, PRP_CHACHA20_POLY1305_TAG_LEN);
        return status;
    }
    *written = plaintext_len;
    return PRP_OK;
}

prp_status_t prp_chacha20_poly1305_open(
    const uint8_t key[PRP_CHACHA20_POLY1305_KEY_LEN],
    const uint8_t nonce[PRP_CHACHA20_POLY1305_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t tag[PRP_CHACHA20_POLY1305_TAG_LEN],
    uint8_t *plaintext, size_t plaintext_size, size_t *written)
{
    prp_status_t status;

    if (written != NULL)
        *written = 0U;
    if (key == NULL || nonce == NULL || tag == NULL || plaintext == NULL ||
            written == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (ciphertext == NULL && ciphertext_len != 0U))
        return PRP_ERR_ARGUMENT;
    if (associated_data_len > (size_t)INT_MAX ||
            ciphertext_len > (size_t)INT_MAX)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (plaintext_size < ciphertext_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    status = status_from_backend(prp_crypto_chacha20_poly1305_decrypt(key,
        nonce, associated_data, associated_data_len, ciphertext,
        ciphertext_len, tag, plaintext));
    if (status != PRP_OK) {
        prp_secure_zero(plaintext, ciphertext_len);
        return status;
    }
    *written = ciphertext_len;
    return PRP_OK;
}
