#include "prp_ed25519ctx_internal.h"

#include "prp_crypto_backend.h"

#include <monocypher-ed25519.h>
#include <monocypher.h>

#include <stdlib.h>
#include <string.h>

struct prp_ed25519ctx_keypair_s {
    uint8_t public_key[PRP_ED25519CTX_PUBLIC_KEY_LEN];
    uint8_t private_key[PRP_ED25519CTX_PRIVATE_KEY_LEN];
};

static const uint8_t dom2[] = "SigEd25519 no Ed25519 collisions";
static const uint8_t hs2_context[] = "PRP-HS2-v4";

static void hash_dom2_begin(crypto_sha512_ctx *ctx, const uint8_t *context,
    size_t context_len)
{
    uint8_t flags[2] = { 0U, (uint8_t)context_len };

    crypto_sha512_init(ctx);
    crypto_sha512_update(ctx, dom2, sizeof(dom2) - 1U);
    crypto_sha512_update(ctx, flags, sizeof(flags));
    if (context_len != 0U)
        crypto_sha512_update(ctx, context, context_len);
}

static void hash_reduce_final(crypto_sha512_ctx *ctx, uint8_t scalar[32])
{
    uint8_t hash[64];

    crypto_sha512_final(ctx, hash);
    crypto_eddsa_reduce(scalar, hash);
    prp_crypto_secure_zero(hash, sizeof(hash));
    prp_crypto_secure_zero(ctx, sizeof(*ctx));
}

int prp_ed25519ctx_sign_context(const uint8_t private_key[64],
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len, uint8_t signature[64])
{
    crypto_sha512_ctx hash_context;
    uint8_t expanded[64];
    uint8_t nonce[32];
    uint8_t challenge[32];
    uint8_t commitment[32];

    if (private_key == NULL || signature == NULL ||
            (message == NULL && message_len != 0U) ||
            (context == NULL && context_len != 0U) || context_len > 255U)
        return PRP_CRYPTO_ERR_BAD_ARGS;

    crypto_sha512(expanded, private_key, 32U);
    crypto_eddsa_trim_scalar(expanded, expanded);

    hash_dom2_begin(&hash_context, context, context_len);
    crypto_sha512_update(&hash_context, expanded + 32U, 32U);
    if (message_len != 0U)
        crypto_sha512_update(&hash_context, message, message_len);
    hash_reduce_final(&hash_context, nonce);
    crypto_eddsa_scalarbase(commitment, nonce);

    hash_dom2_begin(&hash_context, context, context_len);
    crypto_sha512_update(&hash_context, commitment, sizeof(commitment));
    crypto_sha512_update(&hash_context, private_key + 32U, 32U);
    if (message_len != 0U)
        crypto_sha512_update(&hash_context, message, message_len);
    hash_reduce_final(&hash_context, challenge);

    memcpy(signature, commitment, sizeof(commitment));
    crypto_eddsa_mul_add(signature + 32U, challenge, expanded, nonce);
    prp_crypto_secure_zero(expanded, sizeof(expanded));
    prp_crypto_secure_zero(nonce, sizeof(nonce));
    prp_crypto_secure_zero(challenge, sizeof(challenge));
    prp_crypto_secure_zero(commitment, sizeof(commitment));
    return PRP_CRYPTO_OK;
}

static int canonical_point_encoding(const uint8_t point[32])
{
    static const uint8_t field_prime[32] = {
        0xed, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
        0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x7f,
    };
    int index;

    for (index = 31; index >= 0; index--) {
        uint8_t value = point[index];

        if (index == 31)
            value &= 0x7fU;
        if (value < field_prime[index])
            return 1;
        if (value > field_prime[index])
            return 0;
    }
    return 0;
}

static int low_order_point(const uint8_t point[32])
{
    uint8_t identity_signature[64] = { 0 };
    uint8_t scalar_one[32] = { 0 };

    /* Monocypher checks [8](R + hA - sB) = 0.  With R = identity,
     * h = 1, and s = 0, success means exactly [8]point = 0. */
    identity_signature[0] = 1U;
    scalar_one[0] = 1U;
    return crypto_eddsa_check_equation(identity_signature, point,
        scalar_one) == 0;
}

int prp_ed25519ctx_verify_context(const uint8_t public_key[32],
    const uint8_t signature[64], const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len)
{
    crypto_sha512_ctx hash_context;
    uint8_t hash[64];
    int valid;

    if (public_key == NULL || signature == NULL ||
            (message == NULL && message_len != 0U) ||
            (context == NULL && context_len != 0U) || context_len > 255U)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    if (!canonical_point_encoding(public_key) ||
            !canonical_point_encoding(signature) ||
            low_order_point(public_key) || low_order_point(signature))
        return PRP_CRYPTO_ERR_CRYPTO;

    hash_dom2_begin(&hash_context, context, context_len);
    crypto_sha512_update(&hash_context, signature, 32U);
    crypto_sha512_update(&hash_context, public_key, 32U);
    if (message_len != 0U)
        crypto_sha512_update(&hash_context, message, message_len);
    crypto_sha512_final(&hash_context, hash);
    crypto_eddsa_reduce(hash, hash);
    valid = crypto_eddsa_check_equation(signature, public_key, hash) == 0;
    prp_crypto_secure_zero(hash, sizeof(hash));
    prp_crypto_secure_zero(&hash_context, sizeof(hash_context));
    return valid ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

static prp_status_t keypair_create(prp_ed25519ctx_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519CTX_SEED_LEN])
{
    prp_ed25519ctx_keypair_t *created;
    uint8_t mutable_seed[PRP_ED25519CTX_SEED_LEN];

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (seed == NULL)
        return PRP_ERR_ARGUMENT;
    created = calloc(1U, sizeof(*created));
    if (created == NULL)
        return PRP_ERR_NO_MEMORY;
    memcpy(mutable_seed, seed, sizeof(mutable_seed));
    crypto_ed25519_key_pair(created->private_key, created->public_key,
        mutable_seed);
    prp_crypto_secure_zero(mutable_seed, sizeof(mutable_seed));
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_ed25519ctx_keypair_from_seed(
    prp_ed25519ctx_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519CTX_SEED_LEN])
{
    return keypair_create(keypair, seed);
}

prp_status_t prp_ed25519ctx_keypair_derand(
    prp_ed25519ctx_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519CTX_SEED_LEN])
{
    return prp_ed25519ctx_keypair_from_seed(keypair, seed);
}

prp_status_t prp_ed25519ctx_keypair_generate(
    prp_ed25519ctx_keypair_t **keypair)
{
    uint8_t seed[PRP_ED25519CTX_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    result = keypair_create(keypair, seed);
    prp_crypto_secure_zero(seed, sizeof(seed));
    return result;
}

prp_status_t prp_ed25519ctx_keypair_import(
    prp_ed25519ctx_keypair_t **keypair,
    const uint8_t *private_key, size_t private_key_len)
{
    prp_ed25519ctx_keypair_t *created = NULL;
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (private_key == NULL ||
            private_key_len != PRP_ED25519CTX_PRIVATE_KEY_LEN)
        return PRP_ERR_ARGUMENT;
    result = keypair_create(&created, private_key);
    if (result != PRP_OK)
        return result;
    if (crypto_verify32(created->public_key, private_key + 32U) != 0) {
        prp_ed25519ctx_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_ed25519ctx_public_key_export(
    const prp_ed25519ctx_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_ED25519CTX_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(public_key, keypair->public_key, PRP_ED25519CTX_PUBLIC_KEY_LEN);
    *written = PRP_ED25519CTX_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_ed25519ctx_private_key_export(
    const prp_ed25519ctx_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || private_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (private_key_size < PRP_ED25519CTX_PRIVATE_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(private_key, keypair->private_key, PRP_ED25519CTX_PRIVATE_KEY_LEN);
    *written = PRP_ED25519CTX_PRIVATE_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_ed25519ctx_sign(
    const prp_ed25519ctx_keypair_t *keypair,
    const uint8_t *message, size_t message_len, uint8_t *signature,
    size_t signature_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || (message == NULL && message_len != 0U) ||
            signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_ED25519CTX_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_ed25519ctx_sign_context(keypair->private_key, message, message_len,
            hs2_context, sizeof(hs2_context) - 1U, signature) !=
            PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(signature, PRP_ED25519CTX_SIGNATURE_LEN);
        return PRP_ERR_CRYPTO;
    }
    *written = PRP_ED25519CTX_SIGNATURE_LEN;
    return PRP_OK;
}

prp_status_t prp_ed25519ctx_verify(
    const uint8_t public_key[PRP_ED25519CTX_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519CTX_SIGNATURE_LEN],
    const uint8_t *message, size_t message_len)
{
    int result = prp_ed25519ctx_verify_context(public_key, signature,
        message, message_len, hs2_context, sizeof(hs2_context) - 1U);

    if (result == PRP_CRYPTO_OK)
        return PRP_OK;
    return result == PRP_CRYPTO_ERR_BAD_ARGS ? PRP_ERR_ARGUMENT :
        PRP_ERR_CRYPTO;
}

void prp_ed25519ctx_keypair_destroy(prp_ed25519ctx_keypair_t *keypair)
{
    if (keypair != NULL) {
        prp_crypto_secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}
