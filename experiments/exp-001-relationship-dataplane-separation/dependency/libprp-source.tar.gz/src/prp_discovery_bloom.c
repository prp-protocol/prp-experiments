#include "prp_discovery_bloom.h"

#include <prp/wire_v4_codec.h>
#include <stdlib.h>
#include <string.h>

static const uint8_t bloom_domain[] = "PRP-DISCOVERY-BLOOM-v1";
static const uint8_t bloom_v4_domain[] =
    "PRP-DISCOVERY-SHARDED-BLOOM-INDEX-v4";
static const uint8_t bloom_v4_shard_domain[] =
    "PRP-DISCOVERY-SHARDED-BLOOM-SHARD-v4";
static const uint8_t bloom_v4_empty_domain[] =
    "PRP-DISCOVERY-SHARDED-BLOOM-EMPTY-v4";
static const uint8_t bloom_v4_node_domain[] =
    "PRP-DISCOVERY-SHARDED-BLOOM-NODE-v4";
static const uint8_t discovery_proof_context[] = "PRP-DISCOVERY-v1";
static const uint8_t bloom_v4_record_magic[] = "PRB4";
static const uint8_t bloom_microshard_request_magic[] = "PRMQ";
static const uint8_t bloom_microshard_response_magic[] = "PRMS";
static const uint8_t bloom_remote_view_magic[] = "PRVM";

static uint16_t
read_u16(const uint8_t *p)
{
    return (uint16_t) (((uint16_t) p[0] << 8) | p[1]);
}

static uint32_t
read_u32(const uint8_t *p)
{
    return ((uint32_t) p[0] << 24) | ((uint32_t) p[1] << 16) |
        ((uint32_t) p[2] << 8) | p[3];
}

static uint64_t
read_u64(const uint8_t *p)
{
    return ((uint64_t) read_u32(p) << 32) | read_u32(p + 4);
}

static void
write_u16(uint8_t *p, uint16_t v)
{
    p[0] = (uint8_t) (v >> 8);
    p[1] = (uint8_t) v;
}

static void
write_u32(uint8_t *p, uint32_t v)
{
    p[0] = (uint8_t) (v >> 24);
    p[1] = (uint8_t) (v >> 16);
    p[2] = (uint8_t) (v >> 8);
    p[3] = (uint8_t) v;
}

static void
write_u64(uint8_t *p, uint64_t v)
{
    write_u32(p, (uint32_t) (v >> 32));
    write_u32(p + 4, (uint32_t) v);
}

int
prp_discovery_bloom_profile_get(uint8_t profile_id,
    prp_discovery_bloom_profile_t *profile)
{
    static const prp_discovery_bloom_profile_t profiles[] = {
        { PRP_DISCOVERY_BLOOM_PROFILE_8K, 8u * 1024u, 2839u,
            PRP_DISCOVERY_BLOOM_HASH_COUNT },
        { PRP_DISCOVERY_BLOOM_PROFILE_32K, 32u * 1024u, 11357u,
            PRP_DISCOVERY_BLOOM_HASH_COUNT },
        { PRP_DISCOVERY_BLOOM_PROFILE_128K, 128u * 1024u, 45426u,
            PRP_DISCOVERY_BLOOM_HASH_COUNT },
        { PRP_DISCOVERY_BLOOM_PROFILE_512K, 512u * 1024u, 181704u,
            PRP_DISCOVERY_BLOOM_HASH_COUNT },
        { PRP_DISCOVERY_BLOOM_PROFILE_2M, 2u * 1024u * 1024u, 726817u,
            PRP_DISCOVERY_BLOOM_HASH_COUNT }
    };
    size_t i;

    if (profile == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    for (i = 0; i < sizeof(profiles) / sizeof(profiles[0]); i++) {
        if (profiles[i].profile_id == profile_id) {
            *profile = profiles[i];
            return PRP_OK;
        }
    }
    return PRP_ERR_PROTOCOL;
}

int
prp_discovery_bloom_indexes(uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len,
    uint8_t profile_id,
    uint32_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT])
{
    struct prp_wire_v4_identity_suite_desc identity_suite;
    prp_discovery_bloom_profile_t profile;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    uint64_t h1;
    uint64_t h2;
    uint64_t mask;
    uint8_t identity[3u + PRP_DISCOVERY_BLOOM_STRONG_ID_MAX_LEN];
    size_t i;

    if (published_strong_id == NULL ||
        prp_wire_v4_identity_suite_get(published_identity_suite,
            &identity_suite) != PRP_WIRE_V4_OK ||
        published_strong_id_len != identity_suite.strong_id_len ||
        indexes == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (prp_discovery_bloom_profile_get(profile_id, &profile) != PRP_OK) {
        return PRP_ERR_PROTOCOL;
    }
    write_u16(identity, published_identity_suite);
    identity[2] = (uint8_t) published_strong_id_len;
    memcpy(identity + 3, published_strong_id, published_strong_id_len);
    if (prp_hash_blake3_concat(bloom_domain, sizeof(bloom_domain) - 1u,
            identity, published_strong_id_len + 3u, digest) != 0) {
        return PRP_ERR_CRYPTO;
    }
    h1 = read_u64(digest);
    h2 = read_u64(digest + 8) | 1u;
    mask = ((uint64_t) profile.bitmap_bytes * 8u) - 1u;
    for (i = 0; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        indexes[i] = (uint32_t) ((h1 + ((uint64_t) i * h2)) & mask);
    }
    return PRP_OK;
}

int
prp_discovery_bloom_add(uint8_t *bitmap, size_t bitmap_len,
    uint8_t profile_id, uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len)
{
    prp_discovery_bloom_profile_t profile;
    uint32_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t i;
    int rc;

    if (bitmap == NULL ||
        prp_discovery_bloom_profile_get(profile_id, &profile) != PRP_OK ||
        bitmap_len != profile.bitmap_bytes) {
        return PRP_ERR_ARGUMENT;
    }
    rc = prp_discovery_bloom_indexes(published_identity_suite,
        published_strong_id, published_strong_id_len, profile_id, indexes);
    if (rc != PRP_OK) {
        return rc;
    }
    for (i = 0; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        bitmap[indexes[i] >> 3] |= (uint8_t) (1u << (indexes[i] & 7u));
    }
    return PRP_OK;
}

int
prp_discovery_bloom_maybe_contains(const uint8_t *bitmap,
    size_t bitmap_len, uint8_t profile_id, uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len,
    int *maybe_contains)
{
    prp_discovery_bloom_profile_t profile;
    uint32_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t i;
    int rc;

    if (bitmap == NULL || maybe_contains == NULL ||
        prp_discovery_bloom_profile_get(profile_id, &profile) != PRP_OK ||
        bitmap_len != profile.bitmap_bytes) {
        return PRP_ERR_ARGUMENT;
    }
    rc = prp_discovery_bloom_indexes(published_identity_suite,
        published_strong_id, published_strong_id_len, profile_id, indexes);
    if (rc != PRP_OK) {
        return rc;
    }
    *maybe_contains = 1;
    for (i = 0; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        if ((bitmap[indexes[i] >> 3] &
                (uint8_t) (1u << (indexes[i] & 7u))) == 0u) {
            *maybe_contains = 0;
            break;
        }
    }
    return PRP_OK;
}

uint32_t
prp_discovery_bloom_popcount(const uint8_t *bitmap, size_t bitmap_len)
{
    uint32_t count = 0;
    size_t i;

    if (bitmap == NULL) {
        return 0;
    }
    for (i = 0; i < bitmap_len; i++) {
        uint8_t value = bitmap[i];
        while (value != 0u) {
            value &= (uint8_t) (value - 1u);
            count++;
        }
    }
    return count;
}

static int
bloom_v4_geometry(uint8_t bit_order, size_t bitmap_len, uint64_t *bitmap_bits)
{
    uint64_t expected_bits;

    if (bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER) {
        return PRP_ERR_PROTOCOL;
    }
    expected_bits = UINT64_C(1) << bit_order;
    if (bitmap_len != (size_t) (expected_bits / 8u)) {
        return PRP_ERR_ARGUMENT;
    }
    if (bitmap_bits != NULL) {
        *bitmap_bits = expected_bits;
    }
    return PRP_OK;
}

int
prp_discovery_bloom_v4_indexes(uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len, uint8_t filter_bit_order,
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT])
{
    prp_discovery_target_t target;
    uint8_t *input;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    uint64_t mask;
    size_t domain_len = sizeof(bloom_v4_domain) - 1u;
    size_t target_key_len, input_len, written;
    size_t i;

    if (lookup_index_profile == 0u || identifier == NULL ||
        identifier_len == 0u || identifier_len > UINT16_MAX || indexes == NULL ||
        filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER) {
        return PRP_ERR_ARGUMENT;
    }
    target.target_kind = target_kind;
    target.identifier_profile = identifier_profile;
    target.identifier = identifier;
    target.identifier_len = (uint16_t)identifier_len;
    target_key_len = PRP_DISCOVERY_TARGET_KEY_PREFIX_LEN + identifier_len;
    input_len = domain_len + 5u + target_key_len;
    input = malloc(input_len);
    if (input == NULL)
        return PRP_ERR_STATE;
    memcpy(input, bloom_v4_domain, domain_len);
    write_u16(input + domain_len + 1u, lookup_index_profile);
    write_u16(input + domain_len + 3u, (uint16_t)target_key_len);
    if (prp_discovery_target_encode(&target, input + domain_len + 5u,
            target_key_len, &written) != PRP_OK || written != target_key_len) {
        free(input);
        return PRP_ERR_ARGUMENT;
    }
    mask = (UINT64_C(1) << filter_bit_order) - 1u;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        input[domain_len] = (uint8_t) i;
        if (prp_hash_blake3(input, input_len, digest) != 0) {
            free(input);
            return PRP_ERR_CRYPTO;
        }
        indexes[i] = read_u64(digest) & mask;
    }
    free(input);
    return PRP_OK;
}

int
prp_discovery_bloom_v4_add(uint8_t *bitmap, size_t bitmap_len,
    uint8_t filter_bit_order, uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t i;
    int rc;

    if (bitmap == NULL ||
        bloom_v4_geometry(filter_bit_order, bitmap_len, NULL) != PRP_OK) {
        return PRP_ERR_ARGUMENT;
    }
    rc = prp_discovery_bloom_v4_indexes(lookup_index_profile,
        target_kind, identifier_profile, identifier, identifier_len,
        filter_bit_order, indexes);
    if (rc != PRP_OK) {
        return rc;
    }
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        bitmap[indexes[i] >> 3] |=
            (uint8_t) (1u << (indexes[i] & 7u));
    }
    return PRP_OK;
}

int
prp_discovery_bloom_v4_maybe_contains(const uint8_t *bitmap,
    size_t bitmap_len, uint8_t filter_bit_order,
    uint16_t lookup_index_profile, uint8_t target_kind,
    uint16_t identifier_profile, const uint8_t *identifier,
    size_t identifier_len, int *maybe_contains)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t i;
    int rc;

    if (bitmap == NULL || maybe_contains == NULL ||
        bloom_v4_geometry(filter_bit_order, bitmap_len, NULL) != PRP_OK) {
        return PRP_ERR_ARGUMENT;
    }
    rc = prp_discovery_bloom_v4_indexes(lookup_index_profile,
        target_kind, identifier_profile, identifier, identifier_len,
        filter_bit_order, indexes);
    if (rc != PRP_OK) {
        return rc;
    }
    *maybe_contains = 1;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        if ((bitmap[indexes[i] >> 3] &
                (uint8_t) (1u << (indexes[i] & 7u))) == 0u) {
            *maybe_contains = 0;
            break;
        }
    }
    return PRP_OK;
}

static int
bloom_v4_complete_shard_record_len(uint8_t filter_bit_order,
    uint8_t shard_bit_order, uint64_t *record_len)
{
    uint64_t length;

    if (filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        shard_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        shard_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        shard_bit_order > filter_bit_order)
        return PRP_ERR_ARGUMENT;
    length = PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN +
        (UINT64_C(1) << (shard_bit_order - 3u)) +
        (uint64_t)(filter_bit_order - shard_bit_order) *
            PRP_HASH_BLAKE3_OUT_LEN;
    if (length > PRP_WIRE_V4_LOGICAL_UNIT_MAX -
            PRP_WIRE_V4_E2E_ITEM_HEADER_LEN)
        return PRP_ERR_ARGUMENT;
    if (record_len != NULL)
        *record_len = length;
    return PRP_OK;
}

static int
bloom_v4_shard_geometry(uint8_t filter_bit_order, uint8_t shard_bit_order,
    uint64_t shard_index, size_t shard_len)
{
    uint64_t shard_count;

    if (bloom_v4_complete_shard_record_len(filter_bit_order,
            shard_bit_order, NULL) != PRP_OK ||
        shard_len != (size_t)(UINT64_C(1) << (shard_bit_order - 3u)))
        return PRP_ERR_ARGUMENT;
    shard_count = UINT64_C(1) << (filter_bit_order - shard_bit_order);
    return shard_index < shard_count ? PRP_OK : PRP_ERR_ARGUMENT;
}

int
prp_discovery_bloom_v4_shard_add(uint8_t *shard, size_t shard_len,
    uint8_t filter_bit_order, uint8_t shard_bit_order, uint64_t shard_index,
    uint16_t lookup_index_profile, uint8_t target_kind,
    uint16_t identifier_profile, const uint8_t *identifier,
    size_t identifier_len,
    uint32_t *new_set_bits)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    uint64_t offset_mask;
    uint32_t changed = 0u;
    size_t i;
    int rc;

    if (shard == NULL || new_set_bits == NULL ||
        bloom_v4_shard_geometry(filter_bit_order, shard_bit_order,
            shard_index, shard_len) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_bloom_v4_indexes(lookup_index_profile,
        target_kind, identifier_profile, identifier, identifier_len,
        filter_bit_order, indexes);
    if (rc != PRP_OK)
        return rc;
    offset_mask = (UINT64_C(1) << shard_bit_order) - 1u;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        uint64_t offset;
        uint8_t mask;

        if ((indexes[i] >> shard_bit_order) != shard_index)
            continue;
        offset = indexes[i] & offset_mask;
        mask = (uint8_t)(1u << (offset & 7u));
        if ((shard[offset >> 3] & mask) == 0u) {
            shard[offset >> 3] |= mask;
            changed++;
        }
    }
    *new_set_bits = changed;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_sharded_maybe_contains(uint8_t filter_bit_order,
    uint8_t shard_bit_order, uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len,
    prp_discovery_bloom_shard_read_fn read_shard, void *read_context,
    int *maybe_contains)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    uint64_t offset_mask;
    size_t expected_len;
    size_t i;
    int rc;

    if (read_shard == NULL || maybe_contains == NULL ||
        shard_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        shard_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER)
        return PRP_ERR_ARGUMENT;
    expected_len = (size_t)(UINT64_C(1) << (shard_bit_order - 3u));
    if (bloom_v4_shard_geometry(filter_bit_order, shard_bit_order, 0u,
            expected_len) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_bloom_v4_indexes(lookup_index_profile,
        target_kind, identifier_profile, identifier, identifier_len,
        filter_bit_order, indexes);
    if (rc != PRP_OK)
        return rc;
    offset_mask = (UINT64_C(1) << shard_bit_order) - 1u;
    *maybe_contains = 1;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        const uint8_t *shard = NULL;
        size_t shard_len = 0u;
        uint64_t offset = indexes[i] & offset_mask;

        rc = read_shard(read_context, indexes[i] >> shard_bit_order,
            &shard, &shard_len);
        if (rc != PRP_OK)
            return rc;
        if (shard == NULL || shard_len != expected_len)
            return PRP_ERR_PROTOCOL;
        if ((shard[offset >> 3] &
                (uint8_t)(1u << (offset & 7u))) == 0u) {
            *maybe_contains = 0;
            break;
        }
    }
    return PRP_OK;
}

int
prp_discovery_bloom_v4_fold(const uint8_t *source, size_t source_len,
    uint8_t source_bit_order, uint8_t *destination,
    size_t destination_len, uint8_t destination_bit_order)
{
    size_t offset;
    size_t i;

    if (source == NULL || destination == NULL ||
        source_bit_order < destination_bit_order ||
        bloom_v4_geometry(source_bit_order, source_len, NULL) != PRP_OK ||
        bloom_v4_geometry(destination_bit_order, destination_len, NULL) !=
            PRP_OK) {
        return PRP_ERR_ARGUMENT;
    }
    memset(destination, 0, destination_len);
    for (offset = 0u; offset < source_len; offset += destination_len) {
        for (i = 0u; i < destination_len; i++) {
            destination[i] |= source[offset + i];
        }
    }
    return PRP_OK;
}

int
prp_discovery_bloom_v4_compose(uint8_t *destination,
    size_t destination_len, uint8_t destination_bit_order,
    const uint8_t *candidate, size_t candidate_len,
    uint8_t candidate_bit_order, uint32_t maximum_density_ppm,
    uint64_t *result_set_bit_count)
{
    uint64_t destination_bits;
    uint64_t projected = 0u;
    size_t i;
    size_t offset;

    if (destination == NULL || candidate == NULL ||
        result_set_bit_count == NULL ||
        maximum_density_ppm > PRP_DISCOVERY_BLOOM_DENSITY_PPM_MAX ||
        candidate_bit_order < destination_bit_order ||
        bloom_v4_geometry(destination_bit_order, destination_len,
            &destination_bits) != PRP_OK ||
        bloom_v4_geometry(candidate_bit_order, candidate_len, NULL) !=
            PRP_OK) {
        return PRP_ERR_ARGUMENT;
    }
    for (i = 0u; i < destination_len; i++) {
        uint8_t folded = 0u;

        for (offset = i; offset < candidate_len;
                offset += destination_len) {
            folded |= candidate[offset];
        }
        projected += (uint64_t) __builtin_popcount(
            (unsigned int) (destination[i] | folded));
    }
    if (projected * PRP_DISCOVERY_BLOOM_DENSITY_PPM_MAX >
        destination_bits * maximum_density_ppm) {
        return PRP_ERR_POLICY;
    }
    for (i = 0u; i < destination_len; i++) {
        uint8_t folded = 0u;

        for (offset = i; offset < candidate_len;
                offset += destination_len) {
            folded |= candidate[offset];
        }
        destination[i] |= folded;
    }
    *result_set_bit_count = projected;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_shard_commitment(uint64_t generation,
    uint16_t lookup_index_profile, uint8_t filter_bit_order,
    uint8_t shard_bit_order, uint64_t shard_index,
    const uint8_t *bitmap, size_t bitmap_len,
    uint8_t commitment[PRP_HASH_BLAKE3_OUT_LEN])
{
    uint8_t prefix[sizeof(bloom_v4_shard_domain) - 1u + 8u + 2u + 1u +
        1u + 8u + 4u];
    size_t domain_len = sizeof(bloom_v4_shard_domain) - 1u;
    uint64_t shard_count;

    if (generation == 0u || lookup_index_profile == 0u ||
        bitmap == NULL || commitment == NULL || bitmap_len > UINT32_MAX ||
        filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        shard_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        shard_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        shard_bit_order > filter_bit_order ||
        bitmap_len != (size_t)(UINT64_C(1) << (shard_bit_order - 3u))) {
        return PRP_ERR_ARGUMENT;
    }
    shard_count = UINT64_C(1) << (filter_bit_order - shard_bit_order);
    if (shard_index >= shard_count)
        return PRP_ERR_ARGUMENT;
    memcpy(prefix, bloom_v4_shard_domain, domain_len);
    write_u64(prefix + domain_len, generation);
    write_u16(prefix + domain_len + 8u, lookup_index_profile);
    prefix[domain_len + 10u] = filter_bit_order;
    prefix[domain_len + 11u] = shard_bit_order;
    write_u64(prefix + domain_len + 12u, shard_index);
    write_u32(prefix + domain_len + 20u, (uint32_t) bitmap_len);
    if (prp_hash_blake3_concat(prefix, sizeof(prefix), bitmap, bitmap_len,
            commitment) != 0) {
        return PRP_ERR_CRYPTO;
    }
    return PRP_OK;
}

uint64_t
prp_discovery_bloom_popcount64(const uint8_t *bitmap, size_t bitmap_len)
{
    uint64_t count = 0u;
    size_t i;

    if (bitmap == NULL)
        return 0u;
    for (i = 0u; i < bitmap_len; i++)
        count += (uint64_t)__builtin_popcount((unsigned int)bitmap[i]);
    return count;
}

int
prp_discovery_bloom_density_ppm(uint64_t set_bit_count,
    uint8_t filter_bit_order, uint32_t *density_ppm)
{
    uint64_t bits;
    uint64_t low_product, high_product, low_half_product, high_half_product;
    uint64_t shifted;
    const uint64_t scale = PRP_DISCOVERY_BLOOM_DENSITY_PPM_MAX;

    if (density_ppm == NULL ||
        filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER)
        return PRP_ERR_ARGUMENT;
    bits = UINT64_C(1) << filter_bit_order;
    if (set_bit_count > bits)
        return PRP_ERR_ARGUMENT;
    low_half_product = (set_bit_count & UINT32_MAX) * scale;
    high_half_product = (set_bit_count >> 32) * scale;
    low_product = low_half_product + (high_half_product << 32);
    high_product = (high_half_product >> 32) +
        (low_product < low_half_product ? 1u : 0u);
    shifted = (low_product >> filter_bit_order) |
        (high_product << (64u - filter_bit_order));
    *density_ppm = (uint32_t)shifted;
    return PRP_OK;
}

static int
bloom_v4_record_valid(const prp_discovery_bloom_v4_manifest_t *record,
    int constructing)
{
    struct prp_wire_v4_identity_suite_desc suite;
    uint64_t expected_shards;
    uint64_t filter_bits;
    size_t public_key_len;
    size_t signature_len;

    if (record == NULL ||
        record->origin_identity_suite == 0u ||
        record->origin_identity_proof_profile == 0u ||
        record->lookup_index_profile == 0u || record->generation == 0u ||
        record->previous_generation >= record->generation ||
        record->valid_from >= record->valid_until ||
        record->origin_strong_id == NULL ||
        record->origin_identity_proof_profile > UINT8_MAX ||
        record->filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        record->filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        record->shard_bit_order <
            PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        record->shard_bit_order >
            PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        record->shard_bit_order > record->filter_bit_order ||
        bloom_v4_complete_shard_record_len(record->filter_bit_order,
            record->shard_bit_order, NULL) != PRP_OK ||
        record->shard_root == NULL)
        return PRP_ERR_ARGUMENT;
    filter_bits = UINT64_C(1) << record->filter_bit_order;
    expected_shards = UINT64_C(1) <<
        (record->filter_bit_order - record->shard_bit_order);
    if (record->set_bit_count > filter_bits ||
        record->shard_count != expected_shards)
        return PRP_ERR_ARGUMENT;
    if (prp_wire_v4_identity_suite_get(record->origin_identity_suite,
            &suite) != PRP_WIRE_V4_OK ||
            record->origin_strong_id_len != suite.strong_id_len ||
            suite.public_key_len != prp_identity_proof_public_key_len(
                (uint8_t)record->origin_identity_proof_profile) ||
            suite.proof_len != prp_identity_proof_signature_len(
                (uint8_t)record->origin_identity_proof_profile))
        return PRP_ERR_ARGUMENT;
    if (record->origin_auth_len == 0u)
        return constructing ? PRP_OK : PRP_ERR_CRYPTO;
    public_key_len = prp_identity_proof_public_key_len(
        (uint8_t)record->origin_identity_proof_profile);
    signature_len = prp_identity_proof_signature_len(
        (uint8_t)record->origin_identity_proof_profile);
    if (public_key_len == 0u || signature_len == 0u ||
        public_key_len + signature_len != record->origin_auth_len ||
        record->origin_auth == NULL)
        return PRP_ERR_ARGUMENT;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_manifest_encode(
    const prp_discovery_bloom_v4_manifest_t *record, uint8_t *out,
    size_t out_len, size_t *written)
{
    size_t authenticated_len;
    size_t needed;
    int rc = bloom_v4_record_valid(record, 1);

    if (rc != PRP_OK || out == NULL || written == NULL)
        return rc != PRP_OK ? rc : PRP_ERR_ARGUMENT;
    authenticated_len = PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN +
        record->origin_strong_id_len;
    needed = authenticated_len + record->origin_auth_len;
    if (out_len < needed)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN);
    memcpy(out, bloom_v4_record_magic, sizeof(bloom_v4_record_magic) - 1u);
    out[4] = 4u;
    out[5] = PRP_DISCOVERY_BLOOM_V4_MANIFEST_KIND;
    write_u16(out + 8, record->origin_identity_suite);
    write_u16(out + 10, record->origin_identity_proof_profile);
    write_u16(out + 12, record->lookup_index_profile);
    out[14] = record->filter_bit_order;
    out[15] = record->shard_bit_order;
    write_u64(out + 16, record->generation);
    write_u64(out + 24, record->previous_generation);
    write_u64(out + 32, record->valid_from);
    write_u64(out + 40, record->valid_until);
    write_u64(out + 48, record->set_bit_count);
    write_u64(out + 56, record->shard_count);
    memcpy(out + 64, record->shard_root, PRP_HASH_BLAKE3_OUT_LEN);
    write_u16(out + 96, record->origin_strong_id_len);
    memcpy(out + PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN,
        record->origin_strong_id, record->origin_strong_id_len);
    if (record->origin_auth_len != 0u)
        memcpy(out + authenticated_len, record->origin_auth,
            record->origin_auth_len);
    *written = needed;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_manifest_decode(const uint8_t *data, size_t data_len,
    prp_discovery_bloom_v4_manifest_t *record)
{
    size_t authenticated_len;
    size_t needed;
    size_t i;

    if (data == NULL || record == NULL ||
        data_len < PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN ||
        memcmp(data, bloom_v4_record_magic,
            sizeof(bloom_v4_record_magic) - 1u) != 0)
        return PRP_ERR_PROTOCOL;
    if (data[4] != 4u)
        return PRP_ERR_VERSION;
    if (data[5] != PRP_DISCOVERY_BLOOM_V4_MANIFEST_KIND ||
        read_u16(data + 6u) != 0u || read_u16(data + 98u) != 0u)
        return PRP_ERR_PROTOCOL;
    for (i = 100u; i < PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN; i++)
        if (data[i] != 0u)
            return PRP_ERR_PROTOCOL;
    memset(record, 0, sizeof(*record));
    record->origin_identity_suite = read_u16(data + 8);
    record->origin_identity_proof_profile = read_u16(data + 10);
    record->lookup_index_profile = read_u16(data + 12);
    record->filter_bit_order = data[14];
    record->shard_bit_order = data[15];
    record->generation = read_u64(data + 16);
    record->previous_generation = read_u64(data + 24);
    record->valid_from = read_u64(data + 32);
    record->valid_until = read_u64(data + 40);
    record->set_bit_count = read_u64(data + 48);
    record->shard_count = read_u64(data + 56);
    record->shard_root = data + 64;
    record->origin_strong_id_len = read_u16(data + 96);
    record->origin_auth_len = (uint16_t)(
        prp_identity_proof_public_key_len(
            (uint8_t)record->origin_identity_proof_profile) +
        prp_identity_proof_signature_len(
            (uint8_t)record->origin_identity_proof_profile));
    if ((record->origin_strong_id_len != 32u &&
         record->origin_strong_id_len !=
            PRP_DISCOVERY_BLOOM_STRONG_ID_MAX_LEN))
        return PRP_ERR_PROTOCOL;
    authenticated_len = PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN +
        record->origin_strong_id_len;
    needed = authenticated_len + record->origin_auth_len;
    if (authenticated_len < PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN ||
        needed != data_len)
        return PRP_ERR_PROTOCOL;
    record->origin_strong_id =
        data + PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN;
    record->origin_auth = data + authenticated_len;
    record->authenticated_len = authenticated_len;
    return bloom_v4_record_valid(record, 1);
}

int
prp_discovery_bloom_v4_manifest_admit(const uint8_t *data, size_t data_len,
    uint64_t now, prp_discovery_bloom_v4_manifest_t *record)
{
    uint8_t computed[PRP_DISCOVERY_BLOOM_STRONG_ID_MAX_LEN];
    const uint8_t *context = NULL;
    size_t context_len = 0u;
    size_t computed_len = 0u;
    size_t public_key_len;
    size_t signature_len;
    int rc;

    rc = prp_discovery_bloom_v4_manifest_decode(data, data_len, record);
    if (rc != PRP_OK || now == 0u || now < record->valid_from ||
        now >= record->valid_until ||
        bloom_v4_record_valid(record, 0) != PRP_OK)
        return rc != PRP_OK ? rc : PRP_ERR_CRYPTO;
    public_key_len = prp_identity_proof_public_key_len(
        (uint8_t)record->origin_identity_proof_profile);
    signature_len = prp_identity_proof_signature_len(
        (uint8_t)record->origin_identity_proof_profile);
    if (prp_wire_v4_strong_id_compute(record->origin_identity_suite,
            record->origin_auth, public_key_len, computed, sizeof(computed),
            &computed_len) != 0 ||
        computed_len != record->origin_strong_id_len ||
        memcmp(computed, record->origin_strong_id, computed_len) != 0)
        return PRP_ERR_CRYPTO;
    if (record->origin_identity_proof_profile !=
            PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3) {
        context = discovery_proof_context;
        context_len = sizeof(discovery_proof_context) - 1u;
    }
    if (prp_identity_proof_verify(
            (uint8_t)record->origin_identity_proof_profile,
            record->origin_auth, public_key_len,
            record->origin_auth + public_key_len, signature_len,
            data, record->authenticated_len, context, context_len) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}

static int
bloom_v4_shard_valid(const prp_discovery_bloom_v4_shard_t *record)
{
    uint64_t encoded_len;
    uint64_t expected_len;
    uint64_t shard_count;

    if (record == NULL || record->lookup_index_profile == 0u ||
        record->generation == 0u ||
        (record->flags & ~PRP_DISCOVERY_BLOOM_V4_SHARD_F_MASK) != 0u ||
        record->filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        record->filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        record->shard_bit_order <
            PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        record->shard_bit_order >
            PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        record->shard_bit_order > record->filter_bit_order ||
        record->proof_depth !=
            record->filter_bit_order - record->shard_bit_order ||
        record->proof_depth > PRP_DISCOVERY_BLOOM_V4_MAX_PROOF_DEPTH ||
        bloom_v4_complete_shard_record_len(record->filter_bit_order,
            record->shard_bit_order, NULL) != PRP_OK ||
        (record->proof_depth != 0u && record->proof == NULL))
        return PRP_ERR_ARGUMENT;
    shard_count = UINT64_C(1) <<
        (record->filter_bit_order - record->shard_bit_order);
    encoded_len = PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN +
        (uint64_t)record->shard_len +
        (uint64_t)record->proof_depth * PRP_HASH_BLAKE3_OUT_LEN;
    if (record->shard_index >= shard_count ||
        encoded_len > PRP_WIRE_V4_LOGICAL_UNIT_MAX -
            PRP_WIRE_V4_E2E_ITEM_HEADER_LEN)
        return PRP_ERR_ARGUMENT;
    if ((record->flags & PRP_DISCOVERY_BLOOM_V4_SHARD_F_EMPTY) != 0u)
        return record->shard_len == 0u && record->set_bit_count == 0u &&
            record->shard == NULL ? PRP_OK : PRP_ERR_ARGUMENT;
    expected_len = UINT64_C(1) << (record->shard_bit_order - 3u);
    if (record->shard == NULL || record->shard_len != expected_len ||
        record->set_bit_count !=
            prp_discovery_bloom_popcount64(record->shard,
                record->shard_len))
        return PRP_ERR_ARGUMENT;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_shard_encode(
    const prp_discovery_bloom_v4_shard_t *record, uint8_t *out,
    size_t out_len, size_t *written)
{
    size_t needed;

    if (bloom_v4_shard_valid(record) != PRP_OK || out == NULL ||
        written == NULL)
        return PRP_ERR_ARGUMENT;
    needed = PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN + record->shard_len +
        (size_t)record->proof_depth * PRP_HASH_BLAKE3_OUT_LEN;
    if (out_len < needed)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN);
    memcpy(out, "PRBS", 4u);
    out[4] = 4u;
    out[5] = PRP_DISCOVERY_BLOOM_V4_SHARD_KIND;
    write_u16(out + 6u, record->flags);
    write_u16(out + 8u, record->lookup_index_profile);
    out[10] = record->filter_bit_order;
    out[11] = record->shard_bit_order;
    write_u64(out + 12u, record->generation);
    write_u64(out + 20u, record->shard_index);
    write_u32(out + 28u, record->shard_len);
    out[32] = record->proof_depth;
    write_u64(out + 36u, record->set_bit_count);
    if (record->shard_len != 0u)
        memcpy(out + PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN,
            record->shard, record->shard_len);
    if (record->proof_depth != 0u)
        memcpy(out + PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN +
            record->shard_len, record->proof,
            (size_t)record->proof_depth * PRP_HASH_BLAKE3_OUT_LEN);
    *written = needed;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_shard_decode(const uint8_t *data, size_t data_len,
    prp_discovery_bloom_v4_shard_t *record)
{
    size_t needed;
    size_t i;

    if (data == NULL || record == NULL ||
        data_len < PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN ||
        data_len > PRP_WIRE_V4_LOGICAL_UNIT_MAX -
            PRP_WIRE_V4_E2E_ITEM_HEADER_LEN ||
        memcmp(data, "PRBS", 4u) != 0)
        return PRP_ERR_PROTOCOL;
    if (data[4] != 4u)
        return PRP_ERR_VERSION;
    if (data[5] != PRP_DISCOVERY_BLOOM_V4_SHARD_KIND)
        return PRP_ERR_PROTOCOL;
    for (i = 33u; i < 36u; i++)
        if (data[i] != 0u)
            return PRP_ERR_PROTOCOL;
    for (i = 44u; i < PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN; i++)
        if (data[i] != 0u)
            return PRP_ERR_PROTOCOL;
    memset(record, 0, sizeof(*record));
    record->flags = read_u16(data + 6u);
    record->lookup_index_profile = read_u16(data + 8u);
    record->filter_bit_order = data[10];
    record->shard_bit_order = data[11];
    record->generation = read_u64(data + 12u);
    record->shard_index = read_u64(data + 20u);
    record->shard_len = read_u32(data + 28u);
    record->proof_depth = data[32];
    record->set_bit_count = read_u64(data + 36u);
    needed = PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN + record->shard_len +
        (size_t)record->proof_depth * PRP_HASH_BLAKE3_OUT_LEN;
    if (needed != data_len)
        return PRP_ERR_PROTOCOL;
    if (record->shard_len != 0u)
        record->shard = data + PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN;
    if (record->proof_depth != 0u)
        record->proof = data + PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN +
            record->shard_len;
    return bloom_v4_shard_valid(record) == PRP_OK ?
        PRP_OK : PRP_ERR_PROTOCOL;
}

static int
bloom_v4_parent(uint8_t level, const uint8_t left[PRP_HASH_BLAKE3_OUT_LEN],
    const uint8_t right[PRP_HASH_BLAKE3_OUT_LEN],
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN])
{
    uint8_t input[sizeof(bloom_v4_node_domain) - 1u + 1u +
        2u * PRP_HASH_BLAKE3_OUT_LEN];
    size_t domain_len = sizeof(bloom_v4_node_domain) - 1u;

    memcpy(input, bloom_v4_node_domain, domain_len);
    input[domain_len] = level;
    memcpy(input + domain_len + 1u, left, PRP_HASH_BLAKE3_OUT_LEN);
    memcpy(input + domain_len + 1u + PRP_HASH_BLAKE3_OUT_LEN, right,
        PRP_HASH_BLAKE3_OUT_LEN);
    return prp_hash_blake3(input, sizeof(input), out) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}

typedef struct bloom_v4_root_state_s {
    uint8_t nodes[PRP_DISCOVERY_BLOOM_V4_MAX_PROOF_DEPTH + 1u]
        [PRP_HASH_BLAKE3_OUT_LEN];
    uint64_t occupied;
} bloom_v4_root_state_t;

static int
bloom_v4_root_append(bloom_v4_root_state_t *state, uint8_t level,
    const uint8_t hash[PRP_HASH_BLAKE3_OUT_LEN])
{
    uint8_t current[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t parent[PRP_HASH_BLAKE3_OUT_LEN];
    int rc;

    memcpy(current, hash, sizeof(current));
    while ((state->occupied & (UINT64_C(1) << level)) != 0u) {
        rc = bloom_v4_parent(level, state->nodes[level], current, parent);
        if (rc != PRP_OK)
            return rc;
        state->occupied &= ~(UINT64_C(1) << level);
        memcpy(current, parent, sizeof(current));
        level++;
    }
    memcpy(state->nodes[level], current, sizeof(current));
    state->occupied |= UINT64_C(1) << level;
    return PRP_OK;
}

int
prp_discovery_bloom_v4_sparse_root(uint8_t filter_bit_order,
    uint8_t shard_bit_order, const uint64_t *shard_indexes,
    const uint8_t *shard_commitments, size_t shard_count,
    uint8_t root[PRP_HASH_BLAKE3_OUT_LEN])
{
    uint8_t defaults[PRP_DISCOVERY_BLOOM_V4_MAX_PROOF_DEPTH + 1u]
        [PRP_HASH_BLAKE3_OUT_LEN];
    bloom_v4_root_state_t state = { 0 };
    uint8_t depth;
    uint64_t position = 0u;
    uint64_t total;
    size_t item;
    int rc;

    if (root == NULL ||
        filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        shard_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        shard_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        shard_bit_order > filter_bit_order ||
        bloom_v4_complete_shard_record_len(filter_bit_order,
            shard_bit_order, NULL) != PRP_OK ||
        (shard_count != 0u &&
         (shard_indexes == NULL || shard_commitments == NULL)))
        return PRP_ERR_ARGUMENT;
    depth = filter_bit_order - shard_bit_order;
    total = UINT64_C(1) << depth;
    if (prp_hash_blake3(bloom_v4_empty_domain,
            sizeof(bloom_v4_empty_domain) - 1u, defaults[0]) != 0)
        return PRP_ERR_CRYPTO;
    for (uint8_t level = 0u; level < depth; level++) {
        rc = bloom_v4_parent(level, defaults[level], defaults[level],
            defaults[level + 1u]);
        if (rc != PRP_OK)
            return rc;
    }
    for (item = 0u; item <= shard_count; item++) {
        uint64_t next = item < shard_count ? shard_indexes[item] : total;

        if (next < position || next >= total + (item == shard_count) ||
            (item != 0u && item < shard_count &&
             shard_indexes[item - 1u] >= next))
            return PRP_ERR_ARGUMENT;
        while (position < next) {
            uint64_t remaining = next - position;
            uint8_t level = position == 0u ? depth :
                (uint8_t)__builtin_ctzll(position);

            while ((UINT64_C(1) << level) > remaining)
                level--;
            rc = bloom_v4_root_append(&state, level, defaults[level]);
            if (rc != PRP_OK)
                return rc;
            position += UINT64_C(1) << level;
        }
        if (item < shard_count) {
            rc = bloom_v4_root_append(&state, 0u,
                shard_commitments + item * PRP_HASH_BLAKE3_OUT_LEN);
            if (rc != PRP_OK)
                return rc;
            position++;
        }
    }
    if (state.occupied != (UINT64_C(1) << depth))
        return PRP_ERR_STATE;
    memcpy(root, state.nodes[depth], PRP_HASH_BLAKE3_OUT_LEN);
    return PRP_OK;
}

int
prp_discovery_bloom_v4_shard_verify(
    const prp_discovery_bloom_v4_shard_t *record,
    const uint8_t root[PRP_HASH_BLAKE3_OUT_LEN])
{
    uint8_t current[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t parent[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t level;
    int rc;

    if (root == NULL || bloom_v4_shard_valid(record) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    if ((record->flags & PRP_DISCOVERY_BLOOM_V4_SHARD_F_EMPTY) != 0u) {
        if (prp_hash_blake3(bloom_v4_empty_domain,
                sizeof(bloom_v4_empty_domain) - 1u, current) != 0)
            return PRP_ERR_CRYPTO;
    } else {
        rc = prp_discovery_bloom_v4_shard_commitment(record->generation,
            record->lookup_index_profile, record->filter_bit_order,
            record->shard_bit_order, record->shard_index, record->shard,
            record->shard_len, current);
        if (rc != PRP_OK)
            return rc;
    }
    for (level = 0u; level < record->proof_depth; level++) {
        const uint8_t *sibling = record->proof +
            (size_t)level * PRP_HASH_BLAKE3_OUT_LEN;

        if (((record->shard_index >> level) & 1u) == 0u)
            rc = bloom_v4_parent(level, current, sibling, parent);
        else
            rc = bloom_v4_parent(level, sibling, current, parent);
        if (rc != PRP_OK)
            return rc;
        memcpy(current, parent, sizeof(current));
    }
    return memcmp(current, root, sizeof(current)) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}

static int
bloom_discovery_profile_filter_order(uint16_t profile,
    uint8_t *filter_bit_order)
{
    uint16_t low;

    if (filter_bit_order == NULL ||
        !((profile >= PRP_DISCOVERY_PROFILE_SHARDED_V4_MICROSHARD_P16 &&
           profile <= PRP_DISCOVERY_PROFILE_SHARDED_V4_MICROSHARD_P63) ||
          (profile >= PRP_DISCOVERY_PROFILE_SHARDED_V4_VOPRF_P16 &&
           profile <= PRP_DISCOVERY_PROFILE_SHARDED_V4_VOPRF_P63)))
        return PRP_ERR_ARGUMENT;
    low = profile & 0x00ffu;
    *filter_bit_order = (uint8_t)(15u + low);
    return PRP_OK;
}

static int
bloom_remote_view_valid(const prp_discovery_bloom_remote_view_t *view,
    int constructing)
{
    struct prp_wire_v4_identity_suite_desc suite;
    uint8_t expected_filter_bit_order;
    uint64_t expected_shards;
    uint64_t filter_bits;
    size_t public_key_len, signature_len;

    if (view == NULL ||
        view->relationship_generation == 0u ||
        view->crypto_suite == 0u ||
        view->relationship_identity_proof_profile == 0u ||
        view->discovery_index_algorithm !=
            PRP_DISCOVERY_INDEX_SHARDED_BLOOM_V4 ||
        view->discovery_query_algorithm !=
            PRP_DISCOVERY_QUERY_MICROSHARD_V2 ||
        bloom_discovery_profile_filter_order(view->discovery_profile,
            &expected_filter_bit_order) != PRP_OK ||
        view->lookup_index_profile == 0u ||
        view->origin_identity_suite == 0u ||
        view->origin_identity_proof_profile > UINT8_MAX ||
        view->origin_identity_proof_profile !=
            view->relationship_identity_proof_profile ||
        view->filter_bit_order != expected_filter_bit_order ||
        view->shard_bit_order <
            PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        view->shard_bit_order >
            PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        view->shard_bit_order > view->filter_bit_order ||
        bloom_v4_complete_shard_record_len(view->filter_bit_order,
            view->shard_bit_order, NULL) != PRP_OK ||
        view->query_record_profile !=
            PRP_DISCOVERY_BLOOM_QUERY_PROFILE_MICROSHARD_V2 ||
        view->filter_generation == 0u ||
        view->previous_filter_generation >= view->filter_generation ||
        view->valid_from >= view->valid_until ||
        view->shard_root == NULL || view->origin_strong_id == NULL)
        return PRP_ERR_ARGUMENT;
    if (prp_wire_v4_identity_suite_get(view->origin_identity_suite,
            &suite) != PRP_WIRE_V4_OK ||
            view->origin_strong_id_len != suite.strong_id_len ||
            suite.public_key_len != prp_identity_proof_public_key_len(
                (uint8_t)view->origin_identity_proof_profile) ||
            suite.proof_len != prp_identity_proof_signature_len(
                (uint8_t)view->origin_identity_proof_profile))
        return PRP_ERR_ARGUMENT;
    filter_bits = UINT64_C(1) << view->filter_bit_order;
    expected_shards = UINT64_C(1) <<
        (view->filter_bit_order - view->shard_bit_order);
    if (view->set_bit_count > filter_bits ||
        view->shard_count != expected_shards)
        return PRP_ERR_ARGUMENT;
    if (view->origin_auth_len == 0u)
        return constructing ? PRP_OK : PRP_ERR_CRYPTO;
    public_key_len = prp_identity_proof_public_key_len(
        (uint8_t)view->origin_identity_proof_profile);
    signature_len = prp_identity_proof_signature_len(
        (uint8_t)view->origin_identity_proof_profile);
    if (public_key_len == 0u || signature_len == 0u ||
        public_key_len + signature_len != view->origin_auth_len ||
        view->origin_auth == NULL)
        return PRP_ERR_ARGUMENT;
    return PRP_OK;
}

int
prp_discovery_bloom_remote_view_encode(
    const prp_discovery_bloom_remote_view_t *view, uint8_t *out,
    size_t out_len, size_t *written)
{
    size_t authenticated_len, needed;
    int rc;

    rc = bloom_remote_view_valid(view, 1);
    if (rc != PRP_OK || out == NULL || written == NULL)
        return rc != PRP_OK ? rc : PRP_ERR_ARGUMENT;
    authenticated_len = PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN +
        view->origin_strong_id_len;
    needed = authenticated_len + view->origin_auth_len;
    if (out_len < needed)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memset(out, 0, PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN);
    memcpy(out, bloom_remote_view_magic,
        sizeof(bloom_remote_view_magic) - 1u);
    out[4] = PRP_DISCOVERY_BLOOM_REMOTE_VIEW_VERSION;
    out[5] = PRP_DISCOVERY_BLOOM_REMOTE_VIEW_KIND;
    write_u32(out + 8u, view->relationship_generation);
    write_u16(out + 12u, view->crypto_suite);
    write_u16(out + 14u, view->relationship_identity_proof_profile);
    write_u16(out + 16u, view->discovery_index_algorithm);
    write_u16(out + 18u, view->discovery_query_algorithm);
    write_u16(out + 20u, view->discovery_profile);
    write_u16(out + 22u, view->lookup_index_profile);
    write_u16(out + 24u, view->origin_identity_suite);
    write_u16(out + 26u, view->origin_identity_proof_profile);
    out[28] = view->filter_bit_order;
    out[29] = view->shard_bit_order;
    out[30] = view->query_record_profile;
    write_u64(out + 32u, view->filter_generation);
    write_u64(out + 40u, view->previous_filter_generation);
    write_u64(out + 48u, view->valid_from);
    write_u64(out + 56u, view->valid_until);
    write_u64(out + 64u, view->set_bit_count);
    write_u64(out + 72u, view->shard_count);
    memcpy(out + 80u, view->shard_root, PRP_HASH_BLAKE3_OUT_LEN);
    write_u16(out + 112u, view->origin_strong_id_len);
    memcpy(out + PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN,
        view->origin_strong_id, view->origin_strong_id_len);
    if (view->origin_auth_len != 0u)
        memcpy(out + authenticated_len, view->origin_auth,
            view->origin_auth_len);
    *written = needed;
    return PRP_OK;
}

int
prp_discovery_bloom_remote_view_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_remote_view_t *view)
{
    size_t public_key_len, signature_len, authenticated_len, needed;

    if (data == NULL || view == NULL ||
        data_len < PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN ||
        memcmp(data, bloom_remote_view_magic,
            sizeof(bloom_remote_view_magic) - 1u) != 0)
        return PRP_ERR_PROTOCOL;
    if (data[4] != PRP_DISCOVERY_BLOOM_REMOTE_VIEW_VERSION)
        return PRP_ERR_VERSION;
    if (data[5] != PRP_DISCOVERY_BLOOM_REMOTE_VIEW_KIND ||
        read_u16(data + 6u) != 0u || data[31u] != 0u)
        return PRP_ERR_PROTOCOL;
    for (size_t i = 114u; i < PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN;
            i++)
        if (data[i] != 0u)
            return PRP_ERR_PROTOCOL;
    memset(view, 0, sizeof(*view));
    view->relationship_generation = read_u32(data + 8u);
    view->crypto_suite = read_u16(data + 12u);
    view->relationship_identity_proof_profile = read_u16(data + 14u);
    view->discovery_index_algorithm = read_u16(data + 16u);
    view->discovery_query_algorithm = read_u16(data + 18u);
    view->discovery_profile = read_u16(data + 20u);
    view->lookup_index_profile = read_u16(data + 22u);
    view->origin_identity_suite = read_u16(data + 24u);
    view->origin_identity_proof_profile = read_u16(data + 26u);
    view->filter_bit_order = data[28];
    view->shard_bit_order = data[29];
    view->query_record_profile = data[30];
    view->filter_generation = read_u64(data + 32u);
    view->previous_filter_generation = read_u64(data + 40u);
    view->valid_from = read_u64(data + 48u);
    view->valid_until = read_u64(data + 56u);
    view->set_bit_count = read_u64(data + 64u);
    view->shard_count = read_u64(data + 72u);
    view->shard_root = data + 80u;
    view->origin_strong_id_len = read_u16(data + 112u);
    public_key_len = prp_identity_proof_public_key_len(
        (uint8_t)view->origin_identity_proof_profile);
    signature_len = prp_identity_proof_signature_len(
        (uint8_t)view->origin_identity_proof_profile);
    if (public_key_len == 0u || signature_len == 0u ||
        public_key_len + signature_len > UINT16_MAX)
        return PRP_ERR_PROTOCOL;
    view->origin_auth_len = (uint16_t)(public_key_len + signature_len);
    authenticated_len = PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN +
        view->origin_strong_id_len;
    needed = authenticated_len + view->origin_auth_len;
    if (authenticated_len < PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN ||
        needed != data_len)
        return PRP_ERR_PROTOCOL;
    view->origin_strong_id =
        data + PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN;
    view->origin_auth = data + authenticated_len;
    view->encoded = data;
    view->authenticated_len = authenticated_len;
    view->encoded_len = data_len;
    return bloom_remote_view_valid(view, 0) == PRP_OK ?
        PRP_OK : PRP_ERR_PROTOCOL;
}

int
prp_discovery_bloom_remote_view_admit(const uint8_t *data,
    size_t data_len, uint64_t now,
    const prp_discovery_bloom_remote_view_policy_t *policy,
    prp_discovery_bloom_remote_view_t *view)
{
    uint8_t computed[PRP_DISCOVERY_BLOOM_STRONG_ID_MAX_LEN];
    const uint8_t *context = NULL;
    size_t context_len = 0u, computed_len = 0u;
    size_t public_key_len, signature_len;
    uint64_t shard_bytes;
    uint32_t density_ppm;
    int rc;

    if (policy == NULL || policy->relationship_generation == 0u ||
        policy->crypto_suite == 0u ||
        policy->relationship_identity_proof_profile == 0u ||
        policy->remote_strong_id == NULL ||
        policy->remote_strong_id_len == 0u ||
        policy->minimum_filter_bit_order <
            PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        policy->maximum_filter_bit_order >
            PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        policy->minimum_filter_bit_order > policy->maximum_filter_bit_order ||
        policy->minimum_shard_bit_order <
            PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER ||
        policy->maximum_shard_bit_order >
            PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER ||
        policy->minimum_shard_bit_order > policy->maximum_shard_bit_order ||
        policy->maximum_resident_bytes == 0u ||
        policy->maximum_density_ppm >
            PRP_DISCOVERY_BLOOM_DENSITY_PPM_MAX)
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_bloom_remote_view_decode(data, data_len, view);
    if (rc != PRP_OK)
        return rc;
    if (now == 0u || now < view->valid_from || now >= view->valid_until)
        return PRP_ERR_POLICY;
    if (view->relationship_generation != policy->relationship_generation ||
        view->crypto_suite != policy->crypto_suite ||
        view->relationship_identity_proof_profile !=
            policy->relationship_identity_proof_profile ||
        view->discovery_index_algorithm !=
            policy->discovery_index_algorithm ||
        view->discovery_query_algorithm !=
            policy->discovery_query_algorithm ||
        view->discovery_profile != policy->discovery_profile ||
        view->lookup_index_profile != policy->lookup_index_profile ||
        view->filter_bit_order < policy->minimum_filter_bit_order ||
        view->filter_bit_order > policy->maximum_filter_bit_order ||
        view->shard_bit_order < policy->minimum_shard_bit_order ||
        view->shard_bit_order > policy->maximum_shard_bit_order ||
        view->origin_strong_id_len != policy->remote_strong_id_len ||
        memcmp(view->origin_strong_id, policy->remote_strong_id,
            view->origin_strong_id_len) != 0)
        return PRP_ERR_POLICY;
    shard_bytes = UINT64_C(1) << (view->shard_bit_order - 3u);
    if (shard_bytes > policy->maximum_resident_bytes)
        return PRP_ERR_POLICY;
    if (prp_discovery_bloom_density_ppm(view->set_bit_count,
            view->filter_bit_order, &density_ppm) != PRP_OK)
        return PRP_ERR_PROTOCOL;
    if (density_ppm > policy->maximum_density_ppm)
        return PRP_ERR_POLICY;
    public_key_len = prp_identity_proof_public_key_len(
        (uint8_t)view->origin_identity_proof_profile);
    signature_len = prp_identity_proof_signature_len(
        (uint8_t)view->origin_identity_proof_profile);
    if (prp_wire_v4_strong_id_compute(view->origin_identity_suite,
            view->origin_auth, public_key_len, computed, sizeof(computed),
            &computed_len) != 0 ||
        computed_len != view->origin_strong_id_len ||
        memcmp(computed, view->origin_strong_id, computed_len) != 0)
        return PRP_ERR_CRYPTO;
    if (view->origin_identity_proof_profile !=
            PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3) {
        context = discovery_proof_context;
        context_len = sizeof(discovery_proof_context) - 1u;
    }
    if (prp_identity_proof_verify(
            (uint8_t)view->origin_identity_proof_profile,
            view->origin_auth, public_key_len,
            view->origin_auth + public_key_len, signature_len,
            data, view->authenticated_len, context, context_len) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}

int
prp_discovery_bloom_remote_view_transition(
    const prp_discovery_bloom_remote_view_t *current,
    const prp_discovery_bloom_remote_view_t *candidate)
{
    if (candidate == NULL || candidate->encoded == NULL ||
        candidate->encoded_len == 0u)
        return PRP_ERR_ARGUMENT;
    if (current == NULL)
        return candidate->previous_filter_generation == 0u ?
            PRP_OK : PRP_ERR_PROTOCOL;
    if (current->encoded == NULL || current->encoded_len == 0u)
        return PRP_ERR_ARGUMENT;
    if (candidate->filter_generation == current->filter_generation)
        return candidate->encoded_len == current->encoded_len &&
            memcmp(candidate->encoded, current->encoded,
                current->encoded_len) == 0 ?
            PRP_ERR_ALREADY : PRP_ERR_PROTOCOL;
    if (candidate->filter_generation < current->filter_generation ||
        candidate->previous_filter_generation != current->filter_generation)
        return PRP_ERR_PROTOCOL;
    return PRP_OK;
}

static int
bloom_microshard_indexes_valid(uint8_t filter_bit_order,
    const uint64_t *indexes)
{
    uint64_t limit;
    size_t i;

    if (filter_bit_order < PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER ||
        filter_bit_order > PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER ||
        indexes == NULL)
        return 0;
    limit = UINT64_C(1) << (filter_bit_order - 7u);
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; i++) {
        if (indexes[i] >= limit || (i != 0u && indexes[i - 1u] >= indexes[i]))
            return 0;
    }
    return 1;
}

static int
bloom_microshard_header_encode(const uint8_t magic[4],
    uint8_t query_profile, uint8_t filter_bit_order,
    uint16_t lookup_index_profile,
    uint64_t generation, const uint8_t *commitment,
    const uint8_t *query_nonce, const uint64_t *microshard_indexes,
    uint8_t *out, size_t out_len)
{
    size_t i;

    if (query_profile != PRP_DISCOVERY_BLOOM_QUERY_PROFILE_MICROSHARD_V2 ||
        lookup_index_profile == 0u || generation == 0u ||
        commitment == NULL || query_nonce == NULL || out == NULL ||
        out_len < PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN ||
        !bloom_microshard_indexes_valid(filter_bit_order,
            microshard_indexes))
        return PRP_ERR_ARGUMENT;
    memcpy(out, magic, 4u);
    out[4] = PRP_DISCOVERY_BLOOM_QUERY_VERSION;
    out[5] = query_profile;
    out[6] = filter_bit_order;
    out[7] = PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES;
    write_u16(out + 8u, lookup_index_profile);
    write_u16(out + 10u, PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT);
    write_u64(out + 12u, generation);
    memcpy(out + 20u, commitment,
        PRP_DISCOVERY_BLOOM_QUERY_COMMITMENT_LEN);
    memcpy(out + 52u, query_nonce, PRP_DISCOVERY_BLOOM_QUERY_NONCE_LEN);
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; i++)
        write_u64(out + 68u + i * 8u, microshard_indexes[i]);
    return PRP_OK;
}

static int
bloom_microshard_header_decode(const uint8_t magic[4], const uint8_t *data,
    size_t data_len, uint8_t *query_profile, uint8_t *filter_bit_order,
    uint16_t *lookup_index_profile, uint64_t *generation,
    const uint8_t **commitment, const uint8_t **query_nonce,
    uint64_t *microshard_indexes)
{
    size_t i;

    if (data == NULL || data_len <
            PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN ||
        memcmp(data, magic, 4u) != 0 ||
        data[4] != PRP_DISCOVERY_BLOOM_QUERY_VERSION ||
        data[5] != PRP_DISCOVERY_BLOOM_QUERY_PROFILE_MICROSHARD_V2 ||
        data[7] != PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES ||
        read_u16(data + 8u) == 0u ||
        read_u16(data + 10u) != PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT ||
        read_u64(data + 12u) == 0u)
        return PRP_ERR_PROTOCOL;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; i++)
        microshard_indexes[i] = read_u64(data + 68u + i * 8u);
    if (!bloom_microshard_indexes_valid(data[6], microshard_indexes))
        return PRP_ERR_PROTOCOL;
    *query_profile = data[5];
    *filter_bit_order = data[6];
    *lookup_index_profile = read_u16(data + 8u);
    *generation = read_u64(data + 12u);
    *commitment = data + 20u;
    *query_nonce = data + 52u;
    return PRP_OK;
}

int
prp_discovery_bloom_microshard_request_encode(
    const prp_discovery_bloom_microshard_request_t *request, uint8_t *out,
    size_t out_len, size_t *written)
{
    int rc;

    if (request == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    rc = bloom_microshard_header_encode(bloom_microshard_request_magic,
        request->query_profile, request->filter_bit_order,
        request->lookup_index_profile, request->generation,
        request->commitment, request->query_nonce,
        request->microshard_indexes, out, out_len);
    if (rc == PRP_OK)
        *written = PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN;
    return rc;
}

int
prp_discovery_bloom_microshard_request_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_microshard_request_t *request)
{
    if (request == NULL ||
        data_len != PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN)
        return PRP_ERR_PROTOCOL;
    memset(request, 0, sizeof(*request));
    return bloom_microshard_header_decode(bloom_microshard_request_magic,
        data, data_len, &request->query_profile,
        &request->filter_bit_order,
        &request->lookup_index_profile, &request->generation,
        &request->commitment, &request->query_nonce,
        request->microshard_indexes);
}

int
prp_discovery_bloom_microshard_response_build(
    const prp_discovery_bloom_microshard_request_t *request,
    const uint8_t *bitmap, size_t bitmap_len, uint8_t *out,
    size_t out_len, size_t *written)
{
    size_t i;
    int rc;

    if (request == NULL || bitmap == NULL || out == NULL || written == NULL ||
        out_len < PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN ||
        bloom_v4_geometry(request->filter_bit_order, bitmap_len, NULL) !=
            PRP_OK)
        return PRP_ERR_ARGUMENT;
    rc = bloom_microshard_header_encode(bloom_microshard_response_magic,
        request->query_profile, request->filter_bit_order,
        request->lookup_index_profile, request->generation,
        request->commitment, request->query_nonce,
        request->microshard_indexes, out, out_len);
    if (rc != PRP_OK)
        return rc;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; i++)
        memcpy(out + PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN +
                i * PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES,
            bitmap + (size_t)request->microshard_indexes[i] *
                PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES,
            PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES);
    *written = PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN;
    return PRP_OK;
}

int
prp_discovery_bloom_microshard_response_build_sparse(
    const prp_discovery_bloom_microshard_request_t *request,
    prp_discovery_bloom_region_read_fn read_region, void *read_context,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t i;
    int rc;

    if (request == NULL || read_region == NULL || out == NULL ||
        written == NULL ||
        out_len < PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN ||
        !bloom_microshard_indexes_valid(request->filter_bit_order,
            request->microshard_indexes))
        return PRP_ERR_ARGUMENT;
    rc = bloom_microshard_header_encode(bloom_microshard_response_magic,
        request->query_profile, request->filter_bit_order,
        request->lookup_index_profile, request->generation,
        request->commitment, request->query_nonce,
        request->microshard_indexes, out, out_len);
    if (rc != PRP_OK)
        return rc;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; i++) {
        uint64_t offset = request->microshard_indexes[i] *
            PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES;

        if (read_region(read_context, offset,
                out + PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN +
                    i * PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES,
                PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES) != 0)
            return PRP_ERR_STATE;
    }
    *written = PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN;
    return PRP_OK;
}

int
prp_discovery_bloom_microshard_response_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_microshard_response_t *response)
{
    int rc;

    if (response == NULL ||
        data_len != PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN)
        return PRP_ERR_PROTOCOL;
    memset(response, 0, sizeof(*response));
    rc = bloom_microshard_header_decode(bloom_microshard_response_magic,
        data, data_len, &response->query_profile,
        &response->filter_bit_order,
        &response->lookup_index_profile, &response->generation,
        &response->commitment, &response->query_nonce,
        response->microshard_indexes);
    if (rc != PRP_OK)
        return rc;
    response->microshards =
        data + PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN;
    return PRP_OK;
}

int
prp_discovery_bloom_microshard_response_verify(
    const prp_discovery_bloom_microshard_request_t *request,
    const prp_discovery_bloom_microshard_response_t *response)
{
    if (request == NULL || response == NULL ||
        request->query_profile != response->query_profile ||
        request->filter_bit_order != response->filter_bit_order ||
        request->lookup_index_profile != response->lookup_index_profile ||
        request->generation != response->generation ||
        memcmp(request->commitment, response->commitment,
            PRP_DISCOVERY_BLOOM_QUERY_COMMITMENT_LEN) != 0 ||
        memcmp(request->query_nonce, response->query_nonce,
            PRP_DISCOVERY_BLOOM_QUERY_NONCE_LEN) != 0 ||
        memcmp(request->microshard_indexes, response->microshard_indexes,
            sizeof(request->microshard_indexes)) != 0)
        return PRP_ERR_CRYPTO;
    return PRP_OK;
}

int
prp_discovery_bloom_microshard_maybe_contains(
    const prp_discovery_bloom_microshard_response_t *response,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len, int *maybe_contains)
{
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT];
    size_t i;
    int rc;

    if (response == NULL || response->microshards == NULL ||
        maybe_contains == NULL)
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_bloom_v4_indexes(response->lookup_index_profile,
        target_kind, identifier_profile, identifier, identifier_len,
        response->filter_bit_order, indexes);
    if (rc != PRP_OK)
        return rc;
    *maybe_contains = 1;
    for (i = 0u; i < PRP_DISCOVERY_BLOOM_HASH_COUNT; i++) {
        uint64_t microshard = indexes[i] /
            (PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES * 8u);
        uint64_t bit = indexes[i] %
            (PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES * 8u);
        size_t slot;

        for (slot = 0u; slot < PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT; slot++)
            if (response->microshard_indexes[slot] == microshard)
                break;
        if (slot == PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT)
            return PRP_ERR_PROTOCOL;
        if ((response->microshards[
                slot * PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES + (bit >> 3)] &
                (uint8_t)(1u << (bit & 7u))) == 0u) {
            *maybe_contains = 0;
            break;
        }
    }
    return PRP_OK;
}

static int
record_fields_valid(const prp_discovery_bloom_record_t *record,
    prp_discovery_bloom_profile_t *profile)
{
    struct prp_wire_v4_identity_suite_desc identity_suite;

    if (record == NULL || record->origin_strong_id == NULL ||
        prp_wire_v4_identity_suite_get(record->origin_identity_suite,
            &identity_suite) != PRP_WIRE_V4_OK ||
        record->origin_strong_id_len != identity_suite.strong_id_len ||
        record->bitmap == NULL ||
        (record->origin_auth_len != 0u && record->origin_auth == NULL) ||
        prp_discovery_bloom_profile_get(record->profile_id, profile) !=
            PRP_OK ||
        record->bitmap_len != profile->bitmap_bytes ||
        record->created_at >= record->expires_at ||
        record->payload_set_bit_count !=
            prp_discovery_bloom_popcount(record->bitmap,
                record->bitmap_len)) {
        return 0;
    }
    if (record->record_kind == PRP_DISCOVERY_BLOOM_RECORD_SNAPSHOT) {
        return record->update_sequence == 0u;
    }
    if (record->record_kind == PRP_DISCOVERY_BLOOM_RECORD_DELTA) {
        return record->update_sequence != 0u;
    }
    return 0;
}

int
prp_discovery_bloom_record_encode(
    const prp_discovery_bloom_record_t *record, uint8_t *out,
    size_t out_len, size_t *written)
{
    prp_discovery_bloom_profile_t profile;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    size_t needed;

    if (out == NULL || written == NULL ||
        !record_fields_valid(record, &profile)) {
        return PRP_ERR_ARGUMENT;
    }
    needed = PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN + record->bitmap_len +
        record->origin_auth_len;
    if (out_len < needed) {
        return PRP_ERR_OUTPUT_TOO_SMALL;
    }
    if (prp_hash_blake3(record->bitmap, record->bitmap_len, digest) != 0) {
        return PRP_ERR_CRYPTO;
    }
    memset(out, 0, PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN);
    memcpy(out, "PRDB", 4);
    out[4] = PRP_DISCOVERY_BLOOM_VERSION;
    out[5] = record->record_kind;
    out[8] = record->profile_id;
    write_u16(out + 9, record->origin_identity_suite);
    out[11] = record->origin_strong_id_len;
    write_u64(out + 12, record->generation);
    write_u64(out + 20, record->update_sequence);
    write_u64(out + 28, record->created_at);
    write_u64(out + 36, record->expires_at);
    write_u64(out + 44, record->participant_count);
    write_u32(out + 52, record->payload_set_bit_count);
    write_u32(out + 56, record->bitmap_len);
    write_u16(out + 60, record->origin_auth_len);
    memcpy(out + 64, record->origin_strong_id,
        record->origin_strong_id_len);
    memcpy(out + 128, digest, sizeof(digest));
    memcpy(out + PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN, record->bitmap,
        record->bitmap_len);
    if (record->origin_auth_len != 0u) {
        memcpy(out + PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN +
            record->bitmap_len, record->origin_auth,
            record->origin_auth_len);
    }
    *written = needed;
    return PRP_OK;
}

int
prp_discovery_bloom_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_bloom_record_t *record)
{
    struct prp_wire_v4_identity_suite_desc identity_suite;
    prp_discovery_bloom_profile_t profile;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    size_t needed;

    if (data == NULL || record == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (data_len < PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN) {
        return PRP_ERR_SHORT;
    }
    if (memcmp(data, "PRDB", 4) != 0) {
        return PRP_ERR_MARKER;
    }
    if (data[4] != PRP_DISCOVERY_BLOOM_VERSION) {
        return PRP_ERR_VERSION;
    }
    if (read_u16(data + 6) != 0u ||
        read_u16(data + 62) != 0u) {
        return PRP_ERR_PROTOCOL;
    }
    memset(record, 0, sizeof(*record));
    record->record_kind = data[5];
    record->profile_id = data[8];
    record->origin_identity_suite = read_u16(data + 9);
    record->origin_strong_id_len = data[11];
    record->generation = read_u64(data + 12);
    record->update_sequence = read_u64(data + 20);
    record->created_at = read_u64(data + 28);
    record->expires_at = read_u64(data + 36);
    record->participant_count = read_u64(data + 44);
    record->payload_set_bit_count = read_u32(data + 52);
    record->bitmap_len = read_u32(data + 56);
    record->origin_auth_len = read_u16(data + 60);
    needed = PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN + record->bitmap_len +
        record->origin_auth_len;
    if (needed > data_len) {
        return PRP_ERR_SHORT;
    }
    if (needed != data_len ||
        prp_wire_v4_identity_suite_get(record->origin_identity_suite,
            &identity_suite) != PRP_WIRE_V4_OK ||
        record->origin_strong_id_len != identity_suite.strong_id_len ||
        prp_discovery_bloom_profile_get(record->profile_id, &profile) !=
            PRP_OK ||
        record->bitmap_len != profile.bitmap_bytes) {
        return PRP_ERR_PROTOCOL;
    }
    record->origin_strong_id = data + 64;
    record->bitmap = data + PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN;
    record->origin_auth = record->bitmap + record->bitmap_len;
    record->authenticated_len = PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN +
        record->bitmap_len;
    if (prp_hash_blake3(record->bitmap, record->bitmap_len, digest) != 0) {
        return PRP_ERR_CRYPTO;
    }
    if (memcmp(digest, data + 128, sizeof(digest)) != 0 ||
        !record_fields_valid(record, &profile)) {
        return PRP_ERR_PROTOCOL;
    }
    return PRP_OK;
}

int
prp_discovery_bloom_forward_encode(
    const prp_discovery_bloom_forward_t *forward, uint8_t *out,
    size_t out_len, size_t *written)
{
    struct prp_wire_v4_identity_suite_desc identity_suite;
    prp_discovery_bloom_record_t origin;
    size_t needed;
    int rc;

    if (forward == NULL || out == NULL || written == NULL ||
        forward->forwarder_strong_id == NULL ||
        prp_wire_v4_identity_suite_get(forward->forwarder_identity_suite,
            &identity_suite) != PRP_WIRE_V4_OK ||
        forward->forwarder_strong_id_len != identity_suite.strong_id_len ||
        forward->origin_record == NULL ||
        (forward->forwarder_auth_len != 0u &&
            forward->forwarder_auth == NULL) ||
        forward->forwarded_at >= forward->expires_at) {
        return PRP_ERR_ARGUMENT;
    }
    rc = prp_discovery_bloom_record_decode(forward->origin_record,
        forward->origin_record_len, &origin);
    if (rc != PRP_OK) {
        return rc;
    }
    if (forward->expires_at > origin.expires_at) {
        return PRP_ERR_PROTOCOL;
    }
    needed = PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN +
        forward->origin_record_len + forward->forwarder_auth_len;
    if (out_len < needed) {
        return PRP_ERR_OUTPUT_TOO_SMALL;
    }
    memset(out, 0, PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN);
    memcpy(out, "PRDF", 4);
    out[4] = PRP_DISCOVERY_BLOOM_VERSION;
    write_u16(out + 5, forward->forwarder_identity_suite);
    out[7] = forward->forwarder_strong_id_len;
    write_u64(out + 8, forward->forwarded_at);
    write_u64(out + 16, forward->expires_at);
    write_u32(out + 24, forward->origin_record_len);
    write_u16(out + 28, forward->forwarder_auth_len);
    memcpy(out + 32, forward->forwarder_strong_id,
        forward->forwarder_strong_id_len);
    memcpy(out + PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN,
        forward->origin_record, forward->origin_record_len);
    if (forward->forwarder_auth_len != 0u) {
        memcpy(out + PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN +
            forward->origin_record_len, forward->forwarder_auth,
            forward->forwarder_auth_len);
    }
    *written = needed;
    return PRP_OK;
}

int
prp_discovery_bloom_forward_decode(const uint8_t *data, size_t data_len,
    prp_discovery_bloom_forward_t *forward)
{
    struct prp_wire_v4_identity_suite_desc identity_suite;
    size_t needed;
    int rc;

    if (data == NULL || forward == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (data_len < PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN) {
        return PRP_ERR_SHORT;
    }
    if (memcmp(data, "PRDF", 4) != 0) {
        return PRP_ERR_MARKER;
    }
    if (data[4] != PRP_DISCOVERY_BLOOM_VERSION) {
        return PRP_ERR_VERSION;
    }
    if (read_u16(data + 30) != 0u) {
        return PRP_ERR_PROTOCOL;
    }
    memset(forward, 0, sizeof(*forward));
    forward->forwarder_identity_suite = read_u16(data + 5);
    forward->forwarder_strong_id_len = data[7];
    forward->forwarded_at = read_u64(data + 8);
    forward->expires_at = read_u64(data + 16);
    forward->origin_record_len = read_u32(data + 24);
    forward->forwarder_auth_len = read_u16(data + 28);
    needed = PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN +
        forward->origin_record_len + forward->forwarder_auth_len;
    if (needed > data_len) {
        return PRP_ERR_SHORT;
    }
    if (needed != data_len ||
        prp_wire_v4_identity_suite_get(forward->forwarder_identity_suite,
            &identity_suite) != PRP_WIRE_V4_OK ||
        forward->forwarder_strong_id_len != identity_suite.strong_id_len ||
        forward->forwarded_at >= forward->expires_at) {
        return PRP_ERR_PROTOCOL;
    }
    forward->forwarder_strong_id = data + 32;
    forward->origin_record = data + PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN;
    forward->forwarder_auth = forward->origin_record +
        forward->origin_record_len;
    forward->authenticated_len = PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN +
        forward->origin_record_len;
    rc = prp_discovery_bloom_record_decode(forward->origin_record,
        forward->origin_record_len, &forward->decoded_origin);
    if (rc != PRP_OK) {
        return rc;
    }
    if (forward->expires_at > forward->decoded_origin.expires_at) {
        return PRP_ERR_PROTOCOL;
    }
    return PRP_OK;
}

static int
timing_header_decode(const uint8_t *data, size_t data_len, uint8_t kind)
{
    if (data == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (data_len < PRP_DISCOVERY_TIMING_RECORD_LEN) {
        return PRP_ERR_SHORT;
    }
    if (data_len != PRP_DISCOVERY_TIMING_RECORD_LEN ||
        memcmp(data, "PRDT", 4) != 0) {
        return PRP_ERR_MARKER;
    }
    if (data[4] != PRP_DISCOVERY_TIMING_VERSION) {
        return PRP_ERR_VERSION;
    }
    if (data[5] != kind || read_u16(data + 6) !=
            PRP_DISCOVERY_TIMING_RECORD_LEN) {
        return PRP_ERR_PROTOCOL;
    }
    return PRP_OK;
}

int
prp_discovery_timing_offer_encode(
    const prp_discovery_timing_offer_t *offer, uint8_t *out,
    size_t out_len, size_t *written)
{
    if (offer == NULL || out == NULL || written == NULL ||
        offer->minimum_update_interval_ms == 0u ||
        offer->minimum_update_interval_ms >
            offer->maximum_update_interval_ms ||
        offer->minimum_snapshot_interval_ms == 0u ||
        offer->minimum_snapshot_interval_ms >
            offer->maximum_snapshot_interval_ms ||
        offer->maximum_acceptable_age_ms == 0u) {
        return PRP_ERR_ARGUMENT;
    }
    if (out_len < PRP_DISCOVERY_TIMING_RECORD_LEN) {
        return PRP_ERR_OUTPUT_TOO_SMALL;
    }
    memset(out, 0, PRP_DISCOVERY_TIMING_RECORD_LEN);
    memcpy(out, "PRDT", 4);
    out[4] = PRP_DISCOVERY_TIMING_VERSION;
    out[5] = PRP_DISCOVERY_TIMING_OFFER;
    write_u16(out + 6, PRP_DISCOVERY_TIMING_RECORD_LEN);
    write_u64(out + 8, offer->minimum_update_interval_ms);
    write_u64(out + 16, offer->maximum_update_interval_ms);
    write_u64(out + 24, offer->minimum_snapshot_interval_ms);
    write_u64(out + 32, offer->maximum_snapshot_interval_ms);
    write_u64(out + 40, offer->maximum_acceptable_age_ms);
    write_u64(out + 48, offer->maximum_jitter_ms);
    write_u32(out + 56, offer->maximum_buffered_deltas);
    *written = PRP_DISCOVERY_TIMING_RECORD_LEN;
    return PRP_OK;
}

int
prp_discovery_timing_offer_decode(const uint8_t *data, size_t data_len,
    prp_discovery_timing_offer_t *offer)
{
    int rc;

    if (offer == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    rc = timing_header_decode(data, data_len, PRP_DISCOVERY_TIMING_OFFER);
    if (rc != PRP_OK) {
        return rc;
    }
    if (read_u32(data + 60) != 0u) {
        return PRP_ERR_PROTOCOL;
    }
    memset(offer, 0, sizeof(*offer));
    offer->minimum_update_interval_ms = read_u64(data + 8);
    offer->maximum_update_interval_ms = read_u64(data + 16);
    offer->minimum_snapshot_interval_ms = read_u64(data + 24);
    offer->maximum_snapshot_interval_ms = read_u64(data + 32);
    offer->maximum_acceptable_age_ms = read_u64(data + 40);
    offer->maximum_jitter_ms = read_u64(data + 48);
    offer->maximum_buffered_deltas = read_u32(data + 56);
    if (offer->minimum_update_interval_ms == 0u ||
        offer->minimum_update_interval_ms >
            offer->maximum_update_interval_ms ||
        offer->minimum_snapshot_interval_ms == 0u ||
        offer->minimum_snapshot_interval_ms >
            offer->maximum_snapshot_interval_ms ||
        offer->maximum_acceptable_age_ms == 0u) {
        return PRP_ERR_PROTOCOL;
    }
    return PRP_OK;
}

int
prp_discovery_timing_agreement_encode(
    const prp_discovery_timing_agreement_t *agreement, uint8_t *out,
    size_t out_len, size_t *written)
{
    if (agreement == NULL || out == NULL || written == NULL ||
        agreement->update_interval_ms == 0u ||
        agreement->snapshot_interval_ms == 0u ||
        agreement->maximum_acceptable_age_ms == 0u) {
        return PRP_ERR_ARGUMENT;
    }
    if (out_len < PRP_DISCOVERY_TIMING_RECORD_LEN) {
        return PRP_ERR_OUTPUT_TOO_SMALL;
    }
    memset(out, 0, PRP_DISCOVERY_TIMING_RECORD_LEN);
    memcpy(out, "PRDT", 4);
    out[4] = PRP_DISCOVERY_TIMING_VERSION;
    out[5] = PRP_DISCOVERY_TIMING_AGREEMENT;
    write_u16(out + 6, PRP_DISCOVERY_TIMING_RECORD_LEN);
    write_u64(out + 8, agreement->update_interval_ms);
    write_u64(out + 16, agreement->snapshot_interval_ms);
    write_u64(out + 24, agreement->maximum_acceptable_age_ms);
    write_u64(out + 32, agreement->jitter_ms);
    write_u32(out + 40, agreement->maximum_buffered_deltas);
    *written = PRP_DISCOVERY_TIMING_RECORD_LEN;
    return PRP_OK;
}

int
prp_discovery_timing_agreement_decode(const uint8_t *data, size_t data_len,
    prp_discovery_timing_agreement_t *agreement)
{
    size_t i;
    int rc;

    if (agreement == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    rc = timing_header_decode(data, data_len,
        PRP_DISCOVERY_TIMING_AGREEMENT);
    if (rc != PRP_OK) {
        return rc;
    }
    for (i = 44u; i < PRP_DISCOVERY_TIMING_RECORD_LEN; i++) {
        if (data[i] != 0u) {
            return PRP_ERR_PROTOCOL;
        }
    }
    memset(agreement, 0, sizeof(*agreement));
    agreement->update_interval_ms = read_u64(data + 8);
    agreement->snapshot_interval_ms = read_u64(data + 16);
    agreement->maximum_acceptable_age_ms = read_u64(data + 24);
    agreement->jitter_ms = read_u64(data + 32);
    agreement->maximum_buffered_deltas = read_u32(data + 40);
    if (agreement->update_interval_ms == 0u ||
        agreement->snapshot_interval_ms == 0u ||
        agreement->maximum_acceptable_age_ms == 0u) {
        return PRP_ERR_PROTOCOL;
    }
    return PRP_OK;
}
