#include "prp_ed25519_blake3.h"

#include "prp_crypto_backend.h"
#include "prp_hash.h"

#include <monocypher-ed25519.h>
#include <monocypher.h>
#include <prp/wire_v4_crypto.h>

#include <stdlib.h>
#include <string.h>

struct prp_ed25519_blake3_keypair_s {
    uint8_t public_key[PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN];
    uint8_t private_key[PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN];
};

static prp_status_t keypair_create(prp_ed25519_blake3_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519_BLAKE3_SEED_LEN])
{
    prp_ed25519_blake3_keypair_t *created;
    uint8_t mutable_seed[PRP_ED25519_BLAKE3_SEED_LEN];

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (seed == NULL)
        return PRP_ERR_ARGUMENT;
    created = calloc(1U, sizeof(*created));
    if (created == NULL)
        return PRP_ERR_NO_MEMORY;
    memcpy(mutable_seed, seed, sizeof(mutable_seed));
    crypto_ed25519_key_pair(created->private_key, created->public_key,
        mutable_seed);
    prp_crypto_secure_zero(mutable_seed, sizeof(mutable_seed));
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_ed25519_blake3_keypair_from_seed(
    prp_ed25519_blake3_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519_BLAKE3_SEED_LEN])
{
    return keypair_create(keypair, seed);
}

prp_status_t prp_ed25519_blake3_keypair_generate(
    prp_ed25519_blake3_keypair_t **keypair)
{
    uint8_t seed[PRP_ED25519_BLAKE3_SEED_LEN];
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        prp_crypto_secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    result = keypair_create(keypair, seed);
    prp_crypto_secure_zero(seed, sizeof(seed));
    return result;
}

prp_status_t prp_ed25519_blake3_keypair_import(
    prp_ed25519_blake3_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len)
{
    prp_ed25519_blake3_keypair_t *created = NULL;
    prp_status_t result;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (private_key == NULL ||
            private_key_len != PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN)
        return PRP_ERR_ARGUMENT;
    result = keypair_create(&created, private_key);
    if (result != PRP_OK)
        return result;
    if (crypto_verify32(created->public_key,
            private_key + PRP_ED25519_BLAKE3_SEED_LEN) != 0) {
        prp_ed25519_blake3_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t prp_ed25519_blake3_public_key_export(
    const prp_ed25519_blake3_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(public_key, keypair->public_key,
        PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN);
    *written = PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t prp_ed25519_blake3_private_key_export(
    const prp_ed25519_blake3_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || private_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (private_key_size < PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(private_key, keypair->private_key,
        PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN);
    *written = PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN;
    return PRP_OK;
}

static prp_status_t proof_digest(const uint8_t *hs2_prefix,
    size_t hs2_prefix_len, uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN])
{
    if (hs2_prefix == NULL || hs2_prefix_len == 0U || digest == NULL)
        return PRP_ERR_ARGUMENT;
    return prp_hash_blake3_concat(
        (const uint8_t *)PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN,
        PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN_LEN, hs2_prefix, hs2_prefix_len,
        digest) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t prp_ed25519_blake3_sign(
    const prp_ed25519_blake3_keypair_t *keypair,
    const uint8_t *hs2_prefix, size_t hs2_prefix_len, uint8_t *signature,
    size_t signature_size, size_t *written)
{
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    prp_status_t result;

    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || signature == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_ED25519_BLAKE3_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = proof_digest(hs2_prefix, hs2_prefix_len, digest);
    if (result == PRP_OK) {
        crypto_ed25519_sign(signature, keypair->private_key, digest,
            sizeof(digest));
        *written = PRP_ED25519_BLAKE3_SIGNATURE_LEN;
    }
    prp_crypto_secure_zero(digest, sizeof(digest));
    return result;
}

prp_status_t prp_ed25519_blake3_verify(
    const uint8_t public_key[PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519_BLAKE3_SIGNATURE_LEN],
    const uint8_t *hs2_prefix, size_t hs2_prefix_len)
{
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    prp_status_t result;

    if (public_key == NULL || signature == NULL)
        return PRP_ERR_ARGUMENT;
    result = proof_digest(hs2_prefix, hs2_prefix_len, digest);
    if (result == PRP_OK && prp_identity_proof_verify(
            PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3, public_key,
            PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN, signature,
            PRP_ED25519_BLAKE3_SIGNATURE_LEN, digest, sizeof(digest), NULL,
            0U) != 0)
        result = PRP_ERR_CRYPTO;
    prp_crypto_secure_zero(digest, sizeof(digest));
    return result;
}

prp_status_t prp_ed25519_blake3_discovery_sign(
    const prp_ed25519_blake3_keypair_t *keypair,
    const uint8_t *canonical_preimage, size_t canonical_preimage_len,
    uint8_t *signature, size_t signature_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || canonical_preimage == NULL ||
            canonical_preimage_len == 0U || signature == NULL ||
            written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_ED25519_BLAKE3_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    crypto_ed25519_sign(signature, keypair->private_key, canonical_preimage,
        canonical_preimage_len);
    *written = PRP_ED25519_BLAKE3_SIGNATURE_LEN;
    return PRP_OK;
}

prp_status_t prp_ed25519_blake3_discovery_verify(
    const uint8_t public_key[PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519_BLAKE3_SIGNATURE_LEN],
    const uint8_t *canonical_preimage, size_t canonical_preimage_len)
{
    if (public_key == NULL || signature == NULL ||
            canonical_preimage == NULL || canonical_preimage_len == 0U)
        return PRP_ERR_ARGUMENT;
    return prp_identity_proof_verify(PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3,
        public_key, PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN, signature,
        PRP_ED25519_BLAKE3_SIGNATURE_LEN, canonical_preimage,
        canonical_preimage_len, NULL, 0U) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

void prp_ed25519_blake3_keypair_destroy(
    prp_ed25519_blake3_keypair_t *keypair)
{
    if (keypair != NULL) {
        prp_crypto_secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}
