#ifndef PRP_APP_V1_STATE_INTERNAL_H
#define PRP_APP_V1_STATE_INTERNAL_H
/* PRIVATE engine. Only a verified, fresh, session-owning transport may drive
 * this engine. Its outputs are NOT consumer application capabilities. */
#include "prp_application_agreement_v1.h"
#define PRP_APP_STATE_SLOTS 64u
#define PRP_APP_STATE_ATTEMPTS 4096u
enum prp_app_phase { APP_EMPTY, APP_OFFER, APP_RECEIVED, APP_ACCEPT,
    APP_CONFIRM, APP_ACTIVE, APP_DEAD };
struct prp_app_attempt {
    uint64_t id, deadline, expires;
    uint8_t role, phase, sent_kind, duplicates;
    uint8_t offer[125], accept[113], reply[113];
    size_t offer_len, reply_len;
    uint16_t alias;
    uint32_t generation, tombstone;
};
struct prp_app_state {
    uint8_t context[32], used[8192], role, live;
    uint64_t now, high[2];
    uint32_t attempts[2], generation[2];
    struct prp_app_attempt slots[PRP_APP_STATE_SLOTS];
};
/* trusted calls, deliberately not exported/installed. Negative result never
 * authorizes delivery. A clock regression invalidates the entire session. */
void prp_app_state_init(struct prp_app_state *, const uint8_t context[32], unsigned role);
void prp_app_state_invalidate(struct prp_app_state *);
int prp_app_state_tick(struct prp_app_state *, uint64_t monotonic_ms);
int prp_app_state_offer(struct prp_app_state *, const prp_app_v1_message *, uint64_t,
    uint8_t out[125], size_t *);
int prp_app_state_receive(struct prp_app_state *, const uint8_t *, size_t,
    unsigned authenticated_sender, uint64_t, uint8_t out[113], size_t *);
/* policy must authorize exact immutable offer, not a label. reason!=0 refuses. */
int prp_app_state_decide(struct prp_app_state *, uint64_t attempt, unsigned opener,
    uint16_t alias, uint32_t generation, uint16_t reason, uint64_t,
    uint8_t out[113], size_t *);
int prp_app_state_handed(struct prp_app_state *, uint64_t, unsigned, uint64_t);
int prp_app_state_cancel(struct prp_app_state *, uint64_t, unsigned, uint64_t);
int prp_app_state_close(struct prp_app_state *, uint16_t, uint32_t, uint64_t);
int prp_app_state_admits(struct prp_app_state *, uint16_t, uint32_t, uint64_t);
/* ALL compatibility allocations must enter this ledger before emission/admission.
 * Re-observing the same allocation is the transport owner's job, not reserve. */
int prp_app_state_compatibility_reserve(struct prp_app_state *, uint16_t);
#endif
