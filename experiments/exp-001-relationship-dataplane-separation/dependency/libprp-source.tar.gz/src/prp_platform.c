#include "prp_platform.h"

#include <string.h>

static void completion_init(prp_platform_completion_t *completion)
{
    if (!completion)
        return;
    completion->abi_version = PRP_PLATFORM_ASYNC_ABI_VERSION;
    completion->struct_size = sizeof(*completion);
    completion->token.words[0] = 0;
    completion->token.words[1] = 0;
    completion->status = PRP_OK;
    completion->result_len = 0;
    completion->value = 0;
}

int prp_platform_async_token_valid(const prp_platform_async_token_t *token)
{
    return token && (token->words[0] != 0 || token->words[1] != 0);
}

int prp_platform_validate(
    const prp_platform_t *platform, uint32_t required_capabilities)
{
    if (!platform || (required_capabilities & ~PRP_PLATFORM_CAP_ALL) != 0U)
        return PRP_ERR_ARGUMENT;
    if (platform->abi_version == PRP_PLATFORM_ABI_VERSION_4) {
        if (platform->struct_size != PRP_PLATFORM_ABI_V4_STRUCT_SIZE ||
                (platform->capabilities & ~PRP_PLATFORM_CAP_V4_ALL) != 0U ||
                (required_capabilities & ~PRP_PLATFORM_CAP_V4_ALL) != 0U)
            return PRP_ERR_VERSION;
    } else if (platform->abi_version == PRP_PLATFORM_ABI_VERSION) {
        if (platform->struct_size < PRP_PLATFORM_ABI_V5_STRUCT_SIZE)
            return PRP_ERR_VERSION;
    } else {
        return PRP_ERR_VERSION;
    }
    if ((platform->capabilities & ~PRP_PLATFORM_CAP_ALL) != 0U ||
        (required_capabilities & ~platform->capabilities) != 0U)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_CRYPTO) != 0U &&
        !platform->crypto)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_RANDOM) != 0U &&
        !platform->random)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_CLOCK) != 0U &&
        !platform->monotonic_time)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_TRANSPORT) != 0U &&
        (!platform->transport_send || !platform->transport_receive))
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_STORAGE) != 0U &&
        (!platform->storage_load ||
         (!platform->storage_store && !platform->storage_replace) ||
         !platform->storage_delete))
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_STORAGE_ATOMIC) != 0U &&
        !platform->storage_replace)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_STORAGE_DURABLE) != 0U &&
        !platform->storage_flush)
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_ASYNC) != 0U &&
        (!platform->async_begin || !platform->async_poll ||
         !platform->async_step || !platform->async_cancel))
        return PRP_ERR_STATE;
    if ((platform->capabilities &
         PRP_PLATFORM_CAP_NONEXPORTABLE_KEYS) != 0U &&
        (platform->abi_version != PRP_PLATFORM_ABI_VERSION_4 ||
         (platform->capabilities & PRP_PLATFORM_CAP_CRYPTO) == 0U ||
         (platform->capabilities & PRP_PLATFORM_CAP_ASYNC) == 0U))
        return PRP_ERR_STATE;
    if ((platform->capabilities & PRP_PLATFORM_CAP_KEY_CUSTODY) != 0U &&
        (platform->abi_version != PRP_PLATFORM_ABI_VERSION ||
         !platform->custody_query || !platform->custody_execute))
        return PRP_ERR_STATE;
    return PRP_OK;
}

static uint32_t operation_capability(prp_platform_operation_t operation)
{
    switch (operation) {
    case PRP_PLATFORM_OP_CRYPTO: return PRP_PLATFORM_CAP_CRYPTO;
    case PRP_PLATFORM_OP_RANDOM: return PRP_PLATFORM_CAP_RANDOM;
    case PRP_PLATFORM_OP_MONOTONIC_TIME: return PRP_PLATFORM_CAP_CLOCK;
    case PRP_PLATFORM_OP_TRANSPORT_SEND:
    case PRP_PLATFORM_OP_TRANSPORT_RECEIVE:
        return PRP_PLATFORM_CAP_TRANSPORT;
    case PRP_PLATFORM_OP_STORAGE_LOAD:
    case PRP_PLATFORM_OP_STORAGE_DELETE:
        return PRP_PLATFORM_CAP_STORAGE;
    case PRP_PLATFORM_OP_STORAGE_REPLACE:
        return PRP_PLATFORM_CAP_STORAGE | PRP_PLATFORM_CAP_STORAGE_ATOMIC;
    case PRP_PLATFORM_OP_STORAGE_FLUSH:
        return PRP_PLATFORM_CAP_STORAGE | PRP_PLATFORM_CAP_STORAGE_DURABLE;
    default:
        return 0;
    }
}

static prp_platform_custody_operation_t custody_operation_for_crypto(
    prp_crypto_operation_t operation)
{
    switch (operation) {
    case PRP_CRYPTO_OP_SIGN:
        return PRP_CUSTODY_OP_SIGN;
    case PRP_CRYPTO_OP_KEM_DECAPSULATE:
        return PRP_CUSTODY_OP_DECAPSULATE;
    case PRP_CRYPTO_OP_KEY_AGREEMENT:
        return PRP_CUSTODY_OP_KEY_AGREEMENT;
    default:
        return 0;
    }
}

int prp_platform_request_validate(
    const prp_platform_t *platform, const prp_platform_request_t *request)
{
    uint32_t required;
    int custody_handle;

    if (!platform || !request ||
        request->abi_version != PRP_PLATFORM_ASYNC_ABI_VERSION ||
        request->struct_size != sizeof(*request) ||
        (request->flags & ~PRP_PLATFORM_REQUEST_F_MASK) != 0U)
        return PRP_ERR_ARGUMENT;
    required = operation_capability(request->operation);
    if (!required)
        return PRP_ERR_ARGUMENT;
    if (prp_platform_validate(platform, required) != PRP_OK)
        return PRP_ERR_STATE;
    custody_handle = (request->flags &
        PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE) != 0U;
    if (custody_handle &&
            ((request->flags &
              PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY) != 0U ||
             platform->abi_version != PRP_PLATFORM_ABI_VERSION ||
             (platform->capabilities & PRP_PLATFORM_CAP_KEY_CUSTODY) == 0U ||
             request->operation != PRP_PLATFORM_OP_CRYPTO ||
             request->key_handle == 0U || request->key || request->key_len ||
             !custody_operation_for_crypto(request->crypto_operation)))
        return PRP_ERR_STATE;
    if ((request->flags & PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY) != 0U &&
         (platform->abi_version != PRP_PLATFORM_ABI_VERSION_4 ||
          (platform->capabilities &
          PRP_PLATFORM_CAP_NONEXPORTABLE_KEYS) == 0U ||
         request->operation != PRP_PLATFORM_OP_CRYPTO ||
         request->key_handle == 0U || request->key || request->key_len))
        return PRP_ERR_STATE;
    if ((request->flags & (PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY |
            PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE)) == 0U &&
        request->key_handle != 0U)
        return PRP_ERR_ARGUMENT;
    if (!!request->key != !!request->key_len)
        return PRP_ERR_ARGUMENT;
    switch (request->operation) {
    case PRP_PLATFORM_OP_CRYPTO:
        if (!request->negotiated_suite || !request->crypto_operation ||
            (!request->input && request->input_len) ||
            (!request->auxiliary && request->auxiliary_len) ||
            (!request->nonce && request->nonce_len) ||
            (!request->associated_data && request->associated_data_len) ||
            (!request->output && request->output_capacity) ||
            (!request->secondary_output &&
             request->secondary_output_capacity))
            return PRP_ERR_ARGUMENT;
        switch (request->crypto_operation) {
        case PRP_CRYPTO_OP_HASH:
            if (!request->input || !request->input_len ||
                !request->output || !request->output_capacity ||
                request->key || request->key_len || request->key_handle ||
                request->algorithm_profile || request->nonce_len ||
                request->associated_data_len ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_SIGN:
            if (!request->algorithm_profile ||
                !request->input || !request->input_len ||
                !request->output || !request->output_capacity ||
                request->auxiliary_len || request->nonce_len ||
                request->associated_data_len ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_VERIFY:
            if (!request->algorithm_profile ||
                !request->input || !request->input_len ||
                !request->auxiliary || !request->auxiliary_len ||
                request->output_capacity || request->nonce_len ||
                request->associated_data_len ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_KEM_ENCAPSULATE:
            if (request->algorithm_profile ||
                !request->key || !request->key_len || request->key_handle ||
                request->input_len || request->auxiliary_len ||
                request->nonce_len || request->associated_data_len ||
                !request->output || !request->output_capacity ||
                !request->secondary_output ||
                !request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_KEM_DECAPSULATE:
            if (request->algorithm_profile ||
                !request->input || !request->input_len ||
                request->auxiliary_len || request->nonce_len ||
                request->associated_data_len ||
                !request->output || !request->output_capacity ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_AEAD_SEAL:
        case PRP_CRYPTO_OP_AEAD_OPEN:
            if (request->algorithm_profile ||
                !request->input || !request->input_len ||
                !request->nonce || !request->nonce_len ||
                !request->output || !request->output_capacity ||
                request->auxiliary_len ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_KEY_AGREEMENT_KEYPAIR:
        case PRP_CRYPTO_OP_KEM_KEYPAIR:
            if (request->algorithm_profile || request->key ||
                request->key_len || request->key_handle ||
                request->input_len || request->auxiliary_len ||
                request->nonce_len || request->associated_data_len ||
                !request->output || !request->output_capacity ||
                !request->secondary_output ||
                !request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_KEY_AGREEMENT:
            if (request->algorithm_profile ||
                !request->input || !request->input_len ||
                request->auxiliary_len || request->nonce_len ||
                request->associated_data_len ||
                !request->output || !request->output_capacity ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        case PRP_CRYPTO_OP_KDF:
            if (request->algorithm_profile ||
                !request->input || !request->input_len ||
                !request->auxiliary || !request->auxiliary_len ||
                request->nonce_len || request->associated_data_len ||
                !request->output || !request->output_capacity ||
                request->secondary_output_capacity)
                return PRP_ERR_ARGUMENT;
            break;
        default:
            return PRP_ERR_ARGUMENT;
        }
        if (request->crypto_operation != PRP_CRYPTO_OP_HASH &&
            request->crypto_operation !=
                PRP_CRYPTO_OP_KEY_AGREEMENT_KEYPAIR &&
            request->crypto_operation != PRP_CRYPTO_OP_KEM_KEYPAIR &&
            ((request->flags &
              (PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY |
               PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE)) == 0U) &&
            (!request->key || !request->key_len))
            return PRP_ERR_ARGUMENT;
        if (custody_handle) {
            prp_platform_custody_query_t query = {
                PRP_PLATFORM_CUSTODY_ABI_VERSION,
                sizeof(query),
                request->negotiated_suite,
                request->algorithm_profile,
                custody_operation_for_crypto(request->crypto_operation),
                request->crypto_operation == PRP_CRYPTO_OP_SIGN ?
                    PRP_CUSTODY_PURPOSE_SIGN :
                    request->crypto_operation ==
                        PRP_CRYPTO_OP_KEM_DECAPSULATE ?
                    PRP_CUSTODY_PURPOSE_DECAPSULATE :
                    PRP_CUSTODY_PURPOSE_KEY_AGREEMENT,
                0U,
            };
            prp_platform_custody_capabilities_t capabilities;
            int result = prp_platform_custody_query(platform, &query,
                &capabilities);

            if (result != PRP_OK)
                return result;
        }
        break;
    case PRP_PLATFORM_OP_RANDOM:
    case PRP_PLATFORM_OP_TRANSPORT_RECEIVE:
        if (!request->output || !request->output_capacity)
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_PLATFORM_OP_TRANSPORT_SEND:
        if (!request->input || !request->input_len)
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_PLATFORM_OP_STORAGE_LOAD:
        if (!request->key || !request->key_len ||
            !request->output || !request->output_capacity)
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_PLATFORM_OP_STORAGE_REPLACE:
        if (!request->key || !request->key_len ||
            (!request->input && request->input_len))
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_PLATFORM_OP_STORAGE_DELETE:
        if (!request->key || !request->key_len)
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_PLATFORM_OP_MONOTONIC_TIME:
    case PRP_PLATFORM_OP_STORAGE_FLUSH:
        break;
    default:
        return PRP_ERR_ARGUMENT;
    }
    return PRP_OK;
}

static int begin_sync(const prp_platform_t *platform,
    const prp_platform_request_t *request,
    prp_platform_completion_t *completion)
{
    size_t output_len = request->output_capacity;
    size_t secondary_output_len = request->secondary_output_capacity;
    int result;

    switch (request->operation) {
    case PRP_PLATFORM_OP_CRYPTO:
        result = platform->crypto(platform->context, request,
            &output_len, &secondary_output_len);
        break;
    case PRP_PLATFORM_OP_RANDOM:
        result = platform->random(platform->context, request->output,
            request->output_capacity);
        output_len = result == PRP_OK ? request->output_capacity : 0;
        break;
    case PRP_PLATFORM_OP_MONOTONIC_TIME:
        result = platform->monotonic_time(platform->context,
            &completion->value);
        output_len = 0;
        break;
    case PRP_PLATFORM_OP_TRANSPORT_SEND:
        result = platform->transport_send(platform->context, request->input,
            request->input_len);
        output_len = result == PRP_OK ? request->input_len : 0;
        break;
    case PRP_PLATFORM_OP_TRANSPORT_RECEIVE:
        result = platform->transport_receive(platform->context,
            request->output, &output_len);
        break;
    case PRP_PLATFORM_OP_STORAGE_LOAD:
        result = platform->storage_load(platform->context, request->key,
            request->key_len, request->output, &output_len);
        break;
    case PRP_PLATFORM_OP_STORAGE_REPLACE:
        result = platform->storage_replace(platform->context, request->key,
            request->key_len, request->input, request->input_len);
        output_len = 0;
        break;
    case PRP_PLATFORM_OP_STORAGE_DELETE:
        result = platform->storage_delete(platform->context, request->key,
            request->key_len);
        output_len = 0;
        break;
    case PRP_PLATFORM_OP_STORAGE_FLUSH:
        result = platform->storage_flush(platform->context);
        output_len = 0;
        break;
    default:
        return PRP_ERR_ARGUMENT;
    }
    completion->status = result;
    completion->result_len = output_len;
    completion->value = secondary_output_len;
    return result;
}

int prp_platform_begin(const prp_platform_t *platform,
    const prp_platform_request_t *request,
    prp_platform_async_token_t *token,
    prp_platform_completion_t *immediate)
{
    int result;

    if (!token || !immediate)
        return PRP_ERR_ARGUMENT;
    token->words[0] = 0;
    token->words[1] = 0;
    completion_init(immediate);
    result = prp_platform_request_validate(platform, request);
    if (result != PRP_OK)
        return result;
    if ((platform->capabilities & PRP_PLATFORM_CAP_ASYNC) == 0U)
        return begin_sync(platform, request, immediate);
    result = platform->async_begin(platform->context, request, token,
        immediate);
    if (result == PRP_ERR_AGAIN && !prp_platform_async_token_valid(token))
        return PRP_ERR_PROTOCOL;
    if (result == PRP_OK &&
        (immediate->abi_version != PRP_PLATFORM_ASYNC_ABI_VERSION ||
         immediate->struct_size != sizeof(*immediate)))
        return PRP_ERR_PROTOCOL;
    return result;
}

int prp_platform_poll(const prp_platform_t *platform,
    prp_platform_completion_t *completion)
{
    int result;

    if (!platform || !completion ||
        prp_platform_validate(platform, PRP_PLATFORM_CAP_ASYNC) != PRP_OK)
        return PRP_ERR_STATE;
    completion_init(completion);
    result = platform->async_poll(platform->context, completion);
    if (result == PRP_OK &&
        (!prp_platform_async_token_valid(&completion->token) ||
         completion->abi_version != PRP_PLATFORM_ASYNC_ABI_VERSION ||
         completion->struct_size != sizeof(*completion)))
        return PRP_ERR_PROTOCOL;
    return result;
}

int prp_platform_step(const prp_platform_t *platform, uint32_t work_budget,
    uint32_t *work_done)
{
    if (!platform || !work_budget || !work_done ||
        prp_platform_validate(platform, PRP_PLATFORM_CAP_ASYNC) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    *work_done = 0;
    return platform->async_step(platform->context, work_budget, work_done);
}

int prp_platform_cancel(const prp_platform_t *platform,
    const prp_platform_async_token_t *token)
{
    if (!platform || !prp_platform_async_token_valid(token) ||
        prp_platform_validate(platform, PRP_PLATFORM_CAP_ASYNC) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    return platform->async_cancel(platform->context, token);
}

static int custody_operation_valid(prp_platform_custody_operation_t operation)
{
    return operation >= PRP_CUSTODY_OP_CREATE &&
        operation <= PRP_CUSTODY_OP_KEY_AGREEMENT;
}

static int custody_key_id_valid(const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN])
{
    size_t i;

    for (i = 0; i < PRP_PLATFORM_KEY_ID_LEN; i++) {
        if (key_id[i] != 0U)
            return 1;
    }
    return 0;
}

static void custody_capabilities_init(
    prp_platform_custody_capabilities_t *capabilities)
{
    capabilities->abi_version = PRP_PLATFORM_CUSTODY_ABI_VERSION;
    capabilities->struct_size = sizeof(*capabilities);
    capabilities->operations = 0U;
    capabilities->purposes = 0U;
    capabilities->properties = 0U;
    capabilities->max_components = 0U;
}

static int custody_capabilities_validate(
    const prp_platform_custody_query_t *query,
    const prp_platform_custody_capabilities_t *capabilities)
{
    uint32_t operation_bit = PRP_CUSTODY_OPERATION_BIT(query->operation);

    if (capabilities->abi_version != PRP_PLATFORM_CUSTODY_ABI_VERSION ||
            capabilities->struct_size < sizeof(*capabilities) ||
            (capabilities->operations & ~PRP_CUSTODY_OPERATION_MASK) != 0U ||
            (capabilities->purposes & ~PRP_CUSTODY_PURPOSE_MASK) != 0U ||
            (capabilities->properties & ~PRP_CUSTODY_PROPERTY_MASK) != 0U ||
            capabilities->max_components == 0U ||
            capabilities->max_components > 64U)
        return PRP_ERR_PROTOCOL;
    if ((capabilities->operations & operation_bit) == 0U ||
            (query->purpose & ~capabilities->purposes) != 0U ||
            (query->required_properties & ~capabilities->properties) != 0U)
        return PRP_ERR_UNAVAILABLE;
    return PRP_OK;
}

int prp_platform_custody_query(const prp_platform_t *platform,
    const prp_platform_custody_query_t *query,
    prp_platform_custody_capabilities_t *capabilities)
{
    int result;

    if (!query || !capabilities ||
            query->abi_version != PRP_PLATFORM_CUSTODY_ABI_VERSION ||
            query->struct_size < sizeof(*query) ||
            !custody_operation_valid(query->operation) ||
            (query->purpose & ~PRP_CUSTODY_PURPOSE_MASK) != 0U ||
            (query->required_properties & ~PRP_CUSTODY_PROPERTY_MASK) != 0U ||
            (query->required_properties &
             PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) ==
                PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK)
        return PRP_ERR_ARGUMENT;
    result = prp_platform_validate(platform, PRP_PLATFORM_CAP_KEY_CUSTODY);
    if (result != PRP_OK)
        return result;
    custody_capabilities_init(capabilities);
    result = platform->custody_query(platform->context, query, capabilities);
    if (result != PRP_OK)
        return result;
    return custody_capabilities_validate(query, capabilities);
}

static int custody_request_validate(
    const prp_platform_custody_request_t *request,
    uint64_t *required_properties)
{
    int has_key_id;

    if (!request || !required_properties ||
            request->abi_version != PRP_PLATFORM_CUSTODY_ABI_VERSION ||
            request->struct_size < sizeof(*request) ||
            !custody_operation_valid(request->operation) ||
            (request->flags & ~PRP_CUSTODY_REQUEST_F_MASK) != 0U ||
            (request->purpose & ~PRP_CUSTODY_PURPOSE_MASK) != 0U ||
            (request->required_properties &
             ~PRP_CUSTODY_PROPERTY_MASK) != 0U ||
            (request->required_properties &
             PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) ==
                PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK ||
            (request->flags != 0U && request->operation !=
             PRP_CUSTODY_OP_PRIVATE_EXPORT) ||
            (!!request->input != !!request->input_len) ||
            (!request->public_output && request->public_output_capacity) ||
            (!request->output && request->output_capacity) ||
            (!request->components && request->component_capacity))
        return PRP_ERR_ARGUMENT;

    has_key_id = custody_key_id_valid(request->key_id);
    *required_properties = request->required_properties;
    switch (request->operation) {
    case PRP_CUSTODY_OP_CREATE:
    case PRP_CUSTODY_OP_IMPORT:
        if (!has_key_id || request->key_handle != 0U ||
                !request->negotiated_suite || !request->purpose ||
                (request->operation == PRP_CUSTODY_OP_CREATE &&
                 request->input_len != 0U) ||
                (request->operation == PRP_CUSTODY_OP_IMPORT &&
                 request->input_len == 0U) ||
                request->output_capacity != 0U)
            return PRP_ERR_ARGUMENT;
        *required_properties |= PRP_CUSTODY_PROPERTY_ATOMIC_DURABLE;
        break;
    case PRP_CUSTODY_OP_OPEN:
        if (!has_key_id || request->key_handle != 0U ||
                request->input_len != 0U ||
                request->output_capacity != 0U)
            return PRP_ERR_ARGUMENT;
        break;
    case PRP_CUSTODY_OP_DELETE:
        if (!has_key_id || request->key_handle != 0U ||
                request->input_len != 0U ||
                request->public_output_capacity != 0U ||
                request->output_capacity != 0U ||
                request->component_capacity != 0U)
            return PRP_ERR_ARGUMENT;
        *required_properties |= PRP_CUSTODY_PROPERTY_ATOMIC_DURABLE;
        break;
    case PRP_CUSTODY_OP_CLOSE:
    case PRP_CUSTODY_OP_INFO:
    case PRP_CUSTODY_OP_PUBLIC_EXPORT:
    case PRP_CUSTODY_OP_PRIVATE_EXPORT:
        if (has_key_id || request->key_handle == 0U ||
                request->input_len != 0U)
            return PRP_ERR_ARGUMENT;
        if (request->operation == PRP_CUSTODY_OP_PRIVATE_EXPORT) {
            if ((request->flags &
                 PRP_CUSTODY_REQUEST_F_AUTHORIZE_PRIVATE_EXPORT) == 0U)
                return PRP_ERR_POLICY;
            *required_properties |=
                PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE;
        } else if (request->flags != 0U) {
            return PRP_ERR_ARGUMENT;
        }
        if ((request->operation == PRP_CUSTODY_OP_CLOSE &&
             (request->public_output_capacity != 0U ||
              request->output_capacity != 0U)) ||
            (request->operation == PRP_CUSTODY_OP_INFO &&
             request->output_capacity != 0U) ||
            ((request->operation == PRP_CUSTODY_OP_PUBLIC_EXPORT ||
              request->operation == PRP_CUSTODY_OP_PRIVATE_EXPORT) &&
             request->public_output_capacity != 0U))
            return PRP_ERR_ARGUMENT;
        break;
    default:
        return PRP_ERR_ARGUMENT;
    }
    return PRP_OK;
}

static void custody_result_init(prp_platform_custody_result_t *result)
{
    result->abi_version = PRP_PLATFORM_CUSTODY_ABI_VERSION;
    result->struct_size = sizeof(*result);
    {
        size_t i;

        for (i = 0; i < PRP_PLATFORM_KEY_ID_LEN; i++)
            result->key_id[i] = 0U;
    }
    result->negotiated_suite = 0U;
    result->algorithm_profile = 0U;
    result->purpose = 0U;
    result->key_handle = 0U;
    result->actual_properties = 0U;
    result->generation = 0U;
    result->component_count = 0U;
    result->public_output_len = 0U;
    result->output_len = 0U;
}

static int custody_result_validate(
    const prp_platform_custody_request_t *request,
    const prp_platform_custody_result_t *result,
    const prp_platform_custody_capabilities_t *capabilities,
    uint64_t required_properties,
    int provider_status)
{
    uint64_t component_properties = PRP_CUSTODY_PROPERTY_MASK;
    uint32_t component_purposes = 0U;
    size_t i;
    int returns_metadata;

    if (result->abi_version != PRP_PLATFORM_CUSTODY_ABI_VERSION ||
            result->struct_size < sizeof(*result) ||
            (result->actual_properties & ~PRP_CUSTODY_PROPERTY_MASK) != 0U ||
            (result->actual_properties & ~capabilities->properties) != 0U ||
            (result->purpose & ~PRP_CUSTODY_PURPOSE_MASK) != 0U ||
            (result->purpose & ~capabilities->purposes) != 0U ||
            (required_properties & ~result->actual_properties) != 0U ||
            result->component_count > 64U ||
            result->component_count > capabilities->max_components)
        return PRP_ERR_PROTOCOL;
    returns_metadata = request->operation == PRP_CUSTODY_OP_CREATE ||
        request->operation == PRP_CUSTODY_OP_IMPORT ||
        request->operation == PRP_CUSTODY_OP_OPEN ||
        request->operation == PRP_CUSTODY_OP_INFO;
    if (provider_status == PRP_OK && returns_metadata &&
            (!custody_key_id_valid(result->key_id) ||
             !result->negotiated_suite || !result->purpose ||
             !result->component_count || !request->components ||
             result->component_count > request->component_capacity ||
             ((result->actual_properties &
               PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) !=
                  PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE &&
              (result->actual_properties &
               PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) !=
                  PRP_CUSTODY_PROPERTY_PRIVATE_NONEXPORTABLE)))
        return PRP_ERR_PROTOCOL;
    if (provider_status == PRP_OK &&
            (request->operation == PRP_CUSTODY_OP_CREATE ||
             request->operation == PRP_CUSTODY_OP_IMPORT) &&
            (memcmp(result->key_id, request->key_id,
                PRP_PLATFORM_KEY_ID_LEN) != 0 ||
             result->negotiated_suite != request->negotiated_suite ||
             result->algorithm_profile != request->algorithm_profile ||
             result->purpose != request->purpose))
        return PRP_ERR_PROTOCOL;
    if (provider_status == PRP_OK &&
            request->operation == PRP_CUSTODY_OP_OPEN &&
            memcmp(result->key_id, request->key_id,
                PRP_PLATFORM_KEY_ID_LEN) != 0)
        return PRP_ERR_PROTOCOL;
    if (provider_status == PRP_OK && returns_metadata &&
            request->operation != PRP_CUSTODY_OP_CREATE &&
            request->operation != PRP_CUSTODY_OP_IMPORT &&
            ((request->negotiated_suite != 0U &&
              result->negotiated_suite != request->negotiated_suite) ||
             (request->algorithm_profile != 0U &&
              result->algorithm_profile != request->algorithm_profile) ||
             (request->purpose & ~result->purpose) != 0U))
        return PRP_ERR_PROTOCOL;
    if (provider_status == PRP_OK && returns_metadata) {
        for (i = 0; i < result->component_count; i++) {
            const prp_platform_custody_component_t *component =
                &request->components[i];

            if (component->abi_version !=
                    PRP_PLATFORM_CUSTODY_ABI_VERSION ||
                    component->struct_size < sizeof(*component) ||
                    !component->negotiated_suite || !component->purpose ||
                    (component->purpose & ~PRP_CUSTODY_PURPOSE_MASK) != 0U ||
                    (component->actual_properties &
                     ~PRP_CUSTODY_PROPERTY_MASK) != 0U ||
                    ((component->actual_properties &
                      PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) !=
                         PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE &&
                     (component->actual_properties &
                      PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK) !=
                         PRP_CUSTODY_PROPERTY_PRIVATE_NONEXPORTABLE) ||
                    component->public_key_offset > result->public_output_len ||
                    component->public_key_len > result->public_output_len -
                        component->public_key_offset ||
                    component->purpose == 0U)
                return PRP_ERR_PROTOCOL;
            component_properties &= component->actual_properties;
            component_purposes |= component->purpose;
        }
        if ((result->actual_properties & ~component_properties) != 0U ||
                result->purpose != component_purposes)
            return PRP_ERR_PROTOCOL;
    }
    if (provider_status == PRP_OK &&
            (result->public_output_len > request->public_output_capacity ||
             result->output_len > request->output_capacity))
        return PRP_ERR_PROTOCOL;
    if ((request->operation == PRP_CUSTODY_OP_CREATE ||
         request->operation == PRP_CUSTODY_OP_IMPORT ||
         request->operation == PRP_CUSTODY_OP_OPEN) &&
        provider_status == PRP_OK && result->key_handle == 0U)
        return PRP_ERR_PROTOCOL;
    return provider_status;
}

int prp_platform_custody_execute(const prp_platform_t *platform,
    const prp_platform_custody_request_t *request,
    prp_platform_custody_result_t *result)
{
    prp_platform_custody_query_t query;
    prp_platform_custody_capabilities_t capabilities;
    uint64_t required_properties;
    int status;

    if (!result)
        return PRP_ERR_ARGUMENT;
    status = custody_request_validate(request, &required_properties);
    if (status != PRP_OK)
        return status;
    query.abi_version = PRP_PLATFORM_CUSTODY_ABI_VERSION;
    query.struct_size = sizeof(query);
    query.negotiated_suite = request->negotiated_suite;
    query.algorithm_profile = request->algorithm_profile;
    query.operation = request->operation;
    query.purpose = request->purpose;
    query.required_properties = required_properties;
    status = prp_platform_custody_query(platform, &query, &capabilities);
    if (status != PRP_OK)
        return status;
    custody_result_init(result);
    status = platform->custody_execute(platform->context, request, result);
    if (status != PRP_OK && status != PRP_ERR_OUTPUT_TOO_SMALL)
        return status;
    return custody_result_validate(request, result, &capabilities,
        required_properties, status);
}
