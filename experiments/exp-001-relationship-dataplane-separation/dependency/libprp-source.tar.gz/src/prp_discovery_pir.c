#include "prp_discovery_pir.h"
#include "prp_hash.h"

#include <string.h>

static const uint8_t record_magic[4] = { 'P', 'R', 'P', 'I' };

static uint16_t
read_u16(const uint8_t *data)
{
    return (uint16_t)((uint16_t)data[0] << 8) | data[1];
}

static uint32_t
read_u32(const uint8_t *data)
{
    return ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) | data[3];
}

static uint64_t
read_u64(const uint8_t *data)
{
    uint64_t value = 0u;
    unsigned int i;

    for (i = 0u; i < 8u; i++)
        value = (value << 8) | data[i];
    return value;
}

static void
write_u16(uint8_t *data, uint16_t value)
{
    data[0] = (uint8_t)(value >> 8);
    data[1] = (uint8_t)value;
}

static void
write_u32(uint8_t *data, uint32_t value)
{
    data[0] = (uint8_t)(value >> 24);
    data[1] = (uint8_t)(value >> 16);
    data[2] = (uint8_t)(value >> 8);
    data[3] = (uint8_t)value;
}

static void
write_u64(uint8_t *data, uint64_t value)
{
    unsigned int i;

    for (i = 0u; i < 8u; i++) {
        data[7u - i] = (uint8_t)value;
        value >>= 8;
    }
}

static int
all_zero(const uint8_t *data, size_t len)
{
    uint8_t value = 0u;
    size_t i;

    for (i = 0u; i < len; i++)
        value |= data[i];
    return value == 0u;
}

static int
algorithm_profile_valid(uint16_t algorithm, uint16_t profile)
{
    if (algorithm == PRP_DISCOVERY_QUERY_SPIRAL)
        return profile >= PRP_DISCOVERY_PROFILE_SPIRAL_MIN &&
            profile <= PRP_DISCOVERY_PROFILE_SPIRAL_MAX;
    if (algorithm == PRP_DISCOVERY_QUERY_YPIR)
        return profile >= PRP_DISCOVERY_PROFILE_YPIR_MIN &&
            profile <= PRP_DISCOVERY_PROFILE_YPIR_MAX;
    return 0;
}

static int
record_valid(const prp_discovery_pir_record_t *record)
{
    uint64_t end;

    if (record == NULL ||
        record->kind < PRP_DISCOVERY_PIR_KIND_PARAMETERS ||
        record->kind > PRP_DISCOVERY_PIR_KIND_CANCEL ||
        (record->flags & ~PRP_DISCOVERY_PIR_F_MASK) != 0u ||
        record->relationship_generation == 0u ||
        record->filter_generation == 0u ||
        !algorithm_profile_valid(record->query_algorithm, record->profile) ||
        all_zero(record->filter_commitment,
            PRP_DISCOVERY_PIR_COMMITMENT_LEN) ||
        all_zero(record->operation_id, PRP_DISCOVERY_PIR_OPERATION_ID_LEN))
        return 0;
    if (record->kind == PRP_DISCOVERY_PIR_KIND_CANCEL)
        return record->flags ==
            (PRP_DISCOVERY_PIR_F_START | PRP_DISCOVERY_PIR_F_END) &&
            record->total_object_len == 0u && record->chunk_offset == 0u &&
            record->chunk_len == 0u &&
            all_zero(record->object_commitment,
                PRP_DISCOVERY_PIR_COMMITMENT_LEN);
    if (record->total_object_len == 0u || record->chunk_len == 0u ||
        record->chunk == NULL ||
        all_zero(record->object_commitment,
            PRP_DISCOVERY_PIR_COMMITMENT_LEN) ||
        record->chunk_offset > record->total_object_len ||
        record->chunk_len > record->total_object_len - record->chunk_offset)
        return 0;
    end = record->chunk_offset + record->chunk_len;
    if ((record->flags & PRP_DISCOVERY_PIR_F_START) != 0u ?
        record->chunk_offset != 0u : record->chunk_offset == 0u)
        return 0;
    if ((record->flags & PRP_DISCOVERY_PIR_F_END) != 0u ?
        end != record->total_object_len : end == record->total_object_len)
        return 0;
    return 1;
}

int
prp_discovery_pir_record_encode(const prp_discovery_pir_record_t *record,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t required;

    if (!record_valid(record) || out == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    required = PRP_DISCOVERY_PIR_HEADER_LEN + record->chunk_len;
    if (out_len < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(out, record_magic, sizeof(record_magic));
    out[4] = PRP_DISCOVERY_PIR_VERSION;
    out[5] = record->kind;
    write_u16(out + 6u, record->flags);
    write_u32(out + 8u, record->relationship_generation);
    write_u16(out + 12u, record->query_algorithm);
    write_u16(out + 14u, record->profile);
    write_u64(out + 16u, record->filter_generation);
    memcpy(out + 24u, record->filter_commitment,
        PRP_DISCOVERY_PIR_COMMITMENT_LEN);
    memcpy(out + 56u, record->operation_id,
        PRP_DISCOVERY_PIR_OPERATION_ID_LEN);
    write_u64(out + 72u, record->total_object_len);
    write_u64(out + 80u, record->chunk_offset);
    memcpy(out + 88u, record->object_commitment,
        PRP_DISCOVERY_PIR_COMMITMENT_LEN);
    write_u32(out + 120u, record->chunk_len);
    write_u32(out + 124u, 0u);
    if (record->chunk_len != 0u)
        memcpy(out + PRP_DISCOVERY_PIR_HEADER_LEN, record->chunk,
            record->chunk_len);
    *written = required;
    return PRP_OK;
}

int
prp_discovery_pir_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_pir_record_t *record)
{
    uint32_t chunk_len;

    if (data == NULL || record == NULL ||
        data_len < PRP_DISCOVERY_PIR_HEADER_LEN)
        return PRP_ERR_SHORT;
    if (memcmp(data, record_magic, sizeof(record_magic)) != 0)
        return PRP_ERR_MARKER;
    if (data[4] != PRP_DISCOVERY_PIR_VERSION)
        return PRP_ERR_VERSION;
    if (read_u32(data + 124u) != 0u)
        return PRP_ERR_PROTOCOL;
    chunk_len = read_u32(data + 120u);
    if ((size_t)chunk_len != data_len - PRP_DISCOVERY_PIR_HEADER_LEN)
        return PRP_ERR_PROTOCOL;
    memset(record, 0, sizeof(*record));
    record->kind = data[5];
    record->flags = read_u16(data + 6u);
    record->relationship_generation = read_u32(data + 8u);
    record->query_algorithm = read_u16(data + 12u);
    record->profile = read_u16(data + 14u);
    record->filter_generation = read_u64(data + 16u);
    memcpy(record->filter_commitment, data + 24u,
        PRP_DISCOVERY_PIR_COMMITMENT_LEN);
    memcpy(record->operation_id, data + 56u,
        PRP_DISCOVERY_PIR_OPERATION_ID_LEN);
    record->total_object_len = read_u64(data + 72u);
    record->chunk_offset = read_u64(data + 80u);
    memcpy(record->object_commitment, data + 88u,
        PRP_DISCOVERY_PIR_COMMITMENT_LEN);
    record->chunk = chunk_len == 0u ? NULL :
        data + PRP_DISCOVERY_PIR_HEADER_LEN;
    record->chunk_len = chunk_len;
    return record_valid(record) ? PRP_OK : PRP_ERR_PROTOCOL;
}

int
prp_discovery_pir_object_verify(const prp_discovery_pir_record_t *record,
    const uint8_t *object, size_t object_len)
{
    uint8_t commitment[PRP_DISCOVERY_PIR_COMMITMENT_LEN];
    int rc;

    if (!record_valid(record) ||
        record->kind == PRP_DISCOVERY_PIR_KIND_CANCEL ||
        object == NULL || record->total_object_len != object_len)
        return PRP_ERR_ARGUMENT;
    rc = prp_hash_blake3(object, object_len, commitment);
    if (rc != PRP_OK)
        return rc;
    return memcmp(commitment, record->object_commitment,
        sizeof(commitment)) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

int
prp_discovery_pir_profile_registered(uint16_t query_algorithm,
    uint16_t profile)
{
    if (!algorithm_profile_valid(query_algorithm, profile))
        return PRP_ERR_ARGUMENT;
    return PRP_ERR_NOT_FOUND;
}

int
prp_discovery_pir_provider_validate(
    const prp_discovery_pir_provider_t *provider)
{
    if (provider == NULL ||
        provider->abi_version != PRP_DISCOVERY_PIR_PROVIDER_ABI_VERSION ||
        provider->struct_size != sizeof(*provider) ||
        provider->profile_get == NULL || provider->begin == NULL ||
        provider->poll == NULL || provider->step == NULL ||
        provider->cancel == NULL)
        return PRP_ERR_ARGUMENT;
    return PRP_OK;
}

int
prp_discovery_pir_profile_available(
    const prp_discovery_pir_provider_t *provider, uint16_t query_algorithm,
    uint16_t profile, prp_discovery_pir_profile_info_t *info)
{
    int rc;

    if (info == NULL)
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_pir_profile_registered(query_algorithm, profile);
    if (rc != PRP_OK)
        return rc;
    rc = prp_discovery_pir_provider_validate(provider);
    if (rc != PRP_OK)
        return rc;
    memset(info, 0, sizeof(*info));
    rc = provider->profile_get(provider->context, query_algorithm, profile,
        info);
    if (rc != PRP_OK)
        return rc;
    return info->query_algorithm == query_algorithm &&
        info->profile == profile ? PRP_OK : PRP_ERR_PROTOCOL;
}
