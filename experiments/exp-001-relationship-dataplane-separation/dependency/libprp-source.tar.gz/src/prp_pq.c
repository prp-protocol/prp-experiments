#include "prp_pq.h"
#include "prp_crypto_backend.h"
#include "prp_memory.h"
#include "prp_pq_internal.h"

#include <mlkem_native.h>
#include <mldsa_native.h>
#include <prp/wire_v4_crypto.h>

#include <stdlib.h>
#include <string.h>

extern int prp_thirdparty_mlkem1024_keypair_derand(
    unsigned char *public_key, unsigned char *private_key,
    const unsigned char *seed);
extern int prp_thirdparty_mlkem1024_enc_derand(
    unsigned char *ciphertext, unsigned char *shared_secret,
    const unsigned char *public_key, const unsigned char *seed);
extern int prp_thirdparty_mlkem1024_dec(
    unsigned char *shared_secret, const unsigned char *ciphertext,
    const unsigned char *private_key);

struct prp_mldsa87_keypair_s {
    unsigned char public_key[PRP_MLDSA87_PUBLIC_KEY_LEN];
    unsigned char private_key[PRP_MLDSA87_PRIVATE_KEY_LEN];
};

static const unsigned char mldsa87_hs2_prefix[] =
    "\x00\x0d" PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;
static const unsigned char mldsa87_discovery_prefix[] =
    "\x00\x10" "PRP-DISCOVERY-v1";

static void
secure_zero(void *ptr, size_t len)
{
    prp_crypto_secure_zero(ptr, len);
}

prp_status_t
prp_mlkem768_keypair_derand(
    unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN],
    const unsigned char seed[PRP_MLKEM768_KEYPAIR_SEED_LEN])
{
    if (public_key == NULL || private_key == NULL || seed == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem_keypair_derand(public_key, private_key,
        seed) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t
prp_mlkem768_keypair_generate(
    unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN])
{
    unsigned char seed[PRP_MLKEM768_KEYPAIR_SEED_LEN];
    int rc;

    if (public_key == NULL || private_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = prp_mlkem768_keypair_derand(public_key, private_key, seed);
    secure_zero(seed, sizeof(seed));
    return rc;
}

prp_status_t
prp_mlkem768_encapsulate_derand(
    unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    const unsigned char seed[PRP_MLKEM768_ENCAPS_SEED_LEN])
{
    if (ciphertext == NULL || shared_secret == NULL || public_key == NULL ||
        seed == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem_enc_derand(ciphertext, shared_secret,
        public_key, seed) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t
prp_mlkem768_encapsulate(
    unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN])
{
    unsigned char seed[PRP_MLKEM768_ENCAPS_SEED_LEN];
    int rc;

    if (ciphertext == NULL || shared_secret == NULL || public_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = prp_mlkem768_encapsulate_derand(ciphertext, shared_secret,
        public_key, seed);
    secure_zero(seed, sizeof(seed));
    return rc;
}

prp_status_t
prp_mlkem768_decapsulate(
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    const unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN])
{
    if (shared_secret == NULL || ciphertext == NULL || private_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem_dec(shared_secret, ciphertext,
        private_key) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t
prp_mlkem1024_keypair_derand(
    unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN],
    const unsigned char seed[PRP_MLKEM1024_KEYPAIR_SEED_LEN])
{
    if (public_key == NULL || private_key == NULL || seed == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem1024_keypair_derand(public_key, private_key,
        seed) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t
prp_mlkem1024_keypair_generate(
    unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN])
{
    unsigned char seed[PRP_MLKEM1024_KEYPAIR_SEED_LEN];
    int rc;

    if (public_key == NULL || private_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = prp_mlkem1024_keypair_derand(public_key, private_key, seed);
    secure_zero(seed, sizeof(seed));
    return rc;
}

prp_status_t
prp_mlkem1024_encapsulate_derand(
    unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    const unsigned char seed[PRP_MLKEM1024_ENCAPS_SEED_LEN])
{
    if (ciphertext == NULL || shared_secret == NULL || public_key == NULL ||
        seed == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem1024_enc_derand(ciphertext, shared_secret,
        public_key, seed) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

prp_status_t
prp_mlkem1024_encapsulate(
    unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN])
{
    unsigned char seed[PRP_MLKEM1024_ENCAPS_SEED_LEN];
    int rc;

    if (ciphertext == NULL || shared_secret == NULL || public_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = prp_mlkem1024_encapsulate_derand(ciphertext, shared_secret,
        public_key, seed);
    secure_zero(seed, sizeof(seed));
    return rc;
}

prp_status_t
prp_mlkem1024_decapsulate(
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    const unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN])
{
    if (shared_secret == NULL || ciphertext == NULL || private_key == NULL) {
        return PRP_ERR_ARGUMENT;
    }
    return prp_thirdparty_mlkem1024_dec(shared_secret, ciphertext,
        private_key) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

static prp_status_t
mldsa87_allocate(prp_mldsa87_keypair_t **keypair)
{
    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = calloc(1u, sizeof(**keypair));
    return *keypair != NULL ? PRP_OK : PRP_ERR_NO_MEMORY;
}

void
prp_mldsa87_keypair_destroy(prp_mldsa87_keypair_t *keypair)
{
    if (keypair != NULL) {
        secure_zero(keypair, sizeof(*keypair));
        free(keypair);
    }
}

prp_status_t
prp_mldsa87_keypair_from_seed(prp_mldsa87_keypair_t **keypair,
    const unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN])
{
    prp_mldsa87_keypair_t *created;

    if (keypair == NULL || seed == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    {
        prp_status_t result = mldsa87_allocate(&created);
        if (result != PRP_OK)
            return result;
    }
    if (prp_thirdparty_mldsa87_keypair_internal(created->public_key,
            created->private_key, seed) != 0) {
        prp_mldsa87_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t
prp_mldsa87_keypair_derand(prp_mldsa87_keypair_t **keypair,
    const unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN])
{
    return prp_mldsa87_keypair_from_seed(keypair, seed);
}

prp_status_t
prp_mldsa87_keypair_generate(prp_mldsa87_keypair_t **keypair)
{
    unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN];
    int rc;

    if (keypair == NULL)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    if (prp_crypto_random(seed, sizeof(seed)) != PRP_CRYPTO_OK) {
        secure_zero(seed, sizeof(seed));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = prp_mldsa87_keypair_from_seed(keypair, seed);
    secure_zero(seed, sizeof(seed));
    return rc;
}

prp_status_t
prp_mldsa87_keypair_import(prp_mldsa87_keypair_t **keypair,
    const unsigned char *private_key, size_t private_key_len)
{
    prp_mldsa87_keypair_t *created;

    if (keypair == NULL || private_key == NULL ||
            private_key_len != PRP_MLDSA87_PRIVATE_KEY_LEN)
        return PRP_ERR_ARGUMENT;
    *keypair = NULL;
    {
        prp_status_t result = mldsa87_allocate(&created);
        if (result != PRP_OK)
            return result;
    }
    memcpy(created->private_key, private_key, sizeof(created->private_key));
    if (prp_thirdparty_mldsa87_pk_from_sk(created->public_key,
            created->private_key) != 0) {
        prp_mldsa87_keypair_destroy(created);
        return PRP_ERR_CRYPTO;
    }
    *keypair = created;
    return PRP_OK;
}

prp_status_t
prp_mldsa87_public_key_export(const prp_mldsa87_keypair_t *keypair,
    unsigned char *public_key, size_t public_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || public_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (public_key_size < PRP_MLDSA87_PUBLIC_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(public_key, keypair->public_key, PRP_MLDSA87_PUBLIC_KEY_LEN);
    *written = PRP_MLDSA87_PUBLIC_KEY_LEN;
    return PRP_OK;
}

prp_status_t
prp_mldsa87_private_key_export(const prp_mldsa87_keypair_t *keypair,
    unsigned char *private_key, size_t private_key_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || private_key == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    if (private_key_size < PRP_MLDSA87_PRIVATE_KEY_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(private_key, keypair->private_key, PRP_MLDSA87_PRIVATE_KEY_LEN);
    *written = PRP_MLDSA87_PRIVATE_KEY_LEN;
    return PRP_OK;
}

static prp_status_t
mldsa87_sign_derand(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN],
    const unsigned char *prefix, size_t prefix_len, unsigned char *signature,
    size_t signature_size, size_t *written)
{
    if (written != NULL)
        *written = 0U;
    if (keypair == NULL || message == NULL || message_len == 0U ||
            random == NULL || prefix == NULL || signature == NULL ||
            written == NULL)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA87_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_thirdparty_mldsa87_signature_internal(signature, message,
            message_len, prefix, prefix_len, random, keypair->private_key,
            0) != 0) {
        secure_zero(signature, PRP_MLDSA87_SIGNATURE_LEN);
        return PRP_ERR_CRYPTO;
    }
    *written = PRP_MLDSA87_SIGNATURE_LEN;
    return PRP_OK;
}

prp_status_t
prp_mldsa87_sign_derand(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN],
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return mldsa87_sign_derand(keypair, message, message_len, random,
        mldsa87_hs2_prefix, sizeof(mldsa87_hs2_prefix) - 1u, signature,
        signature_size, written);
}

prp_status_t
prp_mldsa87_discovery_sign_derand(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN],
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return mldsa87_sign_derand(keypair, message, message_len, random,
        mldsa87_discovery_prefix, sizeof(mldsa87_discovery_prefix) - 1u,
        signature, signature_size, written);
}

static prp_status_t
mldsa87_sign_randomized(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    unsigned char *signature, size_t signature_size, size_t *written,
    int discovery)
{
    unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN];
    int rc;

    if (keypair == NULL || message == NULL || signature == NULL ||
            written == NULL)
        return PRP_ERR_ARGUMENT;
    if (message_len == 0U)
        return PRP_ERR_ARGUMENT;
    if (signature_size < PRP_MLDSA87_SIGNATURE_LEN)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    if (prp_crypto_random(random, sizeof(random)) != PRP_CRYPTO_OK) {
        secure_zero(random, sizeof(random));
        return PRP_ERR_UNAVAILABLE;
    }
    rc = discovery ? prp_mldsa87_discovery_sign_derand(keypair, message,
        message_len, random, signature, signature_size, written) :
        prp_mldsa87_sign_derand(keypair, message, message_len, random,
            signature, signature_size, written);
    secure_zero(random, sizeof(random));
    return rc;
}

prp_status_t
prp_mldsa87_sign(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return mldsa87_sign_randomized(keypair, message, message_len, signature,
        signature_size, written, 0);
}

prp_status_t
prp_mldsa87_discovery_sign(const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    unsigned char *signature, size_t signature_size, size_t *written)
{
    return mldsa87_sign_randomized(keypair, message, message_len, signature,
        signature_size, written, 1);
}

prp_status_t prp_mldsa87_verify(
    const unsigned char public_key[PRP_MLDSA87_PUBLIC_KEY_LEN],
    const unsigned char signature[PRP_MLDSA87_SIGNATURE_LEN],
    const unsigned char *message, size_t message_len)
{
    if (public_key == NULL || signature == NULL || message == NULL ||
            message_len == 0U)
        return PRP_ERR_ARGUMENT;
    return prp_mldsa87_verify_canonical(public_key, signature, message,
        message_len,
        (const unsigned char *)PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT,
        PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}
