#include "prp_platform_windows.h"

#if !defined(_WIN32)
#error "prp_platform_windows.c requires Windows"
#endif

#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>

#include <limits.h>
#include <string.h>
#include <stdlib.h>

static int windows_random(void *context, uint8_t *output, size_t output_len)
{
    (void)context;
    if (output == NULL && output_len != 0U)
        return PRP_ERR_ARGUMENT;
    while (output_len != 0U) {
        ULONG chunk = output_len > ULONG_MAX ? ULONG_MAX : (ULONG)output_len;
        NTSTATUS status = BCryptGenRandom(NULL, output, chunk,
            BCRYPT_USE_SYSTEM_PREFERRED_RNG);

        if (!BCRYPT_SUCCESS(status))
            return PRP_ERR_CRYPTO;
        output += chunk;
        output_len -= chunk;
    }
    return PRP_OK;
}

static int windows_monotonic_time(void *context, uint64_t *nanoseconds)
{
    LARGE_INTEGER counter;
    LARGE_INTEGER frequency;
    uint64_t seconds;
    uint64_t remainder;
    const uint64_t nanos_per_second = 1000000000ULL;

    (void)context;
    if (nanoseconds == NULL)
        return PRP_ERR_ARGUMENT;
    if (!QueryPerformanceFrequency(&frequency) || frequency.QuadPart <= 0 ||
            !QueryPerformanceCounter(&counter) || counter.QuadPart < 0)
        return PRP_ERR_STATE;
    seconds = (uint64_t)counter.QuadPart / (uint64_t)frequency.QuadPart;
    remainder = (uint64_t)counter.QuadPart % (uint64_t)frequency.QuadPart;
    if (seconds > UINT64_MAX / nanos_per_second ||
            (uint64_t)frequency.QuadPart > UINT64_MAX / nanos_per_second)
        return PRP_ERR_STATE;
    *nanoseconds = seconds * nanos_per_second +
        remainder * nanos_per_second / (uint64_t)frequency.QuadPart;
    return PRP_OK;
}

int prp_platform_windows_initialize(prp_platform_t *platform)
{
    if (platform == NULL)
        return PRP_ERR_ARGUMENT;
    memset(platform, 0, sizeof(*platform));
    platform->abi_version = PRP_PLATFORM_ABI_VERSION;
    platform->struct_size = sizeof(*platform);
    platform->capabilities = PRP_PLATFORM_CAP_RANDOM |
        PRP_PLATFORM_CAP_CLOCK;
    platform->random = windows_random;
    platform->monotonic_time = windows_monotonic_time;
    return prp_platform_validate(platform, platform->capabilities);
}

static int dpapi_entropy(const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    DATA_BLOB *blob, uint8_t **allocation)
{
    size_t length = PRP_PLATFORM_KEY_ID_LEN + associated_data_len;
    if (associated_data_len > UINT32_MAX - PRP_PLATFORM_KEY_ID_LEN)
        return PRP_ERR_ARGUMENT;
    *allocation = malloc(length);
    if (*allocation == NULL)
        return PRP_ERR_NO_MEMORY;
    memcpy(*allocation, key_id, PRP_PLATFORM_KEY_ID_LEN);
    if (associated_data_len != 0U)
        memcpy(*allocation + PRP_PLATFORM_KEY_ID_LEN, associated_data,
            associated_data_len);
    blob->pbData = *allocation;
    blob->cbData = (DWORD)length;
    return PRP_OK;
}

static int windows_dpapi_protect(void *context,
    const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *sealed, size_t *sealed_len)
{
    DATA_BLOB input, entropy, output = {0U, NULL};
    uint8_t *entropy_bytes = NULL;
    int status;
    (void)context;
    if (sealed_len == NULL || plaintext_len > UINT32_MAX)
        return PRP_ERR_ARGUMENT;
    status = dpapi_entropy(key_id, associated_data, associated_data_len,
        &entropy, &entropy_bytes);
    if (status != PRP_OK)
        return status;
    input.pbData = (BYTE *)plaintext;
    input.cbData = (DWORD)plaintext_len;
    if (!CryptProtectData(&input, L"libprp custody v2", &entropy, NULL, NULL,
            CRYPTPROTECT_UI_FORBIDDEN, &output)) {
        SecureZeroMemory(entropy_bytes, entropy.cbData);
        free(entropy_bytes);
        return PRP_ERR_CRYPTO;
    }
    if (sealed == NULL || *sealed_len < output.cbData) {
        *sealed_len = output.cbData;
        status = PRP_ERR_OUTPUT_TOO_SMALL;
    } else {
        memcpy(sealed, output.pbData, output.cbData);
        *sealed_len = output.cbData;
        status = PRP_OK;
    }
    SecureZeroMemory(output.pbData, output.cbData);
    LocalFree(output.pbData);
    SecureZeroMemory(entropy_bytes, entropy.cbData);
    free(entropy_bytes);
    return status;
}

static int windows_dpapi_unprotect(void *context,
    const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *sealed, size_t sealed_len,
    uint8_t *plaintext, size_t *plaintext_len)
{
    DATA_BLOB input, entropy, output = {0U, NULL};
    uint8_t *entropy_bytes = NULL;
    int status;
    (void)context;
    if (plaintext_len == NULL || sealed_len > UINT32_MAX)
        return PRP_ERR_ARGUMENT;
    status = dpapi_entropy(key_id, associated_data, associated_data_len,
        &entropy, &entropy_bytes);
    if (status != PRP_OK)
        return status;
    input.pbData = (BYTE *)sealed;
    input.cbData = (DWORD)sealed_len;
    if (!CryptUnprotectData(&input, NULL, &entropy, NULL, NULL,
            CRYPTPROTECT_UI_FORBIDDEN, &output)) {
        SecureZeroMemory(entropy_bytes, entropy.cbData);
        free(entropy_bytes);
        return PRP_ERR_CRYPTO;
    }
    if (plaintext == NULL || *plaintext_len < output.cbData) {
        *plaintext_len = output.cbData;
        status = PRP_ERR_OUTPUT_TOO_SMALL;
    } else {
        memcpy(plaintext, output.pbData, output.cbData);
        *plaintext_len = output.cbData;
        status = PRP_OK;
    }
    SecureZeroMemory(output.pbData, output.cbData);
    LocalFree(output.pbData);
    SecureZeroMemory(entropy_bytes, entropy.cbData);
    free(entropy_bytes);
    return status;
}

int prp_platform_windows_custody_initialize(prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config)
{
    prp_platform_sealed_custody_config_t effective;
    int status;
    if (config == NULL || config->struct_size < sizeof(*config))
        return PRP_ERR_ARGUMENT;
    effective = *config;
    effective.protection_properties =
        PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST;
    effective.protect = windows_dpapi_protect;
    effective.unprotect = windows_dpapi_unprotect;
    status = prp_platform_sealed_custody_initialize(platform, &effective);
    if (status != PRP_OK)
        return status;
    platform->capabilities |= PRP_PLATFORM_CAP_CLOCK;
    platform->monotonic_time = windows_monotonic_time;
    return prp_platform_validate(platform, platform->capabilities);
}
