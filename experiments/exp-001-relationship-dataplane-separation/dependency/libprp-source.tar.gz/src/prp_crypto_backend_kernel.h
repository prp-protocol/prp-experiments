#ifndef PRP_CRYPTO_BACKEND_KERNEL_H
#define PRP_CRYPTO_BACKEND_KERNEL_H

#include <stddef.h>
#include <stdint.h>

int prp_crypto_kernel_blake3_hash(const uint8_t *input, size_t input_len,
    uint8_t output[32]);
int prp_crypto_kernel_blake3_keyed_hash(const uint8_t key[32],
    const uint8_t *input, size_t input_len, uint8_t output[32]);
int prp_crypto_kernel_blake3_derive_key(const char *context,
    const uint8_t *key, size_t key_len, const uint8_t *input,
    size_t input_len, uint8_t output[32]);

#endif
