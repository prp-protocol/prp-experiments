#include "prp_app_v1_state.h"
#include <string.h>
#include <stdint.h>

static uint64_t after(uint64_t now, uint32_t delta)
{ return now > UINT64_MAX-delta ? UINT64_MAX : now+delta; }
static int pending(const struct prp_app_attempt *a)
{ return a->phase>=APP_OFFER && a->phase<=APP_CONFIRM; }
static void dead(struct prp_app_state *s, struct prp_app_attempt *a)
{
    if(a->phase==APP_DEAD) return;
    a->phase=APP_DEAD; a->reply_len=0; a->sent_kind=0;
    a->expires=after(s->now,a->tombstone);
}
void prp_app_state_invalidate(struct prp_app_state *s)
{ if(s) memset(s,0,sizeof *s); }
void prp_app_state_init(struct prp_app_state *s,const uint8_t c[32],unsigned role)
{
    memset(s,0,sizeof *s);
    if(c && (role==1 || role==2)) { memcpy(s->context,c,32); s->role=(uint8_t)role; s->live=1; }
}
int prp_app_state_tick(struct prp_app_state *s,uint64_t now)
{
    unsigned i;
    if(!s || !s->live) return -1;
    if(now<s->now) { prp_app_state_invalidate(s); return -1; }
    s->now=now;
    for(i=0;i<PRP_APP_STATE_SLOTS;i++) {
        struct prp_app_attempt *a=&s->slots[i];
        if(pending(a) && now>=a->deadline) dead(s,a);
        if(a->phase==APP_DEAD && now>=a->expires) memset(a,0,sizeof *a);
    }
    return 0;
}
static struct prp_app_attempt *find(struct prp_app_state *s,uint64_t id,unsigned role)
{
    unsigned i;
    for(i=0;i<PRP_APP_STATE_SLOTS;i++) if(s->slots[i].phase &&
        s->slots[i].id==id && s->slots[i].role==role) return &s->slots[i];
    return NULL;
}
static struct prp_app_attempt *allocate(struct prp_app_state *s,const prp_app_v1_message *m)
{
    unsigned i,r=m->opener-1; struct prp_app_attempt *a=NULL;
    if(m->attempt<=s->high[r] || s->attempts[r]>=PRP_APP_STATE_ATTEMPTS) return NULL;
    /* Count even resource-rejected attempts. Eviction never clears high-water. */
    s->high[r]=m->attempt; s->attempts[r]++;
    for(i=0;i<PRP_APP_STATE_SLOTS;i++) if(!s->slots[i].phase) { a=&s->slots[i]; break; }
    if(!a) return NULL;
    memset(a,0,sizeof *a); a->id=m->attempt; a->role=m->opener;
    a->deadline=after(s->now,30000); a->tombstone=m->tombstone_ms;
    return a;
}
int prp_app_state_compatibility_reserve(struct prp_app_state *s,uint16_t alias)
{
    uint8_t mask=(uint8_t)(1u<<(alias&7));
    if(!s || !s->live || !alias) return -1;
    if(s->used[alias>>3]&mask) { prp_app_state_invalidate(s); return -1; }
    s->used[alias>>3]|=mask; return 0;
}
static int reserve(struct prp_app_state *s,struct prp_app_attempt *a,uint16_t alias,uint32_t gen,unsigned acceptor)
{
    if(!alias || !gen) return -1;
    if(s->used[alias>>3] & (1u<<(alias&7))) { prp_app_state_invalidate(s); return -1; }
    if(gen<=s->generation[acceptor-1]) return -1;
    if(prp_app_state_compatibility_reserve(s,alias)) return -1;
    s->generation[acceptor-1]=gen; a->alias=alias; a->generation=gen; return 0;
}
static int reply(struct prp_app_attempt *a,uint8_t *out,size_t *n)
{
    if(!out || !n || !a->reply_len) return -1;
    memcpy(out,a->reply,a->reply_len); *n=a->reply_len; return 0;
}
int prp_app_state_offer(struct prp_app_state *s,const prp_app_v1_message *offer,uint64_t now,uint8_t out[125],size_t *n)
{
    uint8_t wire[125]; size_t len; struct prp_app_attempt *a;
    if(!offer || !out || !n || prp_app_state_tick(s,now) || offer->kind!=7 ||
        offer->opener!=s->role || memcmp(offer->context,s->context,32) ||
        prp_app_v1_encode(offer,wire,sizeof wire,&len)) return -1;
    a=allocate(s,offer); if(!a) return -1;
    memcpy(a->offer,wire,len); a->offer_len=len; a->phase=APP_OFFER;
    memcpy(out,wire,len); *n=len; return 0;
}
int prp_app_state_decide(struct prp_app_state *s,uint64_t id,unsigned role,
    uint16_t alias,uint32_t gen,uint16_t reason,uint64_t now,uint8_t out[113],size_t *n)
{
    struct prp_app_attempt *a; prp_app_v1_message m,offer; size_t len;
    if(!out || !n || prp_app_state_tick(s,now) || role==s->role ||
        !(a=find(s,id,role)) || a->phase!=APP_RECEIVED || reason>5) return -1;
    if(prp_app_v1_decode(a->offer,a->offer_len,&offer)) return -1;
    if(!reason && (offer.profile!=1 || offer.application_version!=1 ||
       !((offer.application_len==4 && !memcmp(offer.application,"POST",4)) ||
         (offer.application_len==4 && !memcmp(offer.application,"PRPD",4))))) reason=3;
    memset(&m,0,sizeof m); m.kind=reason?10:8; m.opener=(uint8_t)role;
    m.attempt=id; memcpy(m.context,s->context,32); m.reason=reason;
    if(prp_app_v1_offer_hash(a->offer,a->offer_len,m.offer_hash)) return -1;
    if(!reason && reserve(s,a,alias,gen,s->role)) return -1;
    m.alias=alias; m.generation=gen;
    if(prp_app_v1_encode(&m,a->reply,sizeof a->reply,&len)) return -1;
    a->reply_len=len; a->phase=reason?APP_DEAD:APP_ACCEPT;
    if(reason) a->expires=after(now,a->tombstone);
    else memcpy(a->accept,a->reply,113);
    return reply(a,out,n);
}
static int dup(struct prp_app_attempt *a,uint8_t *out,size_t *n)
{
    /* Lifetime budget: at most eight duplicate-triggered replies, no reset. */
    if(a->duplicates>=8) return -1;
    a->duplicates++;
    if(!a->reply_len) { *n=0; return 0; }
    return reply(a,out,n);
}
int prp_app_state_receive(struct prp_app_state *s,const uint8_t *wire,size_t len,
    unsigned sender,uint64_t now,uint8_t out[113],size_t *n)
{
    prp_app_v1_message m,confirm; struct prp_app_attempt *a; uint8_t hash[32]; size_t z;
    if(!out || !n || prp_app_state_tick(s,now) || sender!=3u-s->role) return -1;
    *n=0;
    if(prp_app_v1_decode(wire,len,&m)) {
        /* A changed cached body must invalidate even when its commitment or
         * canonical framing fails. This path runs only AFTER authenticated
         * E2E open; unauthenticated corruption cannot cancel an agreement. */
        if(wire && len>=43 && wire[0]>=7 && wire[0]<=10 &&
           (wire[2]==1 || wire[2]==2) && !memcmp(wire+11,s->context,32) &&
           ((wire[0]==7 || wire[0]==9)?sender==wire[2]:sender!=wire[2])) {
            uint64_t id=0; unsigned j;
            for(j=3;j<11;j++) id=(id<<8)|wire[j];
            a=find(s,id,wire[2]);
            if(a) dead(s,a);
        }
        return -1;
    }
    if(memcmp(m.context,s->context,32)) return -1;
    if(((m.kind==7 || m.kind==9) && sender!=m.opener) ||
       ((m.kind==8 || m.kind==10) && sender==m.opener)) return -1;
    a=find(s,m.attempt,m.opener);
    if(m.kind==7) {
        if(a) {
            if(a->offer_len!=len || memcmp(a->offer,wire,len)) { dead(s,a); return -1; }
            if(a->phase==APP_ACTIVE && now>=a->expires) return -1;
            return dup(a,out,n);
        }
        a=allocate(s,&m); if(!a) return -1;
        memcpy(a->offer,wire,len); a->offer_len=len; a->phase=APP_RECEIVED;
        *n=0; return 1; /* one policy decision required; no callback here */
    }
    if(!a || a->phase==APP_DEAD) return -1;
    if(m.kind==9) {
        if((a->phase!=APP_ACCEPT && a->phase!=APP_ACTIVE) ||
            memcmp(m.acceptance_hash,a->accept+81,32)) { dead(s,a); return -1; }
        if(a->phase==APP_ACTIVE) { if(now>=a->expires || a->duplicates>=8) return -1; a->duplicates++; }
        else { a->phase=APP_ACTIVE; a->expires=after(now,a->tombstone); }
        *n=0; return 0;
    }
    if(prp_app_v1_offer_hash(a->offer,a->offer_len,hash) || memcmp(hash,m.offer_hash,32))
        { dead(s,a); return -1; }
    if(m.kind==10) { if(a->phase!=APP_OFFER) { dead(s,a); return -1; } dead(s,a); *n=0; return 0; }
    if(a->phase==APP_CONFIRM || a->phase==APP_ACTIVE) {
        if(memcmp(a->accept,wire,113)) { dead(s,a); return -1; }
        if(a->phase==APP_ACTIVE && now>=a->expires) return -1;
        return dup(a,out,n);
    }
    if(a->phase!=APP_OFFER) return -1;
    if(reserve(s,a,m.alias,m.generation,sender)) { if(s->live) dead(s,a); return -1; }
    memcpy(a->accept,wire,113); memset(&confirm,0,sizeof confirm);
    confirm.kind=9; confirm.opener=m.opener; confirm.attempt=m.attempt;
    memcpy(confirm.context,m.context,32); memcpy(confirm.acceptance_hash,m.acceptance_hash,32);
    if(prp_app_v1_encode(&confirm,a->reply,sizeof a->reply,&z)) { dead(s,a); return -1; }
    a->reply_len=z; a->sent_kind=9; a->phase=APP_CONFIRM;
    return reply(a,out,n);
}
int prp_app_state_handed(struct prp_app_state *s,uint64_t id,unsigned role,uint64_t now)
{
    struct prp_app_attempt *a;
    if(prp_app_state_tick(s,now) || !(a=find(s,id,role)) || role!=s->role ||
       a->phase!=APP_CONFIRM || a->sent_kind!=9) return -1;
    a->phase=APP_ACTIVE; a->sent_kind=0; a->expires=after(now,a->tombstone); return 0;
}
int prp_app_state_cancel(struct prp_app_state *s,uint64_t id,unsigned role,uint64_t now)
{
    struct prp_app_attempt *a;
    if(prp_app_state_tick(s,now) || !(a=find(s,id,role))) return -1;
    if(a->phase!=APP_DEAD) dead(s,a);
    return 0;
}
int prp_app_state_close(struct prp_app_state *s,uint16_t alias,uint32_t gen,uint64_t now)
{
    unsigned i;
    if(prp_app_state_tick(s,now)) return -1;
    for(i=0;i<PRP_APP_STATE_SLOTS;i++) if(s->slots[i].phase &&
       s->slots[i].alias==alias && s->slots[i].generation==gen && alias && gen)
        return prp_app_state_cancel(s,s->slots[i].id,s->slots[i].role,now);
    return -1;
}
int prp_app_state_admits(struct prp_app_state *s,uint16_t alias,uint32_t gen,uint64_t now)
{
    unsigned i;
    if(prp_app_state_tick(s,now)) return 0;
    for(i=0;i<PRP_APP_STATE_SLOTS;i++) if(s->slots[i].phase==APP_ACTIVE &&
       s->slots[i].alias==alias && s->slots[i].generation==gen && alias && gen) return 1;
    return 0;
}
