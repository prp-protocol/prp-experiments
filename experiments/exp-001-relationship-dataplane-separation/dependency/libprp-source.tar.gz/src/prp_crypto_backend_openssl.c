#include "prp_crypto_backend.h"
#include "prp_ed25519ctx_internal.h"
#include "prp_hash.h"
#include "prp_pq_internal.h"

#include <openssl/crypto.h>
#include <openssl/core_names.h>
#include <openssl/evp.h>
#include <openssl/params.h>
#include <openssl/rand.h>

#include <limits.h>

static int ed25519ctx_available(void);

int
prp_crypto_hash_sha2_concat(unsigned int bits,
    const uint8_t *first, size_t first_len, const uint8_t *second,
    size_t second_len, uint8_t *out, size_t out_len)
{
    const EVP_MD *algorithm;
    EVP_MD_CTX *context;
    unsigned int digest_len = 0u;
    size_t expected;
    int result = PRP_CRYPTO_ERR_CRYPTO;

    if ((first == NULL && first_len != 0u) ||
            (second == NULL && second_len != 0u) || out == NULL)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    if (bits == 256u) {
        algorithm = EVP_sha256();
        expected = PRP_CRYPTO_HASH_SHA256_OUT_LEN;
    } else if (bits == 384u) {
        algorithm = EVP_sha384();
        expected = PRP_CRYPTO_HASH_SHA384_OUT_LEN;
    } else {
        return PRP_CRYPTO_ERR_UNSUPPORTED;
    }
    if (out_len < expected)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    context = EVP_MD_CTX_new();
    if (context != NULL &&
            EVP_DigestInit_ex(context, algorithm, NULL) == 1 &&
            (first_len == 0u ||
                EVP_DigestUpdate(context, first, first_len) == 1) &&
            (second_len == 0u ||
                EVP_DigestUpdate(context, second, second_len) == 1) &&
            EVP_DigestFinal_ex(context, out, &digest_len) == 1 &&
            digest_len == expected)
        result = PRP_CRYPTO_OK;
    EVP_MD_CTX_free(context);
    return result;
}

static int
verify_identity_proof_one(const char *algorithm, const char *instance,
    const uint8_t *public_key,
    size_t public_key_len, const uint8_t *signature, size_t signature_len,
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len)
{
    EVP_PKEY *key = NULL;
    EVP_MD_CTX *md = NULL;
    OSSL_PARAM *selected = NULL;
    int verified = 0;

#if defined(OSSL_SIGNATURE_PARAM_INSTANCE) && \
    defined(OSSL_SIGNATURE_PARAM_CONTEXT_STRING)
    OSSL_PARAM params[3];

    if (instance != NULL) {
        params[0] = OSSL_PARAM_construct_utf8_string(
            OSSL_SIGNATURE_PARAM_INSTANCE, (char *)instance, 0U);
        params[1] = OSSL_PARAM_construct_octet_string(
            OSSL_SIGNATURE_PARAM_CONTEXT_STRING, (void *)context,
            context_len);
        params[2] = OSSL_PARAM_construct_end();
        selected = params;
    }
#else
    (void)instance;
    (void)context;
    if (instance != NULL || context_len != 0u)
        return PRP_CRYPTO_ERR_UNSUPPORTED;
#endif
    key = EVP_PKEY_new_raw_public_key_ex(NULL, algorithm, NULL, public_key,
        public_key_len);
    md = EVP_MD_CTX_new();
    if (key != NULL && md != NULL &&
            EVP_DigestVerifyInit_ex(md, NULL, NULL, NULL, NULL, key,
                selected) == 1 &&
            EVP_DigestVerify(md, signature, signature_len, message,
                message_len) == 1)
        verified = 1;
    EVP_MD_CTX_free(md);
    EVP_PKEY_free(key);
    return verified ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_identity_proof_verify(uint8_t profile,
    const uint8_t *public_key, const uint8_t *signature,
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len)
{
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return context_len == 0u ? verify_identity_proof_one("ED25519", NULL,
            public_key, PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN, signature,
            PRP_ID_PROOF_ED25519_SIGNATURE_LEN, message, message_len,
            NULL, 0u) : PRP_CRYPTO_ERR_BAD_ARGS;
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        if (context_len == 0u)
            return PRP_CRYPTO_ERR_BAD_ARGS;
        if (ed25519ctx_available())
            return verify_identity_proof_one("ED25519", "Ed25519ctx",
                public_key, PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN, signature,
                PRP_ID_PROOF_ED25519_SIGNATURE_LEN, message, message_len,
                context, context_len);
        return prp_ed25519ctx_verify_context(public_key, signature, message,
            message_len, context, context_len);
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return prp_mldsa65_verify_canonical(public_key, signature, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return prp_mldsa87_verify_canonical(public_key, signature, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        if (verify_identity_proof_one("ED25519", NULL, public_key,
                PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN, signature,
                PRP_ID_PROOF_ED25519_SIGNATURE_LEN, message, message_len,
                NULL, 0u) != PRP_CRYPTO_OK)
            return PRP_CRYPTO_ERR_CRYPTO;
        return prp_mldsa87_verify_canonical(
            public_key + PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN,
            signature + PRP_ID_PROOF_ED25519_SIGNATURE_LEN, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    default:
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
}

static int
identity_algorithm_available(const char *algorithm)
{
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_from_name(NULL, algorithm, NULL);

    if (ctx == NULL) {
        return 0;
    }
    EVP_PKEY_CTX_free(ctx);
    return 1;
}

static int
ed25519ctx_available(void)
{
#if defined(OSSL_SIGNATURE_PARAM_INSTANCE) && \
    defined(OSSL_SIGNATURE_PARAM_CONTEXT_STRING)
    uint8_t public_key[PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN] = { 0 };
    uint8_t probe_context = 0U;
    char instance[] = "Ed25519ctx";
    OSSL_PARAM params[3];
    EVP_PKEY *key;
    EVP_MD_CTX *md;
    int available = 0;

    params[0] = OSSL_PARAM_construct_utf8_string(
        OSSL_SIGNATURE_PARAM_INSTANCE, instance, 0U);
    params[1] = OSSL_PARAM_construct_octet_string(
        OSSL_SIGNATURE_PARAM_CONTEXT_STRING, &probe_context, 1U);
    params[2] = OSSL_PARAM_construct_end();
    key = EVP_PKEY_new_raw_public_key_ex(NULL, "ED25519", NULL, public_key,
        sizeof(public_key));
    md = EVP_MD_CTX_new();
    if (key != NULL && md != NULL &&
            EVP_DigestVerifyInit_ex(md, NULL, NULL, NULL, NULL, key,
                params) == 1)
        available = 1;
    EVP_MD_CTX_free(md);
    EVP_PKEY_free(key);
    return available;
#else
    return 0;
#endif
}

int
prp_crypto_identity_proof_capable(uint8_t profile)
{
    switch (profile) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
        return identity_algorithm_available("ED25519");
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
        return 1;
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
        return 1;
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
        return 1;
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        return identity_algorithm_available("ED25519");
    default:
        return 0;
    }
}

const char *
prp_crypto_backend_name(void)
{
#ifdef PRP_ENABLE_KERNEL_HASH
    return "prp-kernel-hash+openssl-userlevel";
#else
    return "openssl-userlevel";
#endif
}

uint32_t
prp_crypto_backend_flags(void)
{
    uint32_t flags = PRP_CRYPTO_INFO_FLAG_USERLEVEL |
        PRP_CRYPTO_INFO_FLAG_SOFTWARE_FALLBACK |
        PRP_CRYPTO_INFO_FLAG_RAW_KEYS |
        PRP_CRYPTO_INFO_FLAG_PORTABLE_ED25519CTX;

#ifdef PRP_ENABLE_KERNEL_HASH
    flags |= PRP_CRYPTO_INFO_FLAG_KERNEL;
#endif
    return flags;
}

int
prp_crypto_backend_info(prp_crypto_backend_info_t *info)
{
    if (info == NULL) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    info->abi_version = PRP_CRYPTO_BACKEND_ABI_VERSION;
    info->flags = prp_crypto_backend_flags();
    info->name = prp_crypto_backend_name();
    info->max_ad_len = (uint32_t) INT_MAX;
    info->max_input_len = (uint32_t) INT_MAX;
    info->max_output_len = (uint32_t) INT_MAX;
    info->key_slot_count = 0u;
    return PRP_CRYPTO_OK;
}

int
prp_crypto_backend_capable(prp_crypto_suite_t suite,
    prp_crypto_operation_t operation)
{
    switch (suite) {
    case PRP_CRYPTO_SUITE_BLAKE3_256:
        return operation == PRP_CRYPTO_OP_HASH ? 1 : 0;
    case PRP_CRYPTO_SUITE_BLAKE3_KEYED_256:
        return operation == PRP_CRYPTO_OP_HASH ? 1 : 0;
    case PRP_CRYPTO_SUITE_CHACHA20_POLY1305:
        return operation == PRP_CRYPTO_OP_AEAD_ENCRYPT ||
            operation == PRP_CRYPTO_OP_AEAD_DECRYPT;
    case PRP_CRYPTO_SUITE_X25519:
        return operation == PRP_CRYPTO_OP_KEYPAIR ||
            operation == PRP_CRYPTO_OP_PUBLIC_FROM_PRIVATE ||
            operation == PRP_CRYPTO_OP_DH;
    case PRP_CRYPTO_SUITE_RANDOM:
        return operation == PRP_CRYPTO_OP_RANDOM ? 1 : 0;
    case PRP_CRYPTO_SUITE_AES_256_GCM:
        return operation == PRP_CRYPTO_OP_AEAD_ENCRYPT ||
            operation == PRP_CRYPTO_OP_AEAD_DECRYPT;
    default:
        return 0;
    }
}

const char *
prp_crypto_error_name(int error_code)
{
    switch (error_code) {
    case PRP_CRYPTO_OK:
        return "ok";
    case PRP_CRYPTO_ERR_UNAVAILABLE:
        return "unavailable";
    case PRP_CRYPTO_ERR_UNSUPPORTED:
        return "unsupported";
    case PRP_CRYPTO_ERR_BAD_ARGS:
        return "bad_args";
    case PRP_CRYPTO_ERR_CRYPTO:
        return "crypto";
    default:
        return "unknown";
    }
}

void
prp_crypto_secure_zero(void *ptr, size_t len)
{
    if (ptr != NULL && len != 0u) {
        OPENSSL_cleanse(ptr, len);
    }
}

int
prp_crypto_random(uint8_t *out, size_t out_len)
{
    if (out == NULL && out_len != 0u) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    if (out_len > (size_t) INT_MAX) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    if (out_len == 0u) {
        return PRP_CRYPTO_OK;
    }
    return RAND_bytes(out, (int) out_len) == 1 ? PRP_CRYPTO_OK :
        PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_chacha20_poly1305_encrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *plaintext,
    size_t plaintext_len, uint8_t *ciphertext,
    uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN])
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int out_len;
    int ok;

    if (key == NULL || nonce == NULL || ciphertext == NULL || tag == NULL ||
        (ad == NULL && ad_len != 0u) ||
        (plaintext == NULL && plaintext_len != 0u) ||
        ad_len > (size_t) INT_MAX || plaintext_len > (size_t) INT_MAX) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    len = 0;
    out_len = 0;
    ok = EVP_EncryptInit_ex(ctx, EVP_chacha20_poly1305(), NULL, NULL,
            NULL) == 1 &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_IVLEN,
            PRP_CRYPTO_CHACHAPOLY_NONCE_LEN, NULL) == 1 &&
        EVP_EncryptInit_ex(ctx, NULL, NULL, key, nonce) == 1 &&
        EVP_EncryptUpdate(ctx, NULL, &len, ad, (int) ad_len) == 1 &&
        EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext,
            (int) plaintext_len) == 1;
    out_len = len;
    ok = ok && EVP_EncryptFinal_ex(ctx, ciphertext + out_len, &len) == 1;
    out_len += len;
    ok = ok && out_len == (int) plaintext_len &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_GET_TAG,
            PRP_CRYPTO_CHACHAPOLY_TAG_LEN, tag) == 1;
    EVP_CIPHER_CTX_free(ctx);
    return ok ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_chacha20_poly1305_decrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *ad, size_t ad_len, const uint8_t *ciphertext,
    size_t ciphertext_len, const uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN],
    uint8_t *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int out_len;
    int ok;

    if (key == NULL || nonce == NULL || tag == NULL || plaintext == NULL ||
        (ad == NULL && ad_len != 0u) ||
        (ciphertext == NULL && ciphertext_len != 0u) ||
        ad_len > (size_t) INT_MAX || ciphertext_len > (size_t) INT_MAX) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    len = 0;
    out_len = 0;
    ok = EVP_DecryptInit_ex(ctx, EVP_chacha20_poly1305(), NULL, NULL,
            NULL) == 1 &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_IVLEN,
            PRP_CRYPTO_CHACHAPOLY_NONCE_LEN, NULL) == 1 &&
        EVP_DecryptInit_ex(ctx, NULL, NULL, key, nonce) == 1 &&
        EVP_DecryptUpdate(ctx, NULL, &len, ad, (int) ad_len) == 1 &&
        EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext,
            (int) ciphertext_len) == 1;
    out_len = len;
    ok = ok && EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_TAG,
            PRP_CRYPTO_CHACHAPOLY_TAG_LEN, (void *) tag) == 1 &&
        EVP_DecryptFinal_ex(ctx, plaintext + out_len, &len) == 1;
    out_len += len;
    EVP_CIPHER_CTX_free(ctx);
    return ok && out_len == (int) ciphertext_len ? PRP_CRYPTO_OK :
        PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_aes_256_gcm_encrypt(const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN], const uint8_t *ad,
    size_t ad_len, const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *ciphertext, uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN])
{
    EVP_CIPHER_CTX *ctx;
    int len = 0;
    int output_len = 0;
    int ok;

    if (key == NULL || nonce == NULL || ciphertext == NULL || tag == NULL ||
        (ad == NULL && ad_len != 0U) ||
        (plaintext == NULL && plaintext_len != 0U) ||
        ad_len > (size_t)INT_MAX || plaintext_len > (size_t)INT_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    ok = EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) == 1 &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_IVLEN,
            PRP_CRYPTO_AESGCM_NONCE_LEN, NULL) == 1 &&
        EVP_EncryptInit_ex(ctx, NULL, NULL, key, nonce) == 1 &&
        EVP_EncryptUpdate(ctx, NULL, &len, ad, (int)ad_len) == 1 &&
        EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext,
            (int)plaintext_len) == 1;
    output_len = len;
    ok = ok && EVP_EncryptFinal_ex(ctx, ciphertext + output_len, &len) == 1;
    output_len += len;
    ok = ok && output_len == (int)plaintext_len &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_GET_TAG,
            PRP_CRYPTO_AESGCM_TAG_LEN, tag) == 1;
    EVP_CIPHER_CTX_free(ctx);
    return ok ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_aes_256_gcm_decrypt(const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_AESGCM_NONCE_LEN], const uint8_t *ad,
    size_t ad_len, const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t tag[PRP_CRYPTO_AESGCM_TAG_LEN], uint8_t *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len = 0;
    int output_len = 0;
    int ok;

    if (key == NULL || nonce == NULL || tag == NULL || plaintext == NULL ||
        (ad == NULL && ad_len != 0U) ||
        (ciphertext == NULL && ciphertext_len != 0U) ||
        ad_len > (size_t)INT_MAX || ciphertext_len > (size_t)INT_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL)
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    ok = EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) == 1 &&
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_IVLEN,
            PRP_CRYPTO_AESGCM_NONCE_LEN, NULL) == 1 &&
        EVP_DecryptInit_ex(ctx, NULL, NULL, key, nonce) == 1 &&
        EVP_DecryptUpdate(ctx, NULL, &len, ad, (int)ad_len) == 1 &&
        EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext,
            (int)ciphertext_len) == 1;
    output_len = len;
    ok = ok && EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_AEAD_SET_TAG,
        PRP_CRYPTO_AESGCM_TAG_LEN, (void *)tag) == 1 &&
        EVP_DecryptFinal_ex(ctx, plaintext + output_len, &len) == 1;
    output_len += len;
    EVP_CIPHER_CTX_free(ctx);
    return ok && output_len == (int)ciphertext_len ? PRP_CRYPTO_OK :
        PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_x25519_public_from_private(
    const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    uint8_t public_key[PRP_CRYPTO_KEY_LEN])
{
    EVP_PKEY *pkey;
    size_t public_len;
    int ok;

    if (private_key == NULL || public_key == NULL) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    pkey = EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, NULL, private_key,
        PRP_CRYPTO_KEY_LEN);
    if (pkey == NULL) {
        return PRP_CRYPTO_ERR_CRYPTO;
    }
    public_len = PRP_CRYPTO_KEY_LEN;
    ok = EVP_PKEY_get_raw_public_key(pkey, public_key, &public_len) == 1 &&
        public_len == PRP_CRYPTO_KEY_LEN;
    EVP_PKEY_free(pkey);
    return ok ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_x25519_keypair(uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t private_key[PRP_CRYPTO_KEY_LEN])
{
    EVP_PKEY_CTX *ctx;
    EVP_PKEY *pkey;
    size_t private_len;
    size_t public_len;
    int ok;

    if (public_key == NULL || private_key == NULL) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, NULL);
    if (ctx == NULL) {
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    pkey = NULL;
    ok = EVP_PKEY_keygen_init(ctx) == 1 && EVP_PKEY_keygen(ctx, &pkey) == 1;
    EVP_PKEY_CTX_free(ctx);
    if (!ok || pkey == NULL) {
        EVP_PKEY_free(pkey);
        return PRP_CRYPTO_ERR_CRYPTO;
    }
    private_len = PRP_CRYPTO_KEY_LEN;
    public_len = PRP_CRYPTO_KEY_LEN;
    ok = EVP_PKEY_get_raw_private_key(pkey, private_key, &private_len) == 1 &&
        private_len == PRP_CRYPTO_KEY_LEN &&
        EVP_PKEY_get_raw_public_key(pkey, public_key, &public_len) == 1 &&
        public_len == PRP_CRYPTO_KEY_LEN;
    EVP_PKEY_free(pkey);
    return ok ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int
prp_crypto_x25519_dh(const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    const uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t out[PRP_CRYPTO_KEY_LEN])
{
    EVP_PKEY *local;
    EVP_PKEY *peer;
    EVP_PKEY_CTX *ctx;
    size_t out_len;
    int ok;

    if (private_key == NULL || public_key == NULL || out == NULL) {
        return PRP_CRYPTO_ERR_BAD_ARGS;
    }
    local = EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, NULL, private_key,
        PRP_CRYPTO_KEY_LEN);
    peer = EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, NULL, public_key,
        PRP_CRYPTO_KEY_LEN);
    if (local == NULL || peer == NULL) {
        EVP_PKEY_free(local);
        EVP_PKEY_free(peer);
        return PRP_CRYPTO_ERR_CRYPTO;
    }
    ctx = EVP_PKEY_CTX_new(local, NULL);
    if (ctx == NULL) {
        EVP_PKEY_free(local);
        EVP_PKEY_free(peer);
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    }
    out_len = PRP_CRYPTO_KEY_LEN;
    ok = EVP_PKEY_derive_init(ctx) == 1 &&
        EVP_PKEY_derive_set_peer(ctx, peer) == 1 &&
        EVP_PKEY_derive(ctx, out, &out_len) == 1 &&
        out_len == PRP_CRYPTO_KEY_LEN;
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_free(local);
    EVP_PKEY_free(peer);
    return ok ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}
