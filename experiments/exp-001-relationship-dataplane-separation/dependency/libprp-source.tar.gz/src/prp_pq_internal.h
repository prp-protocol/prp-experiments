#ifndef PRP_PQ_INTERNAL_H
#define PRP_PQ_INTERNAL_H

#include <stddef.h>
#include <stdint.h>

int prp_mldsa87_verify_canonical(const uint8_t *public_key,
    const uint8_t *signature, const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len);
int prp_mldsa65_verify_canonical(const uint8_t *public_key,
    const uint8_t *signature, const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len);

#endif
