#ifndef PRP_ED25519CTX_INTERNAL_H
#define PRP_ED25519CTX_INTERNAL_H

#include "prp_ed25519ctx.h"

#include <stddef.h>
#include <stdint.h>

int prp_ed25519ctx_sign_context(const uint8_t private_key[64],
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len, uint8_t signature[64]);
int prp_ed25519ctx_verify_context(const uint8_t public_key[32],
    const uint8_t signature[64], const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len);

#endif
