#include "prp_platform_android.h"

int prp_platform_android_custody_initialize(
    prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config)
{
    return prp_platform_sealed_custody_initialize(platform, config);
}
