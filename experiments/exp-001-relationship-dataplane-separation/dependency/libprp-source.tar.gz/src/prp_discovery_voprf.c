#include "prp_discovery_voprf.h"

#include "prp_platform.h"

#include <limits.h>
#include <string.h>

#ifdef PRP_HAVE_SODIUM_VOPRF
#include <sodium.h>
#endif

static const uint8_t input_domain[] = "PRP-DISCOVERY-VOPRF-INPUT-v1";
#ifdef PRP_HAVE_SODIUM_VOPRF
static const uint8_t token_domain[] =
    "PRP-DISCOVERY-VOPRF-LOOKUP-TOKEN-v1";
#endif
static const uint8_t key_magic[4] = { 'P', 'R', 'V', 'K' };
static const uint8_t request_magic[4] = { 'P', 'R', 'V', 'Q' };
static const uint8_t response_magic[4] = { 'P', 'R', 'V', 'R' };

static uint16_t
read_u16(const uint8_t *data)
{
    return (uint16_t)((uint16_t)data[0] << 8) | data[1];
}

static uint32_t
read_u32(const uint8_t *data)
{
    return ((uint32_t)data[0] << 24) | ((uint32_t)data[1] << 16) |
        ((uint32_t)data[2] << 8) | data[3];
}

static void
write_u16(uint8_t *data, uint16_t value)
{
    data[0] = (uint8_t)(value >> 8);
    data[1] = (uint8_t)value;
}

static void
write_u32(uint8_t *data, uint32_t value)
{
    data[0] = (uint8_t)(value >> 24);
    data[1] = (uint8_t)(value >> 16);
    data[2] = (uint8_t)(value >> 8);
    data[3] = (uint8_t)value;
}

static int
all_zero(const uint8_t *data, size_t len)
{
    uint8_t value = 0u;
    size_t i;

    for (i = 0u; i < len; i++)
        value |= data[i];
    return value == 0u;
}

int
prp_discovery_voprf_private_input_encode(uint32_t relationship_generation,
    uint16_t rendezvous_identity_suite, const uint8_t *rendezvous_strong_id,
    size_t rendezvous_strong_id_len, uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len,
    uint8_t *out, size_t out_len, size_t *written)
{
    size_t required, offset;

    if (relationship_generation == 0u || rendezvous_identity_suite == 0u ||
        published_identity_suite == 0u || rendezvous_strong_id == NULL ||
        published_strong_id == NULL || rendezvous_strong_id_len == 0u ||
        published_strong_id_len == 0u ||
        rendezvous_strong_id_len > UINT16_MAX ||
        published_strong_id_len > UINT16_MAX || out == NULL || written == NULL)
        return PRP_ERR_ARGUMENT;
    required = 2u + sizeof(input_domain) - 1u + 4u + 2u + 2u +
        rendezvous_strong_id_len + 2u + 2u + published_strong_id_len;
    if (out_len < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    write_u16(out, (uint16_t)(sizeof(input_domain) - 1u));
    memcpy(out + 2u, input_domain, sizeof(input_domain) - 1u);
    offset = 2u + sizeof(input_domain) - 1u;
    write_u32(out + offset, relationship_generation);
    write_u16(out + offset + 4u, rendezvous_identity_suite);
    write_u16(out + offset + 6u, (uint16_t)rendezvous_strong_id_len);
    offset += 8u;
    memcpy(out + offset, rendezvous_strong_id, rendezvous_strong_id_len);
    offset += rendezvous_strong_id_len;
    write_u16(out + offset, published_identity_suite);
    write_u16(out + offset + 2u, (uint16_t)published_strong_id_len);
    memcpy(out + offset + 4u, published_strong_id, published_strong_id_len);
    *written = required;
    return PRP_OK;
}

#ifdef PRP_HAVE_SODIUM_VOPRF

static const uint8_t context_string[] =
    "OPRFV1-\x01-ristretto255-SHA512";
static const uint8_t scalar_order[PRP_DISCOVERY_VOPRF_SCALAR_LEN] = {
    0xed, 0xd3, 0xf5, 0x5c, 0x1a, 0x63, 0x12, 0x58,
    0xd6, 0x9c, 0xf7, 0xa2, 0xde, 0xf9, 0xde, 0x14,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10
};

static int
backend_ready(void)
{
    return sodium_init() >= 0;
}

static int
random_scalar_with_platform(const prp_platform_t *platform,
    uint8_t scalar[PRP_DISCOVERY_VOPRF_SCALAR_LEN])
{
    uint8_t uniform[64];
    int rc;

    if (platform == NULL || scalar == NULL ||
            prp_platform_validate(platform, PRP_PLATFORM_CAP_RANDOM) != PRP_OK)
        return PRP_ERR_ARGUMENT;
    rc = platform->random(platform->context, uniform, sizeof(uniform));
    if (rc == PRP_OK) {
        crypto_core_ristretto255_scalar_reduce(scalar, uniform);
        if (all_zero(scalar, PRP_DISCOVERY_VOPRF_SCALAR_LEN))
            rc = PRP_ERR_CRYPTO;
    }
    sodium_memzero(uniform, sizeof(uniform));
    return rc;
}

static int
scalar_canonical(const uint8_t scalar[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    int nonzero)
{
    size_t i;

    if (nonzero && all_zero(scalar, PRP_DISCOVERY_VOPRF_SCALAR_LEN))
        return 0;
    for (i = PRP_DISCOVERY_VOPRF_SCALAR_LEN; i != 0u; i--) {
        if (scalar[i - 1u] < scalar_order[i - 1u])
            return 1;
        if (scalar[i - 1u] > scalar_order[i - 1u])
            return 0;
    }
    return 0;
}

static int
element_valid(const uint8_t element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN])
{
    return !all_zero(element, PRP_DISCOVERY_VOPRF_ELEMENT_LEN) &&
        crypto_core_ristretto255_is_valid_point(element) == 1;
}

static int
scalar_mult(uint8_t output[32], const uint8_t scalar[32],
    const uint8_t element[32])
{
    if (all_zero(scalar, 32u) || all_zero(element, 32u)) {
        memset(output, 0, 32u);
        return PRP_OK;
    }
    return crypto_scalarmult_ristretto255(output, scalar, element) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}

static int
scalar_mult_base(uint8_t output[32], const uint8_t scalar[32])
{
    if (all_zero(scalar, 32u)) {
        memset(output, 0, 32u);
        return PRP_OK;
    }
    return crypto_scalarmult_ristretto255_base(output, scalar) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}

static int
sha512_xmd(const uint8_t *message, size_t message_len, const uint8_t *prefix,
    size_t prefix_len, uint8_t output[64])
{
    crypto_hash_sha512_state state;
    uint8_t b0[64], zero_pad[128] = {0};
    uint8_t length[2] = { 0u, 64u }, separator = 0u, one = 1u;
    uint8_t dst_len;
    size_t full_dst_len = prefix_len + sizeof(context_string) - 1u;

    if (message == NULL || message_len > UINT16_MAX || full_dst_len > 255u)
        return PRP_ERR_ARGUMENT;
    dst_len = (uint8_t)full_dst_len;
    crypto_hash_sha512_init(&state);
    crypto_hash_sha512_update(&state, zero_pad, sizeof(zero_pad));
    crypto_hash_sha512_update(&state, message, (unsigned long long)message_len);
    crypto_hash_sha512_update(&state, length, sizeof(length));
    crypto_hash_sha512_update(&state, &separator, 1u);
    crypto_hash_sha512_update(&state, prefix, (unsigned long long)prefix_len);
    crypto_hash_sha512_update(&state, context_string,
        sizeof(context_string) - 1u);
    crypto_hash_sha512_update(&state, &dst_len, 1u);
    crypto_hash_sha512_final(&state, b0);

    crypto_hash_sha512_init(&state);
    crypto_hash_sha512_update(&state, b0, sizeof(b0));
    crypto_hash_sha512_update(&state, &one, 1u);
    crypto_hash_sha512_update(&state, prefix, (unsigned long long)prefix_len);
    crypto_hash_sha512_update(&state, context_string,
        sizeof(context_string) - 1u);
    crypto_hash_sha512_update(&state, &dst_len, 1u);
    crypto_hash_sha512_final(&state, output);
    sodium_memzero(b0, sizeof(b0));
    return PRP_OK;
}

static int
hash_to_group(const uint8_t *input, size_t input_len, uint8_t element[32])
{
    static const uint8_t prefix[] = "HashToGroup-";
    uint8_t uniform[64];
    int rc;

    rc = sha512_xmd(input, input_len, prefix, sizeof(prefix) - 1u, uniform);
    if (rc == PRP_OK)
        rc = crypto_core_ristretto255_from_hash(element, uniform) == 0 &&
            element_valid(element) ? PRP_OK : PRP_ERR_CRYPTO;
    sodium_memzero(uniform, sizeof(uniform));
    return rc;
}

static int
hash_to_scalar(const uint8_t *input, size_t input_len, uint8_t scalar[32])
{
    static const uint8_t prefix[] = "HashToScalar-";
    uint8_t uniform[64];
    int rc;

    rc = sha512_xmd(input, input_len, prefix, sizeof(prefix) - 1u, uniform);
    if (rc == PRP_OK)
        crypto_core_ristretto255_scalar_reduce(scalar, uniform);
    sodium_memzero(uniform, sizeof(uniform));
    return rc;
}

static void
hash_update_u16(crypto_hash_sha512_state *state, uint16_t value)
{
    uint8_t encoded[2];

    write_u16(encoded, value);
    crypto_hash_sha512_update(state, encoded, sizeof(encoded));
}

static int
composite(const uint8_t public_key[32], const uint8_t blinded[32],
    const uint8_t evaluated[32], uint8_t m[32], uint8_t z[32])
{
    static const uint8_t seed_prefix[] = "Seed-";
    static const uint8_t composite_suffix[] = "Composite";
    crypto_hash_sha512_state state;
    uint8_t seed[64], transcript[145], d[32];
    size_t offset = 0u;
    int rc;

    crypto_hash_sha512_init(&state);
    hash_update_u16(&state, 32u);
    crypto_hash_sha512_update(&state, public_key, 32u);
    hash_update_u16(&state,
        (uint16_t)(sizeof(seed_prefix) - 1u + sizeof(context_string) - 1u));
    crypto_hash_sha512_update(&state, seed_prefix, sizeof(seed_prefix) - 1u);
    crypto_hash_sha512_update(&state, context_string,
        sizeof(context_string) - 1u);
    crypto_hash_sha512_final(&state, seed);

    write_u16(transcript + offset, 64u);
    offset += 2u;
    memcpy(transcript + offset, seed, sizeof(seed));
    offset += sizeof(seed);
    write_u16(transcript + offset, 0u);
    offset += 2u;
    write_u16(transcript + offset, 32u);
    offset += 2u;
    memcpy(transcript + offset, blinded, 32u);
    offset += 32u;
    write_u16(transcript + offset, 32u);
    offset += 2u;
    memcpy(transcript + offset, evaluated, 32u);
    offset += 32u;
    memcpy(transcript + offset, composite_suffix,
        sizeof(composite_suffix) - 1u);
    offset += sizeof(composite_suffix) - 1u;
    rc = hash_to_scalar(transcript, offset, d);
    if (rc == PRP_OK)
        rc = scalar_mult(m, d, blinded);
    if (rc == PRP_OK)
        rc = scalar_mult(z, d, evaluated);
    sodium_memzero(seed, sizeof(seed));
    sodium_memzero(d, sizeof(d));
    sodium_memzero(transcript, sizeof(transcript));
    return rc;
}

static int
challenge(const uint8_t public_key[32], const uint8_t m[32],
    const uint8_t z[32], const uint8_t t2[32], const uint8_t t3[32],
    uint8_t result[32])
{
    static const uint8_t suffix[] = "Challenge";
    uint8_t transcript[179];
    const uint8_t *elements[5] = { public_key, m, z, t2, t3 };
    size_t i, offset = 0u;

    for (i = 0u; i < 5u; i++) {
        write_u16(transcript + offset, 32u);
        offset += 2u;
        memcpy(transcript + offset, elements[i], 32u);
        offset += 32u;
    }
    memcpy(transcript + offset, suffix, sizeof(suffix) - 1u);
    offset += sizeof(suffix) - 1u;
    return hash_to_scalar(transcript, offset, result);
}

static int
final_hash(const uint8_t *input, size_t input_len,
    const uint8_t element[32], uint8_t output[64])
{
    static const uint8_t suffix[] = "Finalize";
    crypto_hash_sha512_state state;

    if (input == NULL || input_len == 0u || input_len > UINT16_MAX)
        return PRP_ERR_ARGUMENT;
    crypto_hash_sha512_init(&state);
    hash_update_u16(&state, (uint16_t)input_len);
    crypto_hash_sha512_update(&state, input, (unsigned long long)input_len);
    hash_update_u16(&state, 32u);
    crypto_hash_sha512_update(&state, element, 32u);
    crypto_hash_sha512_update(&state, suffix, sizeof(suffix) - 1u);
    crypto_hash_sha512_final(&state, output);
    return PRP_OK;
}

int
prp_discovery_voprf_available(void)
{
    return backend_ready() ? PRP_OK : PRP_ERR_POLICY;
}

int
prp_discovery_voprf_public_key(const uint8_t secret_key[32],
    uint8_t public_key[32])
{
    if (!backend_ready() || secret_key == NULL || public_key == NULL ||
        !scalar_canonical(secret_key, 1))
        return PRP_ERR_ARGUMENT;
    return crypto_scalarmult_ristretto255_base(public_key, secret_key) == 0 ?
        PRP_OK : PRP_ERR_CRYPTO;
}

int
prp_discovery_voprf_keypair_generate(uint8_t secret_key[32],
    uint8_t public_key[32])
{
#ifdef PRP_VOPRF_REQUIRE_PLATFORM_RANDOM
    (void)secret_key;
    (void)public_key;
    return PRP_ERR_UNAVAILABLE;
#else
    if (!backend_ready() || secret_key == NULL || public_key == NULL)
        return PRP_ERR_ARGUMENT;
    crypto_core_ristretto255_scalar_random(secret_key);
    if (prp_discovery_voprf_public_key(secret_key, public_key) != PRP_OK) {
        sodium_memzero(secret_key, 32u);
        return PRP_ERR_CRYPTO;
    }
    return PRP_OK;
#endif
}

int
prp_discovery_voprf_keypair_generate_with_platform(uint8_t secret_key[32],
    uint8_t public_key[32], const prp_platform_t *platform)
{
    int rc;

    if (!backend_ready() || secret_key == NULL || public_key == NULL)
        return PRP_ERR_ARGUMENT;
    rc = random_scalar_with_platform(platform, secret_key);
    if (rc == PRP_OK)
        rc = prp_discovery_voprf_public_key(secret_key, public_key);
    if (rc != PRP_OK)
        sodium_memzero(secret_key, 32u);
    return rc;
}

int
prp_discovery_voprf_blind_with_scalar(const uint8_t *input, size_t input_len,
    const uint8_t blind[32], uint8_t blinded_element[32])
{
    uint8_t element[32];
    int rc;

    if (!backend_ready() || input == NULL || input_len == 0u ||
        input_len > UINT16_MAX || blind == NULL || blinded_element == NULL ||
        !scalar_canonical(blind, 1))
        return PRP_ERR_ARGUMENT;
    rc = hash_to_group(input, input_len, element);
    if (rc == PRP_OK && crypto_scalarmult_ristretto255(blinded_element,
        blind, element) != 0)
        rc = PRP_ERR_CRYPTO;
    sodium_memzero(element, sizeof(element));
    return rc;
}

int
prp_discovery_voprf_blind(const uint8_t *input, size_t input_len,
    uint8_t blind[32], uint8_t blinded_element[32])
{
#ifdef PRP_VOPRF_REQUIRE_PLATFORM_RANDOM
    (void)input;
    (void)input_len;
    (void)blind;
    (void)blinded_element;
    return PRP_ERR_UNAVAILABLE;
#else
    int rc;

    if (!backend_ready() || blind == NULL)
        return PRP_ERR_ARGUMENT;
    crypto_core_ristretto255_scalar_random(blind);
    rc = prp_discovery_voprf_blind_with_scalar(input, input_len, blind,
        blinded_element);
    if (rc != PRP_OK)
        sodium_memzero(blind, 32u);
    return rc;
#endif
}

int
prp_discovery_voprf_blind_with_platform(const uint8_t *input,
    size_t input_len, uint8_t blind[32], uint8_t blinded_element[32],
    const prp_platform_t *platform)
{
    int rc;

    if (!backend_ready() || blind == NULL)
        return PRP_ERR_ARGUMENT;
    rc = random_scalar_with_platform(platform, blind);
    if (rc == PRP_OK)
        rc = prp_discovery_voprf_blind_with_scalar(input, input_len, blind,
            blinded_element);
    if (rc != PRP_OK)
        sodium_memzero(blind, 32u);
    return rc;
}

static int
evaluate_with_scalar(const uint8_t secret_key[32],
    const uint8_t blinded[32], const uint8_t proof_scalar[32],
    uint8_t evaluated[32], uint8_t proof[64])
{
    uint8_t public_key[32], m[32], z[32], t2[32], t3[32], product[32];
    int rc;

    if (!backend_ready() || secret_key == NULL || blinded == NULL ||
        proof_scalar == NULL || evaluated == NULL || proof == NULL ||
        !scalar_canonical(secret_key, 1) ||
        !scalar_canonical(proof_scalar, 1) || !element_valid(blinded))
        return PRP_ERR_ARGUMENT;
    rc = prp_discovery_voprf_public_key(secret_key, public_key);
    if (rc == PRP_OK && crypto_scalarmult_ristretto255(evaluated,
        secret_key, blinded) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        rc = composite(public_key, blinded, evaluated, m, z);
    if (rc == PRP_OK)
        rc = scalar_mult_base(t2, proof_scalar);
    if (rc == PRP_OK)
        rc = scalar_mult(t3, proof_scalar, m);
    if (rc == PRP_OK)
        rc = challenge(public_key, m, z, t2, t3, proof);
    if (rc == PRP_OK) {
        crypto_core_ristretto255_scalar_mul(product, proof, secret_key);
        crypto_core_ristretto255_scalar_sub(proof + 32u, proof_scalar,
            product);
    }
    sodium_memzero(product, sizeof(product));
    sodium_memzero(m, sizeof(m));
    sodium_memzero(z, sizeof(z));
    sodium_memzero(t2, sizeof(t2));
    sodium_memzero(t3, sizeof(t3));
    return rc;
}

int
prp_discovery_voprf_evaluate(const uint8_t secret_key[32],
    const uint8_t blinded[32], uint8_t evaluated[32], uint8_t proof[64])
{
#ifdef PRP_VOPRF_REQUIRE_PLATFORM_RANDOM
    (void)secret_key;
    (void)blinded;
    (void)evaluated;
    (void)proof;
    return PRP_ERR_UNAVAILABLE;
#else
    uint8_t proof_scalar[32];
    int rc;

    if (!backend_ready())
        return PRP_ERR_POLICY;
    crypto_core_ristretto255_scalar_random(proof_scalar);
    rc = evaluate_with_scalar(secret_key, blinded,
        proof_scalar, evaluated, proof);
    sodium_memzero(proof_scalar, sizeof(proof_scalar));
    return rc;
#endif
}

int
prp_discovery_voprf_evaluate_with_platform(const uint8_t secret_key[32],
    const uint8_t blinded[32], uint8_t evaluated[32], uint8_t proof[64],
    const prp_platform_t *platform)
{
    uint8_t proof_scalar[32];
    int rc;

    if (!backend_ready())
        return PRP_ERR_POLICY;
    rc = random_scalar_with_platform(platform, proof_scalar);
    if (rc == PRP_OK)
        rc = evaluate_with_scalar(secret_key, blinded, proof_scalar,
            evaluated, proof);
    sodium_memzero(proof_scalar, sizeof(proof_scalar));
    return rc;
}

static int
verify_proof(const uint8_t public_key[32], const uint8_t blinded[32],
    const uint8_t evaluated[32], const uint8_t proof[64])
{
    uint8_t m[32], z[32], sg[32], cpk[32], sm[32], cz[32], t2[32], t3[32];
    uint8_t expected[32];
    int rc;

    if (!element_valid(public_key) || !element_valid(blinded) ||
        !element_valid(evaluated) || !scalar_canonical(proof, 0) ||
        !scalar_canonical(proof + 32u, 0))
        return PRP_ERR_CRYPTO;
    rc = composite(public_key, blinded, evaluated, m, z);
    if (rc == PRP_OK)
        rc = scalar_mult_base(sg, proof + 32u);
    if (rc == PRP_OK)
        rc = scalar_mult(cpk, proof, public_key);
    if (rc == PRP_OK && crypto_core_ristretto255_add(t2, sg, cpk) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        rc = scalar_mult(sm, proof + 32u, m);
    if (rc == PRP_OK)
        rc = scalar_mult(cz, proof, z);
    if (rc == PRP_OK && crypto_core_ristretto255_add(t3, sm, cz) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        rc = challenge(public_key, m, z, t2, t3, expected);
    if (rc == PRP_OK && sodium_memcmp(expected, proof, 32u) != 0)
        rc = PRP_ERR_CRYPTO;
    sodium_memzero(m, sizeof(m));
    sodium_memzero(z, sizeof(z));
    sodium_memzero(sg, sizeof(sg));
    sodium_memzero(cpk, sizeof(cpk));
    sodium_memzero(sm, sizeof(sm));
    sodium_memzero(cz, sizeof(cz));
    sodium_memzero(t2, sizeof(t2));
    sodium_memzero(t3, sizeof(t3));
    sodium_memzero(expected, sizeof(expected));
    return rc;
}

int
prp_discovery_voprf_finalize(const uint8_t *input, size_t input_len,
    const uint8_t blind[32], const uint8_t blinded[32],
    const uint8_t evaluated[32], const uint8_t proof[64],
    const uint8_t public_key[32], uint8_t output[64])
{
    uint8_t inverse[32], unblinded[32];
    int rc;

    if (!backend_ready() || input == NULL || input_len == 0u ||
        input_len > UINT16_MAX || blind == NULL || blinded == NULL ||
        evaluated == NULL || proof == NULL || public_key == NULL ||
        output == NULL || !scalar_canonical(blind, 1))
        return PRP_ERR_ARGUMENT;
    rc = verify_proof(public_key, blinded, evaluated, proof);
    if (rc == PRP_OK && crypto_core_ristretto255_scalar_invert(inverse,
        blind) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK && crypto_scalarmult_ristretto255(unblinded, inverse,
        evaluated) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        rc = final_hash(input, input_len, unblinded, output);
    sodium_memzero(inverse, sizeof(inverse));
    sodium_memzero(unblinded, sizeof(unblinded));
    return rc;
}

int
prp_discovery_voprf_evaluate_direct(const uint8_t *input, size_t input_len,
    const uint8_t secret_key[32], uint8_t output[64])
{
    uint8_t element[32], evaluated[32];
    int rc;

    if (!backend_ready() || input == NULL || input_len == 0u ||
        input_len > UINT16_MAX || secret_key == NULL || output == NULL ||
        !scalar_canonical(secret_key, 1))
        return PRP_ERR_ARGUMENT;
    rc = hash_to_group(input, input_len, element);
    if (rc == PRP_OK && crypto_scalarmult_ristretto255(evaluated, secret_key,
        element) != 0)
        rc = PRP_ERR_CRYPTO;
    if (rc == PRP_OK)
        rc = final_hash(input, input_len, evaluated, output);
    sodium_memzero(element, sizeof(element));
    sodium_memzero(evaluated, sizeof(evaluated));
    return rc;
}

int
prp_discovery_voprf_lookup_token(const uint8_t output[64], uint8_t token[16])
{
    crypto_hash_sha512_state state;
    uint8_t digest[64];

    if (!backend_ready() || output == NULL || token == NULL)
        return PRP_ERR_ARGUMENT;
    crypto_hash_sha512_init(&state);
    hash_update_u16(&state, (uint16_t)(sizeof(token_domain) - 1u));
    crypto_hash_sha512_update(&state, token_domain, sizeof(token_domain) - 1u);
    hash_update_u16(&state, 64u);
    crypto_hash_sha512_update(&state, output, 64u);
    crypto_hash_sha512_final(&state, digest);
    memcpy(token, digest, 16u);
    sodium_memzero(digest, sizeof(digest));
    return PRP_OK;
}

#else

int prp_discovery_voprf_available(void) { return PRP_ERR_POLICY; }
#if defined(__GNUC__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Warray-parameter"
#endif
#define VOPRF_UNAVAILABLE(name, signature) \
    int name signature { return PRP_ERR_POLICY; }
VOPRF_UNAVAILABLE(prp_discovery_voprf_keypair_generate,
    (uint8_t *a, uint8_t *b))
VOPRF_UNAVAILABLE(prp_discovery_voprf_keypair_generate_with_platform,
    (uint8_t *a, uint8_t *b, const prp_platform_t *c))
VOPRF_UNAVAILABLE(prp_discovery_voprf_public_key,
    (const uint8_t *a, uint8_t *b))
VOPRF_UNAVAILABLE(prp_discovery_voprf_blind,
    (const uint8_t *a, size_t b, uint8_t *c, uint8_t *d))
VOPRF_UNAVAILABLE(prp_discovery_voprf_blind_with_platform,
    (const uint8_t *a, size_t b, uint8_t *c, uint8_t *d,
     const prp_platform_t *e))
VOPRF_UNAVAILABLE(prp_discovery_voprf_blind_with_scalar,
    (const uint8_t *a, size_t b, const uint8_t *c, uint8_t *d))
VOPRF_UNAVAILABLE(prp_discovery_voprf_evaluate,
    (const uint8_t *a, const uint8_t *b, uint8_t *c, uint8_t *d))
VOPRF_UNAVAILABLE(prp_discovery_voprf_evaluate_with_platform,
    (const uint8_t *a, const uint8_t *b, uint8_t *c, uint8_t *d,
     const prp_platform_t *e))
VOPRF_UNAVAILABLE(prp_discovery_voprf_finalize,
    (const uint8_t *a, size_t b, const uint8_t *c, const uint8_t *d,
     const uint8_t *e, const uint8_t *f, const uint8_t *g, uint8_t *h))
VOPRF_UNAVAILABLE(prp_discovery_voprf_evaluate_direct,
    (const uint8_t *a, size_t b, const uint8_t *c, uint8_t *d))
VOPRF_UNAVAILABLE(prp_discovery_voprf_lookup_token,
    (const uint8_t *a, uint8_t *b))
#undef VOPRF_UNAVAILABLE
#if defined(__GNUC__)
#pragma GCC diagnostic pop
#endif

#endif

static int
record_prefix_encode(const uint8_t magic[4], uint8_t kind,
    uint32_t generation, uint8_t *out, size_t out_len, size_t required)
{
    if (generation == 0u || out == NULL)
        return PRP_ERR_ARGUMENT;
    if (out_len < required)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    memcpy(out, magic, 4u);
    out[4] = PRP_DISCOVERY_VOPRF_VERSION;
    out[5] = kind;
    write_u16(out + 6u,
        PRP_DISCOVERY_VOPRF_PROFILE_RISTRETTO255_SHA512_128);
    write_u32(out + 8u, generation);
    return PRP_OK;
}

static int
record_prefix_decode(const uint8_t *data, size_t data_len,
    const uint8_t magic[4], uint8_t kind, size_t expected)
{
    if (data == NULL || data_len < expected)
        return PRP_ERR_SHORT;
    if (data_len != expected)
        return PRP_ERR_PROTOCOL;
    if (memcmp(data, magic, 4u) != 0)
        return PRP_ERR_MARKER;
    if (data[4] != PRP_DISCOVERY_VOPRF_VERSION)
        return PRP_ERR_VERSION;
    if (data[5] != kind || read_u16(data + 6u) !=
        PRP_DISCOVERY_VOPRF_PROFILE_RISTRETTO255_SHA512_128 ||
        read_u32(data + 8u) == 0u)
        return PRP_ERR_PROTOCOL;
    return PRP_OK;
}

int
prp_discovery_voprf_key_record_encode(
    const prp_discovery_voprf_key_record_t *record, uint8_t *out,
    size_t out_len)
{
    int rc;

    if (record == NULL || all_zero(record->public_key, 32u))
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_encode(key_magic, 1u,
        record->relationship_generation, out, out_len,
        PRP_DISCOVERY_VOPRF_KEY_RECORD_LEN);
    if (rc == PRP_OK)
        memcpy(out + 12u, record->public_key, 32u);
    return rc;
}

int
prp_discovery_voprf_key_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_voprf_key_record_t *record)
{
    int rc;

    if (record == NULL)
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_decode(data, data_len, key_magic, 1u,
        PRP_DISCOVERY_VOPRF_KEY_RECORD_LEN);
    if (rc != PRP_OK)
        return rc;
    record->relationship_generation = read_u32(data + 8u);
    memcpy(record->public_key, data + 12u, 32u);
    return all_zero(record->public_key, 32u) ? PRP_ERR_PROTOCOL : PRP_OK;
}

int
prp_discovery_voprf_request_record_encode(
    const prp_discovery_voprf_request_record_t *record, uint8_t *out,
    size_t out_len)
{
    int rc;

    if (record == NULL || all_zero(record->request_id, 16u) ||
        all_zero(record->blinded_element, 32u))
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_encode(request_magic, 2u,
        record->relationship_generation, out, out_len,
        PRP_DISCOVERY_VOPRF_REQUEST_RECORD_LEN);
    if (rc == PRP_OK) {
        memcpy(out + 12u, record->request_id, 16u);
        memcpy(out + 28u, record->blinded_element, 32u);
    }
    return rc;
}

int
prp_discovery_voprf_request_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_voprf_request_record_t *record)
{
    int rc;

    if (record == NULL)
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_decode(data, data_len, request_magic, 2u,
        PRP_DISCOVERY_VOPRF_REQUEST_RECORD_LEN);
    if (rc != PRP_OK)
        return rc;
    record->relationship_generation = read_u32(data + 8u);
    memcpy(record->request_id, data + 12u, 16u);
    memcpy(record->blinded_element, data + 28u, 32u);
    return all_zero(record->request_id, 16u) ||
        all_zero(record->blinded_element, 32u) ? PRP_ERR_PROTOCOL : PRP_OK;
}

int
prp_discovery_voprf_response_record_encode(
    const prp_discovery_voprf_response_record_t *record, uint8_t *out,
    size_t out_len)
{
    int rc;

    if (record == NULL || all_zero(record->request_id, 16u) ||
        all_zero(record->evaluated_element, 32u))
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_encode(response_magic, 3u,
        record->relationship_generation, out, out_len,
        PRP_DISCOVERY_VOPRF_RESPONSE_RECORD_LEN);
    if (rc == PRP_OK) {
        memcpy(out + 12u, record->request_id, 16u);
        memcpy(out + 28u, record->evaluated_element, 32u);
        memcpy(out + 60u, record->proof, 64u);
    }
    return rc;
}

int
prp_discovery_voprf_response_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_voprf_response_record_t *record)
{
    int rc;

    if (record == NULL)
        return PRP_ERR_ARGUMENT;
    rc = record_prefix_decode(data, data_len, response_magic, 3u,
        PRP_DISCOVERY_VOPRF_RESPONSE_RECORD_LEN);
    if (rc != PRP_OK)
        return rc;
    record->relationship_generation = read_u32(data + 8u);
    memcpy(record->request_id, data + 12u, 16u);
    memcpy(record->evaluated_element, data + 28u, 32u);
    memcpy(record->proof, data + 60u, 64u);
    return all_zero(record->request_id, 16u) ||
        all_zero(record->evaluated_element, 32u) ?
        PRP_ERR_PROTOCOL : PRP_OK;
}
