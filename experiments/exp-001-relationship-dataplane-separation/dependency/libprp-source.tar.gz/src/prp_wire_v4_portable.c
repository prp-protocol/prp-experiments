#include "prp_wire_v4_portable.h"

#include "prp_crypto_backend.h"
#include "prp_hash.h"
#include "prp_memory.h"

#include <string.h>

static int status_from_wire(int status)
{
    switch (status) {
    case PRP_WIRE_V4_OK: return PRP_OK;
    case PRP_WIRE_V4_EINVAL: return PRP_ERR_ARGUMENT;
    case PRP_WIRE_V4_ETRUNC: return PRP_ERR_SHORT;
    case PRP_WIRE_V4_ERANGE: return PRP_ERR_OUTPUT_TOO_SMALL;
    case PRP_WIRE_V4_ESUITE: return PRP_ERR_STATE;
    case PRP_WIRE_V4_EREPLAY: return PRP_ERR_ALREADY;
    default: return PRP_ERR_PROTOCOL;
    }
}

int prp_wire_v4_session_suite_capabilities(uint16_t session_suite_id,
    uint32_t *capabilities)
{
    struct prp_wire_v4_session_crypto_desc crypto;
    struct prp_wire_v4_session_suite_desc suite;
    uint32_t value = 0U;
    int key_establishment = 0;
    int kdf = 0;
    int aead = 0;

    if (capabilities == NULL)
        return PRP_ERR_ARGUMENT;
    *capabilities = 0U;
    if (prp_wire_v4_session_suite_get(session_suite_id, &suite) ||
        prp_wire_v4_session_crypto_get(session_suite_id, &crypto))
        return PRP_ERR_ARGUMENT;
    value = PRP_WIRE_V4_SESSION_CAP_REGISTERED |
        PRP_WIRE_V4_SESSION_CAP_TRANSCRIPT_HASH;

    switch (session_suite_id) {
    case PRP_WIRE_V4_SESSION_NONE_BLAKE3:
    case PRP_WIRE_V4_SESSION_NONE_SHA256:
        key_establishment = 1;
        break;
    case PRP_WIRE_V4_SESSION_X25519_CHACHA20POLY1305_BLAKE3:
    case PRP_WIRE_V4_SESSION_X25519_AES256GCM_BLAKE3:
        key_establishment = prp_crypto_backend_capable(
            PRP_CRYPTO_SUITE_X25519, PRP_CRYPTO_OP_DH);
        break;
    case PRP_WIRE_V4_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3:
    case PRP_WIRE_V4_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3:
        key_establishment = prp_crypto_backend_capable(
            PRP_CRYPTO_SUITE_X25519, PRP_CRYPTO_OP_DH);
        break;
    case PRP_WIRE_V4_SESSION_MLKEM768_AES256GCM_SHA256:
    case PRP_WIRE_V4_SESSION_MLKEM1024_AES256GCM_SHA384:
        key_establishment = 1;
        break;
    default:
        break;
    }
    if (key_establishment && crypto.kdf != PRP_WIRE_V4_KDF_NONE)
        value |= PRP_WIRE_V4_SESSION_CAP_KEY_ESTABLISHMENT;
    kdf = crypto.kdf == PRP_WIRE_V4_KDF_NONE ||
        crypto.kdf == PRP_WIRE_V4_KDF_BLAKE3_DERIVE_KEY ||
        crypto.kdf == PRP_WIRE_V4_KDF_HKDF_SHA256 ||
        crypto.kdf == PRP_WIRE_V4_KDF_HKDF_SHA384;
    if (crypto.kdf != PRP_WIRE_V4_KDF_NONE && kdf)
        value |= PRP_WIRE_V4_SESSION_CAP_KDF;
    aead = crypto.aead == PRP_WIRE_V4_AEAD_NONE ||
        crypto.aead == PRP_WIRE_V4_AEAD_CHACHA20_POLY1305 ||
        (crypto.aead == PRP_WIRE_V4_AEAD_AES_256_GCM &&
         prp_crypto_backend_capable(PRP_CRYPTO_SUITE_AES_256_GCM,
             PRP_CRYPTO_OP_AEAD_ENCRYPT) &&
         prp_crypto_backend_capable(PRP_CRYPTO_SUITE_AES_256_GCM,
             PRP_CRYPTO_OP_AEAD_DECRYPT));
    if (crypto.aead != PRP_WIRE_V4_AEAD_NONE && aead)
        value |= PRP_WIRE_V4_SESSION_CAP_AEAD;
    if (key_establishment && kdf && aead)
        value |= PRP_WIRE_V4_SESSION_CAP_COMPLETE;
    *capabilities = value;
    return PRP_OK;
}

int prp_wire_v4_identity_suite_capabilities(uint16_t identity_suite_id,
    uint32_t *capabilities)
{
    struct prp_wire_v4_identity_suite_desc suite;
    uint32_t value;
    int key_management = 0;
    int proof_sign = 0;
    int proof_verify;

    if (capabilities == NULL)
        return PRP_ERR_ARGUMENT;
    *capabilities = 0U;
    if (prp_wire_v4_identity_suite_get(identity_suite_id, &suite))
        return PRP_ERR_ARGUMENT;
    value = PRP_WIRE_V4_IDENTITY_CAP_REGISTERED |
        PRP_WIRE_V4_IDENTITY_CAP_STRONG_ID;
    proof_verify = prp_crypto_identity_proof_capable(
        (uint8_t)identity_suite_id);
    switch (identity_suite_id) {
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3:
    case PRP_SELF_CERT_ID_PROOF_ED25519CTX:
    case PRP_SELF_CERT_ID_PROOF_MLDSA65:
    case PRP_SELF_CERT_ID_PROOF_MLDSA87:
    case PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87:
        key_management = 1;
        proof_sign = 1;
        break;
    default:
        break;
    }
    if (proof_verify)
        value |= PRP_WIRE_V4_IDENTITY_CAP_PROOF_VERIFY;
    if (key_management)
        value |= PRP_WIRE_V4_IDENTITY_CAP_KEY_MANAGEMENT;
    if (proof_sign)
        value |= PRP_WIRE_V4_IDENTITY_CAP_PROOF_SIGN;
    if (proof_verify && key_management && proof_sign)
        value |= PRP_WIRE_V4_IDENTITY_CAP_COMPLETE;
    *capabilities = value;
    return PRP_OK;
}

static int add_tlv(uint8_t type, const uint8_t *value, size_t value_len,
    uint8_t *wire, size_t capacity, size_t *position)
{
    if ((!value && value_len) || value_len > UINT16_MAX)
        return PRP_ERR_ARGUMENT;
    if (*position > capacity ||
        capacity - *position < PRP_WIRE_V4_TLV_HEADER_LEN + value_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    wire[(*position)++] = type;
    prp_wire_v4_put_be16(wire + *position, (uint16_t)value_len);
    *position += 2U;
    if (value_len)
        memcpy(wire + *position, value, value_len);
    *position += value_len;
    return PRP_OK;
}

static int hs2_fields_validate(const prp_wire_v4_hs2_fields_t *fields,
    struct prp_wire_v4_session_suite_desc *session,
    struct prp_wire_v4_identity_suite_desc *identity)
{
    size_t expected_kem;

    if (!fields || !fields->nonce || !fields->identity_public_key ||
        fields->nonce_len != PRP_WIRE_V4_HS2_NONCE_LEN ||
        prp_wire_v4_session_suite_get(fields->session_suite_id, session) ||
        prp_wire_v4_identity_suite_get(fields->identity_suite_id, identity) ||
        fields->identity_public_key_len != identity->public_key_len ||
        fields->ephemeral_key_len != session->ephemeral_key_len ||
        (!!fields->ephemeral_key != !!session->ephemeral_key_len) ||
        (!fields->discovery && fields->discovery_len))
        return PRP_ERR_ARGUMENT;
    if (fields->kind != PRP_WIRE_V4_HS2_M1 &&
        fields->kind != PRP_WIRE_V4_HS2_M2)
        return PRP_ERR_ARGUMENT;
    expected_kem = fields->kind == PRP_WIRE_V4_HS2_M1 ?
        session->kem_public_key_len : session->kem_ciphertext_len;
    if (fields->kem_value_len != expected_kem ||
        (!!fields->kem_value != !!expected_kem))
        return PRP_ERR_ARGUMENT;
    if (fields->kind == PRP_WIRE_V4_HS2_M1)
        return !fields->m1_binding && !fields->m1_binding_len &&
            !fields->session_generation ? PRP_OK : PRP_ERR_ARGUMENT;
    return fields->m1_binding &&
        fields->m1_binding_len == session->commitment_len &&
        fields->session_generation ? PRP_OK : PRP_ERR_ARGUMENT;
}

int prp_wire_v4_hs2_prefix_encode(const prp_wire_v4_hs2_fields_t *fields,
    uint8_t *wire, size_t capacity, size_t *written)
{
    struct prp_wire_v4_session_suite_desc session;
    struct prp_wire_v4_identity_suite_desc identity;
    struct prp_wire_v4_hs2_header header;
    uint8_t identity_suite[2], generation[4];
    size_t pos = PRP_WIRE_V4_HS2_HEADER_LEN;
    int result;

    if (!wire || !written)
        return PRP_ERR_ARGUMENT;
    *written = 0;
    result = hs2_fields_validate(fields, &session, &identity);
    if (result != PRP_OK)
        return result;
    header.session_suite_id = fields->session_suite_id;
    header.kind = fields->kind;
    result = status_from_wire(prp_wire_v4_hs2_header_encode(&header, wire,
        capacity));
    if (result != PRP_OK)
        return result;
    if (fields->discovery_len)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_DISCOVERY,
            fields->discovery, fields->discovery_len, wire, capacity, &pos);
    if (result == PRP_OK)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_NONCE, fields->nonce,
            fields->nonce_len, wire, capacity, &pos);
    if (result == PRP_OK && fields->ephemeral_key)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_EPHEMERAL_KEY,
            fields->ephemeral_key, fields->ephemeral_key_len,
            wire, capacity, &pos);
    if (result == PRP_OK && fields->kem_value)
        result = add_tlv(fields->kind == PRP_WIRE_V4_HS2_M1 ?
                PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY :
                PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT,
            fields->kem_value, fields->kem_value_len, wire, capacity, &pos);
    prp_wire_v4_put_be16(identity_suite, fields->identity_suite_id);
    if (result == PRP_OK)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_IDENTITY_SUITE,
            identity_suite, sizeof(identity_suite), wire, capacity, &pos);
    if (result == PRP_OK)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_IDENTITY_PUBLIC_KEY,
            fields->identity_public_key, fields->identity_public_key_len,
            wire, capacity, &pos);
    if (result == PRP_OK && fields->m1_binding)
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_M1_BINDING,
            fields->m1_binding, fields->m1_binding_len,
            wire, capacity, &pos);
    if (result == PRP_OK && fields->session_generation) {
        prp_wire_v4_put_be32(generation, fields->session_generation);
        result = add_tlv(PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION,
            generation, sizeof(generation), wire, capacity, &pos);
    }
    if (result != PRP_OK)
        return result;
    *written = pos;
    return PRP_OK;
}

int prp_wire_v4_hs2_proof_append(uint16_t identity_suite_id,
    const uint8_t *proof, size_t proof_len, uint8_t *wire, size_t capacity,
    size_t *written)
{
    struct prp_wire_v4_identity_suite_desc identity;
    struct prp_wire_v4_hs2_view view;
    size_t pos;
    int result;

    if (!proof || !wire || !written ||
        prp_wire_v4_identity_suite_get(identity_suite_id, &identity) ||
        proof_len != identity.proof_len)
        return PRP_ERR_ARGUMENT;
    pos = *written;
    result = add_tlv(PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF, proof, proof_len,
        wire, capacity, &pos);
    if (result != PRP_OK)
        return result;
    result = status_from_wire(prp_wire_v4_hs2_validate(wire, pos, &view));
    if (result != PRP_OK || view.identity_suite_id != identity_suite_id)
        return PRP_ERR_PROTOCOL;
    *written = pos;
    return PRP_OK;
}

static int hash_preimage(uint8_t hash, const uint8_t *preimage,
    size_t preimage_len, uint8_t *output, size_t capacity, size_t *written)
{
    size_t output_len;
    int result;

    if (hash == PRP_WIRE_V4_HASH_BLAKE3)
        output_len = PRP_CRYPTO_HASH_BLAKE3_OUT_LEN;
    else if (hash == PRP_WIRE_V4_HASH_SHA256)
        output_len = PRP_CRYPTO_HASH_SHA256_OUT_LEN;
    else if (hash == PRP_WIRE_V4_HASH_SHA384)
        output_len = PRP_CRYPTO_HASH_SHA384_OUT_LEN;
    else
        return PRP_ERR_STATE;
    if (!output || capacity < output_len || !written)
        return PRP_ERR_ARGUMENT;
    if (hash == PRP_WIRE_V4_HASH_BLAKE3)
        result = prp_crypto_hash_blake3(preimage, preimage_len, output,
            output_len);
    else
        result = prp_crypto_hash_sha2_concat(
            hash == PRP_WIRE_V4_HASH_SHA256 ? 256U : 384U,
            preimage, preimage_len, NULL, 0U, output, output_len);
    if (result != PRP_CRYPTO_OK)
        return PRP_ERR_CRYPTO;
    *written = output_len;
    return PRP_OK;
}

int prp_wire_v4_hs2_identity_verify(const uint8_t *wire, size_t wire_len)
{
    struct prp_wire_v4_hs2_view view;
    struct prp_wire_v4_identity_crypto_desc crypto;
    const uint8_t *prefix;
    uint8_t digest[PRP_HASH_BLAKE3_OUT_LEN];
    size_t prefix_len;
    int result;

    if (!wire || prp_wire_v4_hs2_validate(wire, wire_len, &view) ||
        prp_wire_v4_identity_crypto_get(view.identity_suite_id, &crypto) ||
        prp_wire_v4_hs2_proof_prefix(wire, wire_len, &prefix, &prefix_len))
        return PRP_ERR_PROTOCOL;
    if (crypto.proof_algorithm == PRP_WIRE_V4_PROOF_ED25519_BLAKE3 ||
        crypto.proof_algorithm ==
            PRP_WIRE_V4_PROOF_ED25519_BLAKE3_MLDSA87) {
        if (prp_hash_blake3_concat((const uint8_t *)crypto.primary_context,
                crypto.primary_context_len, prefix, prefix_len, digest) != 0)
            return PRP_ERR_CRYPTO;
        result = prp_identity_proof_verify(1, view.public_key, 32,
            view.proof, 64, digest, sizeof(digest), NULL, 0);
        if (result != 0)
            return PRP_ERR_CRYPTO;
        if (crypto.proof_algorithm == PRP_WIRE_V4_PROOF_ED25519_BLAKE3)
            return PRP_OK;
        return prp_identity_proof_verify(4, view.public_key + 32,
            view.public_key_len - 32, view.proof + 64,
            view.proof_len - 64, prefix, prefix_len,
            (const uint8_t *)crypto.secondary_context,
            crypto.secondary_context_len) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
    }
    return prp_identity_proof_verify((uint8_t)view.identity_suite_id,
        view.public_key, view.public_key_len, view.proof, view.proof_len,
        prefix, prefix_len, (const uint8_t *)crypto.primary_context,
        crypto.primary_context_len) == 0 ? PRP_OK : PRP_ERR_CRYPTO;
}

int prp_wire_v4_hs2_extract(const uint8_t *wire, size_t wire_len,
    struct prp_wire_v4_hs2_view *view)
{
    if (!wire || !view)
        return PRP_ERR_ARGUMENT;
    return status_from_wire(prp_wire_v4_hs2_validate(wire, wire_len, view));
}

static int object_hash(uint16_t session_suite_id,
    int (*encode)(const uint8_t *, size_t, uint8_t *, size_t, size_t *),
    const uint8_t *object, size_t object_len,
    uint8_t *output, size_t capacity, size_t *written)
{
    struct prp_wire_v4_session_crypto_desc desc;
    uint8_t preimage[PRP_WIRE_V4_HS2_MAX_LEN + 64U];
    size_t preimage_len = 0;
    int result;

    if (prp_wire_v4_session_crypto_get(session_suite_id, &desc))
        return PRP_ERR_STATE;
    result = status_from_wire(encode(object, object_len, preimage,
        sizeof(preimage), &preimage_len));
    if (result == PRP_OK)
        result = hash_preimage(desc.transcript_hash, preimage, preimage_len,
            output, capacity, written);
    prp_crypto_secure_zero(preimage, sizeof(preimage));
    return result;
}

int prp_wire_v4_m1_binding(const uint8_t *m1, size_t m1_len,
    uint8_t *binding, size_t binding_capacity, size_t *binding_len)
{
    struct prp_wire_v4_hs2_view view;

    if (prp_wire_v4_hs2_validate(m1, m1_len, &view))
        return PRP_ERR_PROTOCOL;
    return object_hash(view.session_suite_id,
        prp_wire_v4_m1_binding_preimage_encode, m1, m1_len,
        binding, binding_capacity, binding_len);
}

int prp_wire_v4_fragment_commitment(const uint8_t *hs2, size_t hs2_len,
    uint8_t *commitment, size_t commitment_capacity, size_t *commitment_len)
{
    struct prp_wire_v4_hs2_view view;

    if (prp_wire_v4_hs2_validate(hs2, hs2_len, &view))
        return PRP_ERR_PROTOCOL;
    return object_hash(view.session_suite_id,
        prp_wire_v4_fragment_commitment_preimage_encode, hs2, hs2_len,
        commitment, commitment_capacity, commitment_len);
}

int prp_wire_v4_transcript_hash(const uint8_t *m1, size_t m1_len,
    const uint8_t *m2, size_t m2_len, uint8_t *transcript,
    size_t transcript_capacity, size_t *transcript_len)
{
    struct prp_wire_v4_hs2_view view;
    struct prp_wire_v4_session_crypto_desc desc;
    uint8_t preimage[2U * PRP_WIRE_V4_HS2_MAX_LEN + 64U];
    size_t preimage_len = 0;
    int result;

    if (prp_wire_v4_hs2_validate(m1, m1_len, &view) ||
        prp_wire_v4_session_crypto_get(view.session_suite_id, &desc))
        return PRP_ERR_PROTOCOL;
    result = status_from_wire(prp_wire_v4_transcript_preimage_encode(
        m1, m1_len, m2, m2_len, preimage, sizeof(preimage), &preimage_len));
    if (result == PRP_OK)
        result = hash_preimage(desc.transcript_hash, preimage, preimage_len,
            transcript, transcript_capacity, transcript_len);
    prp_crypto_secure_zero(preimage, sizeof(preimage));
    return result;
}

static int hmac_sha2(unsigned int bits, const uint8_t *key, size_t key_len,
    const uint8_t *data, size_t data_len, uint8_t *output)
{
    uint8_t key_block[128U];
    uint8_t inner[128U + 64U];
    uint8_t inner_hash[PRP_CRYPTO_HASH_SHA384_OUT_LEN];
    uint8_t outer[128U + PRP_CRYPTO_HASH_SHA384_OUT_LEN];
    size_t block_len = bits == 256U ? 64U : 128U;
    size_t digest_len = bits == 256U ? 32U : 48U;
    size_t index;
    int result = PRP_ERR_CRYPTO;

    if ((bits != 256U && bits != 384U) || key == NULL || output == NULL ||
            (data == NULL && data_len != 0U) || key_len > block_len ||
            data_len > 64U)
        return PRP_ERR_ARGUMENT;
    memset(key_block, 0, sizeof(key_block));
    memcpy(key_block, key, key_len);
    for (index = 0U; index < block_len; index++) {
        inner[index] = key_block[index] ^ 0x36U;
        outer[index] = key_block[index] ^ 0x5cU;
    }
    if (data_len != 0U)
        memcpy(inner + block_len, data, data_len);
    if (prp_crypto_hash_sha2_concat(bits, inner, block_len + data_len,
            NULL, 0U, inner_hash, digest_len) == PRP_CRYPTO_OK) {
        memcpy(outer + block_len, inner_hash, digest_len);
        if (prp_crypto_hash_sha2_concat(bits, outer,
                block_len + digest_len, NULL, 0U, output,
                digest_len) == PRP_CRYPTO_OK)
            result = PRP_OK;
    }
    prp_crypto_secure_zero(key_block, sizeof(key_block));
    prp_crypto_secure_zero(inner, sizeof(inner));
    prp_crypto_secure_zero(inner_hash, sizeof(inner_hash));
    prp_crypto_secure_zero(outer, sizeof(outer));
    return result;
}

static int hkdf_expand_direction(unsigned int bits, uint8_t scope,
    uint8_t direction, uint16_t session_suite_id, uint32_t generation,
    const uint8_t *prk, size_t digest_len, uint8_t output[32])
{
    uint8_t info[PRP_WIRE_V4_HKDF_INFO_LEN + 1U];
    uint8_t expanded[PRP_CRYPTO_HASH_SHA384_OUT_LEN];
    size_t info_len = 0U;
    int result;

    if (prp_wire_v4_hkdf_info_encode(scope, direction, session_suite_id,
            generation, info, sizeof(info) - 1U, &info_len) !=
            PRP_WIRE_V4_OK)
        return PRP_ERR_ARGUMENT;
    info[info_len++] = 1U;
    result = hmac_sha2(bits, prk, digest_len, info, info_len, expanded);
    if (result == PRP_OK)
        memcpy(output, expanded, 32U);
    prp_crypto_secure_zero(info, sizeof(info));
    prp_crypto_secure_zero(expanded, sizeof(expanded));
    return result;
}

int prp_wire_v4_traffic_keys(uint8_t scope, uint16_t session_suite_id,
    uint32_t generation, const uint8_t *transcript_hash,
    size_t transcript_hash_len, const uint8_t *ordered_shared_secret,
    size_t shared_secret_len, uint8_t initiator_to_responder[32],
    uint8_t responder_to_initiator[32])
{
    struct prp_wire_v4_session_crypto_desc desc;
    uint8_t material[PRP_WIRE_V4_TRAFFIC_MATERIAL_PREFIX_LEN + 48U + 64U];
    size_t material_len;
    int result;

    if (!initiator_to_responder || !responder_to_initiator ||
        prp_wire_v4_session_crypto_get(session_suite_id, &desc))
        return PRP_ERR_ARGUMENT;
    if (desc.kdf == PRP_WIRE_V4_KDF_HKDF_SHA256 ||
        desc.kdf == PRP_WIRE_V4_KDF_HKDF_SHA384) {
        uint8_t prk[PRP_CRYPTO_HASH_SHA384_OUT_LEN];
        size_t digest_len = desc.kdf == PRP_WIRE_V4_KDF_HKDF_SHA256 ?
            32U : 48U;
        unsigned int bits = digest_len == 32U ? 256U : 384U;
        size_t expected_secret = desc.x25519_secret_len +
            desc.kem_secret_len;

        if (!transcript_hash || !ordered_shared_secret || !generation ||
            transcript_hash_len != desc.transcript_hash_len ||
            shared_secret_len != expected_secret)
            return PRP_ERR_ARGUMENT;
        result = hmac_sha2(bits, transcript_hash, transcript_hash_len,
            ordered_shared_secret, shared_secret_len, prk);
        if (result == PRP_OK)
            result = hkdf_expand_direction(bits, scope,
                PRP_WIRE_V4_DIRECTION_I2R, session_suite_id, generation,
                prk, digest_len, initiator_to_responder);
        if (result == PRP_OK)
            result = hkdf_expand_direction(bits, scope,
                PRP_WIRE_V4_DIRECTION_R2I, session_suite_id, generation,
                prk, digest_len, responder_to_initiator);
        prp_crypto_secure_zero(prk, sizeof(prk));
        if (result != PRP_OK) {
            prp_crypto_secure_zero(initiator_to_responder, 32U);
            prp_crypto_secure_zero(responder_to_initiator, 32U);
        }
        return result;
    }
    if (desc.kdf != PRP_WIRE_V4_KDF_BLAKE3_DERIVE_KEY)
        return PRP_ERR_STATE;
    result = status_from_wire(prp_wire_v4_traffic_material_encode(scope,
        session_suite_id, generation, transcript_hash, transcript_hash_len,
        ordered_shared_secret, shared_secret_len, material, sizeof(material),
        &material_len));
    if (result == PRP_OK &&
        prp_hash_blake3_derive_key(
            (const uint8_t *)PRP_WIRE_V4_BLAKE3_I2R_CONTEXT,
            PRP_WIRE_V4_BLAKE3_I2R_CONTEXT_LEN, NULL, 0, material,
            material_len, initiator_to_responder) != 0)
        result = PRP_ERR_CRYPTO;
    if (result == PRP_OK &&
        prp_hash_blake3_derive_key(
            (const uint8_t *)PRP_WIRE_V4_BLAKE3_R2I_CONTEXT,
            PRP_WIRE_V4_BLAKE3_R2I_CONTEXT_LEN, NULL, 0, material,
            material_len, responder_to_initiator) != 0)
        result = PRP_ERR_CRYPTO;
    prp_crypto_secure_zero(material, sizeof(material));
    if (result != PRP_OK) {
        prp_crypto_secure_zero(initiator_to_responder, 32);
        prp_crypto_secure_zero(responder_to_initiator, 32);
    }
    return result;
}

int prp_wire_v4_aop_seal(uint8_t scope, uint16_t session_suite_id,
    uint32_t generation, uint64_t sequence, const uint8_t key[32],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    const uint8_t *plaintext, size_t plaintext_len, uint8_t *wire,
    size_t capacity, size_t *written)
{
    struct prp_wire_v4_session_crypto_desc desc;
    struct prp_wire_v4_session_suite_desc suite;
    uint8_t aad[PRP_WIRE_V4_AEAD_AAD_PREFIX_LEN + 48U];
    size_t aad_len;
    int result;

    if (written)
        *written = 0;
    if (!key || (!plaintext && plaintext_len) || !wire || !written ||
        !generation || !sequence ||
        prp_wire_v4_session_crypto_get(session_suite_id, &desc) ||
        prp_wire_v4_session_suite_get(session_suite_id, &suite) ||
        (desc.aead != PRP_WIRE_V4_AEAD_CHACHA20_POLY1305 &&
         desc.aead != PRP_WIRE_V4_AEAD_AES_256_GCM))
        return PRP_ERR_ARGUMENT;
    if (plaintext_len > PRP_WIRE_V4_LOGICAL_UNIT_MAX -
            PRP_WIRE_V4_NONCE_LEN - suite.tag_len)
        return PRP_ERR_PAYLOAD_TOO_LARGE;
    if (capacity < PRP_WIRE_V4_NONCE_LEN + plaintext_len + suite.tag_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = status_from_wire(prp_wire_v4_nonce_encode(session_suite_id,
        generation, sequence, wire));
    if (result == PRP_OK)
        result = status_from_wire(prp_wire_v4_aead_aad_encode(scope,
            session_suite_id, generation, transcript_hash,
            transcript_hash_len, aad, sizeof(aad), &aad_len));
    if (result == PRP_OK) {
        int crypto_result = desc.aead == PRP_WIRE_V4_AEAD_AES_256_GCM ?
            prp_crypto_aes_256_gcm_encrypt(key, wire, aad, aad_len,
                plaintext, plaintext_len, wire + PRP_WIRE_V4_NONCE_LEN,
                wire + PRP_WIRE_V4_NONCE_LEN + plaintext_len) :
            prp_crypto_chacha20_poly1305_encrypt(key, wire, aad, aad_len,
                plaintext, plaintext_len, wire + PRP_WIRE_V4_NONCE_LEN,
                wire + PRP_WIRE_V4_NONCE_LEN + plaintext_len);
        if (crypto_result != PRP_CRYPTO_OK)
            result = PRP_ERR_CRYPTO;
    }
    prp_crypto_secure_zero(aad, sizeof(aad));
    if (result != PRP_OK)
        return result;
    *written = PRP_WIRE_V4_NONCE_LEN + plaintext_len + suite.tag_len;
    return PRP_OK;
}

int prp_wire_v4_aop_open(uint8_t scope, uint16_t session_suite_id,
    const uint8_t key[32], const uint8_t *transcript_hash,
    size_t transcript_hash_len, struct prp_wire_v4_replay_window *replay,
    const uint8_t *wire, size_t wire_len, uint8_t *plaintext,
    size_t plaintext_capacity, size_t *plaintext_len)
{
    struct prp_wire_v4_aop_view view;
    struct prp_wire_v4_session_crypto_desc desc;
    uint8_t aad[PRP_WIRE_V4_AEAD_AAD_PREFIX_LEN + 48U];
    uint32_t generation;
    prp_wire_v4_u64 sequence;
    size_t aad_len;
    int result, wire_result;

    if (plaintext_len)
        *plaintext_len = 0;
    if (!key || !transcript_hash || !replay || !wire || !plaintext ||
        !plaintext_len)
        return PRP_ERR_ARGUMENT;
    wire_result = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
    if (wire_result || (desc.aead != PRP_WIRE_V4_AEAD_CHACHA20_POLY1305 &&
            desc.aead != PRP_WIRE_V4_AEAD_AES_256_GCM))
        return PRP_ERR_ARGUMENT;
    wire_result = prp_wire_v4_aop_decode(session_suite_id, wire, wire_len,
        &view);
    if (wire_result)
        return PRP_ERR_PROTOCOL;
    wire_result = prp_wire_v4_nonce_decode(session_suite_id, view.nonce,
        view.nonce_len, &generation, &sequence);
    if (wire_result)
        return status_from_wire(wire_result);
    wire_result = prp_wire_v4_replay_precheck(replay, generation, sequence);
    if (wire_result)
        return status_from_wire(wire_result);
    if (plaintext_capacity < view.payload_len)
        return PRP_ERR_OUTPUT_TOO_SMALL;
    result = status_from_wire(prp_wire_v4_aead_aad_encode(scope,
        session_suite_id, generation, transcript_hash, transcript_hash_len,
        aad, sizeof(aad), &aad_len));
    if (result == PRP_OK) {
        int crypto_result = desc.aead == PRP_WIRE_V4_AEAD_AES_256_GCM ?
            prp_crypto_aes_256_gcm_decrypt(key, view.nonce, aad, aad_len,
                view.payload, view.payload_len, view.tag, plaintext) :
            prp_crypto_chacha20_poly1305_decrypt(key, view.nonce, aad,
                aad_len, view.payload, view.payload_len, view.tag, plaintext);
        if (crypto_result != PRP_CRYPTO_OK)
            result = PRP_ERR_CRYPTO;
    }
    prp_crypto_secure_zero(aad, sizeof(aad));
    if (result != PRP_OK ||
        prp_wire_v4_replay_commit(replay, generation, sequence)) {
        prp_crypto_secure_zero(plaintext, view.payload_len);
        return result != PRP_OK ? result : PRP_ERR_PROTOCOL;
    }
    *plaintext_len = view.payload_len;
    return PRP_OK;
}

static int onion_annex_commitment(uint16_t session_suite_id,
    const uint8_t *annex, size_t annex_len, uint8_t *commitment,
    size_t commitment_capacity, size_t *commitment_len)
{
    struct prp_wire_v4_session_suite_desc suite;

    if ((!annex && annex_len) || !commitment || !commitment_len ||
        prp_wire_v4_session_suite_get(session_suite_id, &suite))
        return PRP_ERR_ARGUMENT;
    return hash_preimage(suite.commitment_hash, annex, annex_len,
        commitment, commitment_capacity, commitment_len);
}

int prp_wire_v4_onion_layer_seal(uint16_t session_suite_id,
    uint32_t generation, uint64_t sequence, const uint8_t key[32],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    const uint8_t *e2e_annex, size_t e2e_annex_len,
    const struct prp_wire_v4_branch *branches, size_t branch_count,
    uint8_t *direct_plain, size_t direct_plain_capacity,
    uint8_t *wire, size_t wire_capacity, size_t *wire_len)
{
    struct prp_wire_v4_onion onion;
    uint8_t commitment[48U];
    size_t commitment_len = 0U;
    size_t direct_plain_len = 0U;
    size_t direct_layer_len = 0U;
    int result;

    if (wire_len)
        *wire_len = 0U;
    if (!key || !transcript_hash || (!e2e_annex && e2e_annex_len) ||
        (!branches && branch_count) || !direct_plain || !wire || !wire_len)
        return PRP_ERR_ARGUMENT;
    result = onion_annex_commitment(session_suite_id, e2e_annex,
        e2e_annex_len, commitment, sizeof(commitment), &commitment_len);
    if (result == PRP_OK)
        result = status_from_wire(prp_wire_v4_direct_encode(
            session_suite_id, commitment, commitment_len, branches,
            branch_count, direct_plain, direct_plain_capacity,
            &direct_plain_len));
    if (result == PRP_OK && wire_capacity < PRP_WIRE_V4_ONION_HEADER_LEN)
        result = PRP_ERR_OUTPUT_TOO_SMALL;
    if (result == PRP_OK)
        result = prp_wire_v4_aop_seal(PRP_WIRE_V4_SCOPE_DIRECT,
            session_suite_id, generation, sequence, key, transcript_hash,
            transcript_hash_len, direct_plain, direct_plain_len,
            wire + PRP_WIRE_V4_ONION_HEADER_LEN,
            wire_capacity - PRP_WIRE_V4_ONION_HEADER_LEN,
            &direct_layer_len);
    if (result == PRP_OK && direct_layer_len > UINT16_MAX)
        result = PRP_ERR_PAYLOAD_TOO_LARGE;
    if (result == PRP_OK) {
        onion.direct_layer = wire + PRP_WIRE_V4_ONION_HEADER_LEN;
        onion.direct_layer_len = (uint16_t)direct_layer_len;
        onion.e2e_annex = e2e_annex;
        onion.e2e_annex_len = e2e_annex_len <= UINT16_MAX ?
            (uint16_t)e2e_annex_len : 0U;
        if (e2e_annex_len > UINT16_MAX)
            result = PRP_ERR_PAYLOAD_TOO_LARGE;
        else
            result = status_from_wire(prp_wire_v4_onion_encode(&onion,
                wire, wire_capacity, wire_len));
    }
    prp_crypto_secure_zero(commitment, sizeof(commitment));
    prp_crypto_secure_zero(direct_plain, direct_plain_capacity);
    return result;
}

int prp_wire_v4_onion_layer_open(uint16_t session_suite_id,
    const uint8_t key[32], const uint8_t *transcript_hash,
    size_t transcript_hash_len, struct prp_wire_v4_replay_window *replay,
    const uint8_t *wire, size_t wire_len, uint8_t *direct_plain,
    size_t direct_plain_capacity, size_t *direct_plain_len,
    prp_wire_v4_onion_layer_view_t *view)
{
    struct prp_wire_v4_direct_cursor checked;
    struct prp_wire_v4_branch branch;
    uint8_t commitment[48U];
    size_t commitment_len = 0U;
    int result;

    if (direct_plain_len)
        *direct_plain_len = 0U;
    if (view)
        memset(view, 0, sizeof(*view));
    if (!key || !transcript_hash || !replay || !wire || !direct_plain ||
        !direct_plain_len || !view)
        return PRP_ERR_ARGUMENT;
    result = status_from_wire(prp_wire_v4_onion_decode(wire, wire_len,
        &view->onion));
    if (result == PRP_OK)
        result = prp_wire_v4_aop_open(PRP_WIRE_V4_SCOPE_DIRECT,
            session_suite_id, key, transcript_hash, transcript_hash_len,
            replay, view->onion.direct_layer, view->onion.direct_layer_len,
            direct_plain, direct_plain_capacity, direct_plain_len);
    if (result == PRP_OK)
        result = status_from_wire(prp_wire_v4_direct_init(session_suite_id,
            direct_plain, *direct_plain_len, &view->direct));
    if (result == PRP_OK)
        result = onion_annex_commitment(session_suite_id,
            view->onion.e2e_annex, view->onion.e2e_annex_len, commitment,
            sizeof(commitment), &commitment_len);
    if (result == PRP_OK &&
        (view->direct.commitment_len != commitment_len ||
         !prp_constant_time_equal(view->direct.commitment, commitment,
             commitment_len)))
        result = PRP_ERR_CRYPTO;
    if (result == PRP_OK) {
        checked = view->direct;
        while (checked.branches_remaining && result == PRP_OK)
            result = status_from_wire(prp_wire_v4_direct_next(&checked,
                &branch));
        if (result == PRP_OK)
            result = status_from_wire(prp_wire_v4_direct_finish(&checked));
    }
    prp_crypto_secure_zero(commitment, sizeof(commitment));
    if (result != PRP_OK) {
        prp_crypto_secure_zero(direct_plain, direct_plain_capacity);
        *direct_plain_len = 0U;
        memset(view, 0, sizeof(*view));
    }
    return result;
}
