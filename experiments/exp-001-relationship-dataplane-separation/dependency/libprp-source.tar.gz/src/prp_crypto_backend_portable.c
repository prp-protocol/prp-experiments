#include "prp_crypto_backend.h"

#include "prp_hash.h"
#include "prp_ed25519ctx_internal.h"
#include "prp_pq_internal.h"

#include <Hacl_AEAD_Chacha20Poly1305.h>
#include <Hacl_Curve25519_51.h>
#include <Hacl_Ed25519.h>
#include <Hacl_Hash_SHA2.h>
#include <mldsa_native.h>
#include <prp/wire_v4_crypto.h>

#include <limits.h>
#include <stdlib.h>
#include <string.h>

const char *prp_crypto_backend_name(void)
{
    return "hacl-star+bearssl+monocypher+native-portable";
}

uint32_t prp_crypto_backend_flags(void)
{
    return PRP_CRYPTO_INFO_FLAG_USERLEVEL |
        PRP_CRYPTO_INFO_FLAG_SOFTWARE_FALLBACK |
        PRP_CRYPTO_INFO_FLAG_RAW_KEYS |
        PRP_CRYPTO_INFO_FLAG_PORTABLE_ED25519CTX;
}

int prp_crypto_backend_info(prp_crypto_backend_info_t *info)
{
    if (info == NULL)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    info->abi_version = PRP_CRYPTO_BACKEND_ABI_VERSION;
    info->flags = prp_crypto_backend_flags();
    info->name = prp_crypto_backend_name();
    info->max_ad_len = UINT32_MAX;
    info->max_input_len = UINT32_MAX;
    info->max_output_len = UINT32_MAX;
    info->key_slot_count = 0U;
    return PRP_CRYPTO_OK;
}

int prp_crypto_backend_capable(prp_crypto_suite_t suite,
    prp_crypto_operation_t operation)
{
    switch (suite) {
    case PRP_CRYPTO_SUITE_BLAKE3_256:
    case PRP_CRYPTO_SUITE_BLAKE3_KEYED_256:
        return operation == PRP_CRYPTO_OP_HASH;
    case PRP_CRYPTO_SUITE_CHACHA20_POLY1305:
        return operation == PRP_CRYPTO_OP_AEAD_ENCRYPT ||
            operation == PRP_CRYPTO_OP_AEAD_DECRYPT;
    case PRP_CRYPTO_SUITE_X25519:
        return operation == PRP_CRYPTO_OP_PUBLIC_FROM_PRIVATE ||
            operation == PRP_CRYPTO_OP_DH;
    case PRP_CRYPTO_SUITE_AES_256_GCM:
        return operation == PRP_CRYPTO_OP_AEAD_ENCRYPT ||
            operation == PRP_CRYPTO_OP_AEAD_DECRYPT;
    default:
        return 0;
    }
}

const char *prp_crypto_error_name(int error_code)
{
    switch (error_code) {
    case PRP_CRYPTO_OK: return "ok";
    case PRP_CRYPTO_ERR_UNAVAILABLE: return "unavailable";
    case PRP_CRYPTO_ERR_UNSUPPORTED: return "unsupported";
    case PRP_CRYPTO_ERR_BAD_ARGS: return "bad_args";
    case PRP_CRYPTO_ERR_CRYPTO: return "crypto";
    default: return "unknown";
    }
}

void prp_crypto_secure_zero(void *pointer, size_t length)
{
    volatile uint8_t *cursor = pointer;

    while (cursor != NULL && length-- != 0U)
        *cursor++ = 0U;
}

int prp_crypto_random(uint8_t *output, size_t output_len)
{
    if (output == NULL && output_len != 0U)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    return output_len == 0U ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_UNAVAILABLE;
}

int prp_crypto_hash_sha2_concat(unsigned int bits,
    const uint8_t *first, size_t first_len, const uint8_t *second,
    size_t second_len, uint8_t *output, size_t output_len)
{
    uint8_t *input;
    size_t input_len;

    if ((first == NULL && first_len != 0U) ||
            (second == NULL && second_len != 0U) || output == NULL ||
            first_len > SIZE_MAX - second_len ||
            first_len + second_len > UINT32_MAX ||
            !((bits == 256U && output_len == 32U) ||
              (bits == 384U && output_len == 48U)))
        return PRP_CRYPTO_ERR_BAD_ARGS;
    input_len = first_len + second_len;
    input = malloc(input_len != 0U ? input_len : 1U);
    if (input == NULL)
        return PRP_CRYPTO_ERR_UNAVAILABLE;
    if (first_len != 0U)
        memcpy(input, first, first_len);
    if (second_len != 0U)
        memcpy(input + first_len, second, second_len);
    if (bits == 256U)
        Hacl_Hash_SHA2_hash_256(output, input, (uint32_t)input_len);
    else
        Hacl_Hash_SHA2_hash_384(output, input, (uint32_t)input_len);
    prp_crypto_secure_zero(input, input_len);
    free(input);
    return PRP_CRYPTO_OK;
}

int prp_crypto_identity_proof_verify(uint8_t profile,
    const uint8_t *public_key, const uint8_t *signature,
    const uint8_t *message, size_t message_len, const uint8_t *context,
    size_t context_len)
{
    if (public_key == NULL || signature == NULL ||
            (message == NULL && message_len != 0U) ||
            message_len > UINT32_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    if (profile == PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3 &&
            context_len == 0U)
        return Hacl_Ed25519_verify((uint8_t *)public_key,
            (uint32_t)message_len, (uint8_t *)message,
            (uint8_t *)signature) ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
    if (profile == PRP_SELF_CERT_ID_PROOF_ED25519CTX)
        return prp_ed25519ctx_verify_context(public_key, signature, message,
            message_len, context, context_len);
    if (profile == PRP_SELF_CERT_ID_PROOF_MLDSA65)
        return prp_mldsa65_verify_canonical(public_key, signature, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    if (profile == PRP_SELF_CERT_ID_PROOF_MLDSA87)
        return prp_mldsa87_verify_canonical(public_key, signature, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    if (profile == PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87) {
        if (!Hacl_Ed25519_verify((uint8_t *)public_key,
                (uint32_t)message_len, (uint8_t *)message,
                (uint8_t *)signature))
            return PRP_CRYPTO_ERR_CRYPTO;
        return prp_mldsa87_verify_canonical(
            public_key + PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN,
            signature + PRP_ID_PROOF_ED25519_SIGNATURE_LEN, message,
            message_len, context, context_len) == 0 ? PRP_CRYPTO_OK :
            PRP_CRYPTO_ERR_CRYPTO;
    }
    return PRP_CRYPTO_ERR_UNSUPPORTED;
}

int prp_crypto_identity_proof_capable(uint8_t profile)
{
    return profile == PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3 ||
        profile == PRP_SELF_CERT_ID_PROOF_ED25519CTX ||
        profile == PRP_SELF_CERT_ID_PROOF_MLDSA65 ||
        profile == PRP_SELF_CERT_ID_PROOF_MLDSA87 ||
        profile == PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87;
}

int prp_crypto_chacha20_poly1305_encrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len, uint8_t *ciphertext,
    uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN])
{
    if (key == NULL || nonce == NULL || ciphertext == NULL || tag == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (plaintext == NULL && plaintext_len != 0U) ||
            associated_data_len > UINT32_MAX || plaintext_len > UINT32_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    Hacl_AEAD_Chacha20Poly1305_encrypt(ciphertext, tag,
        (uint8_t *)plaintext, (uint32_t)plaintext_len,
        (uint8_t *)associated_data, (uint32_t)associated_data_len,
        (uint8_t *)key, (uint8_t *)nonce);
    return PRP_CRYPTO_OK;
}

int prp_crypto_chacha20_poly1305_decrypt(
    const uint8_t key[PRP_CRYPTO_KEY_LEN],
    const uint8_t nonce[PRP_CRYPTO_CHACHAPOLY_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t tag[PRP_CRYPTO_CHACHAPOLY_TAG_LEN], uint8_t *plaintext)
{
    if (key == NULL || nonce == NULL || tag == NULL || plaintext == NULL ||
            (associated_data == NULL && associated_data_len != 0U) ||
            (ciphertext == NULL && ciphertext_len != 0U) ||
            associated_data_len > UINT32_MAX || ciphertext_len > UINT32_MAX)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    return Hacl_AEAD_Chacha20Poly1305_decrypt(plaintext,
        (uint8_t *)ciphertext, (uint32_t)ciphertext_len,
        (uint8_t *)associated_data, (uint32_t)associated_data_len,
        (uint8_t *)key, (uint8_t *)nonce, (uint8_t *)tag) == 0U ?
        PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}

int prp_crypto_x25519_public_from_private(
    const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    uint8_t public_key[PRP_CRYPTO_KEY_LEN])
{
    if (private_key == NULL || public_key == NULL)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    Hacl_Curve25519_51_secret_to_public(public_key, (uint8_t *)private_key);
    return PRP_CRYPTO_OK;
}

int prp_crypto_x25519_keypair(uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t private_key[PRP_CRYPTO_KEY_LEN])
{
    if (public_key == NULL || private_key == NULL)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    prp_crypto_secure_zero(public_key, PRP_CRYPTO_KEY_LEN);
    prp_crypto_secure_zero(private_key, PRP_CRYPTO_KEY_LEN);
    return PRP_CRYPTO_ERR_UNAVAILABLE;
}

int prp_crypto_x25519_dh(const uint8_t private_key[PRP_CRYPTO_KEY_LEN],
    const uint8_t public_key[PRP_CRYPTO_KEY_LEN],
    uint8_t output[PRP_CRYPTO_KEY_LEN])
{
    if (private_key == NULL || public_key == NULL || output == NULL)
        return PRP_CRYPTO_ERR_BAD_ARGS;
    return Hacl_Curve25519_51_ecdh(output, (uint8_t *)private_key,
        (uint8_t *)public_key) ? PRP_CRYPTO_OK : PRP_CRYPTO_ERR_CRYPTO;
}
