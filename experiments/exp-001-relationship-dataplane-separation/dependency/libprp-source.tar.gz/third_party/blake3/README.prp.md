# BLAKE3 Vendored Source

This directory contains the official BLAKE3 C implementation from upstream tag
`1.8.2`, commit `df610ddc3b93841ffc59a87e3da659a15910eb46`.

PRP builds the portable C backend by default and disables optional SIMD
translation units in `Makefile`. This keeps the default build self-contained
and deterministic across the local validation environments. The PRP wire
protocol depends only on BLAKE3 outputs, not on the selected implementation
backend.

Upstream: https://github.com/BLAKE3-team/BLAKE3

Licensing is preserved in the adjacent upstream license files:

- `LICENSE_CC0`
- `LICENSE_A2`
- `LICENSE_A2LLVM`
