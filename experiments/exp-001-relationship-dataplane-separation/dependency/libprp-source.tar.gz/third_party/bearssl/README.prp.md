# BearSSL subset used by libprp

This directory contains an unmodified subset of BearSSL 0.6, pinned to commit
`8ef7680081c61b486622f2d983c0d3d21e83caad`. It provides the constant-time,
bitsliced AES implementation, portable 32-bit GHASH, and GCM composition used
by the portable Android and Wasm backends.

Imported upstream files:

- `inc/` (public type and API declarations required by `inner.h`);
- `src/config.h` and `src/inner.h`;
- `src/aead/gcm.c`;
- `src/hash/ghash_ctmul32.c`;
- `src/symcipher/aes_ct.c`, `src/symcipher/aes_ct_enc.c`, and
  `src/symcipher/aes_ct_ctr.c`.

The selected cryptographic source files are byte-identical in upstream
`master` at `7bea48e5e850ab4cafbe68d3765cdaba13a86d6f` (2026-04-06). Keep local
changes in the libprp adapter; do not edit the imported implementation.
