# mlkem-native vendoring note

This directory vendors the portable C path of `mlkem-native` for PRP's
experimental hybrid post-quantum work.

Imported upstream:

- repository: `https://github.com/pq-code-package/mlkem-native`
- commit: `4d5bcd0` (`CI: Add gcc16 tests`)
- license choice for PRP: `Apache-2.0 OR ISC OR MIT`

PRP builds only ML-KEM-768 with native assembly backends disabled. The public
PRP wrapper is `include/prp_pq.h`; callers should not include
`mlkem_native.h` directly.
