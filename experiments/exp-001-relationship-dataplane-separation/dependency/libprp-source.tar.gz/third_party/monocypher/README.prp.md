# Monocypher subset used by libprp

This directory contains the unmodified Monocypher 4.0.3 release at commit
`ab2b16dd619ad5f6979a4fbe69cfa324a6fcc35f`. The portable backend uses its
audited EdDSA equation checker and optional SHA-512 implementation to verify
RFC 8032 Ed25519ctx signatures.

The libprp adapter owns the `dom2(F=0,C)` construction and strict rejection of
non-canonical and low-order public points/signature commitments. Keep those
protocol choices outside the vendored sources.
