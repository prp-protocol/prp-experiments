#ifndef PRP_CONTENT_ID_H
#define PRP_CONTENT_ID_H

#include "prp_export.h"

#include <prp/contracts/content_id_v1.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_CONTENT_DIGEST_MAX_LEN 48u
#define PRP_CONTENT_DESCRIPTOR_MAX_LEN \
    (PRP_CONTENT_DESCRIPTOR_PREFIX_LEN + PRP_CONTENT_DIGEST_MAX_LEN)
#define PRP_CONTENT_ID_MAX_LEN \
    (PRP_CONTENT_ID_PREFIX_LEN + PRP_CONTENT_DIGEST_MAX_LEN)
#define PRP_DISCOVERY_TARGET_LOOKUP_V2_PROFILE_BLAKE3_128 1u
#define PRP_DISCOVERY_TARGET_LOOKUP_V2_TAG_LEN 16u

typedef struct prp_content_builder_s prp_content_builder_t;

typedef struct prp_content_descriptor_s {
    uint16_t content_suite;
    uint16_t content_profile;
    uint16_t tree_height;
    uint16_t root_digest_len;
    uint64_t total_length;
    uint8_t root_digest[PRP_CONTENT_DIGEST_MAX_LEN];
} prp_content_descriptor_t;

typedef struct prp_discovery_target_s {
    uint8_t target_kind;
    uint16_t identifier_profile;
    const uint8_t *identifier;
    uint16_t identifier_len;
} prp_discovery_target_t;

PRP_API size_t prp_content_suite_digest_len(uint16_t content_suite);
PRP_API int prp_content_builder_create(uint16_t content_suite,
    prp_content_builder_t **builder);
PRP_API int prp_content_proof_builder_create(uint16_t content_suite,
    uint64_t leaf_index, prp_content_builder_t **builder);
PRP_API int prp_content_builder_update(prp_content_builder_t *builder,
    const uint8_t *data, size_t data_len);
PRP_API int prp_content_builder_finalize(prp_content_builder_t *builder,
    uint8_t *descriptor, size_t descriptor_size, size_t *descriptor_len,
    uint8_t *content_id, size_t content_id_size, size_t *content_id_len);
PRP_API int prp_content_builder_proof(const prp_content_builder_t *builder,
    uint8_t *proof, size_t proof_size, size_t *written);
PRP_API void prp_content_builder_destroy(prp_content_builder_t *builder);

PRP_API int prp_content_descriptor_decode(const uint8_t *encoded,
    size_t encoded_len, prp_content_descriptor_t *descriptor);
PRP_API int prp_content_id_compute(const uint8_t *descriptor,
    size_t descriptor_len, uint8_t *content_id, size_t content_id_size,
    size_t *written);
PRP_API int prp_content_id_validate(const uint8_t *content_id,
    size_t content_id_len, const uint8_t *descriptor, size_t descriptor_len);
PRP_API int prp_content_proof_verify(const uint8_t *descriptor,
    size_t descriptor_len, const uint8_t *leaf, size_t leaf_len,
    const uint8_t *proof, size_t proof_len);

PRP_API int prp_discovery_target_encode(
    const prp_discovery_target_t *target, uint8_t *encoded,
    size_t encoded_size, size_t *written);
PRP_API int prp_discovery_target_decode(const uint8_t *encoded,
    size_t encoded_len, prp_discovery_target_t *target);
PRP_API int prp_discovery_target_exact_lookup_v2_preimage(
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint16_t lookup_index_profile,
    const prp_discovery_target_t *target, uint8_t *preimage,
    size_t preimage_size, size_t *written);
PRP_API int prp_discovery_target_exact_lookup_v2_tag(
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint16_t lookup_index_profile,
    const prp_discovery_target_t *target,
    uint8_t lookup_tag[PRP_DISCOVERY_TARGET_LOOKUP_V2_TAG_LEN]);

#ifdef __cplusplus
}
#endif

#endif
