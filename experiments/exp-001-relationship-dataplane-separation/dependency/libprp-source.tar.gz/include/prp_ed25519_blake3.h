#ifndef PRP_ED25519_BLAKE3_H
#define PRP_ED25519_BLAKE3_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN 32u
#define PRP_ED25519_BLAKE3_PRIVATE_KEY_LEN 64u
#define PRP_ED25519_BLAKE3_SIGNATURE_LEN 64u
#define PRP_ED25519_BLAKE3_SEED_LEN 32u

typedef struct prp_ed25519_blake3_keypair_s
    prp_ed25519_blake3_keypair_t;
struct prp_platform_s;

PRP_API prp_status_t prp_ed25519_blake3_keypair_generate(
    prp_ed25519_blake3_keypair_t **keypair);
PRP_API prp_status_t prp_ed25519_blake3_keypair_generate_with_platform(
    prp_ed25519_blake3_keypair_t **keypair,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_ed25519_blake3_keypair_from_seed(
    prp_ed25519_blake3_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519_BLAKE3_SEED_LEN]);
PRP_API prp_status_t prp_ed25519_blake3_keypair_import(
    prp_ed25519_blake3_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len);
PRP_API prp_status_t prp_ed25519_blake3_public_key_export(
    const prp_ed25519_blake3_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written);

/*
 * Exceptional raw export for explicitly authorized interchange.
 * The caller owns and must erase the output. This is not a backup container.
 */
PRP_API prp_status_t prp_ed25519_blake3_private_key_export(
    const prp_ed25519_blake3_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written);

/*
 * Signs and verifies suite 0x0001 over the BLAKE3 domain-bound HS2 prefix.
 * The domain is normative and deliberately not caller-selectable.
 */
PRP_API prp_status_t prp_ed25519_blake3_sign(
    const prp_ed25519_blake3_keypair_t *keypair,
    const uint8_t *hs2_prefix, size_t hs2_prefix_len, uint8_t *signature,
    size_t signature_size, size_t *written);
PRP_API prp_status_t prp_ed25519_blake3_verify(
    const uint8_t public_key[PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519_BLAKE3_SIGNATURE_LEN],
    const uint8_t *hs2_prefix, size_t hs2_prefix_len);

/*
 * Private-discovery authentication signs the already canonical discovery
 * preimage directly with standard Ed25519. It is deliberately distinct from
 * the BLAKE3-domain-bound HS2 operation above and from Ed25519ctx.
 */
PRP_API prp_status_t prp_ed25519_blake3_discovery_sign(
    const prp_ed25519_blake3_keypair_t *keypair,
    const uint8_t *canonical_preimage, size_t canonical_preimage_len,
    uint8_t *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_ed25519_blake3_discovery_verify(
    const uint8_t public_key[PRP_ED25519_BLAKE3_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519_BLAKE3_SIGNATURE_LEN],
    const uint8_t *canonical_preimage, size_t canonical_preimage_len);
PRP_API void prp_ed25519_blake3_keypair_destroy(
    prp_ed25519_blake3_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
