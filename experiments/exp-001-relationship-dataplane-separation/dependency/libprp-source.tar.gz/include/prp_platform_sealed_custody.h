#ifndef PRP_PLATFORM_SEALED_CUSTODY_H
#define PRP_PLATFORM_SEALED_CUSTODY_H

#include "prp_platform.h"

#if defined(__cplusplus)
extern "C" {
#endif

#define PRP_PLATFORM_SEALED_CUSTODY_CONFIG_VERSION 1U

typedef int (*prp_platform_custody_protect_fn)(
    void *context, const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *sealed, size_t *sealed_len);

typedef int (*prp_platform_custody_unprotect_fn)(
    void *context, const uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *sealed, size_t sealed_len,
    uint8_t *plaintext, size_t *plaintext_len);

/*
 * Portable PRP operations over an OS-sealed persistent private-key blob.
 * Storage must provide insert-only create, atomic replace and durable flush.
 * protect/unprotect is the Android Keystore, Windows DPAPI/CNG or equivalent
 * bridge. It follows the normal two-call output-size convention and must
 * authenticate key_id plus every associated-data byte. It protects at rest
 * only: PRP operations execute in this process.
 */
typedef struct prp_platform_sealed_custody_config_s {
    uint32_t abi_version;
    uint32_t struct_size;
    /* OS_PROTECTED_AT_REST, optionally with USER_AUTHENTICATION. */
    uint64_t protection_properties;
    void *context;
    prp_platform_random_fn random;
    prp_platform_storage_load_fn storage_load;
    prp_platform_storage_store_fn storage_store;
    prp_platform_storage_delete_fn storage_delete;
    prp_platform_storage_replace_fn storage_replace;
    prp_platform_storage_flush_fn storage_flush;
    prp_platform_custody_protect_fn protect;
    prp_platform_custody_unprotect_fn unprotect;
} prp_platform_sealed_custody_config_t;

PRP_API int prp_platform_sealed_custody_initialize(
    prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config);
PRP_API void prp_platform_sealed_custody_destroy(prp_platform_t *platform);

#if defined(__cplusplus)
}
#endif

/* Transitive declaration retained for source compatibility. */
#include "prp_platform_android.h"

#endif
