#ifndef PRP_WIRE_V4_PORTABLE_H
#define PRP_WIRE_V4_PORTABLE_H

#include <stddef.h>
#include <stdint.h>

#include <prp/wire_v4_crypto.h>

#include "prp_export.h"
#include "prp_status.h"

#define PRP_WIRE_V4_PORTABLE_ABI_VERSION 1U

#define PRP_WIRE_V4_SESSION_CAP_REGISTERED        (1U << 0)
#define PRP_WIRE_V4_SESSION_CAP_TRANSCRIPT_HASH   (1U << 1)
#define PRP_WIRE_V4_SESSION_CAP_KEY_ESTABLISHMENT (1U << 2)
#define PRP_WIRE_V4_SESSION_CAP_KDF               (1U << 3)
#define PRP_WIRE_V4_SESSION_CAP_AEAD              (1U << 4)
#define PRP_WIRE_V4_SESSION_CAP_COMPLETE          (1U << 31)

#define PRP_WIRE_V4_IDENTITY_CAP_REGISTERED       (1U << 0)
#define PRP_WIRE_V4_IDENTITY_CAP_STRONG_ID        (1U << 1)
#define PRP_WIRE_V4_IDENTITY_CAP_PROOF_VERIFY     (1U << 2)
#define PRP_WIRE_V4_IDENTITY_CAP_KEY_MANAGEMENT   (1U << 3)
#define PRP_WIRE_V4_IDENTITY_CAP_PROOF_SIGN       (1U << 4)
#define PRP_WIRE_V4_IDENTITY_CAP_COMPLETE         (1U << 31)

typedef struct prp_wire_v4_hs2_fields_s {
    uint16_t session_suite_id;
    uint16_t identity_suite_id;
    uint8_t kind;
    const uint8_t *discovery;
    size_t discovery_len;
    const uint8_t *nonce;
    size_t nonce_len;
    const uint8_t *ephemeral_key;
    size_t ephemeral_key_len;
    const uint8_t *kem_value;
    size_t kem_value_len;
    const uint8_t *identity_public_key;
    size_t identity_public_key_len;
    const uint8_t *m1_binding;
    size_t m1_binding_len;
    uint32_t session_generation;
} prp_wire_v4_hs2_fields_t;

/*
 * A successfully opened portable onion layer. All pointers in onion refer to
 * the caller's wire buffer; all pointers in direct refer to direct_plain.
 * The caller retains both buffers for as long as it uses this view.
 */
typedef struct prp_wire_v4_onion_layer_view_s {
    struct prp_wire_v4_onion onion;
    struct prp_wire_v4_direct_cursor direct;
} prp_wire_v4_onion_layer_view_t;

#ifdef __cplusplus
extern "C" {
#endif

PRP_API int prp_wire_v4_hs2_prefix_encode(
    const prp_wire_v4_hs2_fields_t *fields,
    uint8_t *wire, size_t capacity, size_t *written);
PRP_API int prp_wire_v4_hs2_proof_append(
    uint16_t identity_suite_id, const uint8_t *proof, size_t proof_len,
    uint8_t *wire, size_t capacity, size_t *written);
PRP_API int prp_wire_v4_hs2_identity_verify(
    const uint8_t *wire, size_t wire_len);
PRP_API int prp_wire_v4_hs2_extract(
    const uint8_t *wire, size_t wire_len,
    struct prp_wire_v4_hs2_view *view);

/*
 * Returns the operations implemented by the active libprp crypto backend.
 * Recognition by the normative registry alone never implies COMPLETE.
 */
PRP_API int prp_wire_v4_session_suite_capabilities(
    uint16_t session_suite_id, uint32_t *capabilities);
PRP_API int prp_wire_v4_identity_suite_capabilities(
    uint16_t identity_suite_id, uint32_t *capabilities);

PRP_API int prp_wire_v4_m1_binding(
    const uint8_t *m1, size_t m1_len, uint8_t *binding,
    size_t binding_capacity, size_t *binding_len);
PRP_API int prp_wire_v4_transcript_hash(
    const uint8_t *m1, size_t m1_len,
    const uint8_t *m2, size_t m2_len,
    uint8_t *transcript, size_t transcript_capacity,
    size_t *transcript_len);
PRP_API int prp_wire_v4_fragment_commitment(
    const uint8_t *hs2, size_t hs2_len, uint8_t *commitment,
    size_t commitment_capacity, size_t *commitment_len);

PRP_API int prp_wire_v4_traffic_keys(
    uint8_t scope, uint16_t session_suite_id, uint32_t generation,
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    const uint8_t *ordered_shared_secret, size_t shared_secret_len,
    uint8_t initiator_to_responder[PRP_WIRE_V4_TRAFFIC_KEY_LEN],
    uint8_t responder_to_initiator[PRP_WIRE_V4_TRAFFIC_KEY_LEN]);

PRP_API int prp_wire_v4_aop_seal(
    uint8_t scope, uint16_t session_suite_id, uint32_t generation,
    uint64_t sequence,
    const uint8_t key[PRP_WIRE_V4_TRAFFIC_KEY_LEN],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *wire, size_t capacity, size_t *written);
PRP_API int prp_wire_v4_aop_open(
    uint8_t scope, uint16_t session_suite_id,
    const uint8_t key[PRP_WIRE_V4_TRAFFIC_KEY_LEN],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    struct prp_wire_v4_replay_window *replay,
    const uint8_t *wire, size_t wire_len,
    uint8_t *plaintext, size_t plaintext_capacity, size_t *plaintext_len);

/*
 * Builds one protected DIRECT layer and its canonical onion envelope.
 * direct_plain is caller-owned scratch and is cleared before return.
 * Scratch, wire, annex and branch child buffers must not overlap.
 * Only protected session suites supported by portable AOP are accepted.
 * This function performs no route/session lookup and grants no egress.
 */
PRP_API int prp_wire_v4_onion_layer_seal(
    uint16_t session_suite_id, uint32_t generation, uint64_t sequence,
    const uint8_t key[PRP_WIRE_V4_TRAFFIC_KEY_LEN],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    const uint8_t *e2e_annex, size_t e2e_annex_len,
    const struct prp_wire_v4_branch *branches, size_t branch_count,
    uint8_t *direct_plain, size_t direct_plain_capacity,
    uint8_t *wire, size_t wire_capacity, size_t *wire_len);

/*
 * Opens and completely validates one protected DIRECT layer. replay is
 * explicit caller-owned session state. direct_plain receives the authenticated
 * direct plaintext and must outlive view. wire and direct_plain must not
 * overlap. On failure direct_plain is cleared.
 */
PRP_API int prp_wire_v4_onion_layer_open(
    uint16_t session_suite_id,
    const uint8_t key[PRP_WIRE_V4_TRAFFIC_KEY_LEN],
    const uint8_t *transcript_hash, size_t transcript_hash_len,
    struct prp_wire_v4_replay_window *replay,
    const uint8_t *wire, size_t wire_len,
    uint8_t *direct_plain, size_t direct_plain_capacity,
    size_t *direct_plain_len, prp_wire_v4_onion_layer_view_t *view);

#ifdef __cplusplus
}
#endif

#endif
