#ifndef PRP_PQ_H
#define PRP_PQ_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_MLKEM768_PUBLIC_KEY_LEN 1184u
#define PRP_MLKEM768_PRIVATE_KEY_LEN 2400u
#define PRP_MLKEM768_CIPHERTEXT_LEN 1088u
#define PRP_MLKEM768_SHARED_SECRET_LEN 32u
#define PRP_MLKEM768_KEYPAIR_SEED_LEN 64u
#define PRP_MLKEM768_ENCAPS_SEED_LEN 32u

#define PRP_MLKEM1024_PUBLIC_KEY_LEN 1568u
#define PRP_MLKEM1024_PRIVATE_KEY_LEN 3168u
#define PRP_MLKEM1024_CIPHERTEXT_LEN 1568u
#define PRP_MLKEM1024_SHARED_SECRET_LEN 32u
#define PRP_MLKEM1024_KEYPAIR_SEED_LEN 64u
#define PRP_MLKEM1024_ENCAPS_SEED_LEN 32u

#define PRP_MLDSA87_PUBLIC_KEY_LEN 2592u
#define PRP_MLDSA87_PRIVATE_KEY_LEN 4896u
#define PRP_MLDSA87_SIGNATURE_LEN 4627u
#define PRP_MLDSA87_KEYPAIR_SEED_LEN 32u
#define PRP_MLDSA87_SIGN_RANDOM_LEN 32u

typedef struct prp_mldsa87_keypair_s prp_mldsa87_keypair_t;
struct prp_platform_s;

PRP_API prp_status_t prp_mlkem768_keypair_generate(
    unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN]);
PRP_API prp_status_t prp_mlkem768_keypair_generate_with_platform(
    unsigned char *public_key, unsigned char *private_key,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mlkem768_keypair_derand(
    unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN],
    const unsigned char seed[PRP_MLKEM768_KEYPAIR_SEED_LEN]);
PRP_API prp_status_t prp_mlkem768_encapsulate(
    unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN]);
PRP_API prp_status_t prp_mlkem768_encapsulate_with_platform(
    unsigned char *ciphertext, unsigned char *shared_secret,
    const unsigned char *public_key,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mlkem768_encapsulate_derand(
    unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM768_PUBLIC_KEY_LEN],
    const unsigned char seed[PRP_MLKEM768_ENCAPS_SEED_LEN]);
PRP_API prp_status_t prp_mlkem768_decapsulate(
    unsigned char shared_secret[PRP_MLKEM768_SHARED_SECRET_LEN],
    const unsigned char ciphertext[PRP_MLKEM768_CIPHERTEXT_LEN],
    const unsigned char private_key[PRP_MLKEM768_PRIVATE_KEY_LEN]);

PRP_API prp_status_t prp_mlkem1024_keypair_generate(
    unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN]);
PRP_API prp_status_t prp_mlkem1024_keypair_generate_with_platform(
    unsigned char *public_key, unsigned char *private_key,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mlkem1024_keypair_derand(
    unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN],
    const unsigned char seed[PRP_MLKEM1024_KEYPAIR_SEED_LEN]);
PRP_API prp_status_t prp_mlkem1024_encapsulate(
    unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN]);
PRP_API prp_status_t prp_mlkem1024_encapsulate_with_platform(
    unsigned char *ciphertext, unsigned char *shared_secret,
    const unsigned char *public_key,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mlkem1024_encapsulate_derand(
    unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char public_key[PRP_MLKEM1024_PUBLIC_KEY_LEN],
    const unsigned char seed[PRP_MLKEM1024_ENCAPS_SEED_LEN]);
PRP_API prp_status_t prp_mlkem1024_decapsulate(
    unsigned char shared_secret[PRP_MLKEM1024_SHARED_SECRET_LEN],
    const unsigned char ciphertext[PRP_MLKEM1024_CIPHERTEXT_LEN],
    const unsigned char private_key[PRP_MLKEM1024_PRIVATE_KEY_LEN]);

/*
 * ML-DSA-87 identity keys use the canonical FIPS 204 pure-signing context
 * "PRP-HS2-v4-PQ".  The context is deliberately not caller-selectable.
 */
PRP_API prp_status_t prp_mldsa87_keypair_generate(
    prp_mldsa87_keypair_t **keypair);
PRP_API prp_status_t prp_mldsa87_keypair_generate_with_platform(
    prp_mldsa87_keypair_t **keypair, const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mldsa87_keypair_from_seed(
    prp_mldsa87_keypair_t **keypair,
    const unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN]);
/* Compatibility spelling; new callers should use keypair_from_seed. */
PRP_API prp_status_t prp_mldsa87_keypair_derand(
    prp_mldsa87_keypair_t **keypair,
    const unsigned char seed[PRP_MLDSA87_KEYPAIR_SEED_LEN]);
PRP_API prp_status_t prp_mldsa87_keypair_import(
    prp_mldsa87_keypair_t **keypair,
    const unsigned char *private_key, size_t private_key_len);
PRP_API prp_status_t prp_mldsa87_public_key_export(
    const prp_mldsa87_keypair_t *keypair, unsigned char *public_key,
    size_t public_key_size, size_t *written);
/* Exceptional raw export for explicitly authorized interchange only. */
PRP_API prp_status_t prp_mldsa87_private_key_export(
    const prp_mldsa87_keypair_t *keypair, unsigned char *private_key,
    size_t private_key_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_sign(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    unsigned char *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_sign_with_platform(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const struct prp_platform_s *platform, unsigned char *signature,
    size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_sign_derand(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN],
    unsigned char *signature, size_t signature_size, size_t *written);
/*
 * Private-discovery signatures use the distinct canonical FIPS 204 context
 * "PRP-DISCOVERY-v1".  They cannot be substituted for HS2 signatures.
 */
PRP_API prp_status_t prp_mldsa87_discovery_sign(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    unsigned char *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_discovery_sign_with_platform(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const struct prp_platform_s *platform, unsigned char *signature,
    size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_discovery_sign_derand(
    const prp_mldsa87_keypair_t *keypair,
    const unsigned char *message, size_t message_len,
    const unsigned char random[PRP_MLDSA87_SIGN_RANDOM_LEN],
    unsigned char *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa87_verify(
    const unsigned char public_key[PRP_MLDSA87_PUBLIC_KEY_LEN],
    const unsigned char signature[PRP_MLDSA87_SIGNATURE_LEN],
    const unsigned char *message, size_t message_len);
PRP_API void prp_mldsa87_keypair_destroy(prp_mldsa87_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
