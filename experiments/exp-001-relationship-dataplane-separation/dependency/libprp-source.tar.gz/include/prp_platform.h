#ifndef PRP_PLATFORM_H
#define PRP_PLATFORM_H

#include <stddef.h>
#include <stdint.h>

#include "prp_export.h"
#include "prp_status.h"

#if defined(__cplusplus)
extern "C" {
#endif

#define PRP_PLATFORM_ABI_VERSION 5U
#define PRP_PLATFORM_ABI_VERSION_4 4U
#define PRP_PLATFORM_ASYNC_ABI_VERSION 2U
#define PRP_PLATFORM_CUSTODY_ABI_VERSION 2U
#define PRP_PLATFORM_KEY_ID_LEN 32U

#define PRP_PLATFORM_CAP_CRYPTO              (1U << 0)
#define PRP_PLATFORM_CAP_RANDOM              (1U << 1)
#define PRP_PLATFORM_CAP_CLOCK               (1U << 2)
#define PRP_PLATFORM_CAP_TRANSPORT           (1U << 3)
#define PRP_PLATFORM_CAP_STORAGE             (1U << 4)
#define PRP_PLATFORM_CAP_ASYNC               (1U << 5)
#define PRP_PLATFORM_CAP_STORAGE_ATOMIC      (1U << 6)
#define PRP_PLATFORM_CAP_STORAGE_DURABLE     (1U << 7)
/* ABI 4 compatibility only; ABI 5 uses custody export-policy properties. */
#define PRP_PLATFORM_CAP_NONEXPORTABLE_KEYS  (1U << 8)
#define PRP_PLATFORM_CAP_KEY_CUSTODY          (1U << 9)
#define PRP_PLATFORM_CAP_ALL                 ((1U << 10) - 1U)
#define PRP_PLATFORM_CAP_V4_ALL              ((1U << 9) - 1U)

/* ABI 4 compatibility handle route. */
#define PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY (1U << 0)
/* ABI 5 handle route; requires custody preflight for private operations. */
#define PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE (1U << 1)
#define PRP_PLATFORM_REQUEST_F_MASK \
    (PRP_PLATFORM_REQUEST_F_NONEXPORTABLE_KEY | \
     PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE)

typedef enum prp_crypto_operation_e {
    PRP_CRYPTO_OP_HASH = 1,
    PRP_CRYPTO_OP_SIGN = 2,
    PRP_CRYPTO_OP_VERIFY = 3,
    PRP_CRYPTO_OP_KEM_ENCAPSULATE = 4,
    PRP_CRYPTO_OP_KEM_DECAPSULATE = 5,
    PRP_CRYPTO_OP_AEAD_SEAL = 6,
    PRP_CRYPTO_OP_AEAD_OPEN = 7,
    PRP_CRYPTO_OP_KEY_AGREEMENT_KEYPAIR = 8,
    PRP_CRYPTO_OP_KEY_AGREEMENT = 9,
    PRP_CRYPTO_OP_KEM_KEYPAIR = 10,
    PRP_CRYPTO_OP_KDF = 11
} prp_crypto_operation_t;

struct prp_platform_request_s;

typedef int (*prp_platform_crypto_fn)(
    void *context,
    const struct prp_platform_request_s *request,
    size_t *output_len,
    size_t *secondary_output_len);

typedef int (*prp_platform_random_fn)(
    void *context, uint8_t *output, size_t output_len);

typedef int (*prp_platform_monotonic_time_fn)(
    void *context, uint64_t *nanoseconds);

typedef int (*prp_platform_transport_send_fn)(
    void *context, const uint8_t *record, size_t record_len);

typedef int (*prp_platform_transport_receive_fn)(
    void *context, uint8_t *record, size_t *record_len);

/*
 * Storage keys and values are opaque binary objects.
 *
 * load returns PRP_ERR_NOT_FOUND when the key is absent. If value is NULL or
 * too small, it returns PRP_ERR_OUTPUT_TOO_SMALL and writes the required
 * length to value_len. store is insert-only and returns PRP_ERR_ALREADY for an
 * existing key. replace atomically creates or replaces one complete value.
 * delete is idempotent. flush establishes the provider's advertised durable
 * boundary for every successful operation issued before it.
 *
 * Providers must never expose a partially replaced value after reopen.
 */
typedef int (*prp_platform_storage_load_fn)(
    void *context,
    const uint8_t *key,
    size_t key_len,
    uint8_t *value,
    size_t *value_len);

typedef int (*prp_platform_storage_store_fn)(
    void *context,
    const uint8_t *key,
    size_t key_len,
    const uint8_t *value,
    size_t value_len);

typedef int (*prp_platform_storage_delete_fn)(
    void *context, const uint8_t *key, size_t key_len);

typedef int (*prp_platform_storage_replace_fn)(
    void *context,
    const uint8_t *key,
    size_t key_len,
    const uint8_t *value,
    size_t value_len);

typedef int (*prp_platform_storage_flush_fn)(void *context);

/*
 * Custody is limited to long-lived private keys. key_id is stable storage
 * identity; key_handle is process-local and becomes invalid on close,
 * deletion or provider restart. No operation may silently weaken requested
 * properties.
 */
typedef enum prp_platform_custody_operation_e {
    PRP_CUSTODY_OP_CREATE = 1,
    PRP_CUSTODY_OP_IMPORT = 2,
    PRP_CUSTODY_OP_OPEN = 3,
    PRP_CUSTODY_OP_CLOSE = 4,
    PRP_CUSTODY_OP_INFO = 5,
    PRP_CUSTODY_OP_PUBLIC_EXPORT = 6,
    PRP_CUSTODY_OP_PRIVATE_EXPORT = 7,
    /* Values 8 and 9 are unassigned; backup is outside custody ABI v2. */
    PRP_CUSTODY_OP_DELETE = 10,
    /* Query-only operation classes executed through the crypto callback. */
    PRP_CUSTODY_OP_SIGN = 11,
    PRP_CUSTODY_OP_DECAPSULATE = 12,
    PRP_CUSTODY_OP_KEY_AGREEMENT = 13
} prp_platform_custody_operation_t;

#define PRP_CUSTODY_OPERATION_BIT(operation) \
    (UINT32_C(1) << ((uint32_t)(operation) - UINT32_C(1)))

#define PRP_CUSTODY_OPERATION_MASK \
    (PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_CREATE) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_IMPORT) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_OPEN) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_CLOSE) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_INFO) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_PUBLIC_EXPORT) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_PRIVATE_EXPORT) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_DELETE) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_SIGN) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_DECAPSULATE) | \
     PRP_CUSTODY_OPERATION_BIT(PRP_CUSTODY_OP_KEY_AGREEMENT))

#define PRP_CUSTODY_PURPOSE_SIGN             (1U << 0)
#define PRP_CUSTODY_PURPOSE_DECAPSULATE      (1U << 1)
#define PRP_CUSTODY_PURPOSE_KEY_AGREEMENT    (1U << 2)
#define PRP_CUSTODY_PURPOSE_MASK             ((1U << 3) - 1U)

#define PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE   (UINT64_C(1) << 0)
#define PRP_CUSTODY_PROPERTY_PRIVATE_NONEXPORTABLE (UINT64_C(1) << 1)
#define PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST (UINT64_C(1) << 2)
#define PRP_CUSTODY_PROPERTY_HARDWARE_OPERATION   (UINT64_C(1) << 3)
#define PRP_CUSTODY_PROPERTY_USER_AUTHENTICATION  (UINT64_C(1) << 4)
#define PRP_CUSTODY_PROPERTY_ATOMIC_DURABLE       (UINT64_C(1) << 5)
#define PRP_CUSTODY_PROPERTY_ATTESTED              (UINT64_C(1) << 6)
#define PRP_CUSTODY_PROPERTY_MASK                  ((UINT64_C(1) << 7) - 1U)
#define PRP_CUSTODY_PROPERTY_EXPORT_POLICY_MASK \
    (PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE | \
     PRP_CUSTODY_PROPERTY_PRIVATE_NONEXPORTABLE)

/* PRIVATE_EXPORT requires an explicit authorization on every invocation. */
#define PRP_CUSTODY_REQUEST_F_AUTHORIZE_PRIVATE_EXPORT (1U << 0)
#define PRP_CUSTODY_REQUEST_F_MASK \
    PRP_CUSTODY_REQUEST_F_AUTHORIZE_PRIVATE_EXPORT

typedef struct prp_platform_custody_query_s {
    uint32_t abi_version;
    uint32_t struct_size;
    uint16_t negotiated_suite;
    uint16_t algorithm_profile;
    prp_platform_custody_operation_t operation;
    uint32_t purpose;
    uint64_t required_properties;
} prp_platform_custody_query_t;

typedef struct prp_platform_custody_capabilities_s {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t operations;
    uint32_t purposes;
    uint64_t properties;
    uint32_t max_components;
} prp_platform_custody_capabilities_t;

typedef struct prp_platform_custody_request_s {
    uint32_t abi_version;
    uint32_t struct_size;
    prp_platform_custody_operation_t operation;
    uint32_t flags;
    uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN];
    uint16_t negotiated_suite;
    uint16_t algorithm_profile;
    uint32_t purpose;
    uint64_t required_properties;
    uint64_t key_handle;
    const uint8_t *input;
    size_t input_len;
    uint8_t *public_output;
    size_t public_output_capacity;
    uint8_t *output;
    size_t output_capacity;
    /* Writable component metadata; capacity is measured in array elements. */
    struct prp_platform_custody_component_s *components;
    size_t component_capacity;
} prp_platform_custody_request_t;

typedef struct prp_platform_custody_component_s {
    uint32_t abi_version;
    uint32_t struct_size;
    uint16_t negotiated_suite;
    uint16_t algorithm_profile;
    uint32_t purpose;
    uint64_t actual_properties;
    size_t public_key_offset;
    size_t public_key_len;
} prp_platform_custody_component_t;

/* public_output contains the concatenated public keys described by components. */
typedef struct prp_platform_custody_result_s {
    uint32_t abi_version;
    uint32_t struct_size;
    uint8_t key_id[PRP_PLATFORM_KEY_ID_LEN];
    uint16_t negotiated_suite;
    uint16_t algorithm_profile;
    uint32_t purpose;
    uint64_t key_handle;
    uint64_t actual_properties;
    uint64_t generation;
    uint32_t component_count;
    size_t public_output_len;
    size_t output_len;
} prp_platform_custody_result_t;

typedef int (*prp_platform_custody_query_fn)(
    void *context,
    const prp_platform_custody_query_t *query,
    prp_platform_custody_capabilities_t *capabilities);

typedef int (*prp_platform_custody_execute_fn)(
    void *context,
    const prp_platform_custody_request_t *request,
    prp_platform_custody_result_t *result);

typedef enum prp_platform_operation_e {
    PRP_PLATFORM_OP_CRYPTO = 1,
    PRP_PLATFORM_OP_RANDOM = 2,
    PRP_PLATFORM_OP_MONOTONIC_TIME = 3,
    PRP_PLATFORM_OP_TRANSPORT_SEND = 4,
    PRP_PLATFORM_OP_TRANSPORT_RECEIVE = 5,
    PRP_PLATFORM_OP_STORAGE_LOAD = 6,
    PRP_PLATFORM_OP_STORAGE_REPLACE = 7,
    PRP_PLATFORM_OP_STORAGE_DELETE = 8,
    PRP_PLATFORM_OP_STORAGE_FLUSH = 9
} prp_platform_operation_t;

typedef struct prp_platform_async_token_s {
    uint64_t words[2];
} prp_platform_async_token_t;

typedef struct prp_platform_request_s {
    uint32_t abi_version;
    uint32_t struct_size;
    prp_platform_operation_t operation;
    uint32_t flags;
    uint16_t negotiated_suite;
    /*
     * SIGN and VERIFY use the canonical identity proof profile. Other
     * operations derive their algorithm from negotiated_suite and require 0.
     */
    uint16_t algorithm_profile;
    prp_crypto_operation_t crypto_operation;
    uint64_t key_handle;
    const uint8_t *key;
    size_t key_len;
    const uint8_t *input;
    size_t input_len;
    const uint8_t *auxiliary;
    size_t auxiliary_len;
    const uint8_t *nonce;
    size_t nonce_len;
    const uint8_t *associated_data;
    size_t associated_data_len;
    uint8_t *output;
    size_t output_capacity;
    uint8_t *secondary_output;
    size_t secondary_output_capacity;
} prp_platform_request_t;

typedef struct prp_platform_completion_s {
    uint32_t abi_version;
    uint32_t struct_size;
    prp_platform_async_token_t token;
    int status;
    size_t result_len;
    uint64_t value;
} prp_platform_completion_t;

/*
 * Request buffers remain owned by the caller and must stay valid until the
 * matching completion is polled or cancellation completes.
 */
typedef int (*prp_platform_async_begin_fn)(
    void *context,
    const prp_platform_request_t *request,
    prp_platform_async_token_t *token,
    prp_platform_completion_t *immediate);

typedef int (*prp_platform_async_poll_fn)(
    void *context, prp_platform_completion_t *completion);

typedef int (*prp_platform_async_step_fn)(
    void *context, uint32_t work_budget, uint32_t *work_done);

typedef int (*prp_platform_async_cancel_fn)(
    void *context, const prp_platform_async_token_t *token);

typedef struct prp_platform_s {
    uint32_t abi_version;
    uint32_t struct_size;
    uint32_t capabilities;
    uint32_t reserved;
    void *context;
    prp_platform_crypto_fn crypto;
    prp_platform_random_fn random;
    prp_platform_monotonic_time_fn monotonic_time;
    prp_platform_transport_send_fn transport_send;
    prp_platform_transport_receive_fn transport_receive;
    prp_platform_storage_load_fn storage_load;
    prp_platform_storage_store_fn storage_store;
    prp_platform_storage_delete_fn storage_delete;
    prp_platform_storage_replace_fn storage_replace;
    prp_platform_storage_flush_fn storage_flush;
    prp_platform_async_begin_fn async_begin;
    prp_platform_async_poll_fn async_poll;
    prp_platform_async_step_fn async_step;
    prp_platform_async_cancel_fn async_cancel;
    prp_platform_custody_query_fn custody_query;
    prp_platform_custody_execute_fn custody_execute;
} prp_platform_t;

#define PRP_PLATFORM_ABI_V4_STRUCT_SIZE \
    offsetof(prp_platform_t, custody_query)
#define PRP_PLATFORM_ABI_V5_STRUCT_SIZE \
    (offsetof(prp_platform_t, custody_execute) + \
     sizeof(prp_platform_custody_execute_fn))

PRP_API int prp_platform_validate(
    const prp_platform_t *platform, uint32_t required_capabilities);
PRP_API int prp_platform_request_validate(
    const prp_platform_t *platform, const prp_platform_request_t *request);
PRP_API int prp_platform_begin(
    const prp_platform_t *platform,
    const prp_platform_request_t *request,
    prp_platform_async_token_t *token,
    prp_platform_completion_t *immediate);
PRP_API int prp_platform_poll(
    const prp_platform_t *platform, prp_platform_completion_t *completion);
PRP_API int prp_platform_step(
    const prp_platform_t *platform, uint32_t work_budget,
    uint32_t *work_done);
PRP_API int prp_platform_cancel(
    const prp_platform_t *platform,
    const prp_platform_async_token_t *token);
PRP_API int prp_platform_async_token_valid(
    const prp_platform_async_token_t *token);
PRP_API int prp_platform_custody_query(
    const prp_platform_t *platform,
    const prp_platform_custody_query_t *query,
    prp_platform_custody_capabilities_t *capabilities);
PRP_API int prp_platform_custody_execute(
    const prp_platform_t *platform,
    const prp_platform_custody_request_t *request,
    prp_platform_custody_result_t *result);

#if defined(__cplusplus)
}
#endif

#endif
