#ifndef PRP_MEMBER_ROUTE_H
#define PRP_MEMBER_ROUTE_H

#include "prp_export.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_MEMBER_ROUTE_SECTION_TYPE 0x0100U
#define PRP_MEMBER_ROUTE_VERSION 1U
#define PRP_MEMBER_ROUTE_REQUEST_HEADER_LEN 4U
#define PRP_MEMBER_ROUTE_RESULT_LEN 2U
#define PRP_MEMBER_ROUTE_STRONG_ID_MAX_LEN 48U
#define PRP_MEMBER_ROUTE_CONTROL_MAX_LEN 88U

typedef struct prp_member_route_request_s {
    uint64_t transaction_id;
    uint32_t generation;
    uint16_t identity_suite;
    const uint8_t *strong_id;
    uint16_t strong_id_len;
} prp_member_route_request_t;

typedef struct prp_member_route_result_s {
    uint64_t transaction_id;
    uint32_t generation;
    uint16_t route_alias;
    uint8_t status;
} prp_member_route_result_t;

#ifdef __cplusplus
extern "C" {
#endif

PRP_API int prp_member_route_request_encode(
    const prp_member_route_request_t *request,
    uint8_t *wire, size_t capacity, size_t *written);
PRP_API int prp_member_route_request_decode(
    const uint8_t *wire, size_t wire_len,
    prp_member_route_request_t *request);
PRP_API int prp_member_route_result_encode(
    const prp_member_route_result_t *result,
    uint8_t *wire, size_t capacity, size_t *written);
PRP_API int prp_member_route_result_decode(
    const uint8_t *wire, size_t wire_len,
    prp_member_route_result_t *result);

#ifdef __cplusplus
}
#endif

#endif
