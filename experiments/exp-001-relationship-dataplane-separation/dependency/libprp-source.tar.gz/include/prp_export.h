#ifndef PRP_EXPORT_H
#define PRP_EXPORT_H

#if defined(_WIN32) && defined(PRP_STATIC)
#define PRP_API
#elif defined(_WIN32) && defined(PRP_BUILD_SHARED)
#define PRP_API __declspec(dllexport)
#elif defined(_WIN32)
#define PRP_API __declspec(dllimport)
#elif defined(__GNUC__) || defined(__clang__)
#define PRP_API __attribute__((visibility("default")))
#else
#define PRP_API
#endif

#endif
