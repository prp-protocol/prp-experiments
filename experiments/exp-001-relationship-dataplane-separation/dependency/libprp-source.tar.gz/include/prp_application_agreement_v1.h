#ifndef PRP_APPLICATION_AGREEMENT_V1_H
#define PRP_APPLICATION_AGREEMENT_V1_H
#include <stddef.h>
#include <stdint.h>
#include "prp_export.h"

#define PRP_APP_V1_MAX_WIRE 125u
/* Pure codec outputs are NOT authenticated admission or capabilities. */
typedef struct prp_app_v1_message {
    uint8_t kind, opener, application_len;
    uint64_t attempt;
    uint8_t context[32], application[64], offer_hash[32], acceptance_hash[32];
    uint16_t profile, application_version, flags, window, alias, reason;
    uint32_t max_queued_bytes, tombstone_ms, generation;
} prp_app_v1_message;
#ifdef __cplusplus
extern "C" {
#endif
/* 0 succeeds; -1 rejects. Outputs are unchanged on failure. */
PRP_API int prp_app_v1_decode(const uint8_t *, size_t, prp_app_v1_message *);
PRP_API int prp_app_v1_encode(const prp_app_v1_message *, uint8_t *, size_t, size_t *);
/* Validates and copies canonical wire bytes; suitable for WASM linear memory. */
PRP_API int prp_app_v1_canonicalize(const uint8_t *, size_t, uint8_t *, size_t);
PRP_API int prp_app_v1_offer_hash(const uint8_t *, size_t, uint8_t out[32]);
/* Input is the 81-byte ACCEPT prefix (without its final commitment). */
PRP_API int prp_app_v1_acceptance_hash(const uint8_t *, size_t, uint8_t out[32]);
/* Input is the canonical context preimage after the ASCII domain, starting
 * with wire version/scope. Validates registered lengths, NOT HS2 proofs.
 * The authenticated provider must derive these inputs from verified HS2. */
PRP_API int prp_app_v1_context_hash(const uint8_t *, size_t, uint8_t out[32]);
#ifdef __cplusplus
}
#endif
#endif
