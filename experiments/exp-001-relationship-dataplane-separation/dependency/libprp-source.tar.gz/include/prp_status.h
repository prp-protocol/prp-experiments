#ifndef PRP_STATUS_H
#define PRP_STATUS_H

#include "prp_export.h"

typedef enum prp_status_e {
    PRP_OK = 0,
    PRP_ERR_SHORT = -1,
    PRP_ERR_MARKER = -2,
    PRP_ERR_VERSION = -3,
    PRP_ERR_PAYLOAD_TOO_LARGE = -4,
    PRP_ERR_OUTPUT_TOO_SMALL = -5,
    PRP_ERR_ARGUMENT = -6,
    PRP_ERR_STATE = -7,
    PRP_ERR_CARRIER = -8,
    PRP_ERR_PROTOCOL = -9,
    PRP_ERR_AGAIN = -10,
    PRP_ERR_CRYPTO = -11,
    PRP_ERR_CANCELLED = -12,
    PRP_ERR_ALREADY = -13,
    PRP_ERR_NOT_FOUND = -14,
    PRP_ERR_POLICY = -15,
    PRP_ERR_UNAVAILABLE = -16,
    PRP_ERR_NO_MEMORY = -17
} prp_status_t;

PRP_API const char *prp_error_name(int code);

#endif
