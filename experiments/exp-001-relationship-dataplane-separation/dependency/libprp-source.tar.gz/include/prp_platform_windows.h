#ifndef PRP_PLATFORM_WINDOWS_H
#define PRP_PLATFORM_WINDOWS_H

#include "prp_export.h"
#include "prp_platform.h"
#include "prp_platform_sealed_custody.h"

#if defined(__cplusplus)
extern "C" {
#endif

/*
 * Initializes a synchronous Windows provider backed by CNG system entropy
 * and QueryPerformanceCounter. The caller owns the prp_platform_t storage.
 * No key-custody capability is advertised by this provider.
 */
PRP_API int prp_platform_windows_initialize(prp_platform_t *platform);

/*
 * Adds software PRP key custody with DPAPI protection at rest. The storage
 * and random callbacks in config remain application-owned. DPAPI uses the
 * current Windows user scope. This never advertises hardware PRP execution
 * or a non-exportable PRP private key.
 */
PRP_API int prp_platform_windows_custody_initialize(
    prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config);

#if defined(__cplusplus)
}
#endif

#endif
