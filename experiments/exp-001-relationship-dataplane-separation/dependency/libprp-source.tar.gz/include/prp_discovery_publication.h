#ifndef PRP_DISCOVERY_PUBLICATION_H
#define PRP_DISCOVERY_PUBLICATION_H

#include "prp_export.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_PUBLICATION_VERSION 1u
#define PRP_DISCOVERY_PUBLICATION_OP_PUBLISH 1u
#define PRP_DISCOVERY_PUBLICATION_OP_WITHDRAW 2u
#define PRP_DISCOVERY_PUBLICATION_HEADER_LEN 24u
#define PRP_DISCOVERY_PUBLICATION_MAX_SESSION_SUITES 8u
#define PRP_DISCOVERY_PUBLICATION_MAX_POLICY_LEN 1024u
#define PRP_DISCOVERY_PUBLICATION_MAX_RECORD_LEN 65535u

typedef struct prp_discovery_publication_s {
    uint8_t operation;
    uint64_t policy_generation;
    uint16_t identity_suite;
    const uint8_t *strong_id;
    uint16_t strong_id_len;
    uint16_t session_suites[PRP_DISCOVERY_PUBLICATION_MAX_SESSION_SUITES];
    uint16_t session_suite_count;
    const uint8_t *policy;
    uint16_t policy_len;
} prp_discovery_publication_t;

PRP_API int prp_discovery_publication_encode(
    const prp_discovery_publication_t *publication, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_publication_decode(const uint8_t *data,
    size_t data_len, prp_discovery_publication_t *publication);

#endif
