#ifndef PRP_MLDSA65_H
#define PRP_MLDSA65_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_MLDSA65_PUBLIC_KEY_LEN 1952u
#define PRP_MLDSA65_PRIVATE_KEY_LEN 4032u
#define PRP_MLDSA65_SIGNATURE_LEN 3309u
#define PRP_MLDSA65_SEED_LEN 32u
#define PRP_MLDSA65_SIGN_RANDOM_LEN 32u

typedef struct prp_mldsa65_keypair_s prp_mldsa65_keypair_t;
struct prp_platform_s;

PRP_API prp_status_t prp_mldsa65_keypair_generate(
    prp_mldsa65_keypair_t **keypair);
PRP_API prp_status_t prp_mldsa65_keypair_generate_with_platform(
    prp_mldsa65_keypair_t **keypair,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_mldsa65_keypair_from_seed(
    prp_mldsa65_keypair_t **keypair,
    const uint8_t seed[PRP_MLDSA65_SEED_LEN]);
PRP_API prp_status_t prp_mldsa65_keypair_import(
    prp_mldsa65_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len);
PRP_API prp_status_t prp_mldsa65_public_key_export(
    const prp_mldsa65_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written);

/*
 * Exceptional raw export for explicitly authorized interchange.
 * The caller owns and must erase the output. This is not a backup container.
 */
PRP_API prp_status_t prp_mldsa65_private_key_export(
    const prp_mldsa65_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written);

/* Signs with the fixed FIPS 204 pure-signing context "PRP-HS2-v4-PQ". */
PRP_API prp_status_t prp_mldsa65_sign(
    const prp_mldsa65_keypair_t *keypair, const uint8_t *message,
    size_t message_len, uint8_t *signature, size_t signature_size,
    size_t *written);
PRP_API prp_status_t prp_mldsa65_sign_with_platform(
    const prp_mldsa65_keypair_t *keypair, const uint8_t *message,
    size_t message_len, const struct prp_platform_s *platform,
    uint8_t *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa65_sign_with_random(
    const prp_mldsa65_keypair_t *keypair, const uint8_t *message,
    size_t message_len,
    const uint8_t random[PRP_MLDSA65_SIGN_RANDOM_LEN], uint8_t *signature,
    size_t signature_size, size_t *written);
PRP_API prp_status_t prp_mldsa65_verify(
    const uint8_t public_key[PRP_MLDSA65_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_MLDSA65_SIGNATURE_LEN],
    const uint8_t *message, size_t message_len);
PRP_API void prp_mldsa65_keypair_destroy(prp_mldsa65_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
