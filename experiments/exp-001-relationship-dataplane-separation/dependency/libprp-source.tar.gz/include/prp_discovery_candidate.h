#ifndef PRP_DISCOVERY_CANDIDATE_H
#define PRP_DISCOVERY_CANDIDATE_H

#include "prp_discovery_bloom.h"
#include "prp_export.h"
#include "prp_hash.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_CANDIDATE_HANDLE_LEN 16u
#define PRP_DISCOVERY_MATRIX_DESCRIPTOR_LEN 120u
#define PRP_DISCOVERY_MATRIX_VERSION 1u
#define PRP_DISCOVERY_MATRIX_KIND_SNAPSHOT 1u
#define PRP_DISCOVERY_MATRIX_MAX_COLUMNS 65535u

#define PRP_DISCOVERY_SOURCE_LOCAL_CARRIER 1u
#define PRP_DISCOVERY_SOURCE_PROTECTED_REFERRAL 2u
#define PRP_DISCOVERY_SOURCE_RENDEZVOUS_PIR 3u

#define PRP_DISCOVERY_REFERRAL_LOCAL_ONLY 1u
#define PRP_DISCOVERY_REFERRAL_REFERRABLE 2u
#define PRP_DISCOVERY_REFERRAL_RENDEZVOUS 3u

#define PRP_DISCOVERY_CANDIDATE_CAP_ADJACENT_HS2 UINT64_C(0x0001)
#define PRP_DISCOVERY_CANDIDATE_CAP_DIRECT_HS2 UINT64_C(0x0002)
#define PRP_DISCOVERY_CANDIDATE_CAP_PRIVATE_PAYLOAD UINT64_C(0x0004)
#define PRP_DISCOVERY_CANDIDATE_CAP_MASK UINT64_C(0x0007)

typedef struct prp_discovery_candidate_s {
    uint8_t handle[PRP_DISCOVERY_CANDIDATE_HANDLE_LEN];
    uint64_t generation;
    uint64_t valid_until;
    uint64_t capabilities;
    uint8_t source_scope;
} prp_discovery_candidate_t;

typedef struct prp_discovery_matrix_descriptor_s {
    uint64_t generation;
    uint64_t previous_generation;
    uint64_t valid_from;
    uint64_t valid_until;
    uint16_t lookup_index_profile;
    uint8_t precision;
    uint8_t hash_count;
    uint32_t column_count;
    uint32_t row_bytes;
    uint8_t aliases_commitment[PRP_HASH_BLAKE3_OUT_LEN];
    uint8_t matrix_commitment[PRP_HASH_BLAKE3_OUT_LEN];
} prp_discovery_matrix_descriptor_t;

typedef struct prp_discovery_matrix_view_s {
    const prp_discovery_matrix_descriptor_t *descriptor;
    const uint8_t *aliases;
    size_t aliases_len;
    const uint8_t *column_bitmaps;
    size_t column_bitmaps_len;
} prp_discovery_matrix_view_t;

typedef int (*prp_discovery_cancel_fn)(void *context);

PRP_API int prp_discovery_candidate_validate(
    const prp_discovery_candidate_t *candidate, uint64_t now);
PRP_API int prp_discovery_matrix_descriptor_encode(
    const prp_discovery_matrix_descriptor_t *descriptor, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_matrix_descriptor_decode(const uint8_t *data,
    size_t data_len, prp_discovery_matrix_descriptor_t *descriptor);
PRP_API int prp_discovery_matrix_commitments(
    const prp_discovery_matrix_descriptor_t *descriptor,
    const uint8_t *aliases, size_t aliases_len,
    const uint8_t *column_bitmaps, size_t column_bitmaps_len,
    uint8_t aliases_commitment[PRP_HASH_BLAKE3_OUT_LEN],
    uint8_t matrix_commitment[PRP_HASH_BLAKE3_OUT_LEN]);
PRP_API int prp_discovery_matrix_view_validate(
    const prp_discovery_matrix_view_t *view);
PRP_API int prp_discovery_matrix_query(
    const prp_discovery_matrix_view_t *view, uint8_t identity_profile,
    const uint8_t *strong_id, size_t strong_id_len, uint64_t work_budget,
    prp_discovery_cancel_fn cancelled, void *cancel_context,
    uint8_t *candidate_bits, size_t candidate_bits_len,
    uint32_t *candidate_count);
PRP_API int prp_discovery_matrix_rows_extract(
    const prp_discovery_matrix_view_t *view, const uint64_t *rows,
    size_t row_count, uint64_t work_budget,
    prp_discovery_cancel_fn cancelled, void *cancel_context,
    uint8_t *out, size_t out_len, size_t *written);

#endif
