#ifndef PRP_DISCOVERY_PRIVATE_H
#define PRP_DISCOVERY_PRIVATE_H

#include "prp_export.h"
#include "prp_hash.h"
#include "prp_content_id.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_PRIVATE_VERSION 1u
#define PRP_DISCOVERY_LOOKUP_PROFILE_BLAKE3_128 \
    PRP_DISCOVERY_TARGET_LOOKUP_V2_PROFILE_BLAKE3_128
#define PRP_DISCOVERY_LOOKUP_TAG_LEN \
    PRP_DISCOVERY_TARGET_LOOKUP_V2_TAG_LEN
#define PRP_DISCOVERY_QUERY_NONCE_LEN 16u
#define PRP_DISCOVERY_LOOKUP_REQUEST_LEN 32u
#define PRP_DISCOVERY_COMMITMENT_LEN 32u
#define PRP_DISCOVERY_SALT_LEN 32u
#define PRP_DISCOVERY_MANIFEST_HEADER_LEN 96u
#define PRP_DISCOVERY_MAX_SUITES 8u
#define PRP_DISCOVERY_MAX_SHARDS 4096u
#define PRP_DISCOVERY_MAX_RENDEZVOUS_ID_LEN 64u
#define PRP_DISCOVERY_MAX_STRONG_ID_LEN 64u
#define PRP_DISCOVERY_CHALLENGE_LEN 32u
#define PRP_DISCOVERY_SHARD_HEADER_LEN 56u
#define PRP_DISCOVERY_PROOF_HEADER_LEN 42u
#define PRP_DISCOVERY_AUTH_ED25519_LEN 96u
#define PRP_DISCOVERY_AUTH_MAX_LEN \
    (PRP_ID_PROOF_HYBRID_PUBLIC_KEY_LEN + \
     PRP_ID_PROOF_HYBRID_SIGNATURE_LEN)

typedef struct prp_discovery_private_suite_index_s {
    uint16_t suite;
    uint16_t lookup_index_profile;
} prp_discovery_private_suite_index_t;

typedef struct prp_discovery_private_manifest_s {
    uint16_t rendezvous_identity_suite;
    uint16_t rendezvous_identity_proof_profile;
    const uint8_t *rendezvous_id;
    uint16_t rendezvous_id_len;
    uint64_t generation;
    uint64_t previous_generation;
    uint64_t valid_from;
    uint64_t valid_until;
    uint64_t entry_count;
    uint32_t shard_count;
    uint32_t bitmap_bytes;
    uint8_t bloom_profile;
    uint8_t hash_count;
    const uint8_t *salt;
    uint16_t salt_len;
    const prp_discovery_private_suite_index_t *suites;
    uint16_t suite_count;
    const uint8_t *commitments;
    uint16_t commitment_count;
    const uint8_t *auth;
    uint16_t auth_len;
    size_t authenticated_len;
    prp_discovery_private_suite_index_t
        decoded_suites[PRP_DISCOVERY_MAX_SUITES];
} prp_discovery_private_manifest_t;

typedef struct prp_discovery_challenge_context_s {
    const uint8_t *rendezvous_id;
    uint16_t rendezvous_id_len;
    uint64_t filter_generation;
    uint16_t suite;
    uint16_t lookup_index_profile;
    const uint8_t *lookup_tag;
    const uint8_t *query_nonce;
    const uint8_t *challenge;
    uint16_t published_identity_suite;
    const uint8_t *published_identity;
    uint16_t published_identity_len;
} prp_discovery_challenge_context_t;

typedef struct prp_discovery_private_shard_s {
    uint16_t lookup_index_profile;
    uint64_t generation;
    uint32_t shard;
    const uint8_t *bitmap;
    uint32_t bitmap_len;
    const uint8_t *commitment;
} prp_discovery_private_shard_t;

typedef struct prp_discovery_private_proof_s {
    uint16_t identity_proof_profile;
    const uint8_t *challenge;
    const uint8_t *proof;
    uint16_t proof_len;
} prp_discovery_private_proof_t;

#ifdef __cplusplus
extern "C" {
#endif

PRP_API int prp_discovery_lookup_preimage(const prp_discovery_target_t *target,
    const uint8_t *rendezvous_id, size_t rendezvous_id_len,
    uint64_t filter_generation, uint8_t *out, size_t out_len,
    size_t *written);
PRP_API int prp_discovery_lookup_tag(uint16_t lookup_index_profile,
    const prp_discovery_target_t *target, const uint8_t *rendezvous_id,
    size_t rendezvous_id_len, uint64_t filter_generation,
    uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN]);
PRP_API int prp_discovery_lookup_request_encode(
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    const uint8_t nonce[PRP_DISCOVERY_QUERY_NONCE_LEN],
    uint8_t out[PRP_DISCOVERY_LOOKUP_REQUEST_LEN]);
PRP_API int prp_discovery_lookup_request_decode(const uint8_t *data, size_t data_len,
    uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    uint8_t nonce[PRP_DISCOVERY_QUERY_NONCE_LEN]);
PRP_API int prp_discovery_shard_select(
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint32_t shard_count,
    uint32_t *shard);
PRP_API int prp_discovery_private_bloom_indexes(const uint8_t *salt,
    size_t salt_len, const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN],
    uint32_t bitmap_bytes, uint8_t hash_count, uint32_t *indexes);
PRP_API int prp_discovery_private_bloom_add(uint8_t *bitmap, size_t bitmap_len,
    const uint8_t *salt, size_t salt_len,
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint8_t hash_count);
PRP_API int prp_discovery_private_bloom_test(const uint8_t *bitmap,
    size_t bitmap_len, const uint8_t *salt, size_t salt_len,
    const uint8_t tag[PRP_DISCOVERY_LOOKUP_TAG_LEN], uint8_t hash_count,
    int *maybe);
PRP_API int prp_discovery_shard_commitment(uint64_t generation, uint32_t shard,
    const uint8_t *data, size_t data_len,
    uint8_t commitment[PRP_DISCOVERY_COMMITMENT_LEN]);
PRP_API int prp_discovery_shard_record_encode(
    const prp_discovery_private_shard_t *shard, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_shard_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_shard_t *shard);
PRP_API int prp_discovery_manifest_encode(
    const prp_discovery_private_manifest_t *manifest, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_manifest_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_manifest_t *manifest);
PRP_API int prp_discovery_manifest_admit(const uint8_t *data, size_t data_len,
    uint64_t now, prp_discovery_private_manifest_t *manifest);
PRP_API int prp_discovery_challenge_preimage(
    const prp_discovery_challenge_context_t *context, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_challenge_preimage_decode(const uint8_t *data,
    size_t data_len, prp_discovery_challenge_context_t *context);
PRP_API int prp_discovery_proof_record_encode(
    const prp_discovery_private_proof_t *proof, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_proof_record_decode(const uint8_t *data, size_t data_len,
    prp_discovery_private_proof_t *proof);
PRP_API int prp_discovery_challenge_verify(
    const prp_discovery_challenge_context_t *context,
    uint16_t identity_proof_profile, const uint8_t *proof,
    size_t proof_len);

#ifdef __cplusplus
}
#endif

#endif
