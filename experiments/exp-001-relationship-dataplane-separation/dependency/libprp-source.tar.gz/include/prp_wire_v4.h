#ifndef LIBPRP_WIRE_V4_H
#define LIBPRP_WIRE_V4_H

/* Portable wire-v4 authority installed by the PRP development headers. */
#include <prp/wire_v4.h>
#include <prp/wire_v4_codec.h>

#endif
