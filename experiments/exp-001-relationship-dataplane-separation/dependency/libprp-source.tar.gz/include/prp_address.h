#ifndef PRP_ADDRESS_H
#define PRP_ADDRESS_H

#include "prp_export.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_ADDRESS_PROFILE_BLAKE3 0x01u
#define PRP_ADDRESS_PROFILE_BLAKE3_512 0x04u

#define PRP_ADDRESS_BLAKE3_STRONG_ID_LEN 32u
#define PRP_ADDRESS_BLAKE3_512_STRONG_ID_LEN 64u
#define PRP_ADDRESS_STRONG_ID_MAX_LEN PRP_ADDRESS_BLAKE3_512_STRONG_ID_LEN

#define PRP_ADDRESS_BLAKE3_TEXT_LEN 71u
#define PRP_ADDRESS_BLAKE3_512_TEXT_LEN 135u
/* Maximum buffer capacity, including the terminating NUL byte. */
#define PRP_ADDRESS_TEXT_MAX_LEN 136u

#ifdef __cplusplus
extern "C" {
#endif

typedef struct prp_address_s {
    uint8_t identity_profile;
    uint8_t strong_id_len;
    uint8_t strong_id[PRP_ADDRESS_STRONG_ID_MAX_LEN];
} prp_address_t;

PRP_API int prp_address_parse(const char *text, prp_address_t *address,
    char *error, size_t error_len);
PRP_API int prp_address_format(const prp_address_t *address, char *text,
    size_t text_capacity, char *error, size_t error_len);
PRP_API int prp_address_equal(const prp_address_t *left,
    const prp_address_t *right);

#ifdef __cplusplus
}
#endif

#endif
