#ifndef PRP_PLATFORM_ANDROID_H
#define PRP_PLATFORM_ANDROID_H

#include "prp_export.h"
#include "prp_platform_sealed_custody.h"

#if defined(__cplusplus)
extern "C" {
#endif

/* Android apps implement protect/unprotect through their Java Keystore bridge. */
PRP_API int prp_platform_android_custody_initialize(
    prp_platform_t *platform,
    const prp_platform_sealed_custody_config_t *config);

#if defined(__cplusplus)
}
#endif

#endif
