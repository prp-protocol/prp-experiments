#ifndef PRP_IDENTITY_HYBRID_H
#define PRP_IDENTITY_HYBRID_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_IDENTITY_HYBRID_PUBLIC_KEY_LEN 2624u
#define PRP_IDENTITY_HYBRID_PRIVATE_KEY_LEN 4960u
#define PRP_IDENTITY_HYBRID_SIGNATURE_LEN 4691u
#define PRP_IDENTITY_HYBRID_SEED_LEN 64u

typedef struct prp_identity_hybrid_keypair_s prp_identity_hybrid_keypair_t;
struct prp_platform_s;

PRP_API prp_status_t prp_identity_hybrid_keypair_generate(
    prp_identity_hybrid_keypair_t **keypair);
PRP_API prp_status_t prp_identity_hybrid_keypair_generate_with_platform(
    prp_identity_hybrid_keypair_t **keypair,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_identity_hybrid_keypair_from_seed(
    prp_identity_hybrid_keypair_t **keypair,
    const uint8_t seed[PRP_IDENTITY_HYBRID_SEED_LEN]);
PRP_API prp_status_t prp_identity_hybrid_keypair_import(
    prp_identity_hybrid_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len);
PRP_API prp_status_t prp_identity_hybrid_public_key_export(
    const prp_identity_hybrid_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written);

/* Exceptional raw export for explicitly authorized interchange only. */
PRP_API prp_status_t prp_identity_hybrid_private_key_export(
    const prp_identity_hybrid_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written);
PRP_API prp_status_t prp_identity_hybrid_sign(
    const prp_identity_hybrid_keypair_t *keypair, const uint8_t *hs2_prefix,
    size_t hs2_prefix_len, uint8_t *signature, size_t signature_size,
    size_t *written);
PRP_API prp_status_t prp_identity_hybrid_sign_with_platform(
    const prp_identity_hybrid_keypair_t *keypair, const uint8_t *hs2_prefix,
    size_t hs2_prefix_len, const struct prp_platform_s *platform,
    uint8_t *signature, size_t signature_size, size_t *written);
PRP_API prp_status_t prp_identity_hybrid_verify(
    const uint8_t public_key[PRP_IDENTITY_HYBRID_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_IDENTITY_HYBRID_SIGNATURE_LEN],
    const uint8_t *hs2_prefix, size_t hs2_prefix_len);
PRP_API void prp_identity_hybrid_keypair_destroy(
    prp_identity_hybrid_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
