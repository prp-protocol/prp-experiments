#ifndef PRP_HS2_ADMISSION_H
#define PRP_HS2_ADMISSION_H

#include "prp_export.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_HS2_ADMISSION_VERSION 1u
#define PRP_HS2_ADMISSION_ATTEMPT_NONCE_LEN 16u
#define PRP_HS2_ADMISSION_COMMITMENT_LEN 32u
#define PRP_HS2_ADMISSION_CHALLENGE_NONCE_LEN 32u
#define PRP_HS2_ADMISSION_COOKIE_LEN 32u
#define PRP_HS2_ADMISSION_OFFER_LEN 60u
#define PRP_HS2_ADMISSION_CHALLENGE_LEN 120u
#define PRP_HS2_ADMISSION_PROOF_LEN 52u
#define PRP_HS2_ADMISSION_PROOF_FRAGMENT_HEADER_LEN 60u
#define PRP_HS2_ADMISSION_RESPONDER_ID_MAX 64u
#define PRP_HS2_ADMISSION_M1_MAX_LEN 16384u
#define PRP_HS2_ADMISSION_VALIDITY_MAX_MS 604800000u

#define PRP_HS2_ADMISSION_METHOD_NONE 0u
#define PRP_HS2_ADMISSION_METHOD_HASHCASH 1u
#define PRP_HS2_ADMISSION_METHOD_MASK_NONE \
    (1u << PRP_HS2_ADMISSION_METHOD_NONE)
#define PRP_HS2_ADMISSION_METHOD_MASK_HASHCASH \
    (1u << PRP_HS2_ADMISSION_METHOD_HASHCASH)
#define PRP_HS2_ADMISSION_METHOD_MASK \
    (PRP_HS2_ADMISSION_METHOD_MASK_NONE | \
     PRP_HS2_ADMISSION_METHOD_MASK_HASHCASH)

#define PRP_HS2_ADMISSION_WORK_BLAKE3 1u
#define PRP_HS2_ADMISSION_WORK_SHA256 2u

/* Portable snapshots of the contract identifiers accepted by admission v1. */
#define PRP_HS2_ADMISSION_SESSION_NONE_BLAKE3 0x0001u
#define PRP_HS2_ADMISSION_SESSION_NONE_SHA256 0x0002u
#define PRP_HS2_ADMISSION_SESSION_X25519_CHACHA20POLY1305_BLAKE3 0x0101u
#define PRP_HS2_ADMISSION_SESSION_X25519_AES256GCM_BLAKE3 0x0102u
#define PRP_HS2_ADMISSION_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3 \
    0x0201u
#define PRP_HS2_ADMISSION_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3 \
    0x0202u
#define PRP_HS2_ADMISSION_IDENTITY_PROFILE_BLAKE3 0x0001u

typedef struct prp_hs2_admission_offer_s {
    uint16_t suite;
    uint16_t method_mask;
    uint8_t attempt_nonce[PRP_HS2_ADMISSION_ATTEMPT_NONCE_LEN];
    uint8_t m1_commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN];
} prp_hs2_admission_offer_t;

typedef struct prp_hs2_admission_challenge_s {
    uint16_t suite;
    uint8_t method;
    uint8_t work_primitive;
    uint8_t difficulty_bits;
    uint32_t validity_ms;
    uint64_t generation;
    uint8_t offer_commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    uint8_t challenge_nonce[PRP_HS2_ADMISSION_CHALLENGE_NONCE_LEN];
    uint8_t cookie[PRP_HS2_ADMISSION_COOKIE_LEN];
} prp_hs2_admission_challenge_t;

typedef struct prp_hs2_admission_proof_s {
    uint16_t suite;
    uint8_t method;
    uint8_t work_primitive;
    uint8_t challenge_commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN];
    uint64_t solution_nonce;
} prp_hs2_admission_proof_t;

typedef struct prp_hs2_admission_proof_fragment_s {
    prp_hs2_admission_proof_t proof;
    uint16_t m1_total_len;
    uint16_t m1_offset;
    const uint8_t *fragment;
    uint16_t fragment_len;
} prp_hs2_admission_proof_fragment_t;

#ifdef __cplusplus
extern "C" {
#endif

PRP_API int prp_hs2_admission_suite_work_primitive(uint16_t suite,
    uint8_t *work_primitive);
PRP_API int prp_hs2_admission_m1_commitment(uint16_t suite,
    const uint8_t *m1, size_t m1_len,
    uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN]);
PRP_API int prp_hs2_admission_offer_encode(
    const prp_hs2_admission_offer_t *offer,
    uint8_t out[PRP_HS2_ADMISSION_OFFER_LEN]);
PRP_API int prp_hs2_admission_offer_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_offer_t *offer);
PRP_API int prp_hs2_admission_offer_commitment(const uint8_t *offer,
    size_t offer_len,
    uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN]);
PRP_API int prp_hs2_admission_challenge_encode(
    const prp_hs2_admission_challenge_t *challenge,
    uint8_t out[PRP_HS2_ADMISSION_CHALLENGE_LEN]);
PRP_API int prp_hs2_admission_challenge_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_challenge_t *challenge);
PRP_API int prp_hs2_admission_challenge_commitment(
    const uint8_t *challenge, size_t challenge_len,
    uint8_t commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN]);
PRP_API int prp_hs2_admission_proof_encode(
    const prp_hs2_admission_proof_t *proof,
    uint8_t out[PRP_HS2_ADMISSION_PROOF_LEN]);
PRP_API int prp_hs2_admission_proof_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_proof_t *proof);
PRP_API int prp_hs2_admission_proof_fragment_encode(
    const prp_hs2_admission_proof_fragment_t *fragment, uint8_t *out,
    size_t out_capacity, size_t *out_len);
PRP_API int prp_hs2_admission_proof_fragment_decode(const uint8_t *data,
    size_t data_len, prp_hs2_admission_proof_fragment_t *fragment);
PRP_API int prp_hs2_admission_work_digest(uint16_t suite,
    uint16_t responder_identity_profile, const uint8_t *responder_id,
    size_t responder_id_len,
    const uint8_t challenge_commitment[PRP_HS2_ADMISSION_COMMITMENT_LEN],
    uint64_t solution_nonce,
    uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN]);
PRP_API int prp_hs2_admission_work_meets_difficulty(
    const uint8_t digest[PRP_HS2_ADMISSION_COMMITMENT_LEN],
    uint8_t difficulty_bits);
PRP_API int prp_hs2_admission_verify(uint16_t deterministic_suite,
    uint16_t responder_identity_profile, const uint8_t *responder_id,
    size_t responder_id_len, const uint8_t *canonical_m1, size_t m1_len,
    const uint8_t *offer, size_t offer_len,
    const uint8_t *challenge, size_t challenge_len,
    const uint8_t expected_cookie[PRP_HS2_ADMISSION_COOKIE_LEN],
    const uint8_t *proof, size_t proof_len, uint64_t challenge_age_ms,
    uint8_t proof_id[PRP_HS2_ADMISSION_COMMITMENT_LEN]);

#ifdef __cplusplus
}
#endif

#endif
