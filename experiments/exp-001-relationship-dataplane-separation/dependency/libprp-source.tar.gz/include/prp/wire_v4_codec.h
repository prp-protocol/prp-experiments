/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note OR MIT */
#ifndef PRP_WIRE_V4_CODEC_H
#define PRP_WIRE_V4_CODEC_H

#ifndef PRP_WIRE_V4_EXTERNAL_SIZE_T
#include <stddef.h>
#endif
#include <prp/wire_v4.h>

enum prp_wire_v4_codec_status {
	PRP_WIRE_V4_OK = 0,
	PRP_WIRE_V4_EINVAL = -1,
	PRP_WIRE_V4_ETRUNC = -2,
	PRP_WIRE_V4_ERANGE = -3,
	PRP_WIRE_V4_ECANON = -4,
	PRP_WIRE_V4_EVERSION = -5,
	PRP_WIRE_V4_ESUITE = -6,
	PRP_WIRE_V4_EREPLAY = -7,
};

struct prp_wire_v4_identity_suite_desc {
	prp_wire_v4_u16 id;
	prp_wire_v4_u8 hash;
	prp_wire_v4_u16 strong_id_len;
	prp_wire_v4_u16 public_key_len;
	prp_wire_v4_u16 proof_len;
};

struct prp_wire_v4_session_suite_desc {
	prp_wire_v4_u16 id;
	prp_wire_v4_u8 commitment_hash;
	prp_wire_v4_u16 commitment_len;
	prp_wire_v4_u8 nonce_len;
	prp_wire_v4_u8 tag_len;
	prp_wire_v4_u16 ephemeral_key_len;
	prp_wire_v4_u16 kem_public_key_len;
	prp_wire_v4_u16 kem_ciphertext_len;
};

struct prp_wire_v4_hs2_view {
	prp_wire_v4_u16 session_suite_id;
	prp_wire_v4_u16 identity_suite_id;
	prp_wire_v4_u8 kind;
	const prp_wire_v4_u8 *public_key;
	prp_wire_v4_u16 public_key_len;
	const prp_wire_v4_u8 *proof;
	prp_wire_v4_u16 proof_len;
	prp_wire_v4_u32 session_generation;
	const prp_wire_v4_u8 *discovery;
	prp_wire_v4_u16 discovery_len;
	const prp_wire_v4_u8 *nonce;
	prp_wire_v4_u16 nonce_len;
	const prp_wire_v4_u8 *ephemeral_key;
	prp_wire_v4_u16 ephemeral_key_len;
	const prp_wire_v4_u8 *kem_value;
	prp_wire_v4_u16 kem_value_len;
	const prp_wire_v4_u8 *m1_binding;
	prp_wire_v4_u16 m1_binding_len;
};

struct prp_wire_v4_scoped_hs2 {
	prp_wire_v4_u8 scope;
	prp_wire_v4_u16 route_alias;
	const prp_wire_v4_u8 *hs2;
	prp_wire_v4_u16 hs2_len;
};

struct prp_wire_v4_relation_section {
	prp_wire_v4_u16 type;
	prp_wire_v4_u8 version;
	prp_wire_v4_u8 flags;
	prp_wire_v4_u8 status;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u32 base_generation;
	const prp_wire_v4_u8 *body;
	prp_wire_v4_u16 body_len;
};

struct prp_wire_v4_relation_cursor {
	const prp_wire_v4_u8 *next;
	size_t remaining;
	prp_wire_v4_u64 transaction_id;
	prp_wire_v4_u16 sections_remaining;
	prp_wire_v4_u16 last_type;
	prp_wire_v4_u16 route_alias;
	prp_wire_v4_u8 operation;
	prp_wire_v4_u8 scope;
};

struct prp_wire_v4_key_lifecycle {
	prp_wire_v4_u64 max_active_key_age_ms;
	prp_wire_v4_u64 max_encrypted_bytes;
	prp_wire_v4_u64 max_encrypted_items;
	prp_wire_v4_u64 idle_key_retention_ms;
	prp_wire_v4_u32 old_generation_overlap_ms;
};

struct prp_wire_v4_aop_view {
	const prp_wire_v4_u8 *nonce;
	prp_wire_v4_u8 nonce_len;
	const prp_wire_v4_u8 *payload;
	prp_wire_v4_u16 payload_len;
	const prp_wire_v4_u8 *tag;
	prp_wire_v4_u8 tag_len;
};

struct prp_wire_v4_record {
	prp_wire_v4_u16 route_alias;
	prp_wire_v4_u8 kind;
	prp_wire_v4_u8 flags;
	const prp_wire_v4_u8 *body;
	prp_wire_v4_u16 body_len;
};

struct prp_wire_v4_rrl_cursor {
	const prp_wire_v4_u8 *next;
	size_t remaining;
	prp_wire_v4_u16 records_remaining;
};

struct prp_wire_v4_onion {
	const prp_wire_v4_u8 *direct_layer;
	prp_wire_v4_u16 direct_layer_len;
	const prp_wire_v4_u8 *e2e_annex;
	prp_wire_v4_u16 e2e_annex_len;
};

struct prp_wire_v4_branch {
	prp_wire_v4_u32 egress_capability;
	const prp_wire_v4_u8 *child_layer;
	prp_wire_v4_u16 child_layer_len;
};

struct prp_wire_v4_direct_cursor {
	const prp_wire_v4_u8 *commitment;
	prp_wire_v4_u16 commitment_len;
	const prp_wire_v4_u8 *next;
	size_t remaining;
	prp_wire_v4_u16 branches_remaining;
};

struct prp_wire_v4_fragment {
	prp_wire_v4_u8 object_kind;
	prp_wire_v4_u32 transfer_id;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total_len;
	const prp_wire_v4_u8 *segment;
	prp_wire_v4_u16 segment_len;
};

struct prp_wire_v4_feedback_range {
	prp_wire_v4_u32 transfer_id;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 length;
};

struct prp_wire_v4_feedback_cursor {
	const prp_wire_v4_u8 *next;
	prp_wire_v4_u16 ranges_remaining;
};

struct prp_wire_v4_control {
	prp_wire_v4_u8 kind;
	const prp_wire_v4_u8 *body;
	prp_wire_v4_u16 body_len;
};

struct prp_wire_v4_alias_lifecycle {
	prp_wire_v4_u8 operation;
	prp_wire_v4_u16 route_alias;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u32 lease_seconds;
};

struct prp_wire_v4_scoped_error {
	prp_wire_v4_u8 scope;
	prp_wire_v4_u8 error_class;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u32 retry_after_ms;
	const prp_wire_v4_u8 *token;
	prp_wire_v4_u16 token_len;
};

struct prp_wire_v4_close {
	prp_wire_v4_u8 scope;
	prp_wire_v4_u8 mode_or_status;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u32 selector;
};

struct prp_wire_v4_connection_control {
	prp_wire_v4_u8 kind;
	prp_wire_v4_u32 request_id;
	prp_wire_v4_u16 connection_alias;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u16 flags;
	prp_wire_v4_u16 window;
	prp_wire_v4_u32 max_queued_bytes;
	prp_wire_v4_u32 tombstone_ms;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u32 retry_after_ms;
	prp_wire_v4_u8 close_mode_or_status;
	prp_wire_v4_u64 next_sequence;
	prp_wire_v4_u64 received_bitmap;
};

struct prp_wire_v4_hs2_header {
	prp_wire_v4_u16 session_suite_id;
	prp_wire_v4_u8 kind;
};

struct prp_wire_v4_fragment_start {
	prp_wire_v4_u16 session_suite_id;
	const prp_wire_v4_u8 *commitment;
	prp_wire_v4_u16 commitment_len;
};

struct prp_wire_v4_e2e_item {
	prp_wire_v4_u16 connection_alias;
	prp_wire_v4_u16 flags;
	prp_wire_v4_u64 sequence;
	const prp_wire_v4_u8 *body;
	prp_wire_v4_u16 body_len;
};

struct prp_wire_v4_e2e_cursor {
	const prp_wire_v4_u8 *next;
	size_t remaining;
};

struct prp_wire_v4_drain_policy {
	prp_wire_v4_u8 scope;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u32 grace_ms;
	prp_wire_v4_u32 final_timeout_ms;
};

struct prp_wire_v4_carrier_attachment_binding {
	prp_wire_v4_u8 attachment_id[PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN];
	prp_wire_v4_u64 attachment_generation;
};

struct prp_wire_v4_discovery_policy {
	prp_wire_v4_u8 direction;
	prp_wire_v4_u16 index_algorithm;
	prp_wire_v4_u16 query_algorithm;
	prp_wire_v4_u16 profile;
};

struct prp_wire_v4_discovery_lane_bind {
	prp_wire_v4_u8 direction;
	prp_wire_v4_u16 connection_flags;
	prp_wire_v4_u32 policy_generation;
	prp_wire_v4_u32 session_generation;
	prp_wire_v4_u32 connection_generation;
	prp_wire_v4_u16 connection_alias;
};

static inline int
prp_wire_v4_drain_policy_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_drain_policy *policy);

static inline int prp_wire_v4_carrier_attachment_binding_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_carrier_attachment_binding *binding);

static inline int prp_wire_v4_discovery_policy_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_discovery_policy *policy);

static inline int prp_wire_v4_discovery_lane_bind_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_discovery_lane_bind *binding);

static inline prp_wire_v4_u16
prp_wire_v4_get_be16(const prp_wire_v4_u8 *p)
{
	return (prp_wire_v4_u16)(((prp_wire_v4_u16)p[0] << 8) | p[1]);
}

static inline prp_wire_v4_u32
prp_wire_v4_get_be32(const prp_wire_v4_u8 *p)
{
	return ((prp_wire_v4_u32)p[0] << 24) |
	       ((prp_wire_v4_u32)p[1] << 16) |
	       ((prp_wire_v4_u32)p[2] << 8) | p[3];
}

static inline prp_wire_v4_u64
prp_wire_v4_get_be64(const prp_wire_v4_u8 *p)
{
	return ((prp_wire_v4_u64)prp_wire_v4_get_be32(p) << 32) |
	       prp_wire_v4_get_be32(p + 4);
}

static inline void
prp_wire_v4_put_be16(prp_wire_v4_u8 *p, prp_wire_v4_u16 value)
{
	p[0] = (prp_wire_v4_u8)(value >> 8);
	p[1] = (prp_wire_v4_u8)value;
}

static inline void
prp_wire_v4_put_be32(prp_wire_v4_u8 *p, prp_wire_v4_u32 value)
{
	p[0] = (prp_wire_v4_u8)(value >> 24);
	p[1] = (prp_wire_v4_u8)(value >> 16);
	p[2] = (prp_wire_v4_u8)(value >> 8);
	p[3] = (prp_wire_v4_u8)value;
}

static inline void
prp_wire_v4_put_be64(prp_wire_v4_u8 *p, prp_wire_v4_u64 value)
{
	prp_wire_v4_put_be32(p, (prp_wire_v4_u32)(value >> 32));
	prp_wire_v4_put_be32(p + 4, (prp_wire_v4_u32)value);
}

static inline int
prp_wire_v4_identity_suite_get(prp_wire_v4_u16 id,
	struct prp_wire_v4_identity_suite_desc *desc)
{
	struct prp_wire_v4_identity_suite_desc value;

	switch (id) {
	case PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_256:
		value.hash = PRP_WIRE_V4_HASH_BLAKE3;
		value.strong_id_len = 32;
		value.public_key_len =
			PRP_WIRE_V4_IDENTITY_ED25519_PUBLIC_KEY_LEN;
		value.proof_len = 64;
		break;
	case PRP_WIRE_V4_IDENTITY_ED25519CTX_SHA256_256:
		value.hash = PRP_WIRE_V4_HASH_SHA256;
		value.strong_id_len = 32;
		value.public_key_len =
			PRP_WIRE_V4_IDENTITY_ED25519_PUBLIC_KEY_LEN;
		value.proof_len = 64;
		break;
	case PRP_WIRE_V4_IDENTITY_MLDSA65_SHA256_256:
		value.hash = PRP_WIRE_V4_HASH_SHA256;
		value.strong_id_len = 32;
		value.public_key_len =
			PRP_WIRE_V4_IDENTITY_MLDSA65_PUBLIC_KEY_LEN;
		value.proof_len = 3309;
		break;
	case PRP_WIRE_V4_IDENTITY_MLDSA87_SHA384_384:
		value.hash = PRP_WIRE_V4_HASH_SHA384;
		value.strong_id_len = 48;
		value.public_key_len =
			PRP_WIRE_V4_IDENTITY_MLDSA87_PUBLIC_KEY_LEN;
		value.proof_len = 4627;
		break;
	case PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_MLDSA87_BLAKE3_256:
		value.hash = PRP_WIRE_V4_HASH_BLAKE3;
		value.strong_id_len = 32;
		value.public_key_len =
			PRP_WIRE_V4_IDENTITY_ED25519_MLDSA87_PUBLIC_KEY_LEN;
		value.proof_len = 4691;
		break;
	default:
		return PRP_WIRE_V4_ESUITE;
	}
	value.id = id;
	if (desc)
		*desc = value;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_identity_suite_strong_id_profile(prp_wire_v4_u16 id,
	prp_wire_v4_u8 *profile)
{
	struct prp_wire_v4_identity_suite_desc desc;
	prp_wire_v4_u8 value;
	int rc;

	if (!profile)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_identity_suite_get(id, &desc);
	if (rc)
		return rc;
	switch (desc.hash) {
	case PRP_WIRE_V4_HASH_BLAKE3:
		if (desc.strong_id_len == 32)
			value = PRP_STRONG_ID_PROFILE_BLAKE3;
		else if (desc.strong_id_len == 64)
			value = PRP_STRONG_ID_PROFILE_BLAKE3_512;
		else
			return PRP_WIRE_V4_ESUITE;
		break;
	case PRP_WIRE_V4_HASH_SHA256:
		if (desc.strong_id_len != 32)
			return PRP_WIRE_V4_ESUITE;
		value = PRP_STRONG_ID_PROFILE_SHA256;
		break;
	case PRP_WIRE_V4_HASH_SHA384:
		if (desc.strong_id_len != 48)
			return PRP_WIRE_V4_ESUITE;
		value = PRP_STRONG_ID_PROFILE_SHA384;
		break;
	default:
		return PRP_WIRE_V4_ESUITE;
	}
	*profile = value;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_session_suite_get(prp_wire_v4_u16 id,
	struct prp_wire_v4_session_suite_desc *desc)
{
	struct prp_wire_v4_session_suite_desc value;
	prp_wire_v4_u8 hash;
	prp_wire_v4_u16 commitment_len;
	prp_wire_v4_u16 ephemeral_key_len = 0;
	prp_wire_v4_u16 kem_public_key_len = 0;
	prp_wire_v4_u16 kem_ciphertext_len = 0;
	prp_wire_v4_u8 nonce_len = 12;
	prp_wire_v4_u8 tag_len = 16;

	switch (id) {
	case PRP_WIRE_V4_SESSION_NONE_BLAKE3:
		hash = PRP_WIRE_V4_HASH_BLAKE3;
		commitment_len = 32;
		nonce_len = 0;
		tag_len = 0;
		break;
	case PRP_WIRE_V4_SESSION_NONE_SHA256:
		hash = PRP_WIRE_V4_HASH_SHA256;
		commitment_len = 32;
		nonce_len = 0;
		tag_len = 0;
		break;
	case PRP_WIRE_V4_SESSION_X25519_CHACHA20POLY1305_BLAKE3:
	case PRP_WIRE_V4_SESSION_X25519_AES256GCM_BLAKE3:
		hash = PRP_WIRE_V4_HASH_BLAKE3;
		commitment_len = 32;
		ephemeral_key_len = 32;
		break;
	case PRP_WIRE_V4_SESSION_X25519_MLKEM768_CHACHA20POLY1305_BLAKE3:
		hash = PRP_WIRE_V4_HASH_BLAKE3;
		commitment_len = 32;
		ephemeral_key_len = 32;
		kem_public_key_len = 1184;
		kem_ciphertext_len = 1088;
		break;
	case PRP_WIRE_V4_SESSION_X25519_MLKEM1024_CHACHA20POLY1305_BLAKE3:
		hash = PRP_WIRE_V4_HASH_BLAKE3;
		commitment_len = 32;
		ephemeral_key_len = 32;
		kem_public_key_len = 1568;
		kem_ciphertext_len = 1568;
		break;
	case PRP_WIRE_V4_SESSION_MLKEM768_AES256GCM_SHA256:
		hash = PRP_WIRE_V4_HASH_SHA256;
		commitment_len = 32;
		kem_public_key_len = 1184;
		kem_ciphertext_len = 1088;
		break;
	case PRP_WIRE_V4_SESSION_MLKEM1024_AES256GCM_SHA384:
		hash = PRP_WIRE_V4_HASH_SHA384;
		commitment_len = 48;
		kem_public_key_len = 1568;
		kem_ciphertext_len = 1568;
		break;
	default:
		return PRP_WIRE_V4_ESUITE;
	}
	value.id = id;
	value.commitment_hash = hash;
	value.commitment_len = commitment_len;
	value.nonce_len = nonce_len;
	value.tag_len = tag_len;
	value.ephemeral_key_len = ephemeral_key_len;
	value.kem_public_key_len = kem_public_key_len;
	value.kem_ciphertext_len = kem_ciphertext_len;
	if (desc)
		*desc = value;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_aop_decode(prp_wire_v4_u16 session_suite_id,
	const prp_wire_v4_u8 *wire, size_t len, struct prp_wire_v4_aop_view *view)
{
	struct prp_wire_v4_session_suite_desc desc;
	size_t overhead;
	int rc;

	if (!wire || !view)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	rc = prp_wire_v4_session_suite_get(session_suite_id, &desc);
	if (rc)
		return rc;
	overhead = (size_t)desc.nonce_len + desc.tag_len;
	if (len < overhead)
		return PRP_WIRE_V4_ETRUNC;
	view->nonce = wire;
	view->nonce_len = desc.nonce_len;
	view->payload = wire + desc.nonce_len;
	view->payload_len = (prp_wire_v4_u16)(len - overhead);
	view->tag = wire + len - desc.tag_len;
	view->tag_len = desc.tag_len;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_record_kind_valid(prp_wire_v4_u8 kind)
{
	return kind >= PRP_WIRE_V4_RECORD_ADJ_CONTROL &&
	       kind <= PRP_WIRE_V4_RECORD_SCOPED_HS2_FRAGMENT;
}

static inline int prp_wire_v4_record_validate_fields(
	prp_wire_v4_u16 route_alias, prp_wire_v4_u8 kind,
	prp_wire_v4_u8 flags)
{
	if (!prp_wire_v4_record_kind_valid(kind) ||
	    route_alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID)
		return PRP_WIRE_V4_ECANON;
	if ((kind == PRP_WIRE_V4_RECORD_ADJ_CONTROL) !=
	    (route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL))
		return PRP_WIRE_V4_ECANON;
	if (kind == PRP_WIRE_V4_RECORD_FRAGMENT) {
		if (flags & ~PRP_WIRE_V4_RECORD_F_RECOVERY)
			return PRP_WIRE_V4_ECANON;
	} else if (flags) {
		return PRP_WIRE_V4_ECANON;
	}
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_record_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_record *record)
{
	prp_wire_v4_u16 body_len;
	int rc;

	if (!wire || !record)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_RECORD_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	body_len = prp_wire_v4_get_be16(wire + 4);
	if (len != PRP_WIRE_V4_RECORD_HEADER_LEN + body_len)
		return PRP_WIRE_V4_ECANON;
	rc = prp_wire_v4_record_validate_fields(
		prp_wire_v4_get_be16(wire), wire[2], wire[3]);
	if (rc)
		return rc;
	record->route_alias = prp_wire_v4_get_be16(wire);
	record->kind = wire[2];
	record->flags = wire[3];
	record->body_len = body_len;
	record->body = wire + PRP_WIRE_V4_RECORD_HEADER_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_record_encode(const struct prp_wire_v4_record *record,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	size_t required;
	size_t i;
	int rc;

	if (!record || !wire || !written || (!record->body && record->body_len))
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_record_validate_fields(record->route_alias,
		record->kind, record->flags);
	if (rc)
		return rc;
	required = PRP_WIRE_V4_RECORD_HEADER_LEN + record->body_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, record->route_alias);
	wire[2] = record->kind;
	wire[3] = record->flags;
	prp_wire_v4_put_be16(wire + 4, record->body_len);
	for (i = 0; i < record->body_len; i++)
		wire[PRP_WIRE_V4_RECORD_HEADER_LEN + i] = record->body[i];
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_rrl_init(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_rrl_cursor *cursor)
{
	if (!wire || !cursor)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_RRL_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	cursor->records_remaining = prp_wire_v4_get_be16(wire);
	cursor->next = wire + PRP_WIRE_V4_RRL_HEADER_LEN;
	cursor->remaining = len - PRP_WIRE_V4_RRL_HEADER_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_rrl_next(struct prp_wire_v4_rrl_cursor *cursor,
	struct prp_wire_v4_record *record)
{
	size_t record_len;
	int rc;

	if (!cursor || !record)
		return PRP_WIRE_V4_EINVAL;
	if (!cursor->records_remaining)
		return PRP_WIRE_V4_ECANON;
	if (cursor->remaining < PRP_WIRE_V4_RECORD_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	record_len = PRP_WIRE_V4_RECORD_HEADER_LEN +
		prp_wire_v4_get_be16(cursor->next + 4);
	if (record_len > cursor->remaining)
		return PRP_WIRE_V4_ETRUNC;
	rc = prp_wire_v4_record_decode(cursor->next, record_len, record);
	if (rc)
		return rc;
	cursor->next += record_len;
	cursor->remaining -= record_len;
	cursor->records_remaining--;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_rrl_finish(const struct prp_wire_v4_rrl_cursor *cursor,
	const prp_wire_v4_u8 **padding, size_t *padding_len)
{
	if (!cursor || !padding || !padding_len)
		return PRP_WIRE_V4_EINVAL;
	if (cursor->records_remaining)
		return PRP_WIRE_V4_ETRUNC;
	*padding = cursor->next;
	*padding_len = cursor->remaining;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_rrl_encode(const struct prp_wire_v4_record *records,
	size_t record_count, const prp_wire_v4_u8 *padding, size_t padding_len,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	size_t pos = PRP_WIRE_V4_RRL_HEADER_LEN;
	size_t i;

	if ((!records && record_count) || (!padding && padding_len) ||
	    !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (record_count > 0xffffU)
		return PRP_WIRE_V4_ERANGE;
	if (capacity < PRP_WIRE_V4_RRL_HEADER_LEN)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, (prp_wire_v4_u16)record_count);
	for (i = 0; i < record_count; i++) {
		size_t encoded;
		int rc = prp_wire_v4_record_encode(&records[i], wire + pos,
			capacity - pos, &encoded);

		if (rc)
			return rc;
		pos += encoded;
	}
	if (padding_len > capacity - pos ||
	    pos + padding_len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	for (i = 0; i < padding_len; i++)
		wire[pos + i] = padding[i];
	pos += padding_len;
	*written = pos;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_onion_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_onion *onion)
{
	prp_wire_v4_u16 direct_len;

	if (!wire || !onion)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_ONION_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	direct_len = prp_wire_v4_get_be16(wire);
	if (!direct_len || (size_t)direct_len > len - PRP_WIRE_V4_ONION_HEADER_LEN)
		return PRP_WIRE_V4_ECANON;
	onion->direct_layer = wire + PRP_WIRE_V4_ONION_HEADER_LEN;
	onion->direct_layer_len = direct_len;
	onion->e2e_annex = onion->direct_layer + direct_len;
	onion->e2e_annex_len = (prp_wire_v4_u16)(len -
		PRP_WIRE_V4_ONION_HEADER_LEN - direct_len);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_direct_init(prp_wire_v4_u16 session_suite_id,
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_direct_cursor *cursor)
{
	struct prp_wire_v4_session_suite_desc desc;
	prp_wire_v4_u16 commitment_len;
	size_t prefix;
	int rc;

	if (!wire || !cursor)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	rc = prp_wire_v4_session_suite_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (len < PRP_WIRE_V4_DIRECT_PREFIX_LEN)
		return PRP_WIRE_V4_ETRUNC;
	commitment_len = prp_wire_v4_get_be16(wire);
	if (commitment_len != desc.commitment_len)
		return PRP_WIRE_V4_ECANON;
	prefix = PRP_WIRE_V4_DIRECT_PREFIX_LEN + commitment_len +
		PRP_WIRE_V4_BRANCH_COUNT_LEN;
	if (len < prefix)
		return PRP_WIRE_V4_ETRUNC;
	cursor->commitment = wire + PRP_WIRE_V4_DIRECT_PREFIX_LEN;
	cursor->commitment_len = commitment_len;
	cursor->branches_remaining = prp_wire_v4_get_be16(
		wire + PRP_WIRE_V4_DIRECT_PREFIX_LEN + commitment_len);
	cursor->next = wire + prefix;
	cursor->remaining = len - prefix;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_direct_next(struct prp_wire_v4_direct_cursor *cursor,
	struct prp_wire_v4_branch *branch)
{
	prp_wire_v4_u32 capability;
	prp_wire_v4_u16 child_len;

	if (!cursor || !branch)
		return PRP_WIRE_V4_EINVAL;
	if (!cursor->branches_remaining)
		return PRP_WIRE_V4_ECANON;
	if (cursor->remaining < PRP_WIRE_V4_BRANCH_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	capability = prp_wire_v4_get_be32(cursor->next);
	child_len = prp_wire_v4_get_be16(cursor->next + 4);
	if (!capability || (size_t)child_len >
	    cursor->remaining - PRP_WIRE_V4_BRANCH_HEADER_LEN)
		return PRP_WIRE_V4_ECANON;
	if ((capability == PRP_WIRE_V4_EGRESS_CAPABILITY_LOCAL) !=
	    (child_len == 0))
		return PRP_WIRE_V4_ECANON;
	branch->egress_capability = capability;
	branch->child_layer_len = child_len;
	branch->child_layer = cursor->next + PRP_WIRE_V4_BRANCH_HEADER_LEN;
	cursor->next += PRP_WIRE_V4_BRANCH_HEADER_LEN + child_len;
	cursor->remaining -= PRP_WIRE_V4_BRANCH_HEADER_LEN + child_len;
	cursor->branches_remaining--;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_direct_finish(const struct prp_wire_v4_direct_cursor *cursor)
{
	if (!cursor)
		return PRP_WIRE_V4_EINVAL;
	return !cursor->branches_remaining && !cursor->remaining ?
		PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int
prp_wire_v4_fragment_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_fragment *fragment)
{
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total;
	size_t segment_len;

	if (!wire || !fragment)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_FRAGMENT_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (wire[1] || !prp_wire_v4_record_kind_valid(wire[0]) ||
	    wire[0] == PRP_WIRE_V4_RECORD_FRAGMENT ||
	    wire[0] == PRP_WIRE_V4_RECORD_SCOPED_HS2_FRAGMENT)
		return PRP_WIRE_V4_ECANON;
	if (!prp_wire_v4_get_be32(wire + 2))
		return PRP_WIRE_V4_ECANON;
	offset = prp_wire_v4_get_be16(wire + 6);
	total = prp_wire_v4_get_be16(wire + 8);
	segment_len = len - PRP_WIRE_V4_FRAGMENT_HEADER_LEN;
	if (!total || !segment_len || offset >= total ||
	    segment_len > (size_t)(total - offset))
		return PRP_WIRE_V4_ECANON;
	fragment->object_kind = wire[0];
	fragment->transfer_id = prp_wire_v4_get_be32(wire + 2);
	fragment->offset = offset;
	fragment->total_len = total;
	fragment->segment = wire + PRP_WIRE_V4_FRAGMENT_HEADER_LEN;
	fragment->segment_len = (prp_wire_v4_u16)segment_len;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_feedback_init(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_feedback_cursor *cursor)
{
	prp_wire_v4_u16 count;

	if (!wire || !cursor)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_ADJ_FEEDBACK_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	count = prp_wire_v4_get_be16(wire);
	if (len != PRP_WIRE_V4_ADJ_FEEDBACK_HEADER_LEN +
	    (size_t)count * PRP_WIRE_V4_ADJ_FEEDBACK_RANGE_LEN)
		return PRP_WIRE_V4_ECANON;
	cursor->next = wire + PRP_WIRE_V4_ADJ_FEEDBACK_HEADER_LEN;
	cursor->ranges_remaining = count;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_feedback_next(struct prp_wire_v4_feedback_cursor *cursor,
	struct prp_wire_v4_feedback_range *range)
{
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 length;

	if (!cursor || !range)
		return PRP_WIRE_V4_EINVAL;
	if (!cursor->ranges_remaining)
		return PRP_WIRE_V4_ECANON;
	offset = prp_wire_v4_get_be16(cursor->next + 4);
	length = prp_wire_v4_get_be16(cursor->next + 6);
	if (!prp_wire_v4_get_be32(cursor->next) || !length ||
	    (prp_wire_v4_u32)offset + length > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ECANON;
	range->transfer_id = prp_wire_v4_get_be32(cursor->next);
	range->offset = offset;
	range->length = length;
	cursor->next += PRP_WIRE_V4_ADJ_FEEDBACK_RANGE_LEN;
	cursor->ranges_remaining--;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_control_kind_valid(prp_wire_v4_u8 kind)
{
	return kind >= PRP_WIRE_V4_CONTROL_HS2 &&
	       kind <= PRP_WIRE_V4_CONTROL_HS2_ADMISSION_PROOF;
}

static inline int
prp_wire_v4_control_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_control *control)
{
	if (!wire || !control)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (!len)
		return PRP_WIRE_V4_ETRUNC;
	if (!prp_wire_v4_control_kind_valid(wire[0]))
		return PRP_WIRE_V4_ECANON;
	control->kind = wire[0];
	control->body = wire + 1;
	control->body_len = (prp_wire_v4_u16)(len - 1);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_onion_encode(const struct prp_wire_v4_onion *onion,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	size_t required;
	size_t i;

	if (!onion || !wire || !written || !onion->direct_layer ||
	    (!onion->e2e_annex && onion->e2e_annex_len))
		return PRP_WIRE_V4_EINVAL;
	if (!onion->direct_layer_len)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_ONION_HEADER_LEN + onion->direct_layer_len +
		onion->e2e_annex_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, onion->direct_layer_len);
	for (i = 0; i < onion->direct_layer_len; i++)
		wire[PRP_WIRE_V4_ONION_HEADER_LEN + i] = onion->direct_layer[i];
	for (i = 0; i < onion->e2e_annex_len; i++)
		wire[PRP_WIRE_V4_ONION_HEADER_LEN + onion->direct_layer_len + i] =
			onion->e2e_annex[i];
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_direct_encode(prp_wire_v4_u16 session_suite_id,
	const prp_wire_v4_u8 *commitment, size_t commitment_len,
	const struct prp_wire_v4_branch *branches, size_t branch_count,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_suite_desc desc;
	struct prp_wire_v4_direct_cursor checked;
	size_t required;
	size_t pos;
	size_t i;
	int rc;

	if (!commitment || (!branches && branch_count) || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (branch_count > 0xffffU)
		return PRP_WIRE_V4_ERANGE;
	rc = prp_wire_v4_session_suite_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (commitment_len != desc.commitment_len)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_DIRECT_PREFIX_LEN + commitment_len +
		PRP_WIRE_V4_BRANCH_COUNT_LEN;
	for (i = 0; i < branch_count; i++) {
		if (!branches[i].egress_capability ||
		    (branches[i].egress_capability ==
			PRP_WIRE_V4_EGRESS_CAPABILITY_LOCAL) !=
		    (branches[i].child_layer_len == 0) ||
		    (!branches[i].child_layer && branches[i].child_layer_len))
			return PRP_WIRE_V4_ECANON;
		required += PRP_WIRE_V4_BRANCH_HEADER_LEN +
			branches[i].child_layer_len;
	}
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, (prp_wire_v4_u16)commitment_len);
	for (i = 0; i < commitment_len; i++)
		wire[PRP_WIRE_V4_DIRECT_PREFIX_LEN + i] = commitment[i];
	pos = PRP_WIRE_V4_DIRECT_PREFIX_LEN + commitment_len;
	prp_wire_v4_put_be16(wire + pos, (prp_wire_v4_u16)branch_count);
	pos += PRP_WIRE_V4_BRANCH_COUNT_LEN;
	for (i = 0; i < branch_count; i++) {
		size_t j;

		prp_wire_v4_put_be32(wire + pos, branches[i].egress_capability);
		prp_wire_v4_put_be16(wire + pos + 4,
			branches[i].child_layer_len);
		for (j = 0; j < branches[i].child_layer_len; j++)
			wire[pos + PRP_WIRE_V4_BRANCH_HEADER_LEN + j] =
				branches[i].child_layer[j];
		pos += PRP_WIRE_V4_BRANCH_HEADER_LEN +
			branches[i].child_layer_len;
	}
	rc = prp_wire_v4_direct_init(session_suite_id, wire, required, &checked);
	if (rc)
		return rc;
	for (i = 0; i < branch_count; i++) {
		struct prp_wire_v4_branch branch;

		rc = prp_wire_v4_direct_next(&checked, &branch);
		if (rc)
			return rc;
	}
	rc = prp_wire_v4_direct_finish(&checked);
	if (rc)
		return rc;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_fragment_encode(const struct prp_wire_v4_fragment *fragment,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_fragment checked;
	size_t required;
	size_t i;
	int rc;

	if (!fragment || !wire || !written || !fragment->segment)
		return PRP_WIRE_V4_EINVAL;
	required = PRP_WIRE_V4_FRAGMENT_HEADER_LEN + fragment->segment_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = fragment->object_kind;
	wire[1] = 0;
	prp_wire_v4_put_be32(wire + 2, fragment->transfer_id);
	prp_wire_v4_put_be16(wire + 6, fragment->offset);
	prp_wire_v4_put_be16(wire + 8, fragment->total_len);
	for (i = 0; i < fragment->segment_len; i++)
		wire[PRP_WIRE_V4_FRAGMENT_HEADER_LEN + i] = fragment->segment[i];
	rc = prp_wire_v4_fragment_decode(wire, required, &checked);
	if (rc)
		return rc;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_feedback_encode(const struct prp_wire_v4_feedback_range *ranges,
	size_t range_count, prp_wire_v4_u8 *wire, size_t capacity,
	size_t *written)
{
	struct prp_wire_v4_feedback_cursor cursor;
	size_t required;
	size_t pos;
	size_t i;
	int rc;

	if ((!ranges && range_count) || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (range_count > 0xffffU)
		return PRP_WIRE_V4_ERANGE;
	required = PRP_WIRE_V4_ADJ_FEEDBACK_HEADER_LEN +
		range_count * PRP_WIRE_V4_ADJ_FEEDBACK_RANGE_LEN;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, (prp_wire_v4_u16)range_count);
	pos = PRP_WIRE_V4_ADJ_FEEDBACK_HEADER_LEN;
	for (i = 0; i < range_count; i++) {
		prp_wire_v4_put_be32(wire + pos, ranges[i].transfer_id);
		prp_wire_v4_put_be16(wire + pos + 4, ranges[i].offset);
		prp_wire_v4_put_be16(wire + pos + 6, ranges[i].length);
		pos += PRP_WIRE_V4_ADJ_FEEDBACK_RANGE_LEN;
	}
	rc = prp_wire_v4_feedback_init(wire, required, &cursor);
	if (rc)
		return rc;
	for (i = 0; i < range_count; i++) {
		struct prp_wire_v4_feedback_range range;

		rc = prp_wire_v4_feedback_next(&cursor, &range);
		if (rc)
			return rc;
	}
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_control_encode(const struct prp_wire_v4_control *control,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	size_t required;
	size_t i;

	if (!control || !wire || !written || (!control->body && control->body_len))
		return PRP_WIRE_V4_EINVAL;
	if (!prp_wire_v4_control_kind_valid(control->kind))
		return PRP_WIRE_V4_ECANON;
	required = 1U + control->body_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = control->kind;
	for (i = 0; i < control->body_len; i++)
		wire[1U + i] = control->body[i];
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_alias_lifecycle_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_alias_lifecycle *lifecycle)
{
	prp_wire_v4_u8 operation;
	prp_wire_v4_u16 alias;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u32 lease;

	if (!wire || !lifecycle)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_ALIAS_LIFECYCLE_LEN)
		return len < PRP_WIRE_V4_ALIAS_LIFECYCLE_LEN ?
			PRP_WIRE_V4_ETRUNC : PRP_WIRE_V4_ECANON;
	operation = wire[0];
	alias = prp_wire_v4_get_be16(wire + 2);
	generation = prp_wire_v4_get_be32(wire + 4);
	lease = prp_wire_v4_get_be32(wire + 8);
	if (operation < PRP_WIRE_V4_ALIAS_OFFER ||
	    operation > PRP_WIRE_V4_ALIAS_REVOKE || wire[1] ||
	    alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
	    alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL || !generation)
		return PRP_WIRE_V4_ECANON;
	if ((operation == PRP_WIRE_V4_ALIAS_REVOKE) != (lease == 0))
		return PRP_WIRE_V4_ECANON;
	lifecycle->operation = operation;
	lifecycle->route_alias = alias;
	lifecycle->generation = generation;
	lifecycle->lease_seconds = lease;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_error_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_scoped_error *error)
{
	prp_wire_v4_u16 token_len;

	if (!wire || !error)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_SCOPED_ERROR_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	token_len = prp_wire_v4_get_be16(wire + 8);
	if (len != PRP_WIRE_V4_SCOPED_ERROR_HEADER_LEN + token_len)
		return PRP_WIRE_V4_ECANON;
	if (wire[0] < PRP_WIRE_V4_SCOPE_ADJACENT ||
	    wire[0] > PRP_WIRE_V4_SCOPE_E2E ||
	    wire[1] < PRP_WIRE_V4_ERROR_POLICY ||
	    wire[1] > PRP_WIRE_V4_ERROR_TEMPORARY)
		return PRP_WIRE_V4_ECANON;
	error->scope = wire[0];
	error->error_class = wire[1];
	error->reason = prp_wire_v4_get_be16(wire + 2);
	error->retry_after_ms = prp_wire_v4_get_be32(wire + 4);
	error->token_len = token_len;
	error->token = wire + PRP_WIRE_V4_SCOPED_ERROR_HEADER_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_close_decode(const prp_wire_v4_u8 *wire, size_t len,
	int acknowledgment, struct prp_wire_v4_close *close)
{
	prp_wire_v4_u8 value;
	prp_wire_v4_u16 reason;

	if (!wire || !close)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_CLOSE_LEN)
		return len < PRP_WIRE_V4_CLOSE_LEN ?
			PRP_WIRE_V4_ETRUNC : PRP_WIRE_V4_ECANON;
	value = wire[1];
	reason = prp_wire_v4_get_be16(wire + 2);
	if (wire[0] < PRP_WIRE_V4_SCOPE_ADJACENT ||
	    wire[0] > PRP_WIRE_V4_SCOPE_E2E ||
	    !prp_wire_v4_get_be32(wire + 4) ||
	    !prp_wire_v4_get_be32(wire + 8))
		return PRP_WIRE_V4_ECANON;
	if (acknowledgment) {
		if (value < PRP_WIRE_V4_CLOSE_STATUS_CLOSED ||
		    value > PRP_WIRE_V4_CLOSE_STATUS_REFUSED || reason)
			return PRP_WIRE_V4_ECANON;
	} else if (value < PRP_WIRE_V4_CLOSE_GRACEFUL ||
		   value > PRP_WIRE_V4_CLOSE_HARD) {
		return PRP_WIRE_V4_ECANON;
	}
	close->scope = wire[0];
	close->mode_or_status = value;
	close->reason = reason;
	close->generation = prp_wire_v4_get_be32(wire + 4);
	close->selector = prp_wire_v4_get_be32(wire + 8);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_alias_lifecycle_encode(
	const struct prp_wire_v4_alias_lifecycle *lifecycle,
	prp_wire_v4_u8 *wire, size_t capacity)
{
	struct prp_wire_v4_alias_lifecycle checked;
	prp_wire_v4_u8 candidate[PRP_WIRE_V4_ALIAS_LIFECYCLE_LEN];
	int rc;

	if (!lifecycle || !wire)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < sizeof(candidate))
		return PRP_WIRE_V4_ERANGE;
	candidate[0] = lifecycle->operation;
	candidate[1] = 0;
	prp_wire_v4_put_be16(candidate + 2, lifecycle->route_alias);
	prp_wire_v4_put_be32(candidate + 4, lifecycle->generation);
	prp_wire_v4_put_be32(candidate + 8, lifecycle->lease_seconds);
	rc = prp_wire_v4_alias_lifecycle_decode(candidate, sizeof(candidate),
		&checked);
	if (rc)
		return rc;
	for (size_t i = 0; i < sizeof(candidate); i++)
		wire[i] = candidate[i];
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_error_encode(const struct prp_wire_v4_scoped_error *error,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_scoped_error checked;
	size_t required;
	size_t i;
	int rc;

	if (!error || !wire || !written || (!error->token && error->token_len))
		return PRP_WIRE_V4_EINVAL;
	required = PRP_WIRE_V4_SCOPED_ERROR_HEADER_LEN + error->token_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = error->scope;
	wire[1] = error->error_class;
	prp_wire_v4_put_be16(wire + 2, error->reason);
	prp_wire_v4_put_be32(wire + 4, error->retry_after_ms);
	prp_wire_v4_put_be16(wire + 8, error->token_len);
	for (i = 0; i < error->token_len; i++)
		wire[PRP_WIRE_V4_SCOPED_ERROR_HEADER_LEN + i] = error->token[i];
	rc = prp_wire_v4_scoped_error_decode(wire, required, &checked);
	if (rc)
		return rc;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_close_encode(const struct prp_wire_v4_close *close,
	int acknowledgment, prp_wire_v4_u8 *wire, size_t capacity)
{
	struct prp_wire_v4_close checked;
	int rc;

	if (!close || !wire)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_CLOSE_LEN)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = close->scope;
	wire[1] = close->mode_or_status;
	prp_wire_v4_put_be16(wire + 2, close->reason);
	prp_wire_v4_put_be32(wire + 4, close->generation);
	prp_wire_v4_put_be32(wire + 8, close->selector);
	rc = prp_wire_v4_close_decode(wire, PRP_WIRE_V4_CLOSE_LEN,
		acknowledgment, &checked);
	return rc;
}

static inline size_t
prp_wire_v4_connection_control_len(prp_wire_v4_u8 kind)
{
	switch (kind) {
	case PRP_WIRE_V4_CONNECTION_OPEN:
		return PRP_WIRE_V4_CONNECTION_OPEN_LEN;
	case PRP_WIRE_V4_CONNECTION_ACCEPT:
		return PRP_WIRE_V4_CONNECTION_ACCEPT_LEN;
	case PRP_WIRE_V4_CONNECTION_REFUSE:
		return PRP_WIRE_V4_CONNECTION_REFUSE_LEN;
	case PRP_WIRE_V4_CONNECTION_CLOSE:
		return PRP_WIRE_V4_CONNECTION_CLOSE_LEN;
	case PRP_WIRE_V4_CONNECTION_CLOSE_ACK:
		return PRP_WIRE_V4_CONNECTION_CLOSE_ACK_LEN;
	case PRP_WIRE_V4_CONNECTION_FEEDBACK:
		return PRP_WIRE_V4_CONNECTION_FEEDBACK_LEN;
	default:
		return 0;
	}
}

static inline int
prp_wire_v4_connection_policy_validate(prp_wire_v4_u16 flags,
	prp_wire_v4_u16 window, prp_wire_v4_u32 max_queued_bytes,
	prp_wire_v4_u32 tombstone_ms)
{
	if ((flags & ~PRP_WIRE_V4_CONNECTION_F_MASK) || !tombstone_ms)
		return PRP_WIRE_V4_ECANON;
	if ((flags & PRP_WIRE_V4_CONNECTION_F_RELIABLE) &&
	    !(flags & PRP_WIRE_V4_CONNECTION_F_ORDERED))
		return PRP_WIRE_V4_ECANON;
	if (flags & PRP_WIRE_V4_CONNECTION_F_ORDERED) {
		if (!window || window > PRP_WIRE_V4_CONNECTION_MAX_WINDOW ||
		    !max_queued_bytes)
			return PRP_WIRE_V4_ECANON;
	} else if (window || max_queued_bytes) {
		return PRP_WIRE_V4_ECANON;
	}
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_connection_control_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_connection_control *control)
{
	size_t required;
	int rc;

	if (!wire || !control)
		return PRP_WIRE_V4_EINVAL;
	if (!len)
		return PRP_WIRE_V4_ETRUNC;
	required = prp_wire_v4_connection_control_len(wire[0]);
	if (!required)
		return PRP_WIRE_V4_ECANON;
	if (len != required)
		return len < required ? PRP_WIRE_V4_ETRUNC : PRP_WIRE_V4_ECANON;
	control->kind = wire[0];
	control->request_id = 0;
	control->connection_alias = 0;
	control->generation = 0;
	control->flags = 0;
	control->window = 0;
	control->max_queued_bytes = 0;
	control->tombstone_ms = 0;
	control->reason = 0;
	control->retry_after_ms = 0;
	control->close_mode_or_status = 0;
	control->next_sequence = 0;
	control->received_bitmap = 0;
	switch (wire[0]) {
	case PRP_WIRE_V4_CONNECTION_OPEN:
		control->request_id = prp_wire_v4_get_be32(wire + 1);
		control->flags = prp_wire_v4_get_be16(wire + 5);
		control->window = prp_wire_v4_get_be16(wire + 7);
		control->max_queued_bytes = prp_wire_v4_get_be32(wire + 9);
		control->tombstone_ms = prp_wire_v4_get_be32(wire + 13);
		if (!control->request_id)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_connection_policy_validate(control->flags,
			control->window, control->max_queued_bytes,
			control->tombstone_ms);
	case PRP_WIRE_V4_CONNECTION_ACCEPT:
		control->request_id = prp_wire_v4_get_be32(wire + 1);
		control->connection_alias = prp_wire_v4_get_be16(wire + 5);
		control->generation = prp_wire_v4_get_be32(wire + 7);
		control->flags = prp_wire_v4_get_be16(wire + 11);
		control->window = prp_wire_v4_get_be16(wire + 13);
		control->max_queued_bytes = prp_wire_v4_get_be32(wire + 15);
		control->tombstone_ms = prp_wire_v4_get_be32(wire + 19);
		if (!control->request_id || !control->connection_alias ||
		    !control->generation)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_connection_policy_validate(control->flags,
			control->window, control->max_queued_bytes,
			control->tombstone_ms);
	case PRP_WIRE_V4_CONNECTION_REFUSE:
		control->request_id = prp_wire_v4_get_be32(wire + 1);
		control->reason = prp_wire_v4_get_be16(wire + 5);
		control->retry_after_ms = prp_wire_v4_get_be32(wire + 7);
		if (!control->request_id ||
		    control->reason > PRP_WIRE_V4_CONNECTION_REASON_SHUTDOWN)
			return PRP_WIRE_V4_ECANON;
		break;
	case PRP_WIRE_V4_CONNECTION_CLOSE:
		control->connection_alias = prp_wire_v4_get_be16(wire + 1);
		control->generation = prp_wire_v4_get_be32(wire + 3);
		control->close_mode_or_status = wire[7];
		control->reason = prp_wire_v4_get_be16(wire + 8);
		if (!control->connection_alias || !control->generation ||
		    control->close_mode_or_status < PRP_WIRE_V4_CLOSE_GRACEFUL ||
		    control->close_mode_or_status > PRP_WIRE_V4_CLOSE_HARD)
			return PRP_WIRE_V4_ECANON;
		break;
	case PRP_WIRE_V4_CONNECTION_CLOSE_ACK:
		control->connection_alias = prp_wire_v4_get_be16(wire + 1);
		control->generation = prp_wire_v4_get_be32(wire + 3);
		control->close_mode_or_status = wire[7];
		if (!control->connection_alias || !control->generation ||
		    control->close_mode_or_status >
			PRP_WIRE_V4_CONNECTION_CLOSE_STATUS_ALREADY_CLOSED)
			return PRP_WIRE_V4_ECANON;
		break;
	case PRP_WIRE_V4_CONNECTION_FEEDBACK:
		control->connection_alias = prp_wire_v4_get_be16(wire + 1);
		control->generation = prp_wire_v4_get_be32(wire + 3);
		control->next_sequence = prp_wire_v4_get_be64(wire + 7);
		control->received_bitmap = prp_wire_v4_get_be64(wire + 15);
		if (!control->connection_alias || !control->generation)
			return PRP_WIRE_V4_ECANON;
		break;
	}
	rc = PRP_WIRE_V4_OK;
	return rc;
}

static inline int
prp_wire_v4_connection_control_encode(
	const struct prp_wire_v4_connection_control *control,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_connection_control checked;
	size_t required;
	int rc;

	if (!control || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	required = prp_wire_v4_connection_control_len(control->kind);
	if (!required)
		return PRP_WIRE_V4_ECANON;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = control->kind;
	switch (control->kind) {
	case PRP_WIRE_V4_CONNECTION_OPEN:
		prp_wire_v4_put_be32(wire + 1, control->request_id);
		prp_wire_v4_put_be16(wire + 5, control->flags);
		prp_wire_v4_put_be16(wire + 7, control->window);
		prp_wire_v4_put_be32(wire + 9, control->max_queued_bytes);
		prp_wire_v4_put_be32(wire + 13, control->tombstone_ms);
		break;
	case PRP_WIRE_V4_CONNECTION_ACCEPT:
		prp_wire_v4_put_be32(wire + 1, control->request_id);
		prp_wire_v4_put_be16(wire + 5, control->connection_alias);
		prp_wire_v4_put_be32(wire + 7, control->generation);
		prp_wire_v4_put_be16(wire + 11, control->flags);
		prp_wire_v4_put_be16(wire + 13, control->window);
		prp_wire_v4_put_be32(wire + 15, control->max_queued_bytes);
		prp_wire_v4_put_be32(wire + 19, control->tombstone_ms);
		break;
	case PRP_WIRE_V4_CONNECTION_REFUSE:
		prp_wire_v4_put_be32(wire + 1, control->request_id);
		prp_wire_v4_put_be16(wire + 5, control->reason);
		prp_wire_v4_put_be32(wire + 7, control->retry_after_ms);
		break;
	case PRP_WIRE_V4_CONNECTION_CLOSE:
		prp_wire_v4_put_be16(wire + 1, control->connection_alias);
		prp_wire_v4_put_be32(wire + 3, control->generation);
		wire[7] = control->close_mode_or_status;
		prp_wire_v4_put_be16(wire + 8, control->reason);
		break;
	case PRP_WIRE_V4_CONNECTION_CLOSE_ACK:
		prp_wire_v4_put_be16(wire + 1, control->connection_alias);
		prp_wire_v4_put_be32(wire + 3, control->generation);
		wire[7] = control->close_mode_or_status;
		break;
	case PRP_WIRE_V4_CONNECTION_FEEDBACK:
		prp_wire_v4_put_be16(wire + 1, control->connection_alias);
		prp_wire_v4_put_be32(wire + 3, control->generation);
		prp_wire_v4_put_be64(wire + 7, control->next_sequence);
		prp_wire_v4_put_be64(wire + 15, control->received_bitmap);
		break;
	}
	rc = prp_wire_v4_connection_control_decode(wire, required, &checked);
	if (rc)
		return rc;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_identity_address_validate(const prp_wire_v4_u8 *wire, size_t len)
{
	struct prp_wire_v4_identity_suite_desc desc;
	int rc;

	if (!wire)
		return PRP_WIRE_V4_EINVAL;
	if (len < 2)
		return PRP_WIRE_V4_ETRUNC;
	rc = prp_wire_v4_identity_suite_get(prp_wire_v4_get_be16(wire), &desc);
	if (rc)
		return rc;
	return len == 2U + desc.strong_id_len ?
		PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int
prp_wire_v4_identity_address_encode(prp_wire_v4_u16 identity_suite_id,
	const prp_wire_v4_u8 *strong_id, size_t strong_id_len,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_identity_suite_desc desc;
	int rc;
	size_t i;

	if (!strong_id || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_identity_suite_get(identity_suite_id, &desc);
	if (rc)
		return rc;
	if (strong_id_len != desc.strong_id_len)
		return PRP_WIRE_V4_ECANON;
	if (capacity < 2U + strong_id_len)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, identity_suite_id);
	for (i = 0; i < strong_id_len; i++)
		wire[2U + i] = strong_id[i];
	*written = 2U + strong_id_len;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_header_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_hs2_header *header)
{
	prp_wire_v4_u16 suite;

	if (!wire || !header)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_HS2_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (wire[0] != PRP_WIRE_V4_VERSION)
		return PRP_WIRE_V4_EVERSION;
	suite = prp_wire_v4_get_be16(wire + 1);
	if (prp_wire_v4_session_suite_get(suite, NULL))
		return PRP_WIRE_V4_ESUITE;
	if (wire[3] != PRP_WIRE_V4_HS2_M1 && wire[3] != PRP_WIRE_V4_HS2_M2)
		return PRP_WIRE_V4_ECANON;
	header->session_suite_id = suite;
	header->kind = wire[3];
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_header_encode(const struct prp_wire_v4_hs2_header *header,
	prp_wire_v4_u8 *wire, size_t capacity)
{
	if (!header || !wire)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_HS2_HEADER_LEN)
		return PRP_WIRE_V4_ERANGE;
	if (prp_wire_v4_session_suite_get(header->session_suite_id, NULL))
		return PRP_WIRE_V4_ESUITE;
	if (header->kind != PRP_WIRE_V4_HS2_M1 &&
	    header->kind != PRP_WIRE_V4_HS2_M2)
		return PRP_WIRE_V4_ECANON;
	wire[0] = PRP_WIRE_V4_VERSION;
	prp_wire_v4_put_be16(wire + 1, header->session_suite_id);
	wire[3] = header->kind;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_identity_suite_tlv_decode(const prp_wire_v4_u8 *wire,
	size_t len, prp_wire_v4_u16 *identity_suite_id)
{
	prp_wire_v4_u16 suite;

	if (!wire || !identity_suite_id)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_IDENTITY_SUITE_TLV_LEN)
		return len < PRP_WIRE_V4_IDENTITY_SUITE_TLV_LEN ?
			PRP_WIRE_V4_ETRUNC : PRP_WIRE_V4_ECANON;
	if (wire[0] != PRP_WIRE_V4_IDENTITY_SUITE_TLV ||
	    prp_wire_v4_get_be16(wire + 1) != 2)
		return PRP_WIRE_V4_ECANON;
	suite = prp_wire_v4_get_be16(wire + 3);
	if (prp_wire_v4_identity_suite_get(suite, NULL))
		return PRP_WIRE_V4_ESUITE;
	*identity_suite_id = suite;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_identity_suite_tlv_encode(prp_wire_v4_u16 identity_suite_id,
	prp_wire_v4_u8 *wire, size_t capacity)
{
	if (!wire)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_IDENTITY_SUITE_TLV_LEN)
		return PRP_WIRE_V4_ERANGE;
	if (prp_wire_v4_identity_suite_get(identity_suite_id, NULL))
		return PRP_WIRE_V4_ESUITE;
	wire[0] = PRP_WIRE_V4_IDENTITY_SUITE_TLV;
	prp_wire_v4_put_be16(wire + 1, 2);
	prp_wire_v4_put_be16(wire + 3, identity_suite_id);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_validate(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_hs2_view *view)
{
	const prp_wire_v4_u8 *values[10] = { 0 };
	prp_wire_v4_u16 lengths[10] = { 0 };
	struct prp_wire_v4_identity_suite_desc identity;
	struct prp_wire_v4_session_suite_desc session;
	struct prp_wire_v4_hs2_header header;
	prp_wire_v4_u16 identity_suite;
	prp_wire_v4_u8 previous = 0;
	size_t pos = PRP_WIRE_V4_HS2_HEADER_LEN;
	int have_previous = 0;
	int rc;

	if (!wire || !view)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_HS2_MAX_LEN)
		return PRP_WIRE_V4_ERANGE;
	rc = prp_wire_v4_hs2_header_decode(wire, len, &header);
	if (rc)
		return rc;
	while (pos < len) {
		prp_wire_v4_u8 type;
		prp_wire_v4_u16 value_len;

		if (len - pos < PRP_WIRE_V4_TLV_HEADER_LEN)
			return PRP_WIRE_V4_ETRUNC;
		type = wire[pos];
		value_len = prp_wire_v4_get_be16(wire + pos + 1);
		if (type > PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF ||
		    (have_previous && type <= previous))
			return PRP_WIRE_V4_ECANON;
		pos += PRP_WIRE_V4_TLV_HEADER_LEN;
		if (value_len > len - pos)
			return PRP_WIRE_V4_ETRUNC;
		values[type] = wire + pos;
		lengths[type] = value_len;
		previous = type;
		have_previous = 1;
		pos += value_len;
	}
	if (!values[PRP_WIRE_V4_HS2_TLV_NONCE] ||
	    lengths[PRP_WIRE_V4_HS2_TLV_NONCE] != PRP_WIRE_V4_HS2_NONCE_LEN ||
	    !values[PRP_WIRE_V4_HS2_TLV_IDENTITY_SUITE] ||
	    lengths[PRP_WIRE_V4_HS2_TLV_IDENTITY_SUITE] != 2 ||
	    !values[PRP_WIRE_V4_HS2_TLV_IDENTITY_PUBLIC_KEY] ||
	    !values[PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF] ||
	    previous != PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF)
		return PRP_WIRE_V4_ECANON;
	identity_suite = prp_wire_v4_get_be16(
		values[PRP_WIRE_V4_HS2_TLV_IDENTITY_SUITE]);
	rc = prp_wire_v4_identity_suite_get(identity_suite, &identity);
	if (rc)
		return rc;
	rc = prp_wire_v4_session_suite_get(header.session_suite_id, &session);
	if (rc)
		return rc;
	if (lengths[PRP_WIRE_V4_HS2_TLV_IDENTITY_PUBLIC_KEY] !=
		identity.public_key_len ||
	    lengths[PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF] != identity.proof_len)
		return PRP_WIRE_V4_ECANON;
	if ((session.ephemeral_key_len != 0) !=
	    (values[PRP_WIRE_V4_HS2_TLV_EPHEMERAL_KEY] != NULL) ||
	    (session.ephemeral_key_len &&
	     lengths[PRP_WIRE_V4_HS2_TLV_EPHEMERAL_KEY] !=
		session.ephemeral_key_len))
		return PRP_WIRE_V4_ECANON;
	if (header.kind == PRP_WIRE_V4_HS2_M1) {
		if ((session.kem_public_key_len != 0) !=
		    (values[PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY] != NULL) ||
		    (session.kem_public_key_len &&
		     lengths[PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY] !=
			session.kem_public_key_len) ||
		    values[PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT] ||
		    values[PRP_WIRE_V4_HS2_TLV_M1_BINDING] ||
		    values[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION])
			return PRP_WIRE_V4_ECANON;
	} else {
		if (values[PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY] ||
		    (session.kem_ciphertext_len != 0) !=
		    (values[PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT] != NULL) ||
		    (session.kem_ciphertext_len &&
		     lengths[PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT] !=
			session.kem_ciphertext_len) ||
		    !values[PRP_WIRE_V4_HS2_TLV_M1_BINDING] ||
		    lengths[PRP_WIRE_V4_HS2_TLV_M1_BINDING] !=
			session.commitment_len ||
		    !values[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION] ||
		    lengths[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION] != 4 ||
		    !prp_wire_v4_get_be32(
			values[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION]))
			return PRP_WIRE_V4_ECANON;
	}
	view->session_suite_id = header.session_suite_id;
	view->identity_suite_id = identity_suite;
	view->kind = header.kind;
	view->discovery = values[PRP_WIRE_V4_HS2_TLV_DISCOVERY];
	view->discovery_len = lengths[PRP_WIRE_V4_HS2_TLV_DISCOVERY];
	view->nonce = values[PRP_WIRE_V4_HS2_TLV_NONCE];
	view->nonce_len = lengths[PRP_WIRE_V4_HS2_TLV_NONCE];
	view->ephemeral_key = values[PRP_WIRE_V4_HS2_TLV_EPHEMERAL_KEY];
	view->ephemeral_key_len =
		lengths[PRP_WIRE_V4_HS2_TLV_EPHEMERAL_KEY];
	view->kem_value = header.kind == PRP_WIRE_V4_HS2_M1 ?
		values[PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY] :
		values[PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT];
	view->kem_value_len = header.kind == PRP_WIRE_V4_HS2_M1 ?
		lengths[PRP_WIRE_V4_HS2_TLV_KEM_PUBLIC_KEY] :
		lengths[PRP_WIRE_V4_HS2_TLV_KEM_CIPHERTEXT];
	view->public_key = values[PRP_WIRE_V4_HS2_TLV_IDENTITY_PUBLIC_KEY];
	view->public_key_len = identity.public_key_len;
	view->m1_binding = values[PRP_WIRE_V4_HS2_TLV_M1_BINDING];
	view->m1_binding_len = lengths[PRP_WIRE_V4_HS2_TLV_M1_BINDING];
	view->proof = values[PRP_WIRE_V4_HS2_TLV_IDENTITY_PROOF];
	view->proof_len = identity.proof_len;
	view->session_generation =
		values[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION] ?
		prp_wire_v4_get_be32(
			values[PRP_WIRE_V4_HS2_TLV_SESSION_GENERATION]) : 0;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_scoped_hs2 *scoped)
{
	struct prp_wire_v4_hs2_view view;
	prp_wire_v4_u16 alias;
	int rc;

	if (!wire || !scoped)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN +
	    PRP_WIRE_V4_HS2_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	alias = prp_wire_v4_get_be16(wire + 1);
	if (wire[0] < PRP_WIRE_V4_SCOPE_ADJACENT ||
	    wire[0] > PRP_WIRE_V4_SCOPE_E2E ||
	    (wire[0] == PRP_WIRE_V4_SCOPE_ADJACENT &&
	     alias != PRP_WIRE_V4_ROUTE_ALIAS_CONTROL) ||
	    (wire[0] != PRP_WIRE_V4_SCOPE_ADJACENT &&
	     (alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
	      alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL)))
		return PRP_WIRE_V4_ECANON;
	rc = prp_wire_v4_hs2_validate(wire + PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN,
		len - PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN, &view);
	if (rc)
		return rc;
	scoped->scope = wire[0];
	scoped->route_alias = alias;
	scoped->hs2 = wire + PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN;
	scoped->hs2_len = (prp_wire_v4_u16)(len -
		PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_encode(const struct prp_wire_v4_scoped_hs2 *scoped,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_scoped_hs2 checked;
	size_t required;
	size_t i;
	int rc;

	if (!scoped || !wire || !written || !scoped->hs2)
		return PRP_WIRE_V4_EINVAL;
	required = PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN + scoped->hs2_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = scoped->scope;
	prp_wire_v4_put_be16(wire + 1, scoped->route_alias);
	for (i = 0; i < scoped->hs2_len; i++)
		wire[PRP_WIRE_V4_SCOPED_HS2_PREFIX_LEN + i] = scoped->hs2[i];
	rc = prp_wire_v4_scoped_hs2_decode(wire, required, &checked);
	if (rc)
		return rc;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_key_lifecycle_encode(
	const struct prp_wire_v4_key_lifecycle *policy,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	if (!policy || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (!policy->max_active_key_age_ms || !policy->idle_key_retention_ms)
		return PRP_WIRE_V4_ECANON;
	if (capacity < PRP_WIRE_V4_KEY_LIFECYCLE_LEN)
		return PRP_WIRE_V4_ETRUNC;
	prp_wire_v4_put_be64(wire, policy->max_active_key_age_ms);
	prp_wire_v4_put_be64(wire + 8, policy->max_encrypted_bytes);
	prp_wire_v4_put_be64(wire + 16, policy->max_encrypted_items);
	prp_wire_v4_put_be64(wire + 24, policy->idle_key_retention_ms);
	prp_wire_v4_put_be32(wire + 32, policy->old_generation_overlap_ms);
	prp_wire_v4_put_be32(wire + 36, 0);
	*written = PRP_WIRE_V4_KEY_LIFECYCLE_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_carrier_attachment_binding_encode(
	const struct prp_wire_v4_carrier_attachment_binding *binding,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	size_t i;
	int nonzero = 0;

	if (!binding || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_CARRIER_ATTACHMENT_BINDING_LEN)
		return PRP_WIRE_V4_ETRUNC;
	for (i = 0; i < PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN; i++)
		nonzero |= binding->attachment_id[i];
	if (!nonzero || !binding->attachment_generation)
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN; i++)
		wire[i] = binding->attachment_id[i];
	prp_wire_v4_put_be64(wire + PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN,
		binding->attachment_generation);
	*written = PRP_WIRE_V4_CARRIER_ATTACHMENT_BINDING_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_carrier_attachment_binding_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_carrier_attachment_binding *binding)
{
	size_t i;
	int nonzero = 0;

	if (!wire || !binding)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_CARRIER_ATTACHMENT_BINDING_LEN)
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN; i++) {
		binding->attachment_id[i] = wire[i];
		nonzero |= wire[i];
	}
	binding->attachment_generation = prp_wire_v4_get_be64(wire +
		PRP_WIRE_V4_CARRIER_ATTACHMENT_ID_LEN);
	return nonzero && binding->attachment_generation ?
		PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int prp_wire_v4_discovery_policy_encode(
	const struct prp_wire_v4_discovery_policy *policy,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	int any_selector;
	int all_selectors;

	if (!policy || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_DISCOVERY_POLICY_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (policy->direction < PRP_WIRE_V4_DISCOVERY_INITIATOR_TO_RESPONDER ||
	    policy->direction > PRP_WIRE_V4_DISCOVERY_RESPONDER_TO_INITIATOR)
		return PRP_WIRE_V4_ECANON;
	any_selector = policy->index_algorithm || policy->query_algorithm ||
		policy->profile;
	all_selectors = policy->index_algorithm && policy->query_algorithm &&
		policy->profile;
	if (any_selector && !all_selectors)
		return PRP_WIRE_V4_ECANON;
	wire[0] = policy->direction;
	wire[1] = 0;
	prp_wire_v4_put_be16(wire + 2, policy->index_algorithm);
	prp_wire_v4_put_be16(wire + 4, policy->query_algorithm);
	prp_wire_v4_put_be16(wire + 6, policy->profile);
	*written = PRP_WIRE_V4_DISCOVERY_POLICY_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_discovery_policy_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_discovery_policy *policy)
{
	int any_selector;
	int all_selectors;

	if (!wire || !policy)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_DISCOVERY_POLICY_LEN)
		return PRP_WIRE_V4_ECANON;
	policy->direction = wire[0];
	policy->index_algorithm = prp_wire_v4_get_be16(wire + 2);
	policy->query_algorithm = prp_wire_v4_get_be16(wire + 4);
	policy->profile = prp_wire_v4_get_be16(wire + 6);
	any_selector = policy->index_algorithm || policy->query_algorithm ||
		policy->profile;
	all_selectors = policy->index_algorithm && policy->query_algorithm &&
		policy->profile;
	if (wire[1] ||
	    policy->direction < PRP_WIRE_V4_DISCOVERY_INITIATOR_TO_RESPONDER ||
	    policy->direction > PRP_WIRE_V4_DISCOVERY_RESPONDER_TO_INITIATOR ||
	    (any_selector && !all_selectors))
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_discovery_lane_bind_encode(
	const struct prp_wire_v4_discovery_lane_bind *binding,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	if (!binding || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_DISCOVERY_LANE_BIND_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (binding->direction < PRP_WIRE_V4_DISCOVERY_INITIATOR_TO_RESPONDER ||
	    binding->direction > PRP_WIRE_V4_DISCOVERY_RESPONDER_TO_INITIATOR ||
	    binding->connection_flags != PRP_WIRE_V4_CONNECTION_F_MASK ||
	    !binding->policy_generation || !binding->session_generation ||
	    !binding->connection_generation || !binding->connection_alias)
		return PRP_WIRE_V4_ECANON;
	wire[0] = binding->direction;
	wire[1] = 0;
	prp_wire_v4_put_be16(wire + 2, binding->connection_flags);
	prp_wire_v4_put_be32(wire + 4, binding->policy_generation);
	prp_wire_v4_put_be32(wire + 8, binding->session_generation);
	prp_wire_v4_put_be32(wire + 12, binding->connection_generation);
	prp_wire_v4_put_be16(wire + 16, binding->connection_alias);
	prp_wire_v4_put_be16(wire + 18, 0);
	*written = PRP_WIRE_V4_DISCOVERY_LANE_BIND_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_discovery_lane_bind_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_discovery_lane_bind *binding)
{
	if (!wire || !binding)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_DISCOVERY_LANE_BIND_LEN)
		return PRP_WIRE_V4_ECANON;
	binding->direction = wire[0];
	binding->connection_flags = prp_wire_v4_get_be16(wire + 2);
	binding->policy_generation = prp_wire_v4_get_be32(wire + 4);
	binding->session_generation = prp_wire_v4_get_be32(wire + 8);
	binding->connection_generation = prp_wire_v4_get_be32(wire + 12);
	binding->connection_alias = prp_wire_v4_get_be16(wire + 16);
	if (wire[1] || prp_wire_v4_get_be16(wire + 18))
		return PRP_WIRE_V4_ECANON;
	return binding->direction >=
		PRP_WIRE_V4_DISCOVERY_INITIATOR_TO_RESPONDER &&
		binding->direction <=
		PRP_WIRE_V4_DISCOVERY_RESPONDER_TO_INITIATOR &&
		binding->connection_flags == PRP_WIRE_V4_CONNECTION_F_MASK &&
		binding->policy_generation && binding->session_generation &&
		binding->connection_generation && binding->connection_alias ?
		PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int prp_wire_v4_key_lifecycle_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_key_lifecycle *policy)
{
	if (!wire || !policy)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_KEY_LIFECYCLE_LEN)
		return PRP_WIRE_V4_ECANON;
	policy->max_active_key_age_ms = prp_wire_v4_get_be64(wire);
	policy->max_encrypted_bytes = prp_wire_v4_get_be64(wire + 8);
	policy->max_encrypted_items = prp_wire_v4_get_be64(wire + 16);
	policy->idle_key_retention_ms = prp_wire_v4_get_be64(wire + 24);
	policy->old_generation_overlap_ms = prp_wire_v4_get_be32(wire + 32);
	if (!policy->max_active_key_age_ms || !policy->idle_key_retention_ms ||
	    prp_wire_v4_get_be32(wire + 36))
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline prp_wire_v4_u64 prp_wire_v4_min_nonzero_u64(
	prp_wire_v4_u64 left, prp_wire_v4_u64 right)
{
	if (!left)
		return right;
	if (!right)
		return left;
	return left < right ? left : right;
}

static inline int prp_wire_v4_key_lifecycle_intersect(
	const struct prp_wire_v4_key_lifecycle *left,
	const struct prp_wire_v4_key_lifecycle *right,
	struct prp_wire_v4_key_lifecycle *effective)
{
	if (!left || !right || !effective || !left->max_active_key_age_ms ||
	    !right->max_active_key_age_ms || !left->idle_key_retention_ms ||
	    !right->idle_key_retention_ms)
		return PRP_WIRE_V4_ECANON;
	effective->max_active_key_age_ms = prp_wire_v4_min_nonzero_u64(
		left->max_active_key_age_ms, right->max_active_key_age_ms);
	effective->max_encrypted_bytes = prp_wire_v4_min_nonzero_u64(
		left->max_encrypted_bytes, right->max_encrypted_bytes);
	effective->max_encrypted_items = prp_wire_v4_min_nonzero_u64(
		left->max_encrypted_items, right->max_encrypted_items);
	effective->idle_key_retention_ms = prp_wire_v4_min_nonzero_u64(
		left->idle_key_retention_ms, right->idle_key_retention_ms);
	effective->old_generation_overlap_ms =
		left->old_generation_overlap_ms < right->old_generation_overlap_ms ?
		left->old_generation_overlap_ms : right->old_generation_overlap_ms;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_relation_section_type_known(prp_wire_v4_u16 type)
{
	return (type >= PRP_WIRE_V4_RELATION_SECTION_KEY_LIFECYCLE &&
		type <= PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_POLICY) ||
	       type == PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_LANE_BIND;
}

static inline int prp_wire_v4_relation_section_effective_matches(
	const struct prp_wire_v4_relation_section *expected,
	const struct prp_wire_v4_relation_section *result)
{
	size_t i;

	if (!expected || !result)
		return PRP_WIRE_V4_EINVAL;
	if (result->status != PRP_WIRE_V4_RELATION_STATUS_ACCEPTED ||
	    expected->type != result->type ||
	    expected->version != result->version ||
	    expected->generation != result->generation ||
	    expected->base_generation != result->base_generation ||
	    expected->body_len != result->body_len ||
	    (!expected->body && expected->body_len) ||
	    (!result->body && result->body_len))
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < expected->body_len; i++)
		if (expected->body[i] != result->body[i])
			return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_relation_section_body_validate(prp_wire_v4_u16 type,
	prp_wire_v4_u8 version, const prp_wire_v4_u8 *body,
	prp_wire_v4_u16 body_len)
{
	struct prp_wire_v4_drain_policy drain;
	struct prp_wire_v4_carrier_attachment_binding attachment;
	struct prp_wire_v4_discovery_policy discovery_policy;
	struct prp_wire_v4_discovery_lane_bind discovery_lane;
	prp_wire_v4_u16 suite_count;
	prp_wire_v4_u16 previous = 0;
	size_t i;

	if ((!body && body_len) || !version)
		return PRP_WIRE_V4_EINVAL;
	switch (type) {
	case PRP_WIRE_V4_RELATION_SECTION_KEY_LIFECYCLE:
		return version == PRP_WIRE_V4_KEY_LIFECYCLE_VERSION &&
		       body_len == PRP_WIRE_V4_KEY_LIFECYCLE_LEN ?
			PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
	case PRP_WIRE_V4_RELATION_SECTION_REKEY_SCHEDULE:
		if (version != PRP_WIRE_V4_REKEY_SCHEDULE_VERSION ||
		    body_len < PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN)
			return PRP_WIRE_V4_ECANON;
		suite_count = prp_wire_v4_get_be16(body + 6);
		if (!suite_count || suite_count > PRP_WIRE_V4_REKEY_MAX_SUITES ||
		    body_len != PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN +
			(size_t)suite_count * 2U)
			return PRP_WIRE_V4_ECANON;
		for (i = 0; i < suite_count; i++) {
			prp_wire_v4_u16 suite = prp_wire_v4_get_be16(body +
				PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN + i * 2U);

			if (suite <= previous ||
			    prp_wire_v4_session_suite_get(suite, NULL))
				return PRP_WIRE_V4_ECANON;
			previous = suite;
		}
		return PRP_WIRE_V4_OK;
	case PRP_WIRE_V4_RELATION_SECTION_RESOURCE_REPORT_POLICY:
		return version == PRP_WIRE_V4_RESOURCE_REPORT_POLICY_VERSION &&
		       body_len == PRP_WIRE_V4_RESOURCE_REPORT_POLICY_LEN ?
			PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
	case PRP_WIRE_V4_RELATION_SECTION_DRAIN_POLICY:
		if (version != PRP_WIRE_V4_DRAIN_POLICY_VERSION)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_drain_policy_decode(body, body_len, &drain);
	case PRP_WIRE_V4_RELATION_SECTION_CARRIER_ATTACHMENT_BINDING:
		if (version != PRP_WIRE_V4_CARRIER_ATTACHMENT_BINDING_VERSION)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_carrier_attachment_binding_decode(body,
			body_len, &attachment);
	case PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_POLICY:
		if (version != PRP_WIRE_V4_DISCOVERY_POLICY_VERSION)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_discovery_policy_decode(body, body_len,
			&discovery_policy);
	case PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_LANE_BIND:
		if (version != PRP_WIRE_V4_DISCOVERY_LANE_BIND_VERSION)
			return PRP_WIRE_V4_ECANON;
		return prp_wire_v4_discovery_lane_bind_decode(body, body_len,
			&discovery_lane);
	default:
		return PRP_WIRE_V4_OK;
	}
}

static inline int
prp_wire_v4_relation_result_body_required(prp_wire_v4_u16 type,
	prp_wire_v4_u8 status)
{
	return prp_wire_v4_relation_section_type_known(type) &&
	       (status == PRP_WIRE_V4_RELATION_STATUS_ACCEPTED ||
		status == PRP_WIRE_V4_RELATION_STATUS_STALE);
}

static inline int
prp_wire_v4_relation_control_open(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_relation_cursor *cursor)
{
	prp_wire_v4_u16 alias;

	if (!wire || !cursor)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_RELATION_CONTROL_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	if (len > PRP_WIRE_V4_RELATION_CONTROL_MAX_LEN)
		return PRP_WIRE_V4_ERANGE;
	alias = prp_wire_v4_get_be16(wire + 6);
	if (wire[0] != PRP_WIRE_V4_CONTROL_RELATION ||
	    wire[1] != PRP_WIRE_V4_RELATION_CONTROL_VERSION ||
	    wire[2] < PRP_WIRE_V4_RELATION_DECLARE ||
	    wire[2] > PRP_WIRE_V4_RELATION_RESULT || wire[3] ||
	    wire[4] < PRP_WIRE_V4_SCOPE_ADJACENT ||
	    wire[4] > PRP_WIRE_V4_SCOPE_E2E || wire[5] ||
	    (wire[4] == PRP_WIRE_V4_SCOPE_ADJACENT &&
	     alias != PRP_WIRE_V4_ROUTE_ALIAS_CONTROL) ||
	    (wire[4] != PRP_WIRE_V4_SCOPE_ADJACENT &&
	     (alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
	      alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL)) ||
	    !prp_wire_v4_get_be64(wire + 8) ||
	    !prp_wire_v4_get_be16(wire + 16) ||
	    prp_wire_v4_get_be16(wire + 16) >
		PRP_WIRE_V4_RELATION_CONTROL_MAX_SECTIONS ||
	    prp_wire_v4_get_be16(wire + 18))
		return PRP_WIRE_V4_ECANON;
	cursor->next = wire + PRP_WIRE_V4_RELATION_CONTROL_HEADER_LEN;
	cursor->remaining = len - PRP_WIRE_V4_RELATION_CONTROL_HEADER_LEN;
	cursor->transaction_id = prp_wire_v4_get_be64(wire + 8);
	cursor->sections_remaining = prp_wire_v4_get_be16(wire + 16);
	cursor->last_type = 0;
	cursor->route_alias = alias;
	cursor->operation = wire[2];
	cursor->scope = wire[4];
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_relation_control_next(struct prp_wire_v4_relation_cursor *cursor,
	struct prp_wire_v4_relation_section *section)
{
	int body_required;
	int rc;

	if (!cursor || !section)
		return PRP_WIRE_V4_EINVAL;
	if (!cursor->sections_remaining)
		return cursor->remaining ? PRP_WIRE_V4_ECANON : PRP_WIRE_V4_ERANGE;
	if (cursor->remaining < PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	section->type = prp_wire_v4_get_be16(cursor->next);
	section->version = cursor->next[2];
	section->flags = cursor->next[3];
	section->status = cursor->next[4];
	section->body_len = prp_wire_v4_get_be16(cursor->next + 6);
	section->generation = prp_wire_v4_get_be32(cursor->next + 8);
	section->base_generation = prp_wire_v4_get_be32(cursor->next + 12);
	if (!section->type || section->type <= cursor->last_type ||
	    !section->version ||
	    (section->flags & ~PRP_WIRE_V4_RELATION_SECTION_F_CRITICAL) ||
	    cursor->next[5] || !section->generation ||
	    section->base_generation >= section->generation ||
	    section->status > PRP_WIRE_V4_RELATION_STATUS_MALFORMED ||
	    (cursor->operation == PRP_WIRE_V4_RELATION_RESULT ?
	     section->status == PRP_WIRE_V4_RELATION_STATUS_NONE :
	     section->status != PRP_WIRE_V4_RELATION_STATUS_NONE))
		return PRP_WIRE_V4_ECANON;
	if ((section->type ==
	     PRP_WIRE_V4_RELATION_SECTION_CARRIER_ATTACHMENT_BINDING ||
	     section->type == PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_POLICY ||
	     section->type ==
		PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_LANE_BIND) &&
	    section->flags)
		return PRP_WIRE_V4_ECANON;
	if (cursor->operation != PRP_WIRE_V4_RELATION_RESULT &&
	    ((section->type ==
	      PRP_WIRE_V4_RELATION_SECTION_CARRIER_ATTACHMENT_BINDING &&
	      cursor->operation != PRP_WIRE_V4_RELATION_DECLARE) ||
	     ((section->type == PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_POLICY ||
	       section->type ==
		PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_LANE_BIND) &&
	      cursor->operation != PRP_WIRE_V4_RELATION_PROPOSE)))
		return PRP_WIRE_V4_ECANON;
	if ((size_t)section->body_len > cursor->remaining -
	    PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	section->body = cursor->next + PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN;
	body_required = prp_wire_v4_relation_result_body_required(section->type,
		section->status);
	if (prp_wire_v4_relation_section_type_known(section->type) &&
	    ((cursor->operation == PRP_WIRE_V4_RELATION_RESULT &&
	      (!!section->body_len != !!body_required)) ||
	     (cursor->operation != PRP_WIRE_V4_RELATION_RESULT &&
	      !section->body_len)))
		return PRP_WIRE_V4_ECANON;
	if (section->body_len &&
	    (cursor->operation != PRP_WIRE_V4_RELATION_RESULT || body_required)) {
		rc = prp_wire_v4_relation_section_body_validate(section->type,
			section->version, section->body, section->body_len);
		if (rc)
			return rc;
	}
	if (section->type == PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_POLICY &&
	    (section->base_generation == ~(prp_wire_v4_u32)0 ||
	     section->generation != section->base_generation + 1U))
		return PRP_WIRE_V4_ECANON;
	if (section->type ==
	    PRP_WIRE_V4_RELATION_SECTION_DISCOVERY_LANE_BIND &&
	    (section->base_generation ||
	     (section->body_len && section->generation !=
		prp_wire_v4_get_be32(section->body + 4))))
		return PRP_WIRE_V4_ECANON;
	cursor->next = section->body + section->body_len;
	cursor->remaining -= PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN +
		section->body_len;
	cursor->sections_remaining--;
	cursor->last_type = section->type;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_relation_control_encode(prp_wire_v4_u8 scope,
	prp_wire_v4_u16 route_alias, prp_wire_v4_u8 operation,
	prp_wire_v4_u64 transaction_id,
	const struct prp_wire_v4_relation_section *sections, size_t section_count,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_relation_cursor cursor;
	struct prp_wire_v4_relation_section checked;
	size_t required = PRP_WIRE_V4_RELATION_CONTROL_HEADER_LEN;
	size_t pos;
	size_t i;

	if (!sections || !wire || !written)
		return PRP_WIRE_V4_EINVAL;
	if (!section_count ||
	    section_count > PRP_WIRE_V4_RELATION_CONTROL_MAX_SECTIONS)
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < section_count; i++) {
		if (!sections[i].body && sections[i].body_len)
			return PRP_WIRE_V4_EINVAL;
		if ((size_t)sections[i].body_len >
		    PRP_WIRE_V4_RELATION_CONTROL_MAX_LEN - required -
			PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN)
			return PRP_WIRE_V4_ERANGE;
		required += PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN +
			sections[i].body_len;
	}
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = PRP_WIRE_V4_CONTROL_RELATION;
	wire[1] = PRP_WIRE_V4_RELATION_CONTROL_VERSION;
	wire[2] = operation;
	wire[3] = 0;
	wire[4] = scope;
	wire[5] = 0;
	prp_wire_v4_put_be16(wire + 6, route_alias);
	prp_wire_v4_put_be64(wire + 8, transaction_id);
	prp_wire_v4_put_be16(wire + 16, (prp_wire_v4_u16)section_count);
	prp_wire_v4_put_be16(wire + 18, 0);
	pos = PRP_WIRE_V4_RELATION_CONTROL_HEADER_LEN;
	for (i = 0; i < section_count; i++) {
		const struct prp_wire_v4_relation_section *section = &sections[i];
		size_t j;

		prp_wire_v4_put_be16(wire + pos, section->type);
		wire[pos + 2] = section->version;
		wire[pos + 3] = section->flags;
		wire[pos + 4] = section->status;
		wire[pos + 5] = 0;
		prp_wire_v4_put_be16(wire + pos + 6, section->body_len);
		prp_wire_v4_put_be32(wire + pos + 8, section->generation);
		prp_wire_v4_put_be32(wire + pos + 12,
			section->base_generation);
		pos += PRP_WIRE_V4_RELATION_SECTION_HEADER_LEN;
		for (j = 0; j < section->body_len; j++)
			wire[pos++] = section->body[j];
	}
	if (prp_wire_v4_relation_control_open(wire, required, &cursor))
		return PRP_WIRE_V4_ECANON;
	while (cursor.sections_remaining)
		if (prp_wire_v4_relation_control_next(&cursor, &checked))
			return PRP_WIRE_V4_ECANON;
	if (cursor.remaining)
		return PRP_WIRE_V4_ECANON;
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_fragment_start_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_fragment_start *start)
{
	struct prp_wire_v4_session_suite_desc desc;
	prp_wire_v4_u16 suite;
	int rc;

	if (!wire || !start)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_FRAGMENT_SUITE_LEN)
		return PRP_WIRE_V4_ETRUNC;
	suite = prp_wire_v4_get_be16(wire);
	rc = prp_wire_v4_session_suite_get(suite, &desc);
	if (rc)
		return rc;
	if (len != PRP_WIRE_V4_FRAGMENT_SUITE_LEN + desc.commitment_len)
		return PRP_WIRE_V4_ECANON;
	start->session_suite_id = suite;
	start->commitment = wire + PRP_WIRE_V4_FRAGMENT_SUITE_LEN;
	start->commitment_len = desc.commitment_len;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_fragment_start_encode(const struct prp_wire_v4_fragment_start *start,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_suite_desc desc;
	size_t required;
	size_t i;
	int rc;

	if (!start || !wire || !written || !start->commitment)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_suite_get(start->session_suite_id, &desc);
	if (rc)
		return rc;
	if (start->commitment_len != desc.commitment_len)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_FRAGMENT_SUITE_LEN + desc.commitment_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, start->session_suite_id);
	for (i = 0; i < desc.commitment_len; i++)
		wire[PRP_WIRE_V4_FRAGMENT_SUITE_LEN + i] = start->commitment[i];
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_e2e_item_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_e2e_item *item)
{
	struct prp_wire_v4_connection_control control;
	prp_wire_v4_u16 body_len;
	prp_wire_v4_u16 alias;
	prp_wire_v4_u16 flags;
	prp_wire_v4_u64 sequence;

	if (!wire || !item)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	if (len < PRP_WIRE_V4_E2E_ITEM_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	body_len = prp_wire_v4_get_be16(wire + 12);
	if (len != PRP_WIRE_V4_E2E_ITEM_HEADER_LEN + body_len)
		return PRP_WIRE_V4_ECANON;
	alias = prp_wire_v4_get_be16(wire);
	flags = prp_wire_v4_get_be16(wire + 2);
	sequence = prp_wire_v4_get_be64(wire + 4);
	if (flags & ~PRP_WIRE_V4_ITEM_F_MASK)
		return PRP_WIRE_V4_ECANON;
	if (!alias && (!body_len || flags || sequence ||
	    prp_wire_v4_connection_control_decode(
		wire + PRP_WIRE_V4_E2E_ITEM_HEADER_LEN, body_len, &control)))
		return PRP_WIRE_V4_ECANON;
	item->connection_alias = alias;
	item->flags = flags;
	item->sequence = sequence;
	item->body_len = body_len;
	item->body = wire + PRP_WIRE_V4_E2E_ITEM_HEADER_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_e2e_init(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_e2e_cursor *cursor)
{
	if ((!wire && len) || !cursor)
		return PRP_WIRE_V4_EINVAL;
	if (len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	cursor->next = wire;
	cursor->remaining = len;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_e2e_next(struct prp_wire_v4_e2e_cursor *cursor,
	struct prp_wire_v4_e2e_item *item)
{
	prp_wire_v4_u16 body_len;
	size_t item_len;
	int rc;

	if (!cursor || !item)
		return PRP_WIRE_V4_EINVAL;
	if (cursor->remaining < PRP_WIRE_V4_E2E_ITEM_HEADER_LEN)
		return cursor->remaining ? PRP_WIRE_V4_ETRUNC :
			PRP_WIRE_V4_ECANON;
	body_len = prp_wire_v4_get_be16(cursor->next + 12);
	item_len = PRP_WIRE_V4_E2E_ITEM_HEADER_LEN + body_len;
	if (item_len > cursor->remaining)
		return PRP_WIRE_V4_ETRUNC;
	rc = prp_wire_v4_e2e_item_decode(cursor->next, item_len, item);
	if (rc)
		return rc;
	cursor->next += item_len;
	cursor->remaining -= item_len;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_e2e_item_encode(const struct prp_wire_v4_e2e_item *item,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_connection_control control;
	size_t required;

	if (!item || !wire || !written || (!item->body && item->body_len))
		return PRP_WIRE_V4_EINVAL;
	if (item->flags & ~PRP_WIRE_V4_ITEM_F_MASK)
		return PRP_WIRE_V4_ECANON;
	if (!item->connection_alias &&
	    (!item->body_len || item->flags || item->sequence ||
	     prp_wire_v4_connection_control_decode(item->body,
		item->body_len, &control)))
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_E2E_ITEM_HEADER_LEN + item->body_len;
	if (required > PRP_WIRE_V4_LOGICAL_UNIT_MAX || capacity < required)
		return PRP_WIRE_V4_ERANGE;
	prp_wire_v4_put_be16(wire, item->connection_alias);
	prp_wire_v4_put_be16(wire + 2, item->flags);
	prp_wire_v4_put_be64(wire + 4, item->sequence);
	prp_wire_v4_put_be16(wire + 12, item->body_len);
	if (item->body_len) {
		size_t i;

		for (i = 0; i < item->body_len; i++)
			wire[PRP_WIRE_V4_E2E_ITEM_HEADER_LEN + i] = item->body[i];
	}
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_drain_policy_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_drain_policy *policy)
{
	prp_wire_v4_u8 scope;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u32 grace;
	prp_wire_v4_u32 final_timeout;

	if (!wire || !policy)
		return PRP_WIRE_V4_EINVAL;
	if (len != PRP_WIRE_V4_DRAIN_POLICY_LEN)
		return len < PRP_WIRE_V4_DRAIN_POLICY_LEN ?
			PRP_WIRE_V4_ETRUNC : PRP_WIRE_V4_ECANON;
	scope = wire[0];
	if (scope > PRP_WIRE_V4_DRAIN_ALL)
		return PRP_WIRE_V4_ECANON;
	if (wire[1])
		return PRP_WIRE_V4_ECANON;
	reason = prp_wire_v4_get_be16(wire + 2);
	grace = prp_wire_v4_get_be32(wire + 4);
	final_timeout = prp_wire_v4_get_be32(wire + 8);
	if (scope == PRP_WIRE_V4_DRAIN_CANCEL) {
		if (reason || grace || final_timeout)
			return PRP_WIRE_V4_ECANON;
	} else if (!grace || final_timeout < grace) {
		return PRP_WIRE_V4_ECANON;
	}
	policy->scope = scope;
	policy->reason = reason;
	policy->grace_ms = grace;
	policy->final_timeout_ms = final_timeout;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_drain_policy_encode(const struct prp_wire_v4_drain_policy *policy,
	prp_wire_v4_u8 *wire, size_t capacity)
{
	struct prp_wire_v4_drain_policy checked;
	prp_wire_v4_u8 candidate[PRP_WIRE_V4_DRAIN_POLICY_LEN];
	int rc;

	if (!policy || !wire)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < PRP_WIRE_V4_DRAIN_POLICY_LEN)
		return PRP_WIRE_V4_ERANGE;
	candidate[0] = policy->scope;
	candidate[1] = 0;
	prp_wire_v4_put_be16(candidate + 2, policy->reason);
	prp_wire_v4_put_be32(candidate + 4, policy->grace_ms);
	prp_wire_v4_put_be32(candidate + 8, policy->final_timeout_ms);
	rc = prp_wire_v4_drain_policy_decode(candidate, sizeof(candidate), &checked);
	if (rc)
		return rc;
	for (size_t i = 0; i < sizeof(candidate); i++)
		wire[i] = candidate[i];
	return PRP_WIRE_V4_OK;
}

#define PRP_WIRE_V4_RESOURCE_REPORT_VERSION 1U
#define PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN 68U
#define PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN 4U
#define PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN 16U
#define PRP_WIRE_V4_RESOURCE_REPORT_MAX_LEN \
	(PRP_WIRE_V4_LOGICAL_UNIT_MAX - PRP_WIRE_V4_RRL_HEADER_LEN - \
	 PRP_WIRE_V4_RECORD_HEADER_LEN)
#define PRP_WIRE_V4_RESOURCE_REPORT_MAX_TLVS \
	((PRP_WIRE_V4_RESOURCE_REPORT_MAX_LEN - \
	  PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN) / \
	 PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN)
#define PRP_WIRE_V4_RESOURCE_REPORT_TLV_F_CRITICAL 0x8000U
#define PRP_WIRE_V4_RESOURCE_REPORT_TLV_TYPE_MASK 0x7fffU

enum prp_wire_v4_resource_report_direction {
	PRP_WIRE_V4_RESOURCE_DIRECTION_TX = 1,
	PRP_WIRE_V4_RESOURCE_DIRECTION_RX = 2,
};

enum prp_wire_v4_resource_report_mode {
	PRP_WIRE_V4_RESOURCE_REPORT_DISABLED = 0x00,
	PRP_WIRE_V4_RESOURCE_REPORT_PERIODIC = 0x01,
	PRP_WIRE_V4_RESOURCE_REPORT_EVENT_ONLY = 0x02,
	PRP_WIRE_V4_RESOURCE_REPORT_SOLICITED = 0x03,
	PRP_WIRE_V4_RESOURCE_REPORT_PIGGYBACK = 0x04,
};

enum prp_wire_v4_resource_report_field {
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO = 1ULL << 0,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_BYTES = 1ULL << 1,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_BYTES = 1ULL << 2,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_ITEMS = 1ULL << 3,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_ITEMS = 1ULL << 4,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_DROPS = 1ULL << 5,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_DROPS = 1ULL << 6,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES = 1ULL << 7,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES = 1ULL << 8,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RESIDUAL_CAPACITY_BPS = 1ULL << 9,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE = 1ULL << 10,
	PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE = 1ULL << 11,
};

#define PRP_WIRE_V4_RESOURCE_REPORT_FIELD_MASK \
	(PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_BYTES | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_BYTES | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_ITEMS | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_ITEMS | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_DROPS | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_DROPS | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RESIDUAL_CAPACITY_BPS | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE | \
	 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE)

enum prp_wire_v4_resource_report_tlv_type {
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_GENERATION = 0x0001,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_SEQUENCE = 0x0002,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_NONCE = 0x0003,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_RECEIVE_MONOTONIC_NS = 0x0004,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_BYTES = 0x0005,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_BYTES = 0x0006,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_ITEMS = 0x0007,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_ITEMS = 0x0008,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_DROPS = 0x0009,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_DROPS = 0x000a,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_OCCUPANCY_BYTES = 0x000b,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_CAPACITY_BYTES = 0x000c,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_RESIDUAL_CAPACITY_BPS = 0x000d,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_SHAPING_RESISTANCE = 0x000e,
	PRP_WIRE_V4_RESOURCE_REPORT_TLV_TRAFFIC_RESISTANCE = 0x000f,
};

enum prp_wire_v4_resource_report_order {
	PRP_WIRE_V4_RESOURCE_REPORT_ORDER_STALE = -1,
	PRP_WIRE_V4_RESOURCE_REPORT_ORDER_DUPLICATE = 0,
	PRP_WIRE_V4_RESOURCE_REPORT_ORDER_NEW = 1,
};

enum prp_wire_v4_rekey_reason {
	PRP_WIRE_V4_REKEY_REASON_AGE = 0x0001,
	PRP_WIRE_V4_REKEY_REASON_BYTES = 0x0002,
	PRP_WIRE_V4_REKEY_REASON_ITEMS = 0x0003,
	PRP_WIRE_V4_REKEY_REASON_ADMINISTRATIVE = 0x0004,
	PRP_WIRE_V4_REKEY_REASON_COMPROMISE = 0x0005,
	PRP_WIRE_V4_REKEY_REASON_SUITE = 0x0006,
};
struct prp_wire_v4_rekey_schedule {
	prp_wire_v4_u32 current_generation;
	prp_wire_v4_u16 reason;
	prp_wire_v4_u16 suite_count;
	prp_wire_v4_u64 not_before_ms;
	prp_wire_v4_u64 deadline_ms;
	prp_wire_v4_u32 overlap_ms;
	prp_wire_v4_u16 suites[PRP_WIRE_V4_REKEY_MAX_SUITES];
};

struct prp_wire_v4_resource_report_policy {
	prp_wire_v4_u8 version;
	prp_wire_v4_u8 direction;
	prp_wire_v4_u8 mode;
	prp_wire_v4_u8 flags;
	prp_wire_v4_u64 field_mask;
	prp_wire_v4_u32 preferred_interval_ms;
	prp_wire_v4_u32 minimum_interval_ms;
	prp_wire_v4_u32 validity_ms;
	prp_wire_v4_u16 max_reports_per_minute;
	prp_wire_v4_u16 max_report_bytes;
};

struct prp_wire_v4_resource_report {
	prp_wire_v4_u8 version;
	prp_wire_v4_u8 flags;
	prp_wire_v4_u32 generation;
	prp_wire_v4_u64 sequence;
	prp_wire_v4_u32 validity_ms;
	prp_wire_v4_u32 sample_interval_ms;
	prp_wire_v4_u64 sender_monotonic_ns;
	prp_wire_v4_u64 clock_epoch;
	prp_wire_v4_u64 field_mask;
	prp_wire_v4_u8 report_nonce[PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN];
	prp_wire_v4_u32 echoed_generation;
	prp_wire_v4_u64 echoed_sequence;
	prp_wire_v4_u8 echoed_nonce[PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN];
	prp_wire_v4_u64 echoed_receive_monotonic_ns;
	prp_wire_v4_u64 tx_bytes;
	prp_wire_v4_u64 rx_bytes;
	prp_wire_v4_u64 tx_items;
	prp_wire_v4_u64 rx_items;
	prp_wire_v4_u64 tx_drops;
	prp_wire_v4_u64 rx_drops;
	prp_wire_v4_u64 queue_occupancy_bytes;
	prp_wire_v4_u64 queue_capacity_bytes;
	prp_wire_v4_u64 residual_capacity_bps;
	prp_wire_v4_u8 shaping_resistance;
	prp_wire_v4_u8 traffic_resistance;
	prp_wire_v4_u16 unknown_optional_tlvs;
};
static inline int prp_wire_v4_resource_nonce_nonzero(const prp_wire_v4_u8 *nonce)
{
	size_t i;
	prp_wire_v4_u8 value = 0;

	if (!nonce)
		return 0;
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		value |= nonce[i];
	return value != 0;
}

static inline size_t prp_wire_v4_resource_report_policy_min_bytes(
	prp_wire_v4_u64 field_mask)
{
	prp_wire_v4_u64 counters = field_mask &
		~((prp_wire_v4_u64)PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO |
		  PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE |
		  PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE);
	prp_wire_v4_u64 scores = field_mask &
		(PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE |
		 PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE);

	if (scores)
		return PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN +
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN + 1U;
	if (counters)
		return PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN +
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN + 8U;
	if (field_mask & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO)
		return PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN +
			4U * PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN +
			4U + 8U + PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN + 8U;
	return PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN;
}

static inline int prp_wire_v4_resource_report_policy_validate(
	const struct prp_wire_v4_resource_report_policy *policy)
{
	if (!policy ||
	    policy->version != PRP_WIRE_V4_RESOURCE_REPORT_POLICY_VERSION ||
	    (policy->direction != PRP_WIRE_V4_RESOURCE_DIRECTION_TX &&
	     policy->direction != PRP_WIRE_V4_RESOURCE_DIRECTION_RX) ||
	    policy->mode > PRP_WIRE_V4_RESOURCE_REPORT_PIGGYBACK ||
	    policy->flags ||
	    (policy->field_mask & ~PRP_WIRE_V4_RESOURCE_REPORT_FIELD_MASK))
		return PRP_WIRE_V4_ECANON;
	if (policy->mode == PRP_WIRE_V4_RESOURCE_REPORT_DISABLED)
		return policy->field_mask || policy->preferred_interval_ms ||
		       policy->minimum_interval_ms || policy->validity_ms ||
		       policy->max_reports_per_minute ||
		       policy->max_report_bytes ?
			PRP_WIRE_V4_ECANON : PRP_WIRE_V4_OK;
	if (!policy->field_mask || !policy->minimum_interval_ms ||
	    !policy->validity_ms ||
	    policy->validity_ms < policy->minimum_interval_ms ||
	    !policy->max_reports_per_minute ||
	    policy->max_report_bytes <
		prp_wire_v4_resource_report_policy_min_bytes(policy->field_mask) ||
	    policy->max_report_bytes > PRP_WIRE_V4_RESOURCE_REPORT_MAX_LEN)
		return PRP_WIRE_V4_ECANON;
	if (policy->mode == PRP_WIRE_V4_RESOURCE_REPORT_PERIODIC) {
		if (!policy->preferred_interval_ms ||
		    policy->preferred_interval_ms < policy->minimum_interval_ms ||
		    policy->validity_ms < policy->preferred_interval_ms)
			return PRP_WIRE_V4_ECANON;
	} else if (policy->preferred_interval_ms) {
		return PRP_WIRE_V4_ECANON;
	}
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_resource_report_policy_encode(
	const struct prp_wire_v4_resource_report_policy *policy,
	prp_wire_v4_u8 *out, size_t out_len, size_t *written)
{
	int rc = prp_wire_v4_resource_report_policy_validate(policy);

	if (!out || !written)
		return PRP_WIRE_V4_EINVAL;
	if (rc)
		return rc;
	if (out_len < PRP_WIRE_V4_RESOURCE_REPORT_POLICY_LEN)
		return PRP_WIRE_V4_ETRUNC;
	out[0] = policy->version;
	out[1] = policy->direction;
	out[2] = policy->mode;
	out[3] = policy->flags;
	prp_wire_v4_put_be64(out + 4, policy->field_mask);
	prp_wire_v4_put_be32(out + 12,
		policy->preferred_interval_ms);
	prp_wire_v4_put_be32(out + 16, policy->minimum_interval_ms);
	prp_wire_v4_put_be32(out + 20, policy->validity_ms);
	prp_wire_v4_put_be16(out + 24,
		policy->max_reports_per_minute);
	prp_wire_v4_put_be16(out + 26, policy->max_report_bytes);
	*written = PRP_WIRE_V4_RESOURCE_REPORT_POLICY_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_resource_report_policy_decode(
	const prp_wire_v4_u8 *body, size_t body_len,
	struct prp_wire_v4_resource_report_policy *policy)
{
	if (!body || !policy)
		return PRP_WIRE_V4_EINVAL;
	if (body_len != PRP_WIRE_V4_RESOURCE_REPORT_POLICY_LEN)
		return PRP_WIRE_V4_ECANON;
	policy->version = body[0];
	policy->direction = body[1];
	policy->mode = body[2];
	policy->flags = body[3];
	policy->field_mask = prp_wire_v4_get_be64(body + 4);
	policy->preferred_interval_ms =
		prp_wire_v4_get_be32(body + 12);
	policy->minimum_interval_ms =
		prp_wire_v4_get_be32(body + 16);
	policy->validity_ms = prp_wire_v4_get_be32(body + 20);
	policy->max_reports_per_minute =
		prp_wire_v4_get_be16(body + 24);
	policy->max_report_bytes = prp_wire_v4_get_be16(body + 26);
	return prp_wire_v4_resource_report_policy_validate(policy);
}

static inline size_t prp_wire_v4_resource_report_field_wire_len(prp_wire_v4_u64 field)
{
	if (field == PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO)
		return 4U * PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN +
		       4U + 8U + PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN + 8U;
	if (field == PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE ||
	    field == PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE)
		return PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN + 1U;
	return PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN + 8U;
}

static inline void prp_wire_v4_resource_report_put_tlv_u64(prp_wire_v4_u8 *out,
	size_t *pos, prp_wire_v4_u16 type, prp_wire_v4_u64 value)
{
	prp_wire_v4_put_be16(out + *pos, type);
	prp_wire_v4_put_be16(out + *pos + 2, 8);
	prp_wire_v4_put_be64(out + *pos + 4, value);
	*pos += 12;
}

static inline void prp_wire_v4_resource_report_put_tlv_u8(prp_wire_v4_u8 *out,
	size_t *pos, prp_wire_v4_u16 type, prp_wire_v4_u8 value)
{
	prp_wire_v4_put_be16(out + *pos, type);
	prp_wire_v4_put_be16(out + *pos + 2, 1);
	out[*pos + 4] = value;
	*pos += 5;
}

static inline int prp_wire_v4_resource_report_encode(
	const struct prp_wire_v4_resource_report *report,
	prp_wire_v4_u8 *out, size_t out_len, size_t *written)
{
	prp_wire_v4_u64 fields[] = {
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_ITEMS,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_ITEMS,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_DROPS,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_DROPS,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RESIDUAL_CAPACITY_BPS,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE,
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE,
	};
	size_t required = PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN;
	size_t pos, i;
	prp_wire_v4_u16 tlv_count = 0;

	if (!report || !out || !written)
		return PRP_WIRE_V4_EINVAL;
	if (report->version != PRP_WIRE_V4_RESOURCE_REPORT_VERSION ||
	    report->flags || !report->generation || !report->validity_ms ||
	    !report->field_mask ||
	    (report->field_mask & ~PRP_WIRE_V4_RESOURCE_REPORT_FIELD_MASK) ||
	    report->unknown_optional_tlvs ||
	    !prp_wire_v4_resource_nonce_nonzero(report->report_nonce))
		return PRP_WIRE_V4_ECANON;
	if ((report->field_mask &
	     PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES) &&
	    (report->field_mask &
	     PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES) &&
	    report->queue_occupancy_bytes > report->queue_capacity_bytes)
		return PRP_WIRE_V4_ECANON;
	if (report->field_mask & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO) {
		if (!report->echoed_generation ||
		    !report->echoed_receive_monotonic_ns ||
		    !prp_wire_v4_resource_nonce_nonzero(report->echoed_nonce))
			return PRP_WIRE_V4_ECANON;
	}
	for (i = 0; i < sizeof(fields) / sizeof(fields[0]); i++)
		if (report->field_mask & fields[i]) {
			required += prp_wire_v4_resource_report_field_wire_len(
				fields[i]);
			tlv_count += fields[i] ==
				PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO ? 4 : 1;
		}
	if (required > PRP_WIRE_V4_RESOURCE_REPORT_MAX_LEN)
		return PRP_WIRE_V4_ERANGE;
	if (out_len < required)
		return PRP_WIRE_V4_ETRUNC;
	out[0] = PRP_WIRE_V4_CONTROL_RESOURCE_REPORT;
	out[1] = report->version;
	out[2] = report->flags;
	out[3] = 0;
	prp_wire_v4_put_be32(out + 4, report->generation);
	prp_wire_v4_put_be64(out + 8, report->sequence);
	prp_wire_v4_put_be32(out + 16, report->validity_ms);
	prp_wire_v4_put_be32(out + 20, report->sample_interval_ms);
	prp_wire_v4_put_be64(out + 24, report->sender_monotonic_ns);
	prp_wire_v4_put_be64(out + 32, report->clock_epoch);
	prp_wire_v4_put_be64(out + 40, report->field_mask);
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		out[48 + i] = report->report_nonce[i];
	prp_wire_v4_put_be16(out + 64, tlv_count);
	prp_wire_v4_put_be16(out + 66, 0);
	pos = PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN;
	if (report->field_mask & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO) {
		prp_wire_v4_put_be16(out + pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_GENERATION);
		prp_wire_v4_put_be16(out + pos + 2, 4);
		prp_wire_v4_put_be32(out + pos + 4,
			report->echoed_generation);
		pos += 8;
		prp_wire_v4_resource_report_put_tlv_u64(out, &pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_SEQUENCE,
			report->echoed_sequence);
		prp_wire_v4_put_be16(out + pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_NONCE);
		prp_wire_v4_put_be16(out + pos + 2,
			PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN);
		for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
			out[pos + 4 + i] = report->echoed_nonce[i];
		pos += 4 + PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN;
		prp_wire_v4_resource_report_put_tlv_u64(out, &pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_RECEIVE_MONOTONIC_NS,
			report->echoed_receive_monotonic_ns);
	}
#define PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(field, tlv, member) \
	do { \
		if (report->field_mask & (field)) \
			prp_wire_v4_resource_report_put_tlv_u64(out, &pos, \
				(tlv), report->member); \
	} while (0)
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_BYTES, tx_bytes);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_BYTES, rx_bytes);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_ITEMS,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_ITEMS, tx_items);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_ITEMS,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_ITEMS, rx_items);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_DROPS,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_DROPS, tx_drops);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_DROPS,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_DROPS, rx_drops);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_OCCUPANCY_BYTES,
		queue_occupancy_bytes);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_CAPACITY_BYTES,
		queue_capacity_bytes);
	PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64(
		PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RESIDUAL_CAPACITY_BPS,
		PRP_WIRE_V4_RESOURCE_REPORT_TLV_RESIDUAL_CAPACITY_BPS,
		residual_capacity_bps);
#undef PRP_WIRE_V4_RESOURCE_REPORT_ENCODE_U64
	if (report->field_mask &
	    PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE)
		prp_wire_v4_resource_report_put_tlv_u8(out, &pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_SHAPING_RESISTANCE,
			report->shaping_resistance);
	if (report->field_mask &
	    PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE)
		prp_wire_v4_resource_report_put_tlv_u8(out, &pos,
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_TRAFFIC_RESISTANCE,
			report->traffic_resistance);
	*written = pos;
	return pos == required ? PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int prp_wire_v4_resource_report_decode(
	const prp_wire_v4_u8 *body, size_t body_len,
	struct prp_wire_v4_resource_report *report)
{
	prp_wire_v4_u64 seen = 0;
	size_t pos, i;
	prp_wire_v4_u16 count, last_type = 0;
	prp_wire_v4_u8 echo_parts = 0;

	if (!body || !report)
		return PRP_WIRE_V4_EINVAL;
	if (body_len < PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN ||
	    body_len > PRP_WIRE_V4_RESOURCE_REPORT_MAX_LEN ||
	    body[0] != PRP_WIRE_V4_CONTROL_RESOURCE_REPORT ||
	    body[1] != PRP_WIRE_V4_RESOURCE_REPORT_VERSION ||
	    body[2] || body[3] || prp_wire_v4_get_be16(body + 66))
		return PRP_WIRE_V4_ECANON;
	report->version = body[1];
	report->flags = body[2];
	report->generation = prp_wire_v4_get_be32(body + 4);
	report->sequence = prp_wire_v4_get_be64(body + 8);
	report->validity_ms = prp_wire_v4_get_be32(body + 16);
	report->sample_interval_ms = prp_wire_v4_get_be32(body + 20);
	report->sender_monotonic_ns = prp_wire_v4_get_be64(body + 24);
	report->clock_epoch = prp_wire_v4_get_be64(body + 32);
	report->field_mask = prp_wire_v4_get_be64(body + 40);
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		report->report_nonce[i] = body[48 + i];
	report->echoed_generation = 0;
	report->echoed_sequence = 0;
	report->echoed_receive_monotonic_ns = 0;
	report->tx_bytes = report->rx_bytes = 0;
	report->tx_items = report->rx_items = 0;
	report->tx_drops = report->rx_drops = 0;
	report->queue_occupancy_bytes = report->queue_capacity_bytes = 0;
	report->residual_capacity_bps = 0;
	report->shaping_resistance = 0;
	report->traffic_resistance = 0;
	report->unknown_optional_tlvs = 0;
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		report->echoed_nonce[i] = 0;
	count = prp_wire_v4_get_be16(body + 64);
	if (!report->generation || !report->validity_ms ||
	    !report->field_mask || count > PRP_WIRE_V4_RESOURCE_REPORT_MAX_TLVS ||
	    (report->field_mask & ~PRP_WIRE_V4_RESOURCE_REPORT_FIELD_MASK) ||
	    !prp_wire_v4_resource_nonce_nonzero(report->report_nonce))
		return PRP_WIRE_V4_ECANON;
	pos = PRP_WIRE_V4_RESOURCE_REPORT_HEADER_LEN;
	for (i = 0; i < count; i++) {
		prp_wire_v4_u16 raw_type, type, len;
		prp_wire_v4_u64 field = 0, value = 0;

		if (body_len - pos < PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN)
			return PRP_WIRE_V4_ETRUNC;
		raw_type = prp_wire_v4_get_be16(body + pos);
		type = raw_type & PRP_WIRE_V4_RESOURCE_REPORT_TLV_TYPE_MASK;
		len = prp_wire_v4_get_be16(body + pos + 2);
		if (!type || type <= last_type ||
		    len > body_len - pos - PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN)
			return PRP_WIRE_V4_ECANON;
		last_type = type;
		pos += PRP_WIRE_V4_RESOURCE_REPORT_TLV_HEADER_LEN;
		switch (type) {
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_GENERATION:
			if (len != 4)
				return PRP_WIRE_V4_ECANON;
			report->echoed_generation =
				prp_wire_v4_get_be32(body + pos);
			field = PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO;
			echo_parts++;
			break;
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_SEQUENCE:
			if (len != 8)
				return PRP_WIRE_V4_ECANON;
			report->echoed_sequence =
				prp_wire_v4_get_be64(body + pos);
			field = PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO;
			echo_parts++;
			break;
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_NONCE:
			if (len != PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN)
				return PRP_WIRE_V4_ECANON;
			{
				size_t j;

				for (j = 0;
				     j < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN;
				     j++)
					report->echoed_nonce[j] = body[pos + j];
			}
			field = PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO;
			echo_parts++;
			break;
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_ECHOED_RECEIVE_MONOTONIC_NS:
			if (len != 8)
				return PRP_WIRE_V4_ECANON;
			report->echoed_receive_monotonic_ns =
				prp_wire_v4_get_be64(body + pos);
			field = PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO;
			echo_parts++;
			break;
#define PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(tlv, bit, member) \
		case tlv: \
			if (len != 8) \
				return PRP_WIRE_V4_ECANON; \
			value = prp_wire_v4_get_be64(body + pos); \
			report->member = value; \
			field = bit; \
			break
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_BYTES,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_BYTES, tx_bytes);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_BYTES,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_BYTES, rx_bytes);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_ITEMS,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_ITEMS, tx_items);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_ITEMS,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_ITEMS, rx_items);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_TX_DROPS,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TX_DROPS, tx_drops);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_RX_DROPS,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RX_DROPS, rx_drops);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_OCCUPANCY_BYTES,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES,
			queue_occupancy_bytes);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_QUEUE_CAPACITY_BYTES,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES,
			queue_capacity_bytes);
		PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64(
			PRP_WIRE_V4_RESOURCE_REPORT_TLV_RESIDUAL_CAPACITY_BPS,
			PRP_WIRE_V4_RESOURCE_REPORT_FIELD_RESIDUAL_CAPACITY_BPS,
			residual_capacity_bps);
#undef PRP_WIRE_V4_RESOURCE_REPORT_DECODE_U64
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_SHAPING_RESISTANCE:
			if (len != 1)
				return PRP_WIRE_V4_ECANON;
			report->shaping_resistance = body[pos];
			field =
				PRP_WIRE_V4_RESOURCE_REPORT_FIELD_SHAPING_RESISTANCE;
			break;
		case PRP_WIRE_V4_RESOURCE_REPORT_TLV_TRAFFIC_RESISTANCE:
			if (len != 1)
				return PRP_WIRE_V4_ECANON;
			report->traffic_resistance = body[pos];
			field =
				PRP_WIRE_V4_RESOURCE_REPORT_FIELD_TRAFFIC_RESISTANCE;
			break;
		default:
			if (raw_type & PRP_WIRE_V4_RESOURCE_REPORT_TLV_F_CRITICAL)
				return PRP_WIRE_V4_ECANON;
			report->unknown_optional_tlvs++;
			break;
		}
		if (field != PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO)
			seen |= field;
		pos += len;
	}
	if (pos != body_len)
		return PRP_WIRE_V4_ECANON;
	if (report->field_mask & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO) {
		if (echo_parts != 4 || !report->echoed_generation ||
		    !report->echoed_receive_monotonic_ns ||
		    !prp_wire_v4_resource_nonce_nonzero(report->echoed_nonce))
			return PRP_WIRE_V4_ECANON;
		seen |= PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO;
	}
	if (seen != report->field_mask ||
	    ((seen & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_OCCUPANCY_BYTES) &&
	     (seen & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_QUEUE_CAPACITY_BYTES) &&
	     report->queue_occupancy_bytes > report->queue_capacity_bytes))
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_resource_report_order_compare(
	const struct prp_wire_v4_resource_report *previous,
	const struct prp_wire_v4_resource_report *candidate)
{
	size_t i;

	if (!previous || !candidate)
		return PRP_WIRE_V4_EINVAL;
	if (candidate->generation > previous->generation)
		return PRP_WIRE_V4_RESOURCE_REPORT_ORDER_NEW;
	if (candidate->generation < previous->generation ||
	    candidate->sequence < previous->sequence)
		return PRP_WIRE_V4_RESOURCE_REPORT_ORDER_STALE;
	if (candidate->sequence > previous->sequence)
		return PRP_WIRE_V4_RESOURCE_REPORT_ORDER_NEW;
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		if (candidate->report_nonce[i] != previous->report_nonce[i])
			return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_RESOURCE_REPORT_ORDER_DUPLICATE;
}

static inline int prp_wire_v4_resource_report_echo_matches(
	const struct prp_wire_v4_resource_report *report,
	const struct prp_wire_v4_resource_report *echoed)
{
	size_t i;

	if (!report || !echoed ||
	    !(report->field_mask & PRP_WIRE_V4_RESOURCE_REPORT_FIELD_ECHO) ||
	    report->echoed_generation != echoed->generation ||
	    report->echoed_sequence != echoed->sequence ||
	    !report->echoed_receive_monotonic_ns)
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < PRP_WIRE_V4_RESOURCE_REPORT_NONCE_LEN; i++)
		if (report->echoed_nonce[i] != echoed->report_nonce[i])
			return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_resource_report_expired(
	const struct prp_wire_v4_resource_report *report,
	prp_wire_v4_u64 received_monotonic_ns, prp_wire_v4_u64 now_monotonic_ns)
{
	if (!report || !report->validity_ms ||
	    now_monotonic_ns < received_monotonic_ns)
		return PRP_WIRE_V4_EINVAL;
	return now_monotonic_ns - received_monotonic_ns >
		(prp_wire_v4_u64)report->validity_ms * 1000000ULL;
}

static inline int prp_wire_v4_resource_report_matches_policy(
	const struct prp_wire_v4_resource_report_policy *policy,
	const struct prp_wire_v4_resource_report *report, size_t report_len)
{
	int rc = prp_wire_v4_resource_report_policy_validate(policy);

	if (rc)
		return rc;
	if (!report || policy->mode == PRP_WIRE_V4_RESOURCE_REPORT_DISABLED ||
	    report_len > policy->max_report_bytes ||
	    (report->field_mask & ~policy->field_mask))
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}
static inline int prp_wire_v4_rekey_schedule_encode(
	const struct prp_wire_v4_rekey_schedule *schedule,
	prp_wire_v4_u8 *out, size_t out_len, size_t *written)
{
	size_t required, i;
	prp_wire_v4_u16 previous = 0;

	if (!schedule || !out || !written)
		return PRP_WIRE_V4_EINVAL;
	if (!schedule->current_generation ||
	    schedule->reason < PRP_WIRE_V4_REKEY_REASON_AGE ||
	    schedule->reason > PRP_WIRE_V4_REKEY_REASON_SUITE ||
	    !schedule->suite_count ||
	    schedule->suite_count > PRP_WIRE_V4_REKEY_MAX_SUITES ||
	    !schedule->deadline_ms ||
	    schedule->not_before_ms > schedule->deadline_ms)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN +
		(size_t)schedule->suite_count * 2U;
	if (out_len < required)
		return PRP_WIRE_V4_ETRUNC;
	for (i = 0; i < schedule->suite_count; i++) {
		if (!schedule->suites[i] || schedule->suites[i] <= previous)
			return PRP_WIRE_V4_ECANON;
		previous = schedule->suites[i];
	}
	prp_wire_v4_put_be32(out, schedule->current_generation);
	prp_wire_v4_put_be16(out + 4, schedule->reason);
	prp_wire_v4_put_be16(out + 6, schedule->suite_count);
	prp_wire_v4_put_be64(out + 8, schedule->not_before_ms);
	prp_wire_v4_put_be64(out + 16, schedule->deadline_ms);
	prp_wire_v4_put_be32(out + 24, schedule->overlap_ms);
	prp_wire_v4_put_be32(out + 28, 0);
	for (i = 0; i < schedule->suite_count; i++)
		prp_wire_v4_put_be16(out + 32 + i * 2U,
			schedule->suites[i]);
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_rekey_schedule_decode(
	const prp_wire_v4_u8 *body, size_t body_len,
	struct prp_wire_v4_rekey_schedule *schedule)
{
	size_t required, i;
	prp_wire_v4_u16 previous = 0;

	if (!body || !schedule)
		return PRP_WIRE_V4_EINVAL;
	if (body_len < PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN)
		return PRP_WIRE_V4_ETRUNC;
	schedule->current_generation = prp_wire_v4_get_be32(body);
	schedule->reason = prp_wire_v4_get_be16(body + 4);
	schedule->suite_count = prp_wire_v4_get_be16(body + 6);
	schedule->not_before_ms = prp_wire_v4_get_be64(body + 8);
	schedule->deadline_ms = prp_wire_v4_get_be64(body + 16);
	schedule->overlap_ms = prp_wire_v4_get_be32(body + 24);
	if (!schedule->current_generation ||
	    schedule->reason < PRP_WIRE_V4_REKEY_REASON_AGE ||
	    schedule->reason > PRP_WIRE_V4_REKEY_REASON_SUITE ||
	    !schedule->suite_count ||
	    schedule->suite_count > PRP_WIRE_V4_REKEY_MAX_SUITES ||
	    !schedule->deadline_ms ||
	    schedule->not_before_ms > schedule->deadline_ms ||
	    prp_wire_v4_get_be32(body + 28))
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_REKEY_SCHEDULE_HEADER_LEN +
		(size_t)schedule->suite_count * 2U;
	if (body_len != required)
		return PRP_WIRE_V4_ECANON;
	for (i = 0; i < schedule->suite_count; i++) {
		prp_wire_v4_u16 suite = prp_wire_v4_get_be16(body + 32 + i * 2U);

		if (!suite || suite <= previous)
			return PRP_WIRE_V4_ECANON;
		schedule->suites[i] = suite;
		previous = suite;
	}
	for (; i < PRP_WIRE_V4_REKEY_MAX_SUITES; i++)
		schedule->suites[i] = 0;
	return PRP_WIRE_V4_OK;
}

static inline int prp_wire_v4_rekey_schedule_validate_policy(
	const struct prp_wire_v4_rekey_schedule *schedule,
	const struct prp_wire_v4_key_lifecycle *policy)
{
	if (!schedule || !policy)
		return PRP_WIRE_V4_EINVAL;
	if (schedule->overlap_ms > policy->old_generation_overlap_ms)
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}


#endif /* PRP_WIRE_V4_CODEC_H */
