/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note OR MIT */
#ifndef PRP_WIRE_V4_CRYPTO_H
#define PRP_WIRE_V4_CRYPTO_H

#ifndef PRP_WIRE_V4_EXTERNAL_SIZE_T
#include <stddef.h>
#endif
#include <prp/wire_v4_codec.h>

#define PRP_WIRE_V4_CRYPTO_API_VERSION 1U
#define PRP_WIRE_V4_TRAFFIC_KEY_LEN 32U
#define PRP_WIRE_V4_SHARED_SECRET_COMPONENT_LEN 32U
#define PRP_WIRE_V4_TRAFFIC_SECRET_MAX_LEN 64U
#define PRP_WIRE_V4_NONCE_LEN 12U

#define PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN "PRP-HS2-ID-PROOF-v4"
#define PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN_LEN 19U
#define PRP_WIRE_V4_ID_PROOF_ED25519CTX "PRP-HS2-v4"
#define PRP_WIRE_V4_ID_PROOF_ED25519CTX_LEN 10U
#define PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT "PRP-HS2-v4-PQ"
#define PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN 13U
#define PRP_WIRE_V4_M1_BINDING_DOMAIN "PRP-HS2-M1-BINDING-v4"
#define PRP_WIRE_V4_M1_BINDING_DOMAIN_LEN 21U
#define PRP_WIRE_V4_TRANSCRIPT_DOMAIN "PRP-HS2-TRANSCRIPT-v4"
#define PRP_WIRE_V4_TRANSCRIPT_DOMAIN_LEN 21U
#define PRP_WIRE_V4_FRAGMENT_COMMITMENT_DOMAIN "PRP-HS2-FRAGMENT-v4"
#define PRP_WIRE_V4_FRAGMENT_COMMITMENT_DOMAIN_LEN 19U
#define PRP_WIRE_V4_BLAKE3_I2R_CONTEXT "PRP-HS2-I2R-v4"
#define PRP_WIRE_V4_BLAKE3_I2R_CONTEXT_LEN 14U
#define PRP_WIRE_V4_BLAKE3_R2I_CONTEXT "PRP-HS2-R2I-v4"
#define PRP_WIRE_V4_BLAKE3_R2I_CONTEXT_LEN 14U
#define PRP_WIRE_V4_HKDF_INFO_DOMAIN "PRP-HS2-TRAFFIC-v4"
#define PRP_WIRE_V4_HKDF_INFO_DOMAIN_LEN 18U
#define PRP_WIRE_V4_AEAD_AAD_DOMAIN "PRP-AEAD-v4"
#define PRP_WIRE_V4_AEAD_AAD_DOMAIN_LEN 11U

#define PRP_WIRE_V4_HASHED_OBJECT_PREFIX_LEN 4U
#define PRP_WIRE_V4_TRAFFIC_MATERIAL_PREFIX_LEN 11U
#define PRP_WIRE_V4_HKDF_INFO_LEN \
	(PRP_WIRE_V4_HKDF_INFO_DOMAIN_LEN + 8U)
#define PRP_WIRE_V4_AEAD_AAD_PREFIX_LEN \
	(PRP_WIRE_V4_AEAD_AAD_DOMAIN_LEN + 7U)
#define PRP_WIRE_V4_PUBLIC_FRAGMENT_PREFIX_LEN 14U

enum prp_wire_v4_kdf {
	PRP_WIRE_V4_KDF_NONE = 0,
	PRP_WIRE_V4_KDF_BLAKE3_DERIVE_KEY = 1,
	PRP_WIRE_V4_KDF_HKDF_SHA256 = 2,
	PRP_WIRE_V4_KDF_HKDF_SHA384 = 3,
};

enum prp_wire_v4_aead {
	PRP_WIRE_V4_AEAD_NONE = 0,
	PRP_WIRE_V4_AEAD_CHACHA20_POLY1305 = 1,
	PRP_WIRE_V4_AEAD_AES_256_GCM = 2,
};

enum prp_wire_v4_identity_proof_algorithm {
	PRP_WIRE_V4_PROOF_ED25519_BLAKE3 = 1,
	PRP_WIRE_V4_PROOF_ED25519CTX = 2,
	PRP_WIRE_V4_PROOF_MLDSA65 = 3,
	PRP_WIRE_V4_PROOF_MLDSA87 = 4,
	PRP_WIRE_V4_PROOF_ED25519_BLAKE3_MLDSA87 = 5,
};

enum prp_wire_v4_direction {
	PRP_WIRE_V4_DIRECTION_I2R = 1,
	PRP_WIRE_V4_DIRECTION_R2I = 2,
};

enum prp_wire_v4_public_unit_kind {
	PRP_WIRE_V4_PUBLIC_UNIT_HS2 = 1,
	PRP_WIRE_V4_PUBLIC_UNIT_HS2_FRAGMENT = 2,
};

struct prp_wire_v4_identity_crypto_desc {
	prp_wire_v4_u16 id;
	prp_wire_v4_u8 proof_algorithm;
	const char *primary_context;
	prp_wire_v4_u8 primary_context_len;
	const char *secondary_context;
	prp_wire_v4_u8 secondary_context_len;
};

struct prp_wire_v4_session_crypto_desc {
	prp_wire_v4_u16 id;
	prp_wire_v4_u8 kdf;
	prp_wire_v4_u8 aead;
	prp_wire_v4_u8 transcript_hash;
	prp_wire_v4_u8 transcript_hash_len;
	prp_wire_v4_u8 traffic_key_len;
	prp_wire_v4_u8 x25519_secret_len;
	prp_wire_v4_u8 kem_secret_len;
};

struct prp_wire_v4_public_hs2_fragment {
	prp_wire_v4_u8 hs2_kind;
	prp_wire_v4_u32 transfer_id;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total_len;
	prp_wire_v4_u16 session_suite_id;
	const prp_wire_v4_u8 *commitment;
	prp_wire_v4_u16 commitment_len;
	const prp_wire_v4_u8 *segment;
	prp_wire_v4_u16 segment_len;
};

struct prp_wire_v4_public_unit_view {
	prp_wire_v4_u8 kind;
	struct prp_wire_v4_scoped_hs2 hs2;
	struct prp_wire_v4_public_hs2_fragment fragment;
};

struct prp_wire_v4_scoped_hs2_fragment {
	prp_wire_v4_u16 route_alias;
	prp_wire_v4_u8 scope;
	prp_wire_v4_u8 hs2_kind;
	prp_wire_v4_u32 transfer_id;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total_len;
	prp_wire_v4_u16 session_suite_id;
	const prp_wire_v4_u8 *commitment;
	prp_wire_v4_u16 commitment_len;
	const prp_wire_v4_u8 *segment;
	prp_wire_v4_u16 segment_len;
};

struct prp_wire_v4_hs2_reassembly {
	prp_wire_v4_u8 *storage;
	size_t storage_capacity;
	prp_wire_v4_u8 *coverage;
	size_t coverage_capacity;
	prp_wire_v4_u16 route_alias;
	prp_wire_v4_u8 scope;
	prp_wire_v4_u8 hs2_kind;
	prp_wire_v4_u32 transfer_id;
	prp_wire_v4_u16 total_len;
	prp_wire_v4_u16 received_len;
	prp_wire_v4_u16 session_suite_id;
	prp_wire_v4_u8 commitment[PRP_WIRE_V4_FRAGMENT_COMMITMENT_MAX_LEN];
	prp_wire_v4_u16 commitment_len;
	prp_wire_v4_u8 initialized;
	prp_wire_v4_u8 have_start;
};

struct prp_wire_v4_replay_window {
	prp_wire_v4_u32 generation;
	prp_wire_v4_u64 highest_sequence;
	prp_wire_v4_u64 bitmap;
};

static inline int
prp_wire_v4_identity_crypto_get(prp_wire_v4_u16 id,
	struct prp_wire_v4_identity_crypto_desc *desc)
{
	struct prp_wire_v4_identity_crypto_desc value;

	if (prp_wire_v4_identity_suite_get(id, NULL))
		return PRP_WIRE_V4_ESUITE;
	value.id = id;
	value.secondary_context = NULL;
	value.secondary_context_len = 0;
	switch (id) {
	case PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_256:
		value.proof_algorithm = PRP_WIRE_V4_PROOF_ED25519_BLAKE3;
		value.primary_context = PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN;
		value.primary_context_len = PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN_LEN;
		break;
	case PRP_WIRE_V4_IDENTITY_ED25519CTX_SHA256_256:
		value.proof_algorithm = PRP_WIRE_V4_PROOF_ED25519CTX;
		value.primary_context = PRP_WIRE_V4_ID_PROOF_ED25519CTX;
		value.primary_context_len = PRP_WIRE_V4_ID_PROOF_ED25519CTX_LEN;
		break;
	case PRP_WIRE_V4_IDENTITY_MLDSA65_SHA256_256:
		value.proof_algorithm = PRP_WIRE_V4_PROOF_MLDSA65;
		value.primary_context = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;
		value.primary_context_len = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN;
		break;
	case PRP_WIRE_V4_IDENTITY_MLDSA87_SHA384_384:
		value.proof_algorithm = PRP_WIRE_V4_PROOF_MLDSA87;
		value.primary_context = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;
		value.primary_context_len = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN;
		break;
	case PRP_WIRE_V4_IDENTITY_ED25519_BLAKE3_MLDSA87_BLAKE3_256:
		value.proof_algorithm =
			PRP_WIRE_V4_PROOF_ED25519_BLAKE3_MLDSA87;
		value.primary_context = PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN;
		value.primary_context_len = PRP_WIRE_V4_ID_PROOF_BLAKE3_DOMAIN_LEN;
		value.secondary_context = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT;
		value.secondary_context_len = PRP_WIRE_V4_ID_PROOF_MLDSA_CONTEXT_LEN;
		break;
	default:
		return PRP_WIRE_V4_ESUITE;
	}
	if (desc)
		*desc = value;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_session_crypto_get(prp_wire_v4_u16 id,
	struct prp_wire_v4_session_crypto_desc *desc)
{
	struct prp_wire_v4_session_suite_desc session;
	struct prp_wire_v4_session_crypto_desc value;
	int rc = prp_wire_v4_session_suite_get(id, &session);

	if (rc)
		return rc;
	value.id = id;
	value.transcript_hash = session.commitment_hash;
	value.transcript_hash_len = (prp_wire_v4_u8)session.commitment_len;
	value.traffic_key_len = id == PRP_WIRE_V4_SESSION_NONE_BLAKE3 ||
		id == PRP_WIRE_V4_SESSION_NONE_SHA256 ? 0 :
		PRP_WIRE_V4_TRAFFIC_KEY_LEN;
	value.x25519_secret_len = session.ephemeral_key_len ?
		PRP_WIRE_V4_SHARED_SECRET_COMPONENT_LEN : 0;
	value.kem_secret_len = session.kem_public_key_len ?
		PRP_WIRE_V4_SHARED_SECRET_COMPONENT_LEN : 0;
	if (!value.traffic_key_len) {
		value.kdf = PRP_WIRE_V4_KDF_NONE;
		value.aead = PRP_WIRE_V4_AEAD_NONE;
	} else if (id == PRP_WIRE_V4_SESSION_MLKEM768_AES256GCM_SHA256) {
		value.kdf = PRP_WIRE_V4_KDF_HKDF_SHA256;
		value.aead = PRP_WIRE_V4_AEAD_AES_256_GCM;
	} else if (id == PRP_WIRE_V4_SESSION_MLKEM1024_AES256GCM_SHA384) {
		value.kdf = PRP_WIRE_V4_KDF_HKDF_SHA384;
		value.aead = PRP_WIRE_V4_AEAD_AES_256_GCM;
	} else {
		value.kdf = PRP_WIRE_V4_KDF_BLAKE3_DERIVE_KEY;
		value.aead = id ==
			PRP_WIRE_V4_SESSION_X25519_AES256GCM_BLAKE3 ?
			PRP_WIRE_V4_AEAD_AES_256_GCM :
			PRP_WIRE_V4_AEAD_CHACHA20_POLY1305;
	}
	if (desc)
		*desc = value;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_proof_prefix(const prp_wire_v4_u8 *hs2, size_t hs2_len,
	const prp_wire_v4_u8 **prefix, size_t *prefix_len)
{
	struct prp_wire_v4_hs2_view view;
	size_t proof_offset;
	int rc;

	if (!hs2 || !prefix || !prefix_len)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_hs2_validate(hs2, hs2_len, &view);
	if (rc)
		return rc;
	proof_offset = (size_t)(view.proof - hs2);
	if (proof_offset < PRP_WIRE_V4_TLV_HEADER_LEN)
		return PRP_WIRE_V4_ECANON;
	*prefix = hs2;
	*prefix_len = proof_offset - PRP_WIRE_V4_TLV_HEADER_LEN;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hashed_object_preimage_encode(const char *domain,
	prp_wire_v4_u8 domain_len, const prp_wire_v4_u8 *object,
	size_t object_len, prp_wire_v4_u8 *out, size_t capacity,
	size_t *written)
{
	size_t i;
	size_t required;

	if (!domain || (!object && object_len) || !out || !written)
		return PRP_WIRE_V4_EINVAL;
	if (object_len > PRP_WIRE_V4_LOGICAL_UNIT_MAX)
		return PRP_WIRE_V4_ERANGE;
	required = domain_len + PRP_WIRE_V4_HASHED_OBJECT_PREFIX_LEN +
		object_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	for (i = 0; i < domain_len; i++)
		out[i] = (prp_wire_v4_u8)domain[i];
	prp_wire_v4_put_be32(out + domain_len, (prp_wire_v4_u32)object_len);
	for (i = 0; i < object_len; i++)
		out[domain_len + PRP_WIRE_V4_HASHED_OBJECT_PREFIX_LEN + i] =
			object[i];
	*written = required;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_m1_binding_preimage_encode(const prp_wire_v4_u8 *m1,
	size_t m1_len, prp_wire_v4_u8 *out, size_t capacity, size_t *written)
{
	struct prp_wire_v4_hs2_view view;
	int rc = prp_wire_v4_hs2_validate(m1, m1_len, &view);

	if (rc)
		return rc;
	if (view.kind != PRP_WIRE_V4_HS2_M1)
		return PRP_WIRE_V4_ECANON;
	return prp_wire_v4_hashed_object_preimage_encode(
		PRP_WIRE_V4_M1_BINDING_DOMAIN,
		PRP_WIRE_V4_M1_BINDING_DOMAIN_LEN, m1, m1_len,
		out, capacity, written);
}

static inline int
prp_wire_v4_fragment_commitment_preimage_encode(const prp_wire_v4_u8 *hs2,
	size_t hs2_len, prp_wire_v4_u8 *out, size_t capacity, size_t *written)
{
	struct prp_wire_v4_hs2_view view;
	int rc = prp_wire_v4_hs2_validate(hs2, hs2_len, &view);

	if (rc)
		return rc;
	return prp_wire_v4_hashed_object_preimage_encode(
		PRP_WIRE_V4_FRAGMENT_COMMITMENT_DOMAIN,
		PRP_WIRE_V4_FRAGMENT_COMMITMENT_DOMAIN_LEN, hs2, hs2_len,
		out, capacity, written);
}

static inline int
prp_wire_v4_transcript_preimage_encode(const prp_wire_v4_u8 *m1,
	size_t m1_len, const prp_wire_v4_u8 *m2, size_t m2_len,
	prp_wire_v4_u8 *out, size_t capacity, size_t *written)
{
	struct prp_wire_v4_hs2_view m1_view;
	struct prp_wire_v4_hs2_view m2_view;
	size_t required;
	size_t pos;
	size_t i;
	int rc;

	if (!m1 || !m2 || !out || !written)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_hs2_validate(m1, m1_len, &m1_view);
	if (rc)
		return rc;
	rc = prp_wire_v4_hs2_validate(m2, m2_len, &m2_view);
	if (rc)
		return rc;
	if (m1_view.kind != PRP_WIRE_V4_HS2_M1 ||
	    m2_view.kind != PRP_WIRE_V4_HS2_M2 ||
	    m1_view.session_suite_id != m2_view.session_suite_id)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_TRANSCRIPT_DOMAIN_LEN + 8U + m1_len + m2_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	for (i = 0; i < PRP_WIRE_V4_TRANSCRIPT_DOMAIN_LEN; i++)
		out[i] = (prp_wire_v4_u8)PRP_WIRE_V4_TRANSCRIPT_DOMAIN[i];
	pos = PRP_WIRE_V4_TRANSCRIPT_DOMAIN_LEN;
	prp_wire_v4_put_be32(out + pos, (prp_wire_v4_u32)m1_len);
	pos += 4;
	for (i = 0; i < m1_len; i++)
		out[pos++] = m1[i];
	prp_wire_v4_put_be32(out + pos, (prp_wire_v4_u32)m2_len);
	pos += 4;
	for (i = 0; i < m2_len; i++)
		out[pos++] = m2[i];
	*written = pos;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_traffic_material_encode(prp_wire_v4_u8 scope,
	prp_wire_v4_u16 session_suite_id, prp_wire_v4_u32 generation,
	const prp_wire_v4_u8 *transcript_hash, size_t transcript_hash_len,
	const prp_wire_v4_u8 *shared_secret, size_t shared_secret_len,
	prp_wire_v4_u8 *out, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_crypto_desc desc;
	size_t expected_secret;
	size_t required;
	size_t pos;
	size_t i;
	int rc;

	if (!transcript_hash || !shared_secret || !out || !written ||
	    scope < PRP_WIRE_V4_SCOPE_ADJACENT || scope > PRP_WIRE_V4_SCOPE_E2E ||
	    !generation)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (desc.kdf != PRP_WIRE_V4_KDF_BLAKE3_DERIVE_KEY)
		return PRP_WIRE_V4_ESUITE;
	expected_secret = desc.x25519_secret_len + desc.kem_secret_len;
	if (transcript_hash_len != desc.transcript_hash_len ||
	    shared_secret_len != expected_secret)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_TRAFFIC_MATERIAL_PREFIX_LEN +
		transcript_hash_len + shared_secret_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	out[0] = scope;
	prp_wire_v4_put_be16(out + 1, session_suite_id);
	prp_wire_v4_put_be32(out + 3, generation);
	prp_wire_v4_put_be16(out + 7,
		(prp_wire_v4_u16)transcript_hash_len);
	pos = 9;
	for (i = 0; i < transcript_hash_len; i++)
		out[pos++] = transcript_hash[i];
	prp_wire_v4_put_be16(out + pos,
		(prp_wire_v4_u16)shared_secret_len);
	pos += 2;
	for (i = 0; i < shared_secret_len; i++)
		out[pos++] = shared_secret[i];
	*written = pos;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hkdf_info_encode(prp_wire_v4_u8 scope,
	prp_wire_v4_u8 direction, prp_wire_v4_u16 session_suite_id,
	prp_wire_v4_u32 generation, prp_wire_v4_u8 *out, size_t capacity,
	size_t *written)
{
	struct prp_wire_v4_session_crypto_desc desc;
	size_t i;
	int rc;

	if (!out || !written || !generation ||
	    scope < PRP_WIRE_V4_SCOPE_ADJACENT || scope > PRP_WIRE_V4_SCOPE_E2E ||
	    (direction != PRP_WIRE_V4_DIRECTION_I2R &&
	     direction != PRP_WIRE_V4_DIRECTION_R2I))
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (desc.kdf != PRP_WIRE_V4_KDF_HKDF_SHA256 &&
	    desc.kdf != PRP_WIRE_V4_KDF_HKDF_SHA384)
		return PRP_WIRE_V4_ESUITE;
	if (capacity < PRP_WIRE_V4_HKDF_INFO_LEN)
		return PRP_WIRE_V4_ERANGE;
	for (i = 0; i < PRP_WIRE_V4_HKDF_INFO_DOMAIN_LEN; i++)
		out[i] = (prp_wire_v4_u8)PRP_WIRE_V4_HKDF_INFO_DOMAIN[i];
	out[i++] = scope;
	out[i++] = direction;
	prp_wire_v4_put_be16(out + i, session_suite_id);
	i += 2;
	prp_wire_v4_put_be32(out + i, generation);
	i += 4;
	*written = i;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_nonce_encode(prp_wire_v4_u16 session_suite_id,
	prp_wire_v4_u32 generation, prp_wire_v4_u64 sequence,
	prp_wire_v4_u8 nonce[PRP_WIRE_V4_NONCE_LEN])
{
	struct prp_wire_v4_session_crypto_desc desc;
	int rc;

	if (!nonce || !generation || !sequence)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (desc.aead == PRP_WIRE_V4_AEAD_NONE)
		return PRP_WIRE_V4_ESUITE;
	prp_wire_v4_put_be32(nonce, generation);
	prp_wire_v4_put_be64(nonce + 4, sequence);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_nonce_decode(prp_wire_v4_u16 session_suite_id,
	const prp_wire_v4_u8 *nonce, size_t nonce_len,
	prp_wire_v4_u32 *generation, prp_wire_v4_u64 *sequence)
{
	struct prp_wire_v4_session_crypto_desc desc;
	prp_wire_v4_u32 parsed_generation;
	prp_wire_v4_u64 parsed_sequence;
	int rc;

	if (!nonce || !generation || !sequence)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (desc.aead == PRP_WIRE_V4_AEAD_NONE)
		return PRP_WIRE_V4_ESUITE;
	if (nonce_len != PRP_WIRE_V4_NONCE_LEN)
		return PRP_WIRE_V4_ECANON;
	parsed_generation = prp_wire_v4_get_be32(nonce);
	parsed_sequence = prp_wire_v4_get_be64(nonce + 4);
	if (!parsed_generation || !parsed_sequence)
		return PRP_WIRE_V4_ECANON;
	*generation = parsed_generation;
	*sequence = parsed_sequence;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_replay_init(struct prp_wire_v4_replay_window *window,
	prp_wire_v4_u32 generation)
{
	if (!window || !generation)
		return PRP_WIRE_V4_EINVAL;
	window->generation = generation;
	window->highest_sequence = 0;
	window->bitmap = 0;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_replay_precheck(const struct prp_wire_v4_replay_window *window,
	prp_wire_v4_u32 generation, prp_wire_v4_u64 sequence)
{
	prp_wire_v4_u64 delta;

	if (!window || !generation || !sequence)
		return PRP_WIRE_V4_EINVAL;
	if (generation != window->generation)
		return PRP_WIRE_V4_EREPLAY;
	if (sequence > window->highest_sequence)
		return PRP_WIRE_V4_OK;
	delta = window->highest_sequence - sequence;
	if (delta >= 64U || (window->bitmap & ((prp_wire_v4_u64)1U << delta)))
		return PRP_WIRE_V4_EREPLAY;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_replay_commit(struct prp_wire_v4_replay_window *window,
	prp_wire_v4_u32 generation, prp_wire_v4_u64 sequence)
{
	prp_wire_v4_u64 delta;
	int rc = prp_wire_v4_replay_precheck(window, generation, sequence);

	if (rc)
		return rc;
	if (sequence > window->highest_sequence) {
		delta = sequence - window->highest_sequence;
		window->bitmap = delta >= 64U ? 1U :
			(window->bitmap << delta) | 1U;
		window->highest_sequence = sequence;
	} else {
		delta = window->highest_sequence - sequence;
		window->bitmap |= (prp_wire_v4_u64)1U << delta;
	}
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_aead_aad_encode(prp_wire_v4_u8 scope,
	prp_wire_v4_u16 session_suite_id, prp_wire_v4_u32 generation,
	const prp_wire_v4_u8 *transcript_hash, size_t transcript_hash_len,
	prp_wire_v4_u8 *out, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_crypto_desc desc;
	size_t required;
	size_t i;
	int rc;

	if (!transcript_hash || !out || !written || !generation ||
	    scope < PRP_WIRE_V4_SCOPE_ADJACENT || scope > PRP_WIRE_V4_SCOPE_E2E)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_session_crypto_get(session_suite_id, &desc);
	if (rc)
		return rc;
	if (desc.aead == PRP_WIRE_V4_AEAD_NONE)
		return PRP_WIRE_V4_ESUITE;
	if (transcript_hash_len != desc.transcript_hash_len)
		return PRP_WIRE_V4_ECANON;
	required = PRP_WIRE_V4_AEAD_AAD_PREFIX_LEN + transcript_hash_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	for (i = 0; i < PRP_WIRE_V4_AEAD_AAD_DOMAIN_LEN; i++)
		out[i] = (prp_wire_v4_u8)PRP_WIRE_V4_AEAD_AAD_DOMAIN[i];
	out[i++] = scope;
	prp_wire_v4_put_be16(out + i, session_suite_id);
	i += 2;
	prp_wire_v4_put_be32(out + i, generation);
	i += 4;
	for (size_t j = 0; j < transcript_hash_len; j++)
		out[i++] = transcript_hash[j];
	*written = i;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_fragment_body_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_scoped_hs2_fragment *fragment)
{
	struct prp_wire_v4_session_suite_desc suite;
	size_t pos = PRP_WIRE_V4_SCOPED_HS2_FRAGMENT_PREFIX_LEN;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total;
	int rc;

	if (!wire || !fragment)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_SCOPED_HS2_FRAGMENT_PREFIX_LEN + 1U)
		return PRP_WIRE_V4_ETRUNC;
	if ((wire[0] != PRP_WIRE_V4_SCOPE_DIRECT &&
	     wire[0] != PRP_WIRE_V4_SCOPE_E2E) ||
	    (wire[1] != PRP_WIRE_V4_HS2_M1 &&
	     wire[1] != PRP_WIRE_V4_HS2_M2) || wire[2] || wire[3] ||
	    !prp_wire_v4_get_be32(wire + 4))
		return PRP_WIRE_V4_ECANON;
	offset = prp_wire_v4_get_be16(wire + 8);
	total = prp_wire_v4_get_be16(wire + 10);
	if (!total || total > PRP_WIRE_V4_HS2_MAX_LEN || offset >= total)
		return PRP_WIRE_V4_ECANON;
	fragment->session_suite_id = 0;
	fragment->commitment = NULL;
	fragment->commitment_len = 0;
	if (!offset) {
		if (len - pos < PRP_WIRE_V4_FRAGMENT_SUITE_LEN)
			return PRP_WIRE_V4_ETRUNC;
		fragment->session_suite_id = prp_wire_v4_get_be16(wire + pos);
		rc = prp_wire_v4_session_suite_get(fragment->session_suite_id,
			&suite);
		if (rc)
			return rc;
		pos += PRP_WIRE_V4_FRAGMENT_SUITE_LEN;
		if (len - pos <= suite.commitment_len)
			return PRP_WIRE_V4_ETRUNC;
		fragment->commitment = wire + pos;
		fragment->commitment_len = suite.commitment_len;
		pos += suite.commitment_len;
	}
	if (len <= pos || len - pos > (size_t)(total - offset))
		return PRP_WIRE_V4_ECANON;
	fragment->scope = wire[0];
	fragment->hs2_kind = wire[1];
	fragment->transfer_id = prp_wire_v4_get_be32(wire + 4);
	fragment->offset = offset;
	fragment->total_len = total;
	fragment->segment = wire + pos;
	fragment->segment_len = (prp_wire_v4_u16)(len - pos);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_fragment_body_encode(
	const struct prp_wire_v4_scoped_hs2_fragment *fragment,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_suite_desc suite;
	struct prp_wire_v4_scoped_hs2_fragment checked;
	size_t required = PRP_WIRE_V4_SCOPED_HS2_FRAGMENT_PREFIX_LEN;
	size_t pos;
	size_t i;
	int rc;

	if (!fragment || !wire || !written || !fragment->segment ||
	    (fragment->scope != PRP_WIRE_V4_SCOPE_DIRECT &&
	     fragment->scope != PRP_WIRE_V4_SCOPE_E2E) ||
	    (fragment->hs2_kind != PRP_WIRE_V4_HS2_M1 &&
	     fragment->hs2_kind != PRP_WIRE_V4_HS2_M2) ||
	    !fragment->transfer_id || !fragment->total_len ||
	    fragment->total_len > PRP_WIRE_V4_HS2_MAX_LEN ||
	    !fragment->segment_len || fragment->offset >= fragment->total_len ||
	    fragment->segment_len >
		(prp_wire_v4_u16)(fragment->total_len - fragment->offset))
		return PRP_WIRE_V4_EINVAL;
	if (!fragment->offset) {
		rc = prp_wire_v4_session_suite_get(fragment->session_suite_id,
			&suite);
		if (rc)
			return rc;
		if (!fragment->commitment ||
		    fragment->commitment_len != suite.commitment_len)
			return PRP_WIRE_V4_ECANON;
		required += PRP_WIRE_V4_FRAGMENT_SUITE_LEN +
			fragment->commitment_len;
	} else if (fragment->session_suite_id || fragment->commitment ||
		   fragment->commitment_len) {
		return PRP_WIRE_V4_ECANON;
	}
	required += fragment->segment_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = fragment->scope;
	wire[1] = fragment->hs2_kind;
	wire[2] = 0;
	wire[3] = 0;
	prp_wire_v4_put_be32(wire + 4, fragment->transfer_id);
	prp_wire_v4_put_be16(wire + 8, fragment->offset);
	prp_wire_v4_put_be16(wire + 10, fragment->total_len);
	pos = PRP_WIRE_V4_SCOPED_HS2_FRAGMENT_PREFIX_LEN;
	if (!fragment->offset) {
		prp_wire_v4_put_be16(wire + pos, fragment->session_suite_id);
		pos += PRP_WIRE_V4_FRAGMENT_SUITE_LEN;
		for (i = 0; i < fragment->commitment_len; i++)
			wire[pos++] = fragment->commitment[i];
	}
	for (i = 0; i < fragment->segment_len; i++)
		wire[pos++] = fragment->segment[i];
	rc = prp_wire_v4_scoped_hs2_fragment_body_decode(wire, pos, &checked);
	if (rc)
		return rc;
	*written = pos;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_fragment_record_decode(
	const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_scoped_hs2_fragment *fragment)
{
	struct prp_wire_v4_record record;
	int rc;

	if (!fragment)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_record_decode(wire, len, &record);
	if (rc)
		return rc;
	if (record.kind != PRP_WIRE_V4_RECORD_SCOPED_HS2_FRAGMENT ||
	    record.flags ||
	    record.route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL)
		return PRP_WIRE_V4_ECANON;
	rc = prp_wire_v4_scoped_hs2_fragment_body_decode(record.body,
		record.body_len, fragment);
	if (rc)
		return rc;
	fragment->route_alias = record.route_alias;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_scoped_hs2_fragment_record_encode(
	const struct prp_wire_v4_scoped_hs2_fragment *fragment,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_record record;
	size_t body_len;
	int rc;

	if (!fragment || !wire || !written ||
	    fragment->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
	    fragment->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL ||
	    capacity < PRP_WIRE_V4_RECORD_HEADER_LEN)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_scoped_hs2_fragment_body_encode(fragment,
		wire + PRP_WIRE_V4_RECORD_HEADER_LEN,
		capacity - PRP_WIRE_V4_RECORD_HEADER_LEN, &body_len);
	if (rc)
		return rc;
	record.route_alias = fragment->route_alias;
	record.kind = PRP_WIRE_V4_RECORD_SCOPED_HS2_FRAGMENT;
	record.flags = 0;
	record.body = wire + PRP_WIRE_V4_RECORD_HEADER_LEN;
	record.body_len = (prp_wire_v4_u16)body_len;
	return prp_wire_v4_record_encode(&record, wire, capacity, written);
}

static inline int
prp_wire_v4_hs2_reassembly_init(struct prp_wire_v4_hs2_reassembly *state,
	prp_wire_v4_u8 *storage, size_t storage_capacity,
	prp_wire_v4_u8 *coverage, size_t coverage_capacity)
{
	size_t i;

	if (!state || !storage || !storage_capacity || !coverage ||
	    !coverage_capacity)
		return PRP_WIRE_V4_EINVAL;
	state->storage = storage;
	state->storage_capacity = storage_capacity;
	state->coverage = coverage;
	state->coverage_capacity = coverage_capacity;
	state->route_alias = 0;
	state->scope = 0;
	state->hs2_kind = 0;
	state->transfer_id = 0;
	state->total_len = 0;
	state->received_len = 0;
	state->session_suite_id = 0;
	state->commitment_len = 0;
	state->initialized = 0;
	state->have_start = 0;
	for (i = 0; i < coverage_capacity; i++)
		coverage[i] = 0;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_hs2_reassembly_submit(struct prp_wire_v4_hs2_reassembly *state,
	const struct prp_wire_v4_scoped_hs2_fragment *fragment,
	int *complete)
{
	struct prp_wire_v4_hs2_view view;
	struct prp_wire_v4_session_suite_desc suite;
	size_t required_coverage;
	size_t i;
	int rc;

	if (!state || !fragment || !complete || !state->storage ||
	    !state->coverage || !fragment->segment)
		return PRP_WIRE_V4_EINVAL;
	*complete = 0;
	if (fragment->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_INVALID ||
	    fragment->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL ||
	    (fragment->scope != PRP_WIRE_V4_SCOPE_DIRECT &&
	     fragment->scope != PRP_WIRE_V4_SCOPE_E2E) ||
	    (fragment->hs2_kind != PRP_WIRE_V4_HS2_M1 &&
	     fragment->hs2_kind != PRP_WIRE_V4_HS2_M2) ||
	    !fragment->transfer_id || !fragment->total_len ||
	    fragment->total_len > PRP_WIRE_V4_HS2_MAX_LEN ||
	    !fragment->segment_len || fragment->offset >= fragment->total_len ||
	    fragment->segment_len >
		(prp_wire_v4_u16)(fragment->total_len - fragment->offset))
		return PRP_WIRE_V4_ECANON;
	if (!fragment->offset) {
		rc = prp_wire_v4_session_suite_get(fragment->session_suite_id,
			&suite);
		if (rc)
			return rc;
		if (!fragment->commitment ||
		    fragment->commitment_len != suite.commitment_len)
			return PRP_WIRE_V4_ECANON;
	} else if (fragment->session_suite_id || fragment->commitment ||
		   fragment->commitment_len) {
		return PRP_WIRE_V4_ECANON;
	}
	required_coverage = (fragment->total_len + 7U) / 8U;
	if (fragment->total_len > state->storage_capacity ||
	    required_coverage > state->coverage_capacity)
		return PRP_WIRE_V4_ERANGE;
	if (!state->initialized) {
		state->route_alias = fragment->route_alias;
		state->scope = fragment->scope;
		state->hs2_kind = fragment->hs2_kind;
		state->transfer_id = fragment->transfer_id;
		state->total_len = fragment->total_len;
		state->initialized = 1;
	} else if (state->route_alias != fragment->route_alias ||
		   state->scope != fragment->scope ||
		   state->hs2_kind != fragment->hs2_kind ||
		   state->transfer_id != fragment->transfer_id ||
		   state->total_len != fragment->total_len) {
		return PRP_WIRE_V4_ECANON;
	}
	if (!fragment->offset) {
		if (state->have_start)
			return PRP_WIRE_V4_EREPLAY;
		if (fragment->commitment_len > sizeof(state->commitment))
			return PRP_WIRE_V4_ECANON;
	}
	for (i = 0; i < fragment->segment_len; i++) {
		size_t index = fragment->offset + i;
		prp_wire_v4_u8 bit = (prp_wire_v4_u8)(1U << (index & 7U));

		if (state->coverage[index >> 3] & bit)
			return PRP_WIRE_V4_EREPLAY;
	}
	if (!fragment->offset) {
		state->session_suite_id = fragment->session_suite_id;
		state->commitment_len = fragment->commitment_len;
		for (i = 0; i < fragment->commitment_len; i++)
			state->commitment[i] = fragment->commitment[i];
		state->have_start = 1;
	}
	for (i = 0; i < fragment->segment_len; i++) {
		size_t index = fragment->offset + i;
		prp_wire_v4_u8 bit = (prp_wire_v4_u8)(1U << (index & 7U));

		state->storage[index] = fragment->segment[i];
		state->coverage[index >> 3] |= bit;
	}
	state->received_len = (prp_wire_v4_u16)(state->received_len +
		fragment->segment_len);
	if (state->received_len != state->total_len || !state->have_start)
		return PRP_WIRE_V4_OK;
	rc = prp_wire_v4_hs2_validate(state->storage, state->total_len, &view);
	if (rc)
		return rc;
	if (view.kind != state->hs2_kind ||
	    view.session_suite_id != state->session_suite_id)
		return PRP_WIRE_V4_ECANON;
	*complete = 1;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_public_hs2_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_scoped_hs2 *scoped)
{
	int rc = prp_wire_v4_scoped_hs2_decode(wire, len, scoped);

	if (rc)
		return rc;
	return scoped->scope == PRP_WIRE_V4_SCOPE_ADJACENT &&
		scoped->route_alias == PRP_WIRE_V4_ROUTE_ALIAS_CONTROL ?
		PRP_WIRE_V4_OK : PRP_WIRE_V4_ECANON;
}

static inline int
prp_wire_v4_public_hs2_encode(const prp_wire_v4_u8 *hs2, size_t hs2_len,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_scoped_hs2 scoped;
	size_t scoped_len;
	int rc;

	if (!hs2 || !wire || !written || hs2_len > PRP_WIRE_V4_HS2_MAX_LEN)
		return PRP_WIRE_V4_EINVAL;
	if (capacity < 1U)
		return PRP_WIRE_V4_ETRUNC;
	scoped.scope = PRP_WIRE_V4_SCOPE_ADJACENT;
	scoped.route_alias = PRP_WIRE_V4_ROUTE_ALIAS_CONTROL;
	scoped.hs2 = hs2;
	scoped.hs2_len = (prp_wire_v4_u16)hs2_len;
	wire[0] = PRP_WIRE_V4_CONTROL_HS2;
	rc = prp_wire_v4_scoped_hs2_encode(&scoped, wire + 1U,
		capacity - 1U, &scoped_len);
	if (rc)
		return rc;
	*written = scoped_len + 1U;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_public_hs2_fragment_decode(const prp_wire_v4_u8 *wire,
	size_t len, struct prp_wire_v4_public_hs2_fragment *fragment)
{
	struct prp_wire_v4_session_suite_desc suite;
	size_t pos = PRP_WIRE_V4_PUBLIC_FRAGMENT_PREFIX_LEN;
	prp_wire_v4_u16 offset;
	prp_wire_v4_u16 total;
	int rc;

	if (!wire || !fragment)
		return PRP_WIRE_V4_EINVAL;
	if (len < PRP_WIRE_V4_PUBLIC_FRAGMENT_PREFIX_LEN + 1U)
		return PRP_WIRE_V4_ETRUNC;
	if (wire[0] != PRP_WIRE_V4_CONTROL_HS2_FRAGMENT ||
	    wire[1] != PRP_WIRE_V4_SCOPE_ADJACENT ||
	    prp_wire_v4_get_be16(wire + 2) != PRP_WIRE_V4_ROUTE_ALIAS_CONTROL ||
	    (wire[4] != PRP_WIRE_V4_HS2_M1 &&
	     wire[4] != PRP_WIRE_V4_HS2_M2) || wire[5] ||
	    !prp_wire_v4_get_be32(wire + 6))
		return PRP_WIRE_V4_ECANON;
	offset = prp_wire_v4_get_be16(wire + 10);
	total = prp_wire_v4_get_be16(wire + 12);
	if (!total || total > PRP_WIRE_V4_HS2_MAX_LEN || offset >= total)
		return PRP_WIRE_V4_ECANON;
	fragment->session_suite_id = 0;
	fragment->commitment = NULL;
	fragment->commitment_len = 0;
	if (!offset) {
		if (len - pos < PRP_WIRE_V4_FRAGMENT_SUITE_LEN)
			return PRP_WIRE_V4_ETRUNC;
		fragment->session_suite_id = prp_wire_v4_get_be16(wire + pos);
		rc = prp_wire_v4_session_suite_get(fragment->session_suite_id,
			&suite);
		if (rc)
			return rc;
		pos += PRP_WIRE_V4_FRAGMENT_SUITE_LEN;
		if (len - pos <= suite.commitment_len)
			return PRP_WIRE_V4_ETRUNC;
		fragment->commitment = wire + pos;
		fragment->commitment_len = suite.commitment_len;
		pos += suite.commitment_len;
	}
	if (len <= pos || len - pos > (size_t)(total - offset))
		return PRP_WIRE_V4_ECANON;
	fragment->hs2_kind = wire[4];
	fragment->transfer_id = prp_wire_v4_get_be32(wire + 6);
	fragment->offset = offset;
	fragment->total_len = total;
	fragment->segment = wire + pos;
	fragment->segment_len = (prp_wire_v4_u16)(len - pos);
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_public_hs2_fragment_encode(
	const struct prp_wire_v4_public_hs2_fragment *fragment,
	prp_wire_v4_u8 *wire, size_t capacity, size_t *written)
{
	struct prp_wire_v4_session_suite_desc suite;
	struct prp_wire_v4_public_hs2_fragment checked;
	size_t required = PRP_WIRE_V4_PUBLIC_FRAGMENT_PREFIX_LEN;
	size_t pos;
	size_t i;
	int rc;

	if (!fragment || !wire || !written || !fragment->segment ||
	    !fragment->transfer_id || !fragment->total_len ||
	    fragment->total_len > PRP_WIRE_V4_HS2_MAX_LEN ||
	    !fragment->segment_len || fragment->offset >= fragment->total_len ||
	    fragment->segment_len >
		(prp_wire_v4_u16)(fragment->total_len - fragment->offset) ||
	    (fragment->hs2_kind != PRP_WIRE_V4_HS2_M1 &&
	     fragment->hs2_kind != PRP_WIRE_V4_HS2_M2))
		return PRP_WIRE_V4_EINVAL;
	if (!fragment->offset) {
		rc = prp_wire_v4_session_suite_get(fragment->session_suite_id,
			&suite);
		if (rc)
			return rc;
		if (!fragment->commitment ||
		    fragment->commitment_len != suite.commitment_len)
			return PRP_WIRE_V4_ECANON;
		required += PRP_WIRE_V4_FRAGMENT_SUITE_LEN +
			fragment->commitment_len;
	} else if (fragment->session_suite_id || fragment->commitment ||
		   fragment->commitment_len) {
		return PRP_WIRE_V4_ECANON;
	}
	required += fragment->segment_len;
	if (capacity < required)
		return PRP_WIRE_V4_ERANGE;
	wire[0] = PRP_WIRE_V4_CONTROL_HS2_FRAGMENT;
	wire[1] = PRP_WIRE_V4_SCOPE_ADJACENT;
	prp_wire_v4_put_be16(wire + 2, PRP_WIRE_V4_ROUTE_ALIAS_CONTROL);
	wire[4] = fragment->hs2_kind;
	wire[5] = 0;
	prp_wire_v4_put_be32(wire + 6, fragment->transfer_id);
	prp_wire_v4_put_be16(wire + 10, fragment->offset);
	prp_wire_v4_put_be16(wire + 12, fragment->total_len);
	pos = PRP_WIRE_V4_PUBLIC_FRAGMENT_PREFIX_LEN;
	if (!fragment->offset) {
		prp_wire_v4_put_be16(wire + pos, fragment->session_suite_id);
		pos += PRP_WIRE_V4_FRAGMENT_SUITE_LEN;
		for (i = 0; i < fragment->commitment_len; i++)
			wire[pos++] = fragment->commitment[i];
	}
	for (i = 0; i < fragment->segment_len; i++)
		wire[pos++] = fragment->segment[i];
	rc = prp_wire_v4_public_hs2_fragment_decode(wire, pos, &checked);
	if (rc)
		return rc;
	*written = pos;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_public_hs2_reassembled_shape_validate(
	const struct prp_wire_v4_public_hs2_fragment *start,
	const prp_wire_v4_u8 *hs2, size_t hs2_len)
{
	struct prp_wire_v4_hs2_view view;
	int rc;

	if (!start || !hs2 || start->offset || !start->commitment ||
	    !start->commitment_len || start->total_len != hs2_len)
		return PRP_WIRE_V4_EINVAL;
	rc = prp_wire_v4_hs2_validate(hs2, hs2_len, &view);
	if (rc)
		return rc;
	if (view.kind != start->hs2_kind ||
	    view.session_suite_id != start->session_suite_id)
		return PRP_WIRE_V4_ECANON;
	return PRP_WIRE_V4_OK;
}

static inline int
prp_wire_v4_public_unit_decode(const prp_wire_v4_u8 *wire, size_t len,
	struct prp_wire_v4_public_unit_view *view)
{
	int rc;

	if (!wire || !view || !len)
		return PRP_WIRE_V4_EINVAL;
	if (wire[0] == PRP_WIRE_V4_CONTROL_HS2_FRAGMENT) {
		rc = prp_wire_v4_public_hs2_fragment_decode(wire, len,
			&view->fragment);
		if (!rc)
			view->kind = PRP_WIRE_V4_PUBLIC_UNIT_HS2_FRAGMENT;
		return rc;
	}
	if (wire[0] != PRP_WIRE_V4_CONTROL_HS2 || len <= 1U)
		return PRP_WIRE_V4_ECANON;
	rc = prp_wire_v4_public_hs2_decode(wire + 1U, len - 1U, &view->hs2);
	if (!rc)
		view->kind = PRP_WIRE_V4_PUBLIC_UNIT_HS2;
	return rc;
}

#endif /* PRP_WIRE_V4_CRYPTO_H */
