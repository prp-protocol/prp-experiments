#ifndef PRP_MEMORY_H
#define PRP_MEMORY_H

#include "prp_export.h"

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Erases length bytes through volatile stores. NULL is accepted only at 0. */
PRP_API void prp_secure_zero(void *memory, size_t length);

/* Returns 1 iff both fixed-length byte strings are equal, otherwise 0. */
PRP_API int prp_constant_time_equal(
    const void *left, const void *right, size_t length);

#ifdef __cplusplus
}
#endif

#endif
