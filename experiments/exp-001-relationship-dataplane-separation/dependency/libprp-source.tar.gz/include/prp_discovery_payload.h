#ifndef PRP_DISCOVERY_PAYLOAD_H
#define PRP_DISCOVERY_PAYLOAD_H

#include "prp_export.h"
#include "prp_status.h"

#include <prp/contracts/protected_discovery_payload_v1.h>

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum prp_discovery_payload_class_e {
    PRP_DISCOVERY_PAYLOAD_CLASS_DURABLE = 1,
    PRP_DISCOVERY_PAYLOAD_CLASS_REQUEST = 2,
    PRP_DISCOVERY_PAYLOAD_CLASS_RESPONSE = 3
} prp_discovery_payload_class_t;

typedef enum prp_discovery_payload_role_e {
    PRP_DISCOVERY_PAYLOAD_ROLE_PUBLICATION_CONTROLLER = 1,
    PRP_DISCOVERY_PAYLOAD_ROLE_FILTER_ORIGIN = 2,
    PRP_DISCOVERY_PAYLOAD_ROLE_RENDEZVOUS = 3,
    PRP_DISCOVERY_PAYLOAD_ROLE_REQUESTER = 4,
    PRP_DISCOVERY_PAYLOAD_ROLE_VOPRF_SERVER = 5,
    PRP_DISCOVERY_PAYLOAD_ROLE_VOPRF_CLIENT = 6,
    PRP_DISCOVERY_PAYLOAD_ROLE_PUBLISHED_DESTINATION = 7
} prp_discovery_payload_role_t;

typedef struct prp_discovery_payload_kind_info_s {
    prp_discovery_payload_class_t payload_class;
    prp_discovery_payload_role_t sender_role;
} prp_discovery_payload_kind_info_t;

typedef struct prp_discovery_payload_s {
    uint8_t kind;
    uint32_t policy_generation;
    uint64_t subject_generation;
    uint8_t correlation[PRP_DISCOVERY_PAYLOAD_CORRELATION_LEN];
    const uint8_t *payload;
    uint16_t payload_len;
} prp_discovery_payload_t;

PRP_API int prp_discovery_payload_kind_info(uint8_t kind,
    prp_discovery_payload_kind_info_t *info);
PRP_API int prp_discovery_payload_encode(
    const prp_discovery_payload_t *payload, uint8_t *out, size_t out_len,
    size_t *written);
PRP_API int prp_discovery_payload_decode(const uint8_t *data,
    size_t data_len, prp_discovery_payload_t *payload);

/* These helpers inspect caller-owned state; they never retain protocol state. */
PRP_API int prp_discovery_payload_context_validate(
    const prp_discovery_payload_t *payload, int lane_active,
    uint32_t active_policy_generation, uint64_t expected_subject_generation,
    prp_discovery_payload_role_t sender_role);
PRP_API int prp_discovery_payload_pending_match(
    const prp_discovery_payload_t *request,
    const prp_discovery_payload_t *response);
PRP_API int prp_discovery_payload_replay_compare(
    const prp_discovery_payload_t *accepted,
    const prp_discovery_payload_t *candidate);

#ifdef __cplusplus
}
#endif

#endif
