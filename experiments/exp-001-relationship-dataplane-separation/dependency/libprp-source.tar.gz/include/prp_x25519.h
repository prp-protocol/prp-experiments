#ifndef PRP_X25519_H
#define PRP_X25519_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_X25519_SEED_LEN 32u
#define PRP_X25519_PUBLIC_KEY_LEN 32u
#define PRP_X25519_SHARED_SECRET_LEN 32u

typedef struct prp_x25519_keypair_s prp_x25519_keypair_t;
struct prp_platform_s;

/* Native backend entropy; private material remains inside the opaque object. */
PRP_API prp_status_t prp_x25519_keypair_generate(
    prp_x25519_keypair_t **keypair);

/* Uses the platform random callback, including freestanding providers. */
PRP_API prp_status_t prp_x25519_keypair_generate_with_platform(
    prp_x25519_keypair_t **keypair,
    const struct prp_platform_s *platform);

/* Deterministic vector entry point; the caller must erase the seed. */
PRP_API prp_status_t prp_x25519_keypair_from_seed(
    prp_x25519_keypair_t **keypair,
    const uint8_t seed[PRP_X25519_SEED_LEN]);

PRP_API prp_status_t prp_x25519_public_key_export(
    const prp_x25519_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written);

PRP_API prp_status_t prp_x25519_agree(
    const prp_x25519_keypair_t *keypair,
    const uint8_t peer_public_key[PRP_X25519_PUBLIC_KEY_LEN],
    uint8_t *shared_secret, size_t shared_secret_size, size_t *written);

PRP_API void prp_x25519_keypair_destroy(prp_x25519_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
