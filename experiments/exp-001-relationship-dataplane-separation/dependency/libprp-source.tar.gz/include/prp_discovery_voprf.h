#ifndef PRP_DISCOVERY_VOPRF_H
#define PRP_DISCOVERY_VOPRF_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_VOPRF_VERSION 1u
#define PRP_DISCOVERY_VOPRF_MODE 1u
#define PRP_DISCOVERY_VOPRF_PROFILE_RISTRETTO255_SHA512_128 0x0002u

#define PRP_DISCOVERY_VOPRF_SCALAR_LEN 32u
#define PRP_DISCOVERY_VOPRF_ELEMENT_LEN 32u
#define PRP_DISCOVERY_VOPRF_PROOF_LEN 64u
#define PRP_DISCOVERY_VOPRF_OUTPUT_LEN 64u
#define PRP_DISCOVERY_VOPRF_TOKEN_LEN 16u
#define PRP_DISCOVERY_VOPRF_REQUEST_ID_LEN 16u
#define PRP_DISCOVERY_VOPRF_KEY_RECORD_LEN 44u
#define PRP_DISCOVERY_VOPRF_REQUEST_RECORD_LEN 60u
#define PRP_DISCOVERY_VOPRF_RESPONSE_RECORD_LEN 124u

struct prp_platform_s;

typedef struct prp_discovery_voprf_key_record_s {
    uint32_t relationship_generation;
    uint8_t public_key[PRP_DISCOVERY_VOPRF_ELEMENT_LEN];
} prp_discovery_voprf_key_record_t;

typedef struct prp_discovery_voprf_request_record_s {
    uint32_t relationship_generation;
    uint8_t request_id[PRP_DISCOVERY_VOPRF_REQUEST_ID_LEN];
    uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN];
} prp_discovery_voprf_request_record_t;

typedef struct prp_discovery_voprf_response_record_s {
    uint32_t relationship_generation;
    uint8_t request_id[PRP_DISCOVERY_VOPRF_REQUEST_ID_LEN];
    uint8_t evaluated_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN];
    uint8_t proof[PRP_DISCOVERY_VOPRF_PROOF_LEN];
} prp_discovery_voprf_response_record_t;

PRP_API int prp_discovery_voprf_available(void);
PRP_API int prp_discovery_voprf_private_input_encode(
    uint32_t relationship_generation, uint16_t rendezvous_identity_suite,
    const uint8_t *rendezvous_strong_id, size_t rendezvous_strong_id_len,
    uint16_t published_identity_suite, const uint8_t *published_strong_id,
    size_t published_strong_id_len, uint8_t *out, size_t out_len,
    size_t *written);

PRP_API int prp_discovery_voprf_keypair_generate(
    uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t public_key[PRP_DISCOVERY_VOPRF_ELEMENT_LEN]);
PRP_API int prp_discovery_voprf_keypair_generate_with_platform(
    uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t public_key[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    const struct prp_platform_s *platform);
PRP_API int prp_discovery_voprf_public_key(
    const uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t public_key[PRP_DISCOVERY_VOPRF_ELEMENT_LEN]);
PRP_API int prp_discovery_voprf_blind(const uint8_t *input,
    size_t input_len, uint8_t blind[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN]);
PRP_API int prp_discovery_voprf_blind_with_platform(const uint8_t *input,
    size_t input_len, uint8_t blind[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    const struct prp_platform_s *platform);
PRP_API int prp_discovery_voprf_blind_with_scalar(const uint8_t *input,
    size_t input_len,
    const uint8_t blind[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN]);
PRP_API int prp_discovery_voprf_evaluate(
    const uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    const uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    uint8_t evaluated_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    uint8_t proof[PRP_DISCOVERY_VOPRF_PROOF_LEN]);
PRP_API int prp_discovery_voprf_evaluate_with_platform(
    const uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    const uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    uint8_t evaluated_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    uint8_t proof[PRP_DISCOVERY_VOPRF_PROOF_LEN],
    const struct prp_platform_s *platform);
PRP_API int prp_discovery_voprf_finalize(const uint8_t *input,
    size_t input_len,
    const uint8_t blind[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    const uint8_t blinded_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    const uint8_t evaluated_element[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    const uint8_t proof[PRP_DISCOVERY_VOPRF_PROOF_LEN],
    const uint8_t public_key[PRP_DISCOVERY_VOPRF_ELEMENT_LEN],
    uint8_t output[PRP_DISCOVERY_VOPRF_OUTPUT_LEN]);
PRP_API int prp_discovery_voprf_evaluate_direct(const uint8_t *input,
    size_t input_len,
    const uint8_t secret_key[PRP_DISCOVERY_VOPRF_SCALAR_LEN],
    uint8_t output[PRP_DISCOVERY_VOPRF_OUTPUT_LEN]);
PRP_API int prp_discovery_voprf_lookup_token(
    const uint8_t output[PRP_DISCOVERY_VOPRF_OUTPUT_LEN],
    uint8_t token[PRP_DISCOVERY_VOPRF_TOKEN_LEN]);

PRP_API int prp_discovery_voprf_key_record_encode(
    const prp_discovery_voprf_key_record_t *record, uint8_t *out,
    size_t out_len);
PRP_API int prp_discovery_voprf_key_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_voprf_key_record_t *record);
PRP_API int prp_discovery_voprf_request_record_encode(
    const prp_discovery_voprf_request_record_t *record, uint8_t *out,
    size_t out_len);
PRP_API int prp_discovery_voprf_request_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_voprf_request_record_t *record);
PRP_API int prp_discovery_voprf_response_record_encode(
    const prp_discovery_voprf_response_record_t *record, uint8_t *out,
    size_t out_len);
PRP_API int prp_discovery_voprf_response_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_voprf_response_record_t *record);

#endif
