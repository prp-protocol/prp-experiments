#ifndef PRP_DISCOVERY_BLOOM_H
#define PRP_DISCOVERY_BLOOM_H

#include "prp_status.h"
#include "prp_hash.h"
#include "prp_content_id.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_BLOOM_VERSION 2u
#define PRP_DISCOVERY_BLOOM_HASH_COUNT 16u
#define PRP_DISCOVERY_BLOOM_STRONG_ID_MAX_LEN 64u
#define PRP_DISCOVERY_BLOOM_RECORD_HEADER_LEN 160u
#define PRP_DISCOVERY_BLOOM_FORWARD_HEADER_LEN 96u

#define PRP_DISCOVERY_BLOOM_PROFILE_8K 1u
#define PRP_DISCOVERY_BLOOM_PROFILE_32K 2u
#define PRP_DISCOVERY_BLOOM_PROFILE_128K 3u
#define PRP_DISCOVERY_BLOOM_PROFILE_512K 4u
#define PRP_DISCOVERY_BLOOM_PROFILE_2M 5u

#define PRP_DISCOVERY_BLOOM_RECORD_SNAPSHOT 1u
#define PRP_DISCOVERY_BLOOM_RECORD_DELTA 2u
#define PRP_DISCOVERY_BLOOM_INDEX_SHARDED_V4 1u
#define PRP_DISCOVERY_BLOOM_V4_MIN_BIT_ORDER 16u
#define PRP_DISCOVERY_BLOOM_V4_MAX_BIT_ORDER 63u
#define PRP_DISCOVERY_BLOOM_V4_MIN_SHARD_BIT_ORDER 16u
#define PRP_DISCOVERY_BLOOM_V4_MAX_SHARD_BIT_ORDER 18u
#define PRP_DISCOVERY_BLOOM_DENSITY_PPM_MAX 1000000u
#define PRP_DISCOVERY_BLOOM_V4_MANIFEST_HEADER_LEN 128u
#define PRP_DISCOVERY_BLOOM_V4_MANIFEST_KIND 1u
#define PRP_DISCOVERY_BLOOM_V4_SHARD_KIND 2u
#define PRP_DISCOVERY_BLOOM_V4_SHARD_HEADER_LEN 64u
#define PRP_DISCOVERY_BLOOM_V4_SHARD_F_EMPTY 0x0001u
#define PRP_DISCOVERY_BLOOM_V4_SHARD_F_MASK \
    PRP_DISCOVERY_BLOOM_V4_SHARD_F_EMPTY
#define PRP_DISCOVERY_BLOOM_V4_MAX_PROOF_DEPTH 47u
#define PRP_DISCOVERY_BLOOM_QUERY_VERSION 2u
#define PRP_DISCOVERY_BLOOM_QUERY_PROFILE_MICROSHARD_V2 1u
#define PRP_DISCOVERY_BLOOM_MICROSHARD_BYTES 16u
#define PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT 16u
#define PRP_DISCOVERY_BLOOM_QUERY_NONCE_LEN 16u
#define PRP_DISCOVERY_BLOOM_QUERY_COMMITMENT_LEN 32u
#define PRP_DISCOVERY_BLOOM_MICROSHARD_REQUEST_LEN 196u
#define PRP_DISCOVERY_BLOOM_MICROSHARD_RESPONSE_LEN 452u
#define PRP_DISCOVERY_BLOOM_REMOTE_VIEW_VERSION 2u
#define PRP_DISCOVERY_BLOOM_REMOTE_VIEW_KIND 1u
#define PRP_DISCOVERY_BLOOM_REMOTE_VIEW_HEADER_LEN 120u
#define PRP_DISCOVERY_INDEX_SHARDED_BLOOM_V4 1u
#define PRP_DISCOVERY_QUERY_MICROSHARD_V2 1u
#define PRP_DISCOVERY_PROFILE_SHARDED_V4_MICROSHARD_P16 1u
#define PRP_DISCOVERY_PROFILE_SHARDED_V4_MICROSHARD_P63 48u
#define PRP_DISCOVERY_PROFILE_SHARDED_V4_VOPRF_P16 0x0101u
#define PRP_DISCOVERY_PROFILE_SHARDED_V4_VOPRF_P63 0x0130u
#define PRP_DISCOVERY_TIMING_VERSION 1u
#define PRP_DISCOVERY_TIMING_RECORD_LEN 64u
#define PRP_DISCOVERY_TIMING_OFFER 1u
#define PRP_DISCOVERY_TIMING_AGREEMENT 2u

typedef struct prp_discovery_bloom_profile_s {
    uint8_t profile_id;
    uint32_t bitmap_bytes;
    uint32_t nominal_capacity;
    uint8_t hash_count;
} prp_discovery_bloom_profile_t;

typedef struct prp_discovery_bloom_v4_manifest_s {
    uint8_t filter_bit_order;
    uint8_t shard_bit_order;
    uint16_t origin_identity_suite;
    uint16_t lookup_index_profile;
    uint16_t origin_identity_proof_profile;
    uint64_t generation;
    uint64_t previous_generation;
    uint64_t valid_from;
    uint64_t valid_until;
    uint64_t set_bit_count;
    uint64_t shard_count;
    const uint8_t *origin_strong_id;
    uint16_t origin_strong_id_len;
    const uint8_t *shard_root;
    const uint8_t *origin_auth;
    uint16_t origin_auth_len;
    size_t authenticated_len;
} prp_discovery_bloom_v4_manifest_t;

typedef struct prp_discovery_bloom_v4_shard_s {
    uint16_t flags;
    uint16_t lookup_index_profile;
    uint8_t filter_bit_order;
    uint8_t shard_bit_order;
    uint64_t generation;
    uint64_t shard_index;
    uint64_t set_bit_count;
    const uint8_t *shard;
    uint32_t shard_len;
    const uint8_t *proof;
    uint8_t proof_depth;
} prp_discovery_bloom_v4_shard_t;

typedef struct prp_discovery_bloom_microshard_request_s {
    uint8_t query_profile;
    uint8_t filter_bit_order;
    uint16_t lookup_index_profile;
    uint64_t generation;
    const uint8_t *commitment;
    const uint8_t *query_nonce;
    uint64_t microshard_indexes[PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT];
} prp_discovery_bloom_microshard_request_t;

typedef struct prp_discovery_bloom_microshard_response_s {
    uint8_t query_profile;
    uint8_t filter_bit_order;
    uint16_t lookup_index_profile;
    uint64_t generation;
    const uint8_t *commitment;
    const uint8_t *query_nonce;
    uint64_t microshard_indexes[PRP_DISCOVERY_BLOOM_MICROSHARD_COUNT];
    const uint8_t *microshards;
} prp_discovery_bloom_microshard_response_t;

typedef struct prp_discovery_bloom_remote_view_s {
    uint32_t relationship_generation;
    uint16_t crypto_suite;
    uint16_t relationship_identity_proof_profile;
    uint16_t discovery_index_algorithm;
    uint16_t discovery_query_algorithm;
    uint16_t discovery_profile;
    uint16_t lookup_index_profile;
    uint16_t origin_identity_suite;
    uint16_t origin_identity_proof_profile;
    uint8_t filter_bit_order;
    uint8_t shard_bit_order;
    uint8_t query_record_profile;
    uint64_t filter_generation;
    uint64_t previous_filter_generation;
    uint64_t valid_from;
    uint64_t valid_until;
    uint64_t set_bit_count;
    uint64_t shard_count;
    const uint8_t *shard_root;
    const uint8_t *origin_strong_id;
    uint16_t origin_strong_id_len;
    const uint8_t *origin_auth;
    uint16_t origin_auth_len;
    const uint8_t *encoded;
    size_t authenticated_len;
    size_t encoded_len;
} prp_discovery_bloom_remote_view_t;

typedef struct prp_discovery_bloom_remote_view_policy_s {
    uint32_t relationship_generation;
    uint16_t crypto_suite;
    uint16_t relationship_identity_proof_profile;
    uint16_t discovery_index_algorithm;
    uint16_t discovery_query_algorithm;
    uint16_t discovery_profile;
    uint16_t lookup_index_profile;
    uint8_t minimum_filter_bit_order;
    uint8_t maximum_filter_bit_order;
    uint8_t minimum_shard_bit_order;
    uint8_t maximum_shard_bit_order;
    uint64_t maximum_resident_bytes;
    uint32_t maximum_density_ppm;
    const uint8_t *remote_strong_id;
    uint16_t remote_strong_id_len;
} prp_discovery_bloom_remote_view_policy_t;

typedef int (*prp_discovery_bloom_shard_read_fn)(void *context,
    uint64_t shard_index, const uint8_t **shard, size_t *shard_len);
typedef int (*prp_discovery_bloom_region_read_fn)(void *context,
    uint64_t byte_offset, uint8_t *region, size_t region_len);

typedef struct prp_discovery_bloom_record_s {
    uint8_t record_kind;
    uint8_t profile_id;
    uint64_t generation;
    uint64_t update_sequence;
    uint64_t created_at;
    uint64_t expires_at;
    uint64_t participant_count;
    uint32_t payload_set_bit_count;
    uint16_t origin_identity_suite;
    const uint8_t *origin_strong_id;
    uint8_t origin_strong_id_len;
    const uint8_t *bitmap;
    uint32_t bitmap_len;
    const uint8_t *origin_auth;
    uint16_t origin_auth_len;
    size_t authenticated_len;
} prp_discovery_bloom_record_t;

typedef struct prp_discovery_bloom_forward_s {
    uint64_t forwarded_at;
    uint64_t expires_at;
    uint16_t forwarder_identity_suite;
    const uint8_t *forwarder_strong_id;
    uint8_t forwarder_strong_id_len;
    const uint8_t *origin_record;
    uint32_t origin_record_len;
    const uint8_t *forwarder_auth;
    uint16_t forwarder_auth_len;
    size_t authenticated_len;
    prp_discovery_bloom_record_t decoded_origin;
} prp_discovery_bloom_forward_t;

typedef struct prp_discovery_timing_offer_s {
    uint64_t minimum_update_interval_ms;
    uint64_t maximum_update_interval_ms;
    uint64_t minimum_snapshot_interval_ms;
    uint64_t maximum_snapshot_interval_ms;
    uint64_t maximum_acceptable_age_ms;
    uint32_t maximum_buffered_deltas;
    uint64_t maximum_jitter_ms;
} prp_discovery_timing_offer_t;

typedef struct prp_discovery_timing_agreement_s {
    uint64_t update_interval_ms;
    uint64_t snapshot_interval_ms;
    uint64_t maximum_acceptable_age_ms;
    uint32_t maximum_buffered_deltas;
    uint64_t jitter_ms;
} prp_discovery_timing_agreement_t;

PRP_API int prp_discovery_bloom_profile_get(uint8_t profile_id,
    prp_discovery_bloom_profile_t *profile);
PRP_API int prp_discovery_bloom_indexes(uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len,
    uint8_t profile_id,
    uint32_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT]);
PRP_API int prp_discovery_bloom_add(uint8_t *bitmap, size_t bitmap_len,
    uint8_t profile_id, uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len);
PRP_API int prp_discovery_bloom_maybe_contains(const uint8_t *bitmap,
    size_t bitmap_len, uint8_t profile_id, uint16_t published_identity_suite,
    const uint8_t *published_strong_id, size_t published_strong_id_len,
    int *maybe_contains);
PRP_API uint32_t prp_discovery_bloom_popcount(const uint8_t *bitmap,
    size_t bitmap_len);
PRP_API int prp_discovery_bloom_v4_indexes(uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len, uint8_t filter_bit_order,
    uint64_t indexes[PRP_DISCOVERY_BLOOM_HASH_COUNT]);
PRP_API int prp_discovery_bloom_v4_add(uint8_t *bitmap, size_t bitmap_len,
    uint8_t filter_bit_order, uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len);
PRP_API int prp_discovery_bloom_v4_maybe_contains(const uint8_t *bitmap,
    size_t bitmap_len, uint8_t filter_bit_order, uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len, int *maybe_contains);
PRP_API int prp_discovery_bloom_v4_shard_add(uint8_t *shard,
    size_t shard_len, uint8_t filter_bit_order, uint8_t shard_bit_order,
    uint64_t shard_index, uint16_t lookup_index_profile,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len,
    uint32_t *new_set_bits);
PRP_API int prp_discovery_bloom_v4_sharded_maybe_contains(
    uint8_t filter_bit_order, uint8_t shard_bit_order,
    uint16_t lookup_index_profile, uint8_t target_kind,
    uint16_t identifier_profile, const uint8_t *identifier,
    size_t identifier_len,
    prp_discovery_bloom_shard_read_fn read_shard, void *read_context,
    int *maybe_contains);
PRP_API int prp_discovery_bloom_v4_fold(const uint8_t *source,
    size_t source_len, uint8_t source_bit_order, uint8_t *destination,
    size_t destination_len, uint8_t destination_bit_order);
PRP_API int prp_discovery_bloom_v4_compose(uint8_t *destination,
    size_t destination_len, uint8_t destination_bit_order,
    const uint8_t *candidate, size_t candidate_len,
    uint8_t candidate_bit_order, uint32_t maximum_density_ppm,
    uint64_t *result_set_bit_count);
PRP_API int prp_discovery_bloom_v4_shard_commitment(uint64_t generation,
    uint16_t lookup_index_profile, uint8_t filter_bit_order,
    uint8_t shard_bit_order, uint64_t shard_index,
    const uint8_t *shard, size_t shard_len,
    uint8_t commitment[PRP_HASH_BLAKE3_OUT_LEN]);
PRP_API uint64_t prp_discovery_bloom_popcount64(const uint8_t *bitmap,
    size_t bitmap_len);
PRP_API int prp_discovery_bloom_density_ppm(uint64_t set_bit_count,
    uint8_t filter_bit_order, uint32_t *density_ppm);
PRP_API int prp_discovery_bloom_v4_manifest_encode(
    const prp_discovery_bloom_v4_manifest_t *record, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_v4_manifest_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_v4_manifest_t *record);
PRP_API int prp_discovery_bloom_v4_manifest_admit(const uint8_t *data,
    size_t data_len, uint64_t now,
    prp_discovery_bloom_v4_manifest_t *record);
PRP_API int prp_discovery_bloom_v4_shard_encode(
    const prp_discovery_bloom_v4_shard_t *shard, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_v4_shard_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_v4_shard_t *shard);
PRP_API int prp_discovery_bloom_v4_shard_verify(
    const prp_discovery_bloom_v4_shard_t *shard,
    const uint8_t root[PRP_HASH_BLAKE3_OUT_LEN]);
PRP_API int prp_discovery_bloom_v4_sparse_root(uint8_t filter_bit_order,
    uint8_t shard_bit_order, const uint64_t *shard_indexes,
    const uint8_t *shard_commitments, size_t shard_count,
    uint8_t root[PRP_HASH_BLAKE3_OUT_LEN]);
PRP_API int prp_discovery_bloom_remote_view_encode(
    const prp_discovery_bloom_remote_view_t *view, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_remote_view_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_remote_view_t *view);
PRP_API int prp_discovery_bloom_remote_view_admit(const uint8_t *data,
    size_t data_len, uint64_t now,
    const prp_discovery_bloom_remote_view_policy_t *policy,
    prp_discovery_bloom_remote_view_t *view);
PRP_API int prp_discovery_bloom_remote_view_transition(
    const prp_discovery_bloom_remote_view_t *current,
    const prp_discovery_bloom_remote_view_t *candidate);
PRP_API int prp_discovery_bloom_microshard_request_encode(
    const prp_discovery_bloom_microshard_request_t *request, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_microshard_request_decode(
    const uint8_t *data, size_t data_len,
    prp_discovery_bloom_microshard_request_t *request);
PRP_API int prp_discovery_bloom_microshard_response_build(
    const prp_discovery_bloom_microshard_request_t *request,
    const uint8_t *bitmap, size_t bitmap_len, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_microshard_response_build_sparse(
    const prp_discovery_bloom_microshard_request_t *request,
    prp_discovery_bloom_region_read_fn read_region, void *read_context,
    uint8_t *out, size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_microshard_response_decode(
    const uint8_t *data, size_t data_len,
    prp_discovery_bloom_microshard_response_t *response);
PRP_API int prp_discovery_bloom_microshard_response_verify(
    const prp_discovery_bloom_microshard_request_t *request,
    const prp_discovery_bloom_microshard_response_t *response);
PRP_API int prp_discovery_bloom_microshard_maybe_contains(
    const prp_discovery_bloom_microshard_response_t *response,
    uint8_t target_kind, uint16_t identifier_profile,
    const uint8_t *identifier, size_t identifier_len, int *maybe_contains);

PRP_API int prp_discovery_bloom_record_encode(
    const prp_discovery_bloom_record_t *record, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_record_t *record);
PRP_API int prp_discovery_bloom_forward_encode(
    const prp_discovery_bloom_forward_t *forward, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_bloom_forward_decode(const uint8_t *data,
    size_t data_len, prp_discovery_bloom_forward_t *forward);
PRP_API int prp_discovery_timing_offer_encode(
    const prp_discovery_timing_offer_t *offer, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_timing_offer_decode(const uint8_t *data,
    size_t data_len, prp_discovery_timing_offer_t *offer);
PRP_API int prp_discovery_timing_agreement_encode(
    const prp_discovery_timing_agreement_t *agreement, uint8_t *out,
    size_t out_len, size_t *written);
PRP_API int prp_discovery_timing_agreement_decode(const uint8_t *data,
    size_t data_len, prp_discovery_timing_agreement_t *agreement);
#endif
