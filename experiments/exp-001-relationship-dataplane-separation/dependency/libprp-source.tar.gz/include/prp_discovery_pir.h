#ifndef PRP_DISCOVERY_PIR_H
#define PRP_DISCOVERY_PIR_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_DISCOVERY_PIR_VERSION 1u
#define PRP_DISCOVERY_PIR_HEADER_LEN 128u
#define PRP_DISCOVERY_PIR_OPERATION_ID_LEN 16u
#define PRP_DISCOVERY_PIR_COMMITMENT_LEN 32u

#define PRP_DISCOVERY_PIR_KIND_PARAMETERS 1u
#define PRP_DISCOVERY_PIR_KIND_QUERY 2u
#define PRP_DISCOVERY_PIR_KIND_RESPONSE 3u
#define PRP_DISCOVERY_PIR_KIND_CANCEL 4u

#define PRP_DISCOVERY_PIR_F_START 0x0001u
#define PRP_DISCOVERY_PIR_F_END 0x0002u
#define PRP_DISCOVERY_PIR_F_MASK \
    (PRP_DISCOVERY_PIR_F_START | PRP_DISCOVERY_PIR_F_END)

#define PRP_DISCOVERY_PIR_PROVIDER_ABI_VERSION 1u

#define PRP_DISCOVERY_QUERY_SPIRAL 2u
#define PRP_DISCOVERY_QUERY_YPIR 3u
#define PRP_DISCOVERY_PROFILE_SPIRAL_MIN 0x1000u
#define PRP_DISCOVERY_PROFILE_SPIRAL_MAX 0x1fffu
#define PRP_DISCOVERY_PROFILE_YPIR_MIN 0x2000u
#define PRP_DISCOVERY_PROFILE_YPIR_MAX 0x2fffu

typedef struct prp_discovery_pir_record_s {
    uint8_t kind;
    uint16_t flags;
    uint32_t relationship_generation;
    uint16_t query_algorithm;
    uint16_t profile;
    uint64_t filter_generation;
    uint8_t filter_commitment[PRP_DISCOVERY_PIR_COMMITMENT_LEN];
    uint8_t operation_id[PRP_DISCOVERY_PIR_OPERATION_ID_LEN];
    uint64_t total_object_len;
    uint64_t chunk_offset;
    uint8_t object_commitment[PRP_DISCOVERY_PIR_COMMITMENT_LEN];
    const uint8_t *chunk;
    uint32_t chunk_len;
} prp_discovery_pir_record_t;

typedef enum prp_discovery_pir_operation_e {
    PRP_DISCOVERY_PIR_OP_SERVER_PREPARE = 1,
    PRP_DISCOVERY_PIR_OP_CLIENT_PREPARE = 2,
    PRP_DISCOVERY_PIR_OP_QUERY_CREATE = 3,
    PRP_DISCOVERY_PIR_OP_ANSWER = 4,
    PRP_DISCOVERY_PIR_OP_EXTRACT = 5
} prp_discovery_pir_operation_t;

typedef struct prp_discovery_pir_profile_info_s {
    uint16_t query_algorithm;
    uint16_t profile;
    uint16_t security_bits;
    uint16_t flags;
    uint64_t maximum_database_bits;
    uint64_t maximum_query_bytes;
    uint64_t maximum_response_bytes;
    uint64_t maximum_client_state_bytes;
    uint64_t maximum_server_state_bytes;
} prp_discovery_pir_profile_info_t;

typedef struct prp_discovery_pir_request_s {
    uint32_t abi_version;
    uint32_t struct_size;
    prp_discovery_pir_operation_t operation;
    uint16_t query_algorithm;
    uint16_t profile;
    uint32_t relationship_generation;
    uint64_t filter_generation;
    const uint8_t *filter_commitment;
    const uint64_t *indexes;
    size_t index_count;
    const uint8_t *input;
    size_t input_len;
    const uint8_t *auxiliary;
    size_t auxiliary_len;
    uint8_t *output;
    size_t output_capacity;
} prp_discovery_pir_request_t;

typedef struct prp_discovery_pir_completion_s {
    uint64_t operation_token;
    int status;
    uint64_t provider_state;
    size_t output_len;
    size_t required_output_len;
} prp_discovery_pir_completion_t;

typedef int (*prp_discovery_pir_profile_get_fn)(void *context,
    uint16_t query_algorithm, uint16_t profile,
    prp_discovery_pir_profile_info_t *info);
typedef int (*prp_discovery_pir_begin_fn)(void *context,
    const prp_discovery_pir_request_t *request, uint64_t *operation_token);
typedef int (*prp_discovery_pir_poll_fn)(void *context,
    uint64_t operation_token, prp_discovery_pir_completion_t *completion);
typedef int (*prp_discovery_pir_step_fn)(void *context,
    uint32_t work_budget);
typedef int (*prp_discovery_pir_cancel_fn)(void *context,
    uint64_t operation_token);

typedef struct prp_discovery_pir_provider_s {
    uint32_t abi_version;
    uint32_t struct_size;
    void *context;
    prp_discovery_pir_profile_get_fn profile_get;
    prp_discovery_pir_begin_fn begin;
    prp_discovery_pir_poll_fn poll;
    prp_discovery_pir_step_fn step;
    prp_discovery_pir_cancel_fn cancel;
} prp_discovery_pir_provider_t;

PRP_API int prp_discovery_pir_record_encode(
    const prp_discovery_pir_record_t *record, uint8_t *out, size_t out_len,
    size_t *written);
PRP_API int prp_discovery_pir_record_decode(const uint8_t *data,
    size_t data_len, prp_discovery_pir_record_t *record);
PRP_API int prp_discovery_pir_object_verify(
    const prp_discovery_pir_record_t *record, const uint8_t *object,
    size_t object_len);
PRP_API int prp_discovery_pir_profile_registered(uint16_t query_algorithm,
    uint16_t profile);
PRP_API int prp_discovery_pir_provider_validate(
    const prp_discovery_pir_provider_t *provider);
PRP_API int prp_discovery_pir_profile_available(
    const prp_discovery_pir_provider_t *provider, uint16_t query_algorithm,
    uint16_t profile, prp_discovery_pir_profile_info_t *info);

#endif
