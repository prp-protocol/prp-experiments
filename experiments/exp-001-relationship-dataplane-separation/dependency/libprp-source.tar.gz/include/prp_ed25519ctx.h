#ifndef PRP_ED25519CTX_H
#define PRP_ED25519CTX_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_ED25519CTX_PUBLIC_KEY_LEN 32u
#define PRP_ED25519CTX_PRIVATE_KEY_LEN 64u
#define PRP_ED25519CTX_SIGNATURE_LEN 64u
#define PRP_ED25519CTX_SEED_LEN 32u

typedef struct prp_ed25519ctx_keypair_s prp_ed25519ctx_keypair_t;
struct prp_platform_s;

PRP_API prp_status_t prp_ed25519ctx_keypair_generate(
    prp_ed25519ctx_keypair_t **keypair);
PRP_API prp_status_t prp_ed25519ctx_keypair_generate_with_platform(
    prp_ed25519ctx_keypair_t **keypair,
    const struct prp_platform_s *platform);
PRP_API prp_status_t prp_ed25519ctx_keypair_from_seed(
    prp_ed25519ctx_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519CTX_SEED_LEN]);

/* Compatibility spelling; new callers should use keypair_from_seed. */
PRP_API prp_status_t prp_ed25519ctx_keypair_derand(
    prp_ed25519ctx_keypair_t **keypair,
    const uint8_t seed[PRP_ED25519CTX_SEED_LEN]);
PRP_API prp_status_t prp_ed25519ctx_keypair_import(
    prp_ed25519ctx_keypair_t **keypair, const uint8_t *private_key,
    size_t private_key_len);
PRP_API prp_status_t prp_ed25519ctx_public_key_export(
    const prp_ed25519ctx_keypair_t *keypair, uint8_t *public_key,
    size_t public_key_size, size_t *written);

/*
 * Exceptional raw export for explicitly authorized interchange.
 * The caller owns and must erase the output. This is not a backup container.
 */
PRP_API prp_status_t prp_ed25519ctx_private_key_export(
    const prp_ed25519ctx_keypair_t *keypair, uint8_t *private_key,
    size_t private_key_size, size_t *written);

/*
 * Signs and verifies with RFC 8032 Ed25519ctx and the suite-bound context
 * "PRP-HS2-v4". The context is deliberately not caller-selectable.
 */
PRP_API prp_status_t prp_ed25519ctx_sign(
    const prp_ed25519ctx_keypair_t *keypair, const uint8_t *message,
    size_t message_len, uint8_t *signature, size_t signature_size,
    size_t *written);
PRP_API prp_status_t prp_ed25519ctx_verify(
    const uint8_t public_key[PRP_ED25519CTX_PUBLIC_KEY_LEN],
    const uint8_t signature[PRP_ED25519CTX_SIGNATURE_LEN],
    const uint8_t *message, size_t message_len);
PRP_API void prp_ed25519ctx_keypair_destroy(
    prp_ed25519ctx_keypair_t *keypair);

#ifdef __cplusplus
}
#endif

#endif
