#ifndef PRP_RANDOM_H
#define PRP_RANDOM_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct prp_platform_s;

/* Uses the entropy source owned by the selected native libprp backend. */
PRP_API prp_status_t prp_random_bytes(uint8_t *output, size_t output_len);

/* Uses the caller's platform entropy source, including freestanding hosts. */
PRP_API prp_status_t prp_random_bytes_with_platform(
    uint8_t *output, size_t output_len,
    const struct prp_platform_s *platform);

#ifdef __cplusplus
}
#endif

#endif
