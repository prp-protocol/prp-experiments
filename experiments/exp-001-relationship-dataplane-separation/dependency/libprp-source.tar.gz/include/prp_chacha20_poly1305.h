#ifndef PRP_CHACHA20_POLY1305_H
#define PRP_CHACHA20_POLY1305_H

#include "prp_export.h"
#include "prp_status.h"

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define PRP_CHACHA20_POLY1305_KEY_LEN 32u
#define PRP_CHACHA20_POLY1305_NONCE_LEN 12u
#define PRP_CHACHA20_POLY1305_TAG_LEN 16u

/*
 * Backend-independent RFC 8439 ChaCha20-Poly1305 with a detached tag.
 * Framing, nonce allocation, key custody and persistence remain caller-owned.
 * On an authentication or backend failure, open erases its output buffer.
 */
PRP_API prp_status_t prp_chacha20_poly1305_seal(
    const uint8_t key[PRP_CHACHA20_POLY1305_KEY_LEN],
    const uint8_t nonce[PRP_CHACHA20_POLY1305_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *plaintext, size_t plaintext_len,
    uint8_t *ciphertext, size_t ciphertext_size,
    uint8_t tag[PRP_CHACHA20_POLY1305_TAG_LEN], size_t *written);

PRP_API prp_status_t prp_chacha20_poly1305_open(
    const uint8_t key[PRP_CHACHA20_POLY1305_KEY_LEN],
    const uint8_t nonce[PRP_CHACHA20_POLY1305_NONCE_LEN],
    const uint8_t *associated_data, size_t associated_data_len,
    const uint8_t *ciphertext, size_t ciphertext_len,
    const uint8_t tag[PRP_CHACHA20_POLY1305_TAG_LEN],
    uint8_t *plaintext, size_t plaintext_size, size_t *written);

#ifdef __cplusplus
}
#endif

#endif
