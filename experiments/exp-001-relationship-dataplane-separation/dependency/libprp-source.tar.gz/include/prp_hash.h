#ifndef PRP_HASH_H
#define PRP_HASH_H

#include "prp_export.h"

#include <stddef.h>
#include <stdint.h>

#define PRP_HASH_BLAKE3_OUT_LEN 32u
#define PRP_SELF_CERT_ID_PROFILE_BLAKE3 0x01u
#define PRP_SELF_CERT_ID_PROFILE_BLAKE3_512 0x04u
#define PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3 0x01u
#define PRP_SELF_CERT_ID_PROOF_ED25519CTX 0x02u
#define PRP_SELF_CERT_ID_PROOF_MLDSA65 0x03u
#define PRP_SELF_CERT_ID_PROOF_MLDSA87 0x04u
#define PRP_SELF_CERT_ID_PROOF_ED25519_BLAKE3_MLDSA87 0x05u
#define PRP_SELF_CERT_ID_MAX_LEN 64u
#define PRP_ID_PROOF_ED25519_PUBLIC_KEY_LEN 32u
#define PRP_ID_PROOF_MLDSA65_PUBLIC_KEY_LEN 1952u
#define PRP_ID_PROOF_MLDSA87_PUBLIC_KEY_LEN 2592u
#define PRP_ID_PROOF_HYBRID_PUBLIC_KEY_LEN 2624u
#define PRP_ID_PROOF_ED25519_SIGNATURE_LEN 64u
#define PRP_ID_PROOF_MLDSA65_SIGNATURE_LEN 3309u
#define PRP_ID_PROOF_MLDSA87_SIGNATURE_LEN 4627u
#define PRP_ID_PROOF_HYBRID_SIGNATURE_LEN 4691u

/*
 * Public one-shot BLAKE3 helpers.
 *
 * libprp owns the vendored BLAKE3 implementation. Consumers that need PRP
 * domain-separated hashes should call these helpers instead of including or
 * linking private third_party/blake3 headers directly.
 */
PRP_API int prp_hash_blake3(const uint8_t *input, size_t input_len,
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN]);
PRP_API int prp_hash_blake3_concat(const uint8_t *first, size_t first_len,
    const uint8_t *second, size_t second_len,
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN]);

/* Canonical BLAKE3 derive-key mode used by suite-bound PRP KDF requests. */
PRP_API int prp_hash_blake3_derive_key(const uint8_t *context,
    size_t context_len, const uint8_t *key, size_t key_len,
    const uint8_t *input, size_t input_len,
    uint8_t out[PRP_HASH_BLAKE3_OUT_LEN]);

/* Computes the profile-selected self-certifying id used by PRP HS2. */
PRP_API int prp_self_cert_id_compute(uint8_t identity_profile,
    uint8_t identity_proof_profile, const uint8_t *public_key,
    size_t public_key_len, uint8_t *out, size_t out_size, size_t *written);
/* Computes HASH("PRP-STRONG-ID-v4" || identity_suite_be16 || public_key). */
PRP_API int prp_wire_v4_strong_id_compute(uint16_t identity_suite,
    const uint8_t *public_key, size_t public_key_len,
    uint8_t *out, size_t out_size, size_t *written);
PRP_API size_t prp_identity_proof_public_key_len(uint8_t proof_profile);
PRP_API size_t prp_identity_proof_signature_len(uint8_t proof_profile);
PRP_API int prp_identity_proof_verify(uint8_t proof_profile,
    const uint8_t *public_key, size_t public_key_len,
    const uint8_t *signature, size_t signature_len,
    const uint8_t *message, size_t message_len,
    const uint8_t *context, size_t context_len);

#endif
