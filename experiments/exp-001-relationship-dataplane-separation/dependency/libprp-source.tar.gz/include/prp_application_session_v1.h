#ifndef PRP_APPLICATION_SESSION_V1_H
#define PRP_APPLICATION_SESSION_V1_H
#include <stdint.h>
#include "prp_export.h"
/* Experimental API 1. Separate from the stateless codec and compatibility ABI.
 * Handles are process-local, non-reused and non-persistable. All calls on this
 * registry must be serialized by one session owner (also across JS contexts).
 * No API imports C, traffic keys, a verified boolean, or an existing session.
 * A fresh HS2 is mandatory. The platform must supply 116 fresh CSPRNG bytes.
 * Public-key pins express caller trust policy, NOT social author delegation.
 * Local signing is external: sign the exact returned HS2 prefix, then submit
 * the proof. The provider verifies it and owns ephemeral/KEM secrets and KDF.
 * This API does not implement consumer durable commit or POST activation. */
#ifdef __cplusplus
extern "C" {
#endif
PRP_API uint64_t prp_app_session_v1_create(uint32_t role, uint32_t suite,
    uint32_t local_identity, const uint8_t *local_key, uint32_t local_len,
    uint32_t peer_identity, const uint8_t *peer_key, uint32_t peer_len,
    const uint8_t entropy[116], uint64_t monotonic_ms);
/* M1 prefix on initiator; responder first calls peer_hs2(M1), then prefix.
 * Positive return is byte length; negative is fail-closed. */
PRP_API int32_t prp_app_session_v1_prefix(uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_proof(uint64_t, const uint8_t *, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_peer_hs2(uint64_t, const uint8_t *, uint32_t, uint64_t);
/* offer input is canonical OPEN_APP, with C all zero: C and opener are
 * provider-derived, not authority supplied by the caller. Output is AOP. */
PRP_API int32_t prp_app_session_v1_offer(uint64_t, const uint8_t *, uint32_t,
    uint64_t, uint8_t *, uint32_t);
/* receive: positive AOP cached reply; 0 no reply; -2 new offer, available via
 * pending(); -1 reject. Outgoing CONFIRM requires handed() after transport
 * handoff. A caller claiming handoff cannot forge the remote confirmation. */
PRP_API int32_t prp_app_session_v1_receive(uint64_t, const uint8_t *, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_pending(uint64_t, uint64_t, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_decide(uint64_t, uint64_t, uint32_t,
    uint32_t alias, uint32_t generation, uint32_t reason, uint64_t,
    uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_handed(uint64_t, uint64_t, uint64_t);
/* Bounded exact-body retry, always a fresh AOP nonce; never extends deadline. */
PRP_API int32_t prp_app_session_v1_retry(uint64_t, uint64_t, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_cancel(uint64_t, uint64_t, uint32_t, uint64_t);
PRP_API int32_t prp_app_session_v1_close(uint64_t, uint32_t, uint32_t, uint64_t);
/* Returns the exact canonical ACCEPT only while currently admitted. This is
 * provider agreement evidence, NOT a consumer ApplicationBinding capability. */
PRP_API int32_t prp_app_session_v1_agreement(uint64_t, uint32_t, uint32_t,
    uint64_t, uint8_t *, uint32_t);
/* Exact live ACTIVE attempt/opener lookup; returns 113 copied ACCEPT bytes.
 * Negative return leaves output unchanged. Does not allocate, activate, renew,
 * or issue a public capability. Retry-cache expiry is not an ACTIVE lease.
 * Same registry guard/monotonic invalidation order as tuple lookup. */
PRP_API int32_t prp_app_session_v1_agreement_for_attempt(uint64_t handle,
    uint64_t attempt, uint32_t opener, uint64_t monotonic_ms,
    uint8_t *out, uint32_t capacity);
/* Unified opaque E2E carriage for the same session/nonce/alias ledger.
 * seal_item accepts canonical compatibility controls/data or admitted bound
 * data, never caller-made ApplicationAgreement controls. Compatibility items
 * have no application authority.
 * dispatch returns a copied event: one tag byte followed by bytes:
 * 0=no event; 1=AOP reply; 2=canonical pending OPEN_APP; 3=bound data
 * (113-byte ACCEPT followed by the canonical E2E item); 4=compatibility item.
 * All lengths are the positive return value, including tag. cap must be
 * >=65649. This is transport evidence, not durable commit/application delivery;
 * consumer owns ordered/reliable buffering, fragment assembly and lifecycle.
 * Ciphertext must go through dispatch once, not receive-then-fallback sniffing.
 * Early/closed/unknown alias data is consumed and rejected, never buffered. */
PRP_API int32_t prp_app_session_v1_seal_item(uint64_t, const uint8_t *, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_dispatch(uint64_t, const uint8_t *, uint32_t,
    uint64_t, uint8_t *, uint32_t);
PRP_API int32_t prp_app_session_v1_invalidate(uint64_t);
PRP_API uint32_t prp_app_session_v1_memory_bytes(void);
#ifdef __cplusplus
}
#endif
#endif
