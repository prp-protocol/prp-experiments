#include <prp_platform.h>
#include <prp_platform_sealed_custody.h>

#include <stddef.h>
#include <stdint.h>

#define ABI_ASSERT(name, condition) \
    typedef char prp_abi_assert_##name[(condition) ? 1 : -1]

ABI_ASSERT(platform_version, PRP_PLATFORM_ABI_VERSION == 5U);
ABI_ASSERT(custody_version, PRP_PLATFORM_CUSTODY_ABI_VERSION == 2U);
ABI_ASSERT(sealed_config_version,
    PRP_PLATFORM_SEALED_CUSTODY_CONFIG_VERSION == 1U);
ABI_ASSERT(key_id_len, PRP_PLATFORM_KEY_ID_LEN == 32U);
ABI_ASSERT(custody_enum_width,
    sizeof(prp_platform_custody_operation_t) == sizeof(uint32_t));

ABI_ASSERT(op_create, PRP_CUSTODY_OP_CREATE == 1);
ABI_ASSERT(op_import, PRP_CUSTODY_OP_IMPORT == 2);
ABI_ASSERT(op_open, PRP_CUSTODY_OP_OPEN == 3);
ABI_ASSERT(op_close, PRP_CUSTODY_OP_CLOSE == 4);
ABI_ASSERT(op_info, PRP_CUSTODY_OP_INFO == 5);
ABI_ASSERT(op_public_export, PRP_CUSTODY_OP_PUBLIC_EXPORT == 6);
ABI_ASSERT(op_private_export, PRP_CUSTODY_OP_PRIVATE_EXPORT == 7);
ABI_ASSERT(op_delete, PRP_CUSTODY_OP_DELETE == 10);
ABI_ASSERT(op_sign, PRP_CUSTODY_OP_SIGN == 11);
ABI_ASSERT(op_decapsulate, PRP_CUSTODY_OP_DECAPSULATE == 12);
ABI_ASSERT(op_key_agreement, PRP_CUSTODY_OP_KEY_AGREEMENT == 13);
ABI_ASSERT(operation_mask_reserved,
    (PRP_CUSTODY_OPERATION_MASK &
     (PRP_CUSTODY_OPERATION_BIT(8) | PRP_CUSTODY_OPERATION_BIT(9))) == 0U);

ABI_ASSERT(capability, PRP_PLATFORM_CAP_KEY_CUSTODY == (1U << 9));
ABI_ASSERT(handle_flag,
    PRP_PLATFORM_REQUEST_F_CUSTODY_KEY_HANDLE == (1U << 1));
ABI_ASSERT(private_export_flag,
    PRP_CUSTODY_REQUEST_F_AUTHORIZE_PRIVATE_EXPORT == (1U << 0));
ABI_ASSERT(purpose_sign, PRP_CUSTODY_PURPOSE_SIGN == (1U << 0));
ABI_ASSERT(purpose_decapsulate,
    PRP_CUSTODY_PURPOSE_DECAPSULATE == (1U << 1));
ABI_ASSERT(purpose_key_agreement,
    PRP_CUSTODY_PURPOSE_KEY_AGREEMENT == (1U << 2));
ABI_ASSERT(property_exportable,
    PRP_CUSTODY_PROPERTY_PRIVATE_EXPORTABLE == (UINT64_C(1) << 0));
ABI_ASSERT(property_nonexportable,
    PRP_CUSTODY_PROPERTY_PRIVATE_NONEXPORTABLE == (UINT64_C(1) << 1));
ABI_ASSERT(property_os_protected,
    PRP_CUSTODY_PROPERTY_OS_PROTECTED_AT_REST == (UINT64_C(1) << 2));
ABI_ASSERT(property_hardware,
    PRP_CUSTODY_PROPERTY_HARDWARE_OPERATION == (UINT64_C(1) << 3));
ABI_ASSERT(property_user_auth,
    PRP_CUSTODY_PROPERTY_USER_AUTHENTICATION == (UINT64_C(1) << 4));
ABI_ASSERT(property_atomic,
    PRP_CUSTODY_PROPERTY_ATOMIC_DURABLE == (UINT64_C(1) << 5));
ABI_ASSERT(property_attested,
    PRP_CUSTODY_PROPERTY_ATTESTED == (UINT64_C(1) << 6));

ABI_ASSERT(query_suite,
    offsetof(prp_platform_custody_query_t, negotiated_suite) == 8U);
ABI_ASSERT(query_operation,
    offsetof(prp_platform_custody_query_t, operation) == 12U);

ABI_ASSERT(capabilities_operations,
    offsetof(prp_platform_custody_capabilities_t, operations) == 8U);
ABI_ASSERT(capabilities_properties,
    offsetof(prp_platform_custody_capabilities_t, properties) == 16U);
ABI_ASSERT(capabilities_components,
    offsetof(prp_platform_custody_capabilities_t, max_components) == 24U);

ABI_ASSERT(request_key_id,
    offsetof(prp_platform_custody_request_t, key_id) == 16U);
ABI_ASSERT(request_suite,
    offsetof(prp_platform_custody_request_t, negotiated_suite) == 48U);
ABI_ASSERT(request_properties,
    offsetof(prp_platform_custody_request_t, required_properties) == 56U);
ABI_ASSERT(request_handle,
    offsetof(prp_platform_custody_request_t, key_handle) == 64U);
ABI_ASSERT(request_input,
    offsetof(prp_platform_custody_request_t, input) == 72U);

ABI_ASSERT(component_suite,
    offsetof(prp_platform_custody_component_t, negotiated_suite) == 8U);
ABI_ASSERT(component_properties,
    offsetof(prp_platform_custody_component_t, actual_properties) == 16U);
ABI_ASSERT(component_public_offset,
    offsetof(prp_platform_custody_component_t, public_key_offset) == 24U);

ABI_ASSERT(result_key_id,
    offsetof(prp_platform_custody_result_t, key_id) == 8U);
ABI_ASSERT(result_suite,
    offsetof(prp_platform_custody_result_t, negotiated_suite) == 40U);
ABI_ASSERT(result_handle,
    offsetof(prp_platform_custody_result_t, key_handle) == 48U);
ABI_ASSERT(result_generation,
    offsetof(prp_platform_custody_result_t, generation) == 64U);
ABI_ASSERT(result_components,
    offsetof(prp_platform_custody_result_t, component_count) == 72U);

#if UINTPTR_MAX == UINT64_MAX
ABI_ASSERT(sealed_config_size,
    sizeof(prp_platform_sealed_custody_config_t) == 88U);
ABI_ASSERT(sealed_config_context,
    offsetof(prp_platform_sealed_custody_config_t, context) == 16U);
ABI_ASSERT(sealed_config_unprotect,
    offsetof(prp_platform_sealed_custody_config_t, unprotect) == 80U);
ABI_ASSERT(query_size, sizeof(prp_platform_custody_query_t) == 32U);
ABI_ASSERT(query_properties,
    offsetof(prp_platform_custody_query_t, required_properties) == 24U);
ABI_ASSERT(capabilities_size,
    sizeof(prp_platform_custody_capabilities_t) == 32U);
ABI_ASSERT(request_size, sizeof(prp_platform_custody_request_t) == 136U);
ABI_ASSERT(request_public_output,
    offsetof(prp_platform_custody_request_t, public_output) == 88U);
ABI_ASSERT(request_components,
    offsetof(prp_platform_custody_request_t, components) == 120U);
ABI_ASSERT(component_size,
    sizeof(prp_platform_custody_component_t) == 40U);
ABI_ASSERT(result_size, sizeof(prp_platform_custody_result_t) == 96U);
ABI_ASSERT(result_public_len,
    offsetof(prp_platform_custody_result_t, public_output_len) == 80U);
ABI_ASSERT(platform_query,
    offsetof(prp_platform_t, custody_query) == 136U);
ABI_ASSERT(platform_execute,
    offsetof(prp_platform_t, custody_execute) == 144U);
ABI_ASSERT(platform_v5_size, PRP_PLATFORM_ABI_V5_STRUCT_SIZE == 152U);
#elif UINTPTR_MAX == UINT32_MAX
ABI_ASSERT(sealed_config_size,
    sizeof(prp_platform_sealed_custody_config_t) == 52U ||
    sizeof(prp_platform_sealed_custody_config_t) == 56U);
ABI_ASSERT(sealed_config_context,
    offsetof(prp_platform_sealed_custody_config_t, context) == 16U);
ABI_ASSERT(sealed_config_unprotect,
    offsetof(prp_platform_sealed_custody_config_t, unprotect) == 48U);
/* Android ARM aligns uint64_t to 8; Android x86 aligns it to 4. */
ABI_ASSERT(query_size,
    sizeof(prp_platform_custody_query_t) == 28U ||
    sizeof(prp_platform_custody_query_t) == 32U);
ABI_ASSERT(query_properties,
    offsetof(prp_platform_custody_query_t, required_properties) == 20U ||
    offsetof(prp_platform_custody_query_t, required_properties) == 24U);
ABI_ASSERT(capabilities_size,
    sizeof(prp_platform_custody_capabilities_t) == 28U ||
    sizeof(prp_platform_custody_capabilities_t) == 32U);
ABI_ASSERT(request_size, sizeof(prp_platform_custody_request_t) == 104U);
ABI_ASSERT(request_public_output,
    offsetof(prp_platform_custody_request_t, public_output) == 80U);
ABI_ASSERT(request_components,
    offsetof(prp_platform_custody_request_t, components) == 96U);
ABI_ASSERT(component_size,
    sizeof(prp_platform_custody_component_t) == 32U);
ABI_ASSERT(result_size,
    sizeof(prp_platform_custody_result_t) == 84U ||
    sizeof(prp_platform_custody_result_t) == 88U);
ABI_ASSERT(result_public_len,
    offsetof(prp_platform_custody_result_t, public_output_len) == 76U);
ABI_ASSERT(platform_query,
    offsetof(prp_platform_t, custody_query) == 76U);
ABI_ASSERT(platform_execute,
    offsetof(prp_platform_t, custody_execute) == 80U);
ABI_ASSERT(platform_v5_size, PRP_PLATFORM_ABI_V5_STRUCT_SIZE == 84U);
#else
#error "unsupported pointer width for the custody ABI contract"
#endif

void prp_key_custody_abi_check_signatures(void)
{
    int (*query_fn)(const prp_platform_t *,
        const prp_platform_custody_query_t *,
        prp_platform_custody_capabilities_t *) = prp_platform_custody_query;
    int (*execute_fn)(const prp_platform_t *,
        const prp_platform_custody_request_t *,
        prp_platform_custody_result_t *) = prp_platform_custody_execute;
    int (*sealed_init_fn)(prp_platform_t *,
        const prp_platform_sealed_custody_config_t *) =
        prp_platform_sealed_custody_initialize;
    void (*sealed_destroy_fn)(prp_platform_t *) =
        prp_platform_sealed_custody_destroy;
    int (*android_init_fn)(prp_platform_t *,
        const prp_platform_sealed_custody_config_t *) =
        prp_platform_android_custody_initialize;

    (void)query_fn;
    (void)execute_fn;
    (void)sealed_init_fn;
    (void)sealed_destroy_fn;
    (void)android_init_fn;
}

#if defined(PRP_CUSTODY_ABI_CONTRACT_EXECUTABLE)
int main(void)
{
    prp_key_custody_abi_check_signatures();
    return 0;
}
#endif
