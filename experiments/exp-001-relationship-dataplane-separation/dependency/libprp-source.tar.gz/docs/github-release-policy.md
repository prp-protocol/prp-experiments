# GitHub release repository

The public GitHub repository is `prp/libprp`. Its contents are defined by an
explicit release allowlist.

## Freeze rule

Each public version is materialized from one clean, immutable source commit and
contains only the paths admitted by `metadata/github-export-policy-v1.tsv`, plus
the generated public API PDF, `RELEASE.json` and `SHA256SUMS`. The source commit
identifier in `RELEASE.json` binds the release tree to reviewed source.

English is the canonical language of every first-party path in the repository,
including documentation, build messages, diagnostics and source
code comments. Vendored third-party material remains byte-faithful to its
upstream source and is not rewritten merely to enforce project terminology.
`make check-english-release` rejects known non-English prose markers in the
first-party release surface; this mechanical gate supplements, rather than
replaces, editorial review.

The exporter admits:

- product headers and implementation;
- exact public interface snapshots required for an isolated build;
- build, package and platform integration definitions;
- current public documentation and machine-readable API/security metadata;
- qualification tests, public vectors and fuzz smoke inputs;
- exact third-party source, notices and licenses required by the build; and
- tools needed to reproduce packages, documentation and inventories.

It excludes local configuration, private operational artifacts, temporary
evidence, internal formal-analysis harnesses and records, non-release reference
implementations and build products other than the explicitly generated API
PDF. The allowlist checker classifies every
tracked path as included or explicitly excluded and refuses ambiguous,
unclassified, symlinked or forbidden content.

## Materialization

From a clean source checkout with the API PDF toolchain available:

```sh
make github-export-check
make github-export
```

The default output is `build/github-export/prp-libprp`. The exporter refuses a
non-empty destination; it never deletes or overwrites an earlier export. It
reads admitted source bytes from the selected source commit, copies the
validated PDF and records SHA-256 values for every exported file.

Publication is a separate administrative operation. Before publication, the
operator verifies `SHA256SUMS`, reviews `RELEASE.json` and runs the release
checks in the exported tree.

## Certification meaning

The GitHub release commit freezes content and source binding. It does not itself
certify the cryptographic module. A certification claim must additionally bind
the evaluated artifact, toolchain, target, configuration, security policy and
independent evaluation evidence described in
`security-certification-boundaries.md`.
